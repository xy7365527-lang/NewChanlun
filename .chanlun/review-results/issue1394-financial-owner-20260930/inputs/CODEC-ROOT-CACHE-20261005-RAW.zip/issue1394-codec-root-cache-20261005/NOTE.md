# #1394 纯codec成功根证书 staged 原型

范围只含四份Rust文件的staged镜像与一个补丁，当前真实源码字节仍与base一致。源码基线来自a4699cf603；主控后续7a7492bd86只有文档变化。未执行git、cargo、测试、服务、SQLite或任何故障操作。rustfmt只解析/格式化本目录staged文件，exit=0；这不建立类型检查或测试通过。

外层Verifier::verify_refview逐字保持不变。它仍解析当前format/digest、真实读取当前root并核kind/extent，之后调用run。AuditCapture只有该调用完整Ok后才记录返回digest。Public和Template分集合；只记录Flavor::Value外层根，不缓存JsonInner、业务资格或用量收据。

封闭seed API只接受两份真实Native capture，自行确认format、私有判据版本与Value上下文，并逐一确认旧capture全部digest/tag/body确实相同包含于新capture。它不接same=true令牌。相容性/材料不足返回0并走原路径；没有宽判据降级。资格成立只向新的AuditMemo.seen播种旧成功根；pushed/todo/bytes/elem/field/keycmp/read_digests全部冷，不复制Frame、owner、ordinal、旧收据或旧成功根集合。新capture仅在自己verify_refview再成功后记录新证书。

state的source_same只减少无谓尝试，封闭API仍核全材料；同handler旧capture因合法增长更换为fresh capture时使用同一API，完整history结果仍重新审计。跨请求整份AuditedState/history/独立索引/catalog没有继承。引用依据是APPROVED-SOURCE.md:65、286，当前工作树原文已读取。

Pool只新增两个成功根集合，封存仍清除全部Public/Template memo和所有Frame，保留原件Vec owner。跨请求封存仍发生于同成功handler，原错误清池及COMMIT后缓存失败不覆盖成功回复的路径保持。过512MiB唯一S7源字节预算仍整池不留。

新增源成本配方是本原型选择，并非SPEC原有配方：8字节format长度前缀+CONTENT_FORMAT字节、4字节判据版本、两个集合各1字节Mode+1字节Flavor+8字节长度前缀、每个root32字节digest。总增量=43+32*(Public根数+Template根数)，checked_add/mul。实际HashSet capacity*32单独加入capacity payload；inline证书owner已计入Capture/Pool size_of，不重复加。HashMap/HashSet控制字节、allocator开销、瞬时Verifier/overlay与整heap/RSS/IO峰值仍未覆盖，S7没有改成heap限额。

同材料成功测试预计warm只读两个当前根、严格F=2；具体实际下降数由测试的nocapture输出记录，当前未运行，不能写PASS或数字实测。合法追加测试用正常writer产生独立新增节点及两个新根，与冷核验结果和公开渲染逐项比较；Mode/JsonInner正常夹具守住上下文边界。handler合法增长比较完整raw/cuts/objects/auxiliary结果及capture读取数。现有driver两个正常append/repost/restart与测得预算测试可直接复用。

应用/独评后建议运行的精确正常入口，均在rust目录执行，禁止扩大成旧混合负例测试模块：

```sh
cargo test --offline --release --features s_capture_native_testonly --lib s_content::codec_root_success_tests:: -- --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::cross_request_source_cache::tests::codec_root_success_handler_legal_growth_matches_complete_cold -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::driver::tests::source_keeper_driver_append_repost_restart_preserves_results_and_request_reuse -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::driver::tests::source_keeper_driver_measured_cap_only_changes_retention -- --exact --nocapture
```

最终补丁SHA及逐文件base/staged SHA在RESULT.json。需要主控独立复核、应用、构建及上述正常验证，尚无运行验收结论。
