# #1394 冷启动 166：只读代码路径调查

2026-10-05。只读源码，未打开 DB、运行 Cargo/SQL/服务/测试或故障注入；仅本文件写入。调查基线：共享 worktree HEAD `9ec149e0f43ad21eb5ff8ca13699b91fa4494cfa`；相对 `a81aec3b11` 下列入口文件无 diff。读取的 driver/state/request_audit/cross_request_source_cache/writer_cli/s_allocation/history/source_audit、v2/content_store、s_content、session_transport 共 11 份源码 SHA256 均匹配 `.scratch/issue1394-counts-subset-codec-20261005/SOURCE-r3.json`。冻结 service SHA 与该源码绑定由主控已有 RUN-RESULT 证明承担，本调查不重新认定二进制。以下行号均相对 `rust/src/`。

## 顺序和次数

前提为显式 CapturedNative、idle、无 AcceptedPending、审计成功且原件无变化。166 是域前缀，不是由代码调查测得的实际耗时。

| 顺序 | 入口和行号 | capture / history / Counts |
|---|---|---|
| 1 | `bin/s_session_v3/writer_cli.rs:485` → `Driver::open_for_serve_with_identity` (`driver.rs:154`) 新建 bootstrap context (`:166`) → `open_with_request_and_mode_context` (`:285`) | 首次事务 `:308`，`state::audit_native_in_request` `:314`；cold 新建完整 capture，无 Keeper/Counts 旧池，运行完整 fresh core。 |
| 2 | `driver.rs:356` → `resume_pending` `:563` | 无 pending 不加审计。若有 pending，先丢 bootstrap slot (`:581`)，独立恢复 context `:583` → Advance/Prepare；不能沿用下述 3 次计数。 |
| 3 | `driver.rs:177` → `identity_in_bootstrap` `:182`，第二事务 `:190`、同 context 审计 `:191` | 再完整扫描当前节点、读取 control/raw、精确 binding；不变时复用同 capture 和 Rc history，经 `history::revalidate_current_for_reuse`，不重跑 fresh history/来源逐代循环 (`state.rs:181–244`)。 |
| 4 | `driver.rs:178` drop bootstrap context，然后返回、监听 (`writer_cli.rs:518`) | capture、完整历史/索引和 memo 释放；Driver 初始 `source_keeper=None` (`driver.rs:349`)，bootstrap 不建立 Counts 池。 |
| 5 | Ready：`Driver::handle` `driver.rs:360` → `handle_with_request_audit` `:377` | 新 context，无历史 slot；从 Driver take 旧 Keeper (`:382`)，冷启动为 None；预算冻结 `:390`，cap>8 可新建空 Keeper (`:394–399`)；随后输出 request-budget-entry (`:405–409`)。 |
| 6 | `handle_in_request` `driver.rs:424`，事务 `:433`，审计 `:434` → `s_allocation::audit_in_request` `s_allocation.rs:69/115` | Ready 自己再新建完整 capture，cold fresh history/索引/catalog；若 Keeper 启用，新 Trial 无 prior，所有 cut 的 Counts lookup miss，逐代来源核验并 record；最终 seal SQL binding。 |
| 7 | epoch/identity `driver.rs:440–446` → Ready `:450` | `v2::ready_for_protocol` (`bin/s_session_v2/mod.rs:1743`) 读取就绪头，不另跑完整审计；Ready 事务在函数退出时释放。 |
| 8 | 成功结果 → `request_audit.finish_source_keeper` `driver.rs:419` → `request_audit.rs:137` | drop 完整 history/binding (`:151–152`)，消费本次 capture/PendingPool，构建稀疏 Counts 池；同步完成后 `handle` 才返回，pager handle 日志才可能输出 (`driver.rs:368–374`)。 |
| 9 | `writer_cli.rs:525` 的 handle 返回后 `reply`，actor `session_transport.rs:640–641` 才 try_send | I/O 线程在 `session_transport.rs:546–556` 用入队时 response deadline 等待；超期关闭连接不能撤销 actor 工作。 |

因此该无 pending、不变成功路径是 **3 次当前审计入口，2 次 fresh core + 1 次精确重绑定复用**；完整节点扫描 3 次，capture 构建 2 次，history/独立索引 fresh 构建 2 次。若恰有 166 个 cut，bootstrap cold 与 Ready cold 各进入 166 次来源循环；这是条件性代码工作量，不是实测计数。Ready 不与 bootstrap 共用 capture/history/Counts。审计失败或 binding 不同不保证此计数。

## Ready fresh 审计与可丢弃 collector 的边界

`state::audit_native_in_request` (`state.rs:144`) 顺序：take slot/旧池 `:151–153` → 完整捕获 `:154–179` → control/raw `:214–215` → cold Trial `:249–257` → `audit_core_fresh_inner` `:258` → 完整历史依赖 binding `:274` → Trial seal `:279–281` → retain slot `:283`。Ready 的首个 context 无 slot，无法走同请求 history hit。新 capture 会完整读 SQL 原件 (`bin/s_session_v2/content_store.rs:2166–2207`)，旧池存在时只借它做 tuple 比较/codec 根播种，不复用完整 history。

fresh core (`state.rs:575`) 依次建 NativeRecordFields `:675`、加载 history/aux/object 索引 `:690`（`history.rs:368/375`）、核 public/template 根 `history.rs:403/417`、核 catalog 元数据 `state.rs:703`，新建 NativeSourceAudit `:719–730`；每 cut Counts lookup/source audit `:743–767`、record `:771`、变化集合 `:774`、catalog cut `:791`，最后核 current catalog `:811`。单次 cold 的 source memo 在 cut 之间复用，退出时 drop (`:830`)，不等于跨请求缓存完整审计。

**存在响应前的纯缓存构建段**：`finish_source_keeper` → `Keeper::retain_completed` (`cross_request_source_cache.rs:450/459`) → `Pool::build_bounded_counts` (`:172`) → `AuditCapture::into_counts_original_subset_for_testonly` (`s_content.rs:2254`)。它不读 SQL、不重做业务审计，但清掉旧 memo/codec 根 (`:2273`)，新建 ledger/reader/Verifier (`:2274–2284`)，按新到旧导航 objects/witnesses/observations (`:2291–2310`)，每组核三个完整根 (`:2312–2314`)，**核验完成后**才算费用并比较 cap (`:2344–2354`)；首个超额组回滚并停止，仍已付出该整组核验 CPU 成本。之后全 capture drain/裁剪 (`:2380–2388`)、Pool 成本/容量计算 (`cross_request_source_cache.rs:220–346`)。Collector 失败只丢缓存，不能覆写成功回复 (`:450–469`)，但该性质不保证它及时返回。

Ready 审计传 deadline=None (`state.rs:258–268`)，此服务用 `serve_unix` 而非把 I/O deadline 传入 handler 的另一个入口 (`writer_cli.rs:518`；`session_transport.rs:582–602`)。所以缓存构建可能消耗 30 秒窗口的一部分乃至全部；没有分段时间/采样不能认定发生了这种情况，亦不能把 bootstrap 的启动时间直接计入已经入队的 Ready 窗口。

## 三个可由 CPU 采样区分的候选热点

1. **Ready fresh capture/history**：堆栈含 `audit_native_in_request → capture_with_original_subset_for_source_cache`、SQLite row/body Vec/MemoryNodes/Native 转换，或 `audit_core_fresh_inner → read_indexed_history_inner → verify_many_ref`；对应响应前的当前原件/闭包/索引工作，不是 finish collector。
2. **逐代来源及目录**：堆栈含 `audit_core_fresh_inner → NativeSourceAudit::audit → audit_generated_in_store` / RawLedger、字段/身份 memo 或 `catalog_evidence::verify_cut_for_audit`，对应 fresh 核的 cut 循环；冷 Ready 不能从空旧 Counts 池命中。
3. **成功结果后的稀疏池 collector**：上游含 `handle_with_request_audit → finish_source_keeper → retain_completed → build_bounded_counts → into_counts_original_subset_for_testonly → NativeCountsSubsetReader / Verifier::verify_refview`，或该入口下的 drain/drop/费用计数；能与前两者共享底层 codec 函数，应按调用祖先区分。此时业务 Ready 可已构造，但 handle-after 和传输回包尚未发生。

已知日志只有 startup-before-first-transaction 和 launcher-ready-1 request-budget-entry、没有 handle-after，只能定位到 Ready context 已建且整个 handle 尚无完成证据；不能区分上述三段，也不能证明 fresh audit 已完成。167 未发送维持不变。本文是定位记录，**不是通过结论**；不建议跳过 Ready 必需的当前审计、提高 30 秒、恢复 birth-only/candidate/wire 或注入故障。

## 待采样的最小候选：bootstrap 自有 Keeper 移交同 Driver

**只读判断：现有接口的所有权/资格链允许这个候选，不等于已验证修复。** 在同一个 Native 服务 bootstrap context 挂空 Keeper，使第一次完整 cold audit 走现有 Trial/record/seal；最终 identity 成功后消费 `finish_source_keeper`，把产出的可选稀疏池放入该 Driver 的 `source_keeper`。完整 history、事务、memo不跨到 Ready；Ready 仍按现有 `capture_with_original_subset_for_source_cache` 完整扫描，并经 `Trial::new` 的精确 SQL Binding 自行决定 Counts 命中（`state.rs:154–176/249–281`；`cross_request_source_cache.rs:498–538`）。它减少的是 Ready 可绑定旧 cut 的来源业务核/有限 codec 工作；Ready 的 capture、control/raw、fresh history/索引/catalog仍执行。

当前缺口及变更点：

- `open_for_serve_with_identity` 现在只建默认 context (`driver.rs:166`)，无 Keeper、无冻结 workspace。需在首次事务前冻结 S7，按 `total-legacy-old_pool`（新bootstrap old_pool=0）核 allowance、`total-legacy`核 Keeper cap；复用 `freeze_manifest_workspace_budget` (`request_audit.rs:87`) 和 `retention_possible`，不得引第二预算或更宽准入。
- context挂 Keeper 后首次完整审计才会产生 PendingPool；现状 bootstrap `source_cache_enabled=false`，所以仅在末尾调用finish不会凭空得到Counts资格 (`state.rs:152/249`)。
- 无 pending 且不变时 identity hit 原样携带首次已seal的 `source_pending` (`state.rs:216–239`)；它仍重新读取当前control/raw、完整节点与历史binding，没有需要放宽的门。
- 末尾现状 `drop(context)` (`driver.rs:178`) 要改为成功 identity 后的 `driver.source_keeper=context.finish_source_keeper()`；复用现有收尾的可丢弃失败语义。收尾仍会运行 collector，其CPU费用从 Ready响应窗口移至监听前；这不保证总冷启动更快，需采样比较实际主耗时与启动等待界限。
- **pending/resume不可把启动前候选直接带过恢复。** `resume_pending` 已先 `drop(context.take())` (`driver.rs:579–581`)，释放初次slot/PendingPool；恢复用独立默认 context (`:583–584`)，其结果不会被移交。在保留现有隔离的候选中，最终 `identity_in_bootstrap` 遇空slot，必须完整fresh审计恢复后的持久状态，并重新seal同次Counts/binding，才能finish；资格来自这次成功审计，绝非恢复前候选或仅“恢复成功”标志。
- 从上述静态链没有发现必须新增宽松判据的原因；但pending恢复后的cache资格、资源峰值及错误出口没有在本调查中动态验证。首个实施/验收若不能覆盖该链，应明确限定**已证idle且无pending恢复的启动**；pending继续现有不移交行为，不把严格路径失败转为新缓存放行。identity/open任何错误维持context/Driver释放，不发布池。

该候选仅改变现有同进程缓存的创建/移交时点；未实现、未测时，也未授予生产/完整资源资格。CPU若显示主耗时在fresh history/catalog而非来源/codec，此候选可能无法解决30秒。
