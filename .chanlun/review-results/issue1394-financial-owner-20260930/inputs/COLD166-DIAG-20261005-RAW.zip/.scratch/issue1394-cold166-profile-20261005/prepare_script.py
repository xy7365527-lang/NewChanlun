import pathlib,hashlib,json,difflib
R=pathlib.Path.cwd();B=R/'.scratch/issue1394-counts-codec-window167-180-20261005';O=R/'.scratch/issue1394-cold166-profile-20261005'
s=(B/'window.py').read_text()
s=s.replace('"""#1394 copied166 independent formal S167..180 window; never original9011 continuation."""','"""#1394 CopyQualified166 startup-only passive CPU sample; zero business requests."""')
s=s.replace('import contextlib, hashlib, importlib, json, os, pathlib, shutil, signal, sqlite3, stat, subprocess, sys, time','import contextlib, hashlib, importlib, json, os, pathlib, shutil, signal, sqlite3, stat, subprocess, sys, time, threading, socket, errno')
s=s.replace("OUT=ROOT/'.scratch/issue1394-counts-codec-window167-180-20261005'","OUT=ROOT/'.scratch/issue1394-cold166-profile-20261005'")
s=s.replace("OWN=pathlib.Path('/Volumes/AgentStorage/issue1394-counts-codec-window167-180-20261005-r1')","OWN=pathlib.Path('/Volumes/AgentStorage/issue1394-cold166-profile-20261005-r1')")
s=s.replace("handles.append((self,row))","handles.append((self,row));startup['on_spawn'](self,row,original)")
s=s.replace("require(sha(OUT/'SOURCE-LIST.json')", "require(sha(OUT/'SAMPLER-BINDING.json')==orchestration['sampler_binding_sha256'],'sampler binding changed')\n require(sha('/usr/bin/sample')==load(OUT/'SAMPLER-BINDING.json')['tool']['sha256'],'sampler changed')\n require(sha(OUT/'SOURCE-LIST.json')",1)
s=s.replace("'scope':'independent CopyQualified166 formal167..180 Counts finite-codec normal window, source166 DeliveryUnknown unchanged; not original9011 continuation'","'scope':'independent CopyQualified166 startup-only passive CPU sample; zero business requests; source166 DeliveryUnknown unchanged'")
s=s.replace("'received_window':[],'errors':[]","'received_window':[],'business_requests_sent':0,'ready_received':False,'startup_only':True,'errors':[]",1)
a=s.index('  original_requests=');b=s.index('  config=load(SOURCE_CASE',a);s=s[:a]+s[b:]
s=s.replace("'/private/tmp/nc1394-cscodec167-180-20261005-r1.sock'","'/private/tmp/nc1394-cold166-1005-r1.sock'")
a=s.index('   for ordinal in range(167,181):');b=s.index(' except BaseException as e:result[',a)
s=s[:a]+"  result['state']='STARTUP_READY_OBSERVED'\n"+s[b:]
s=s.replace("  startup={'active':False,'deadline':None}","  startup={'active':False,'deadline':None,'on_spawn':start_profile}")
s=s.replace("  finally:\n   for k,v in original_env.items():","  finally:\n   monitor_stop.set()\n   if monitor is not None:monitor.join(timeout=2)\n   finish_sampler(sampler_info)\n   result['OS_sampler']=sampler_info\n   try:guarded_socket_cleanup(controller,handles,socket_observation,result)\n   except BaseException as e:result['cleanup_errors'].append(error(e))\n   for k,v in original_env.items():",1)
s=s.replace("result['owned_terminal_state']=db.terminal()","result['owned_terminal_state']=db.terminal();result['terminal166_unchanged']=result['owned_terminal_state']==expected_terminal;require(result['terminal166_unchanged'],'startup changed terminal166')")
s=s.replace("if result['state']=='WINDOW_RECEIVED'", "if result['state']=='STARTUP_READY_OBSERVED'")
s=s.replace("result['state']='COMPLETE'", "result['state']='STARTUP_READY_DIAGNOSTIC_ONLY'")
s=s.replace("elif result['state']=='WINDOW_RECEIVED'", "elif result['state']=='STARTUP_READY_OBSERVED'")
s=s.replace("result['whole_Job_or_max_store_qualified']=False;result['strict_peaks']='UNMEASURED';save(OUT/'RESULT.json',result)","result['whole_Job_or_max_store_qualified']=False;result['strict_peaks']='UNMEASURED';result['business_acceptance_complete']=False;result['retries']=False;result['owner_sealed_no_more_SQL_open']=True;save(OUT/'OWNED-DB-FILES-AFTER.json',result.get('owned_after',{}));save(OUT/'RESULT.json',result)")
s=s.replace(" controller=None;handles=[];db=None;original_env=",''' sampler_info={'status':'NOT_STARTED','errors':[],'duration_seconds':25,'sampling_interval_ms':10,'start_delay_seconds':2,'diagnostic_only':True,'exact_duration_attribution':False}
 socket_observation={};monitor_stop=threading.Event();monitor=None
 def start_profile(target,row,popen):
  nonlocal monitor
  def watch():
   try:
    due=time.monotonic()+2
    while not monitor_stop.is_set():
     p=pathlib.Path('/private/tmp/nc1394-cold166-1005-r1.sock')
     if os.path.lexists(p):
      got=socket_identity(p)
      if not socket_observation:socket_observation.update(got)
      else:require(socket_observation==got,'new socket identity changed during startup')
     if time.monotonic()>=due:break
     monitor_stop.wait(.02)
    if monitor_stop.is_set():sampler_info['status']='START_NOT_REACHED';return
    require(target.poll()is None and target.pid==row['pid'],'not same live serve Popen')
    observed=subprocess.run(['/bin/ps','-o','pid=,command=','-p',str(target.pid)],capture_output=True,text=True,timeout=1)
    require(observed.returncode==0 and observed.stdout.strip().startswith(str(target.pid)+' ')and str(binary)in observed.stdout,'sample PID/path mismatch')
    cmd=['/usr/bin/sample',str(target.pid),'25','10','-mayDie','-file',str(OUT/'startup166.sample.txt')]
    with(OUT/'sample-stdout.txt').open('xb')as so,(OUT/'sample-stderr.txt').open('xb')as se:
     begin=time.monotonic_ns();sp=popen(cmd,stdout=so,stderr=se)
    sampler_info.update(status='STARTED',process=sp,target_pid=target.pid,sample_pid=sp.pid,command=cmd,command_identity=observed.stdout.strip(),begin_ns=begin,relative_to_serve_seconds=(begin-row['begin_ns'])/1e9)
   except BaseException as e:sampler_info['status']='SAMPLER_FAILURE_PRESERVED';sampler_info['errors'].append(error(e))
  monitor=threading.Thread(target=watch,name='owned-startup-passive-sampler',daemon=True);monitor.start()
 controller=None;handles=[];db=None;original_env=''')
extra='''
def socket_identity(p):
 st=pathlib.Path(p).lstat();require(stat.S_ISSOCK(st.st_mode),'new domain path not socket')
 return dict(path=str(p),device=st.st_dev,inode=st.st_ino,uid=st.st_uid,mode=oct(stat.S_IMODE(st.st_mode)))
def guarded_socket_cleanup(controller,handles,observed,result):
 p=pathlib.Path('/private/tmp/nc1394-cold166-1005-r1.sock')
 row={'socket_exclusive_new_path_absent_before_start':True,'new_service_or_request_started':False,'SQLite_opened':False}
 if not os.path.lexists(p):row.update(state='SOCKET_ABSENT_AFTER_CLEANUP');result['guarded_socket_cleanup']=row;save(OUT/'POST-FAILURE-SOCKET-CLEANUP.json',row);return
 require(len(handles)==1 and handles[0][1].get('reaped_by_same_Popen')is True and handles[0][0].poll()is not None,'same Popen not reaped')
 require(bool(observed)and socket_identity(p)==observed and observed['uid']==os.getuid(),'owned socket identity not stable')
 with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)as c:
  c.settimeout(.5)
  try:c.connect(str(p))
  except OSError as e:require(e.errno==errno.ECONNREFUSED,'socket not confirmed refused');row['connection_errno']=e.errno
  else:raise RuntimeError('socket has listener')
 require(socket_identity(p)==observed,'socket changed before unlink');p.unlink()
 row.update(state='SOCKET_CLEANUP_COMPLETE',stopped_same_Popen_pid=handles[0][0].pid,removed_socket_identity=observed,identity_rechecked_before_unlink=True)
 result['guarded_socket_cleanup']=row;save(OUT/'POST-FAILURE-SOCKET-CLEANUP.json',row)
def finish_sampler(info):
 proc=info.pop('process',None)
 if proc is None:return
 try:
  if proc.poll()is None:
   try:proc.wait(timeout=2)
   except subprocess.TimeoutExpired:
    proc.terminate()
    try:proc.wait(timeout=2)
    except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=2)
  info.update(exit_code=proc.wait(timeout=0),reaped_by_same_Popen=True,end_ns=time.monotonic_ns())
 except BaseException as e:info.setdefault('errors',[]).append(error(e));info['reaped_by_same_Popen']=False
 info['report_available']=info.get('exit_code')==0 and(OUT/'startup166.sample.txt').is_file()
'''
s=s.replace('\ndef main():',extra+'\ndef main():')
# Keep Popen object out of JSON; sampling thread writes only the in-memory sampler until finally.
compile(s,str(O/'window.py'),'exec');(O/'window.py').write_text(s)
(O/'SCRIPT-DIFF.patch').write_text(''.join(difflib.unified_diff((B/'window.py').read_text().splitlines(True),s.splitlines(True),fromfile=str(B/'window.py'),tofile=str(O/'window.py'))))
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
a=dict(path=str(O/'window.py'),sha256=sha(O/'window.py'),python_binding_sha256=sha(O/'PYTHON-BINDING.json'),source_list_sha256=sha(O/'SOURCE-LIST.json'),controller_proposed_sha256=sha(O/'Controller.proposed.json'),sampler_binding_sha256=sha(O/'SAMPLER-BINDING.json'),script_diff_sha256=sha(O/'SCRIPT-DIFF.patch'),baseline_script=dict(path=str(B/'window.py'),sha256=sha(B/'window.py')),scope='startup-only zero business requests no retries')
(O/'ORCHESTRATOR-BINDING.json').write_text(json.dumps(a,indent=2)+'\n')
print('Bound new startup-only script',a['sha256'])
