import pathlib,json,hashlib,sys,importlib.util,os,subprocess,re
sys.dont_write_bytecode=True
R=pathlib.Path.cwd();O=R/'.scratch/issue1394-cold166-profile-20261005';B=R/'.scratch/issue1394-counts-codec-window167-180-20261005'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
a=json.loads((O/'ORCHESTRATOR-BINDING.json').read_text());assert sha(O/'window.py')==a['sha256']
spec=importlib.util.spec_from_file_location('w',O/'window.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
r=w.load(O/'RESULT.json');assert r['state']=='FAILURE_PRESERVED' and r['errors'][0]['type']=='TimeoutError'
assert r['ready_received']is False and r['business_requests_sent']==0 and not r['received_window'] and 'last_attempted_ordinal'not in r
assert r['owned_terminal_state']==r['copy_qualified_start']==w.load(O/'SOURCE-LIST.json')['expected_terminal166']
assert r['terminal166_unchanged']and r['original_full_stat_and_SHA_unchanged']and r['all_processes_reaped']and r['controller_closed']and not r['cleanup_errors']
assert r['full9011_complete']is False and r['business_acceptance_complete']is False and r['retries']is False and r['owner_sealed_no_more_SQL_open']
assert {n:w.identity(w.SOURCE_CASE/n)for n in w.FILES}==r['original_before']==r['original_after']
assert {n:w.identity(w.OWN/n)for n in w.FILES if(w.OWN/n).exists()}==r['owned_after']==w.load(O/'OWNED-DB-FILES-AFTER.json')
assert sha(B/'RESULT.json')==w.load(B/'POST-FAILURE-SOCKET-CLEANUP.json')['original_RESULT_sha256']
assert not os.path.lexists('/private/tmp/nc1394-cold166-1005-r1.sock')
sam=r['OS_sampler'];assert sam['exit_code']==0 and sam['reaped_by_same_Popen']and sam['report_available']and not sam['errors']
assert sam['target_pid']==r['lifecycle'][0]['pid'];assert r['lifecycle'][0]['reaped_by_same_Popen']
for p in (r['lifecycle'][0]['pid'],sam['sample_pid']):
 q=subprocess.run(['/bin/ps','-p',str(p),'-o','pid='],capture_output=True,text=True);assert q.returncode!=0 and not q.stdout.strip()
wire=[];nonempty_requests=0;complete_replies=0
for p in sorted((O/'execution').glob('*.wire.json')):
 v=w.load(p);wire.append(v)
for p in sorted((O/'execution').glob('*.request.wire')):
 raw=p.read_bytes()
 if raw:
  v=json.loads(raw);assert v['payload']['op']=='ready' and v['message_id']=='launcher-ready-1';nonempty_requests+=1
for p in sorted((O/'execution').glob('*.reply.wire')):
 raw=p.read_bytes()
 if raw:complete_replies+=1
assert complete_replies==0
sample_lines=(O/'startup166.sample.txt').read_text().splitlines()
evidence_lines=[1,12,13,24,32,33,35,36,37,3929,3930,3931,3932,3933,3934,3935,3936,7524,7525,7526,7527,7528,7529,7530,7531,7532,7533,7535]
evidence=[dict(line=n,text=sample_lines[n-1])for n in evidence_lines]
w.save(O/'HOTSPOT-EVIDENCE.json',dict(report=str(O/'startup166.sample.txt'),report_sha256=sha(O/'startup166.sample.txt'),lines=evidence,interpretation='1172 main-thread samples under writer_cli::run startup open branch, 942 under serving branch; serving branch 940 under Driver::handle->audit_in_request. Counts are stack observations, not exact durations; inclusive ancestors and offsets must not be double counted; release optimized/inlined frames and 10ms sampling make causal attribution incomplete.'))
root=dict(ticket='#1394',state='STARTUP_TIMEOUT_WITH_PASSIVE_SAMPLE_PRESERVED',scope='new independent CopyQualified166 startup-only; zero business requests; no retry',original_first_error=r['errors'][0],ready_received=False,ready_complete_reply_count=complete_replies,business_requests_sent=0,controller_ready_wire_observations=len(wire),controller_ready_nonempty_wire_requests=nonempty_requests,terminal166=r['owned_terminal_state'],terminal166_unchanged=True,source166_DeliveryUnknown_preserved=True,source_received_prefix=165,source_persistent_generation=166,next_attempt_ordinal=167,old_window_failure_unchanged=True,startup_call_seconds=(r['startup_call_end_ns']-r['startup_call_begin_ns'])/1e9,stop_requested_after_startup_end_ms=(r['service_stop_begin_ns']-r['startup_call_end_ns'])/1e6,service=r['lifecycle'][0],sampler=sam,sample_coverage=dict(command_start_relative_serve_seconds=sam['relative_to_serve_seconds'],requested_duration_seconds=25,requested_end_relative_serve_seconds=sam['relative_to_serve_seconds']+25,observed_sampler_exit_relative_serve_seconds=(sam['observed_exit_ns']-r['lifecycle'][0]['begin_ns'])/1e9,interval_ms=10,not_precise_phase_duration=True),hotspot_observation='startup Driver::open_for_serve_with_identity and Ready Driver::handle both reach audit_native_in_request/audit_core_fresh_inner; indexed-history read, field-path navigation, checked reads, SHA256/SipHash, allocation and SQLite seen. This identifies candidate costs, not proof of a precise bottleneck or optimized fix.',hotspot_evidence=str(O/'HOTSPOT-EVIDENCE.json'),cleanup=r['guarded_socket_cleanup'],cleanup_errors=[],controller_stop=r['controller_stop'],source_full_stat_and_SHA_unchanged=True,owner_seal=str(O/'OWNED-DB-FILES-AFTER.json'),owner_seal_live_identity_verified=True,all_processes_reaped_same_Popen_and_current_PID_absent=True,source_SQLite_opened=False,owner_SQLite_reopened_after_seal=False,business_acceptance_complete=False,full9011_complete=False,whole_Job_or_max_store_qualified=False,strict_peaks='UNMEASURED',staging_enabled=False,no_fault_injection=True,artifacts={n:dict(path=str(O/n),sha256=sha(O/n))for n in ['RESULT.json','ORCHESTRATOR-BINDING.json','PYTHON-BINDING.json','SOURCE-LIST.json','INPUT-COMPATIBILITY.json','BINARY-BINDING-service.json','SAMPLER-BINDING.json','OWNED-DB-FILES-AFTER.json','POST-FAILURE-SOCKET-CLEANUP.json','startup166.sample.txt','HOTSPOT-EVIDENCE.json']})
w.save(O/'ROOT-RESULT.json',root)
print(json.dumps({k:root[k]for k in ['state','ready_received','business_requests_sent','controller_ready_wire_observations','controller_ready_nonempty_wire_requests','terminal166_unchanged','startup_call_seconds','stop_requested_after_startup_end_ms','sample_coverage','source_full_stat_and_SHA_unchanged','all_processes_reaped_same_Popen_and_current_PID_absent']},indent=2))
