"""#1394 CopyQualified166 startup-only passive CPU sample; zero business requests."""
import contextlib, hashlib, importlib, json, os, pathlib, shutil, signal, sqlite3, stat, subprocess, sys, time, threading, socket, errno
sys.dont_write_bytecode=True
ROOT=pathlib.Path.cwd();OUT=ROOT/'.scratch/issue1394-cold166-profile-20261005'
OLD=pathlib.Path('/Users/silencehan/.codex/worktrees/issue1394-history-sweep/NewChanlun/.scratch/formal-s-request-audit-20261003')
RUNNER=OLD/'runner';INPUTS=ROOT/'.scratch/issue1394-full9011-source-cache-20261005-r2/inputs/inputs'
SOURCE_ROOT=ROOT/'.scratch/issue1394-full9011-source-cache-20261005-r2/ROOT-RESULT.json'
SOURCE_RUN=pathlib.Path('/Volumes/AgentStorage/issue1394-full9011-source-cache-20261005-02');SOURCE_CASE=SOURCE_RUN/'A'
OWN=pathlib.Path('/Volumes/AgentStorage/issue1394-cold166-profile-20261005-r1')
FILES=('s.sqlite','s.sqlite-wal','s.sqlite-shm')
def load(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def require(v,m):
 if not v:raise RuntimeError(m)
def save(p,v):pathlib.Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def identity(p):
 p=pathlib.Path(p);s=p.lstat();require(stat.S_ISREG(s.st_mode),'nonregular file');h=sha(p);a=p.lstat();require(all(getattr(s,k)==getattr(a,k) for k in ('st_dev','st_ino','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_mode','st_blocks','st_nlink')),'file changed while hashing')
 return dict(path=str(p),sha256=h,stat={k:getattr(a,k)for k in ('st_dev','st_ino','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_mode','st_blocks','st_nlink')})
def error(e):return {'type':type(e).__name__,'message':str(e)}
@contextlib.contextmanager
def alarm(seconds):
 prev=signal.getsignal(signal.SIGALRM);signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('private bounded operation expired')));signal.setitimer(signal.ITIMER_REAL,seconds)
 try:yield
 finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,prev)
class CopiedOwned:
 """CopyQualified, never InitObserved; persistent extractor reused without fresh-init adoption."""
 def __init__(self,path,runtime):self.path=path;self.runtime=runtime;self.inode=path.lstat().st_ino;self.query=runtime.OwnedDatabase.query
 @contextlib.contextmanager
 def read(self):
  require(self.path.is_file()and not self.path.is_symlink()and self.path.lstat().st_ino==self.inode,'own DB identity changed')
  with contextlib.closing(sqlite3.connect(self.path.as_uri()+'?mode=ro',uri=True,timeout=2))as c:
   end=time.monotonic()+5;c.set_progress_handler(lambda:int(time.monotonic()>=end),1000);c.execute('PRAGMA query_only=ON');c.execute('BEGIN');yield c
 def persistent(self,envelope,ordinal):return self.runtime.OwnedDatabase.persistent(self,envelope,ordinal)
 def terminal(self):
  with self.read()as c:return {'generation':c.execute("SELECT value FROM meta WHERE key='generation'").fetchone()[0],'advance_state':c.execute("SELECT value FROM meta WHERE key='advance_state'").fetchone()[0],'messages_by_status':dict(c.execute('SELECT status,count(*) FROM s_input_messages GROUP BY status')),'published':c.execute('SELECT count(*) FROM s_content_publications').fetchone()[0],'clocks':c.execute('SELECT count(*) FROM s_clock_events').fetchone()[0],'next_attempt_ordinal':c.execute('SELECT next_attempt_ordinal FROM s_protocol_meta').fetchone()[0]}
@contextlib.contextmanager
def observe(binary,handles,startup):
 original=subprocess.Popen
 class Observed(original):
  def __init__(self,command,*args,**kwargs):
   tracked=isinstance(command,(list,tuple))and str(command[0])==str(binary)
   if tracked:require(command[1]=='serve','copied domain must not init/recover')
   super().__init__(command,*args,**kwargs)
   self.window_tracked=tracked
   if tracked:
    row={'pid':self.pid,'argv':list(command),'begin_ns':time.monotonic_ns(),'environment':{k:kwargs.get('env',{}).get(k)for k in ('S_CAPTURE_NATIVE_TESTONLY','S_ALLOCATION_JSON_TESTONLY','S_ALLOCATION_SQLITE_TESTONLY','S_ALLOCATION_PROFILE','S_MANIFEST_WORKSPACE_DIAGNOSTICS','S_NATIVE_SQLITE_CACHE_KIB')}};handles.append((self,row));startup['on_spawn'](self,row,original)
  def wait(self,timeout=None):
   if self.window_tracked and startup['active']:
    remaining=startup['deadline']-time.monotonic()
    if remaining<=0:raise subprocess.TimeoutExpired(self.args,0)
    timeout=remaining if timeout is None else min(timeout,remaining)
   return super().wait(timeout=timeout)
 subprocess.Popen=Observed
 try:yield
 finally:subprocess.Popen=original

def cleanup(controller,handles,result):
 begin=time.monotonic();end=begin+30;errors=[];result['service_stop_begin_ns']=time.monotonic_ns()
 try:
  # Main process first; never let evidence collection postpone cleanup.
  if controller is not None:
   try:
    with alarm(25):result['controller_stop']=controller.stop('s',signal.SIGTERM)
   except BaseException as e:errors.append(error(e))
 finally:
  for proc,row in handles:
   try:
    if proc.poll()is None:proc.terminate()
    try:code=proc.wait(timeout=max(.001,min(2,end-time.monotonic())))
    except subprocess.TimeoutExpired:
     proc.kill();code=proc.wait(timeout=max(.001,end-time.monotonic()))
    row.update(exit_code=code,reaped_by_same_Popen=True,reaped_ns=time.monotonic_ns())
   except BaseException as e:row.update(reaped_by_same_Popen=False,reap_error=error(e));errors.append(error(e))
  if controller is not None:
   try:
    if handles and all(r.get('reaped_by_same_Popen')for _,r in handles)and result.get('ready_received'):
     with alarm(max(.001,end-time.monotonic())):
      result['socket_cleanup']=controller.prepare_socket(end)
     require(not os.path.lexists(controller.config['socket']),'owned socket still exists')
   except BaseException as e:errors.append(error(e))
   finally:
    try:controller.close();result['controller_closed']=True
    except BaseException as e:errors.append(error(e))
 result['lifecycle']=[r for _,r in handles];result['cleanup_errors']=errors;result['cleanup_seconds']=time.monotonic()-begin

def socket_identity(p):
 st=pathlib.Path(p).lstat();require(stat.S_ISSOCK(st.st_mode),'new domain path not socket')
 return dict(path=str(p),device=st.st_dev,inode=st.st_ino,uid=st.st_uid,mode=oct(stat.S_IMODE(st.st_mode)))
def guarded_socket_cleanup(controller,handles,observed,result):
 p=pathlib.Path('/private/tmp/nc1394-cold166-1005-r1.sock')
 row={'socket_exclusive_new_path_absent_before_start':True,'new_service_or_request_started':False,'SQLite_opened':False}
 if not os.path.lexists(p):row.update(state='SOCKET_ABSENT_AFTER_CLEANUP');result['guarded_socket_cleanup']=row;save(OUT/'POST-FAILURE-SOCKET-CLEANUP.json',row);return
 require(len(handles)==1 and handles[0][1].get('reaped_by_same_Popen')is True and handles[0][0].poll()is not None,'same Popen not reaped')
 require(bool(observed)and socket_identity(p)==observed and observed['uid']==os.getuid(),'owned socket identity not stable')
 with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)as c:
  c.settimeout(.5)
  try:c.connect(str(p))
  except OSError as e:require(e.errno==errno.ECONNREFUSED,'socket not confirmed refused');row['connection_errno']=e.errno
  else:raise RuntimeError('socket has listener')
 require(socket_identity(p)==observed,'socket changed before unlink');p.unlink()
 row.update(state='SOCKET_CLEANUP_COMPLETE',stopped_same_Popen_pid=handles[0][0].pid,removed_socket_identity=observed,identity_rechecked_before_unlink=True)
 result['guarded_socket_cleanup']=row;save(OUT/'POST-FAILURE-SOCKET-CLEANUP.json',row)
def finish_sampler(info):
 proc=info.pop('process',None)
 if proc is None:return
 try:
  if proc.poll()is None:
   try:proc.wait(timeout=2)
   except subprocess.TimeoutExpired:
    proc.terminate()
    try:proc.wait(timeout=2)
    except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=2)
  info.update(exit_code=proc.wait(timeout=0),reaped_by_same_Popen=True,end_ns=time.monotonic_ns())
 except BaseException as e:info.setdefault('errors',[]).append(error(e));info['reaped_by_same_Popen']=False
 info['report_available']=info.get('exit_code')==0 and(OUT/'startup166.sample.txt').is_file()

def main():
 require(not(OUT/'RESULT.json').exists()and not OWN.exists(),'result/domain already exists; no retry')
 orchestration=load(OUT/'ORCHESTRATOR-BINDING.json');require(sha(__file__)==orchestration['sha256'],'window script changed');require(sha(OUT/'PYTHON-BINDING.json')==orchestration['python_binding_sha256'],'Python binding changed')
 require(sha(OUT/'SAMPLER-BINDING.json')==orchestration['sampler_binding_sha256'],'sampler binding changed')
 require(sha('/usr/bin/sample')==load(OUT/'SAMPLER-BINDING.json')['tool']['sha256'],'sampler changed')
 require(sha(OUT/'SOURCE-LIST.json')==orchestration['source_list_sha256']and sha(OUT/'Controller.proposed.json')==orchestration['controller_proposed_sha256'],'source/config preparation changed')
 deps=load(OUT/'PYTHON-BINDING.json')
 for r in deps['files']:require(sha(r['path'])==r['sha256'],'Python/material dependency changed: '+r['path'])
 binding=load(OUT/'BINARY-BINDING-service.json');binary=pathlib.Path(binding['binary']['path']);require(binary==ROOT/'.scratch/issue1394-counts-subset-codec-20261005/frozen-service','unexpected service artifact domain');require(binding['compiler_artifact_profile_test']is False and binding['target_kind']==['bin']and binding['target_name']=='s_structure_session','not service artifact');require(sha(binary)==binding['binary']['sha256'],'service binary changed')
 manifest=load(binding['source_manifest'])
 for r in manifest['entries']:require(sha(pathlib.Path(binding['fixed_source'])/r['path'])==r['sha256'],'fixed source changed')
 sys.path.insert(0,str(RUNNER));sys.path.insert(0,str(ROOT/'s_session'))
 runtime=importlib.import_module('runtime');evidence=importlib.import_module('evidence');control=importlib.import_module('s_service_control');client=importlib.import_module('s_socket_client')
 source_list=load(OUT/'SOURCE-LIST.json');previous=load(SOURCE_ROOT);run_result=load(SOURCE_RUN/'RUN-RESULT.json');case_result=load(SOURCE_CASE/'CASE-RESULT.json');lifecycle=load(SOURCE_CASE/'LIFECYCLE.json');reaped=load(SOURCE_CASE/'PROCESSES-REAPED.json')
 require(previous['status']=='NORMAL_FULL9011_A_STOPPED_AT_DELIVERY_TIMEOUT'and previous['continuous_received_and_validated']==165 and previous['first_unexpected_ordinal']==166 and previous['transport']=='DeliveryUnknown'and previous['persistent_status']=='Committed'and previous['persistent_publication_generation']==166 and previous['next_attempt_ordinal']=='167'and previous['B_started']is False and previous['retries']is False and previous['all_original_cleanup_gates_passed'],'source166 evidence boundary changed')
 require(run_result['status']=='FAIL_OR_PARTIAL'and len(run_result['cases'])==1 and run_result['cases'][0]['label']=='A'and run_result['cases'][0]['committed_count']==165 and not SOURCE_RUN.joinpath('B').exists(),'source run changed or B created')
 require(case_result['status']=='PARTIAL'and case_result['committed_count']==165 and all(case_result['cleanup'].values()),'source cleanup gates changed')
 require(len(lifecycle['processes'])==2 and len(reaped)==2 and all(p['same_Popen_reaped']for p in reaped)and lifecycle['processes']==reaped,'source processes not same-Popen reaped')
 require(load(SOURCE_CASE/'STOP-RESULT.json')['state']=='stopped'and load(SOURCE_CASE/'STOPPED-STATUS.json')['state']=='stopped','source stop evidence changed')
 require(load(SOURCE_CASE/'input-166.exchange.json')['result']['transport']=='DeliveryUnknown','source166 unknown delivery overwritten')
 SOURCE=SOURCE_CASE;expected_terminal=source_list['expected_terminal166'];before={n:identity(SOURCE/n)for n in FILES};seal=load(SOURCE_CASE/'OWNED-DB-FILES-AFTER.json');require(seal==source_list['existing_seal_rows'],'existing seal document changed')
 for r in seal:
  actual=before[pathlib.Path(r['path']).name];st=actual['stat'];got={'bytes':st['st_size'],'device':st['st_dev'],'inode':st['st_ino'],'mode':oct(stat.S_IMODE(st['st_mode'])),'mtime_ns':st['st_mtime_ns'],'path':actual['path'],'sha256':actual['sha256'],'uid':st['st_uid']};require(got==r,'source existing seal drift; do not reseal')
 require(before==source_list['observed_extended_identity_after_existing_seal_matched'],'source full stat identity drift since preparation')
 argv=next(p['argv']for p in lifecycle['processes']if p['op']=='serve');require(argv[argv.index('--db')+1]==str(SOURCE/'s.sqlite'),'source not actual source service database')
 OWN.mkdir(mode=0o700);directory=OUT/'execution';directory.mkdir(mode=0o700)
 result={'state':'RUNNING','scope':'independent CopyQualified166 startup-only passive CPU sample; zero business requests; source166 DeliveryUnknown unchanged','source_qualification':'CopyQualified, not InitObserved or Received','source_continuous_received':165,'source_persistent_committed':166,'source166_persistent_without_received_reply':True,'source166_DeliveryUnknown_preserved':True,'full9011_complete':False,'staging_enabled':False,'received_window':[],'business_requests_sent':0,'ready_received':False,'startup_only':True,'errors':[],'original_before':before,'binding':binding};save(OUT/'RESULT.json',result)
 sampler_info={'status':'NOT_STARTED','errors':[],'duration_seconds':25,'sampling_interval_ms':10,'start_delay_seconds':2,'diagnostic_only':True,'exact_duration_attribution':False}
 socket_observation={};monitor_stop=threading.Event();monitor=None
 def start_profile(target,row,popen):
  nonlocal monitor
  def watch():
   try:
    due=time.monotonic()+2
    while not monitor_stop.is_set():
     p=pathlib.Path('/private/tmp/nc1394-cold166-1005-r1.sock')
     if os.path.lexists(p):
      got=socket_identity(p)
      if not socket_observation:socket_observation.update(got)
      else:require(socket_observation==got,'new socket identity changed during startup')
     if time.monotonic()>=due:break
     monitor_stop.wait(.02)
    if monitor_stop.is_set():sampler_info['status']='START_NOT_REACHED';return
    require(target.poll()is None and target.pid==row['pid'],'not same live serve Popen')
    observed=subprocess.run(['/bin/ps','-o','pid=,command=','-p',str(target.pid)],capture_output=True,text=True,timeout=1)
    require(observed.returncode==0 and observed.stdout.strip().startswith(str(target.pid)+' ')and str(binary)in observed.stdout,'sample PID/path mismatch')
    cmd=['/usr/bin/sample',str(target.pid),'25','10','-mayDie','-file',str(OUT/'startup166.sample.txt')]
    with(OUT/'sample-stdout.txt').open('xb')as so,(OUT/'sample-stderr.txt').open('xb')as se:
     begin=time.monotonic_ns();sp=popen(cmd,stdout=so,stderr=se)
    sampler_info.update(status='STARTED',process=sp,target_pid=target.pid,sample_pid=sp.pid,command=cmd,command_identity=observed.stdout.strip(),begin_ns=begin,relative_to_serve_seconds=(begin-row['begin_ns'])/1e9)
    while not monitor_stop.is_set():
     if os.path.lexists(p):
      got=socket_identity(p)
      if not socket_observation:socket_observation.update(got)
      else:require(socket_observation==got,'new socket identity changed during startup')
     if sp.poll()is not None and 'observed_exit_ns'not in sampler_info:sampler_info['observed_exit_ns']=time.monotonic_ns()
     monitor_stop.wait(.02)
   except BaseException as e:sampler_info['status']='SAMPLER_FAILURE_PRESERVED';sampler_info['errors'].append(error(e))
  monitor=threading.Thread(target=watch,name='owned-startup-passive-sampler',daemon=True);monitor.start()
 controller=None;handles=[];db=None;original_env={k:os.environ.get(k)for k in (*runtime.entry.TESTONLY_ENV_KEYS,'S_MANIFEST_WORKSPACE_DIAGNOSTICS','S_NATIVE_SQLITE_CACHE_KIB')}
 try:
  for n in FILES:
   with(SOURCE/n).open('rb')as src,(OWN/n).open('xb')as dst:shutil.copyfileobj(src,dst,1048576);dst.flush();os.fsync(dst.fileno())
   os.chmod(OWN/n,stat.S_IMODE(before[n]['stat']['st_mode']));require(sha(OWN/n)==before[n]['sha256'],'copy mismatch')
  require(before=={n:identity(SOURCE/n)for n in FILES},'original changed copying')
  db=CopiedOwned(OWN/'s.sqlite',runtime);initial=db.terminal();require(initial==expected_terminal,'copy initial166 not exact');result['copy_qualified_start']=initial
  config=load(SOURCE_CASE/'Controller.json');require(config['s_resources']['response_timeout_ms']=='30000'and config['startup_timeout_ms']=='30000'and config['s_resources']['audit_cache_source_bytes']=='536870912','original deadlines/S7 changed')
  config.update(binary=str(binary),db=str(OWN/'s.sqlite'),socket='/private/tmp/nc1394-cold166-1005-r1.sock')
  config['s_resources']=dict(config['s_resources'],audit_cache_source_bytes='536870912')
  require(config==load(OUT/'Controller.proposed.json'),'proposed controller changed')
  require(not os.path.lexists(config['socket']),'new socket exists');save(OUT/'Controller.json',config);parsed=control.read_config(OUT/'Controller.json');controller=control.Controller(parsed,OWN/'controller-state')
  clock=pathlib.Path(config['clock_plan']).read_bytes();request_file=INPUTS/'envelopes.draft.jsonl';requests=request_file.read_bytes().splitlines(keepends=True);require(len(requests)==9011,'original full envelope count changed')
  for k in runtime.entry.TESTONLY_ENV_KEYS:os.environ.pop(k,None)
  os.environ['S_NATIVE_SQLITE_CACHE_KIB']='262144'
  os.environ['S_CAPTURE_NATIVE_TESTONLY']='1'
  os.environ['S_MANIFEST_WORKSPACE_DIAGNOSTICS']='1'
  startup={'active':False,'deadline':None,'on_spawn':start_profile}
  with observe(binary,handles,startup):
   startup.update(active=True,deadline=time.monotonic()+30);result['startup_call_begin_ns']=time.monotonic_ns();result['startup_deadline_monotonic']=startup['deadline']
   try:
    with runtime.Wire(directory,'start-ready'):ready=controller.start_s('1')
   finally:startup['active']=False;result['startup_call_end_ns']=time.monotonic_ns()
   save(directory/'START-RESULT.json',ready);require(ready['state']=='ready'and ready['initialization']is None,'copied domain requires actual Ready, no init');require(len(handles)==1,'not exactly one serve Popen');running=controller.status('s');require(running['state']=='running'and running['pid']==handles[0][0].pid,'Ready PID mismatch');save(directory/'RUNNING-IDENTITY.json',running)
   result['ready_received']=True;save(OUT/'RESULT.json',result)
  result['state']='STARTUP_READY_OBSERVED'
 except BaseException as e:result['state']='FAILURE_PRESERVED';result['errors'].append(error(e))
 finally:
  try:cleanup(controller,handles,result)
  finally:
   monitor_stop.set()
   if monitor is not None:monitor.join(timeout=2)
   finish_sampler(sampler_info)
   result['OS_sampler']=sampler_info
   try:guarded_socket_cleanup(controller,handles,socket_observation,result)
   except BaseException as e:result['cleanup_errors'].append(error(e))
   for k,v in original_env.items():
    if v is None:os.environ.pop(k,None)
    else:os.environ[k]=v
   try:
    if db is not None:result['owned_terminal_state']=db.terminal();result['terminal166_unchanged']=result['owned_terminal_state']==expected_terminal;require(result['terminal166_unchanged'],'startup changed terminal166')
   except BaseException as e:result['errors'].append(error(e))
   try:
    result['owned_after']={n:identity(OWN/n)for n in FILES if(OWN/n).exists()};after={n:identity(SOURCE/n)for n in FILES};result['original_after']=after;result['original_full_stat_and_SHA_unchanged']=after==before;require(after==before,'original changed')
   except BaseException as e:result['errors'].append(error(e))
   result['all_processes_reaped']=bool(handles)and all(r.get('reaped_by_same_Popen')for _,r in handles)and(sampler_info.get('sample_pid')is None or sampler_info.get('reaped_by_same_Popen')is True)
   if result['state']=='STARTUP_READY_OBSERVED'and not result['errors']and not result.get('cleanup_errors')and result['all_processes_reaped']and result.get('original_full_stat_and_SHA_unchanged'):result['state']='STARTUP_READY_DIAGNOSTIC_ONLY'
   elif result['state']=='STARTUP_READY_OBSERVED':result['state']='FAILURE_PRESERVED'
   result['whole_Job_or_max_store_qualified']=False;result['strict_peaks']='UNMEASURED';result['business_acceptance_complete']=False;result['retries']=False;result['owner_sealed_no_more_SQL_open']=True;save(OUT/'OWNED-DB-FILES-AFTER.json',result.get('owned_after',{}));save(OUT/'RESULT.json',result)
if __name__=='__main__':main()
