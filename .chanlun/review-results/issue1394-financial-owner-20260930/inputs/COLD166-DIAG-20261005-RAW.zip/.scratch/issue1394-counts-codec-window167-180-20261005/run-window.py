import pathlib,json,hashlib,subprocess,time,sys
ROOT=pathlib.Path.cwd();OUT=ROOT/'.scratch/issue1394-counts-codec-window167-180-20261005'
def load(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
b=load(OUT/'BINARY-BINDING-service.json');m=load(b['source_manifest'])
def check():
 assert sha(b['binary']['path'])==b['binary']['sha256'];assert all(sha(ROOT/r['path'])==r['sha256']for r in m['entries']);return {'source_aggregate_sha256':m['aggregate_sha256'],'all_643_source_hashes_match':True,'binary_sha256':b['binary']['sha256']}
before=check();t=time.monotonic()
with(OUT/'RUN.stdout').open('xb')as so,(OUT/'RUN.stderr').open('xb')as se:p=subprocess.run([sys.executable,str(OUT/'window.py')],cwd=ROOT,stdout=so,stderr=se)
r={'command':[sys.executable,str(OUT/'window.py')],'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t,'source_binary_before':before,'source_binary_after':check()};(OUT/'RUN-RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print('WINDOW PROCESS COMPLETE '+json.dumps(r),flush=True);sys.exit(p.returncode)
