# #1394 Counts footprint 限定静态独评（R3）

审阅结论：**PASS**。只对正常新自有副本的来源原料测量给出静态结论；不代表编译通过、实际测量完成、资源资格、生产接纳或正式 9011 完成。本评审未执行 Cargo、测试、SQL、服务或故障/坏数据测试，未修改源码。

## 冻结对象

- 基线 HEAD：`a7ff573643914d5017b0207511529337c98a8996`。
- 基线文件 SHA256：`60e575b3be2fcef03b9395f7cdf568543e85229ed947ca5c9353478662b215d4`。
- R3 staged SHA256：`956a8dfb6c4b3229ef555130520425995f2c27007ad6767ef724ddd0548322ab`。
- R3 patch SHA256：`199d01755349bd3485e3083f496dc66a2974a4c2b9324f982a51cf1c63a56c45`。

从上述 HEAD 读取真实基线并逐字核对：staged 保留全部基线前缀，只追加 `counts_footprint_tests`；主控已实装文件与该 staged 字节相同。R1 两项小修（unix cfg、S7 scope 表述）已进入 R3。R2 曾误改既有测试报告字段并使前缀声明失实，已由 R3 恢复基线前缀解决。当前未发现剩余阻断或修正项。

## 概念层质询结果

通过。新增代码测量 codec 原件与来源费用，不新增或改写缠论判据。完整 Native audit 成功是测量前置；新空 Keeper 无旧池、无播种/命中。每 cut 的真实 Key 与成功封存 proof 对拍，proof/cut/cold 数量一致。期望 cut 数和 legacy 数来自根绑定环境且与现场值比较，151/0 的固定输入由根 runner 负责锁定；测试本身没有伪造 Counts。

依赖元数据和完整 proof 接纳数保持 null，类别总闭包没有被说成逐 cut 独立证明。没有把测量值提升为生产预算或资源资格，R3 的 `s7_scope` 只声明测量范围。

## 工程层审查

| 严重级别 | 数量 | 状态 |
|---------|------|------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | pass |
| LOW | 0 | pass |

静态核对要点：

1. `Pool::build` 清除旧 Public/Template/Frame memo，但完整 Native 节点 owner 未被裁剪。CaptureReader 在 read/checked_read 读取完整当前 tag/body；Recorder 在成功读后记 digest。每类别 `audit_verify_many_refview` 创建全新 Verifier/AuditMemo，不消费 capture 的旧闭包 seen 集。类内共享展开不会遗漏该类总闭包，类别之间不共享闭包 memo。
2. 根的 format/digest/kind/extent 每次重新核对。navigation 走 `object_fields_output`，枚举 OBJECT/字段序列/FIELD_PAIR、完整键比较和选中值 header，不调用整张 generated_state 的递归 verify。
3. navigation 与三类别完整闭包取 digest 并集；每个 digest 必须来自完整 capture 原件。正文逐原件 body.len 收费，节点费沿 Pool 的 `97N` 配方。候选费用严格为 `union.source_bytes + exact_rows_bytes + cut_key_counts_certificate_bytes + 8`，仅另列/剔除 codec root 证书。没有按比例估正文，未漏 SQL/Key/Counts/frontier。根 runner `validate_footprint` 的 `8 + sum(五分项)` 与 Pool `try_fold(8, add)` 一致。
4. DB 硬绑定新 owner 的直接子文件；主 DB 和存在的 WAL/SHM 检查 canonical、普通文件、单硬链接。READ_ONLY 加 query_only 保留正常 WAL；未引入 immutable、checkpoint 或写 SQL。报告用 create_new，已有目标或最终 symlink 无法被覆盖。原件来源/stat/hash 完整链仍由根 runner 在开库前验证，测试只记证书 SHA；本结论没有把该职责误说成测试独立完成。

结论：**PASS（限定静态）**。后续正常副本运行仍应绑定此 R3 源码哈希与根 runner 参数；实际结果由根任务交付。

## R4 报告构造拆分追加独评

**PASS（仅 R3 → R4 静态差异）**。本次没有重新全审，也未运行 Cargo、测试、SQL 或服务。

- R4 source/staged SHA256：`993bd2b3cf2b99b8b301db91ba77ed99455e3a1c242195528ae834d81995e82f`。
- R4 patch SHA256：`0a8119981d10e80750b22ac8f23863b867d30b00b987cf91ba7d2f749c77162c`。

实际 diff 只将报告的一次 json! 展开改为 17/16/17 三个 JSON Object，逐个取出 Map 并 extend，最后包装回 Value::Object。逐行比较确认原字段值表达式保持不变，三段在同一数组构造中仍按原顺序求值。独立静态提取核对得到 50 字段、字段顺序相同且无重复 key，因此 Map::extend 不会覆盖任何原字段。报告构造前后源码均与 R3 相同，真实 HEAD 的 35950 字节前缀仍逐字保留；实装与 staged 的 SHA 一致。

拆分不会改变闭包、费用计算、读取权限、事务关闭或报告 create_new/write 路径，也没有增加 recursion_limit 全局配置。新增临时 Map 仅属于报告构造，原有 source-only 计量及未知 heap 开销的边界继续适用。编译和真实正常副本结果仍由根任务交付；后续执行应绑定上述 R4 哈希。
