# #1394 正常Counts来源体积测量 staged补丁

已形成一个源码文件的可审阅补丁，未修改真实Rust源码，未打开数据库，未执行Cargo、测试、服务或SQL。staged文件实际用rustfmt格式化，原源码前缀逐字相等，git apply --check通过。编译与正常副本180秒观察运行由根任务负责，当前没有测试通过或体积测量结果。

基线HEAD为 `a7ff573643914d5017b0207511529337c98a8996`，基线源码聚合SHA为 `86d44f8c22423ea3e7276d6a706fd84762c179ee08188135b995e1f73abb1fe1`。逐文件base/staged与patch SHA见同目录 `SHA.json`。补丁为 `patch/counts-footprint.patch`，staged源码为 `staged/rust/src/bin/s_session_v3/cross_request_source_cache.rs`。

## 正常路径与测量边界

新模块仅在 `cfg(all(test, feature="s_capture_native_testonly"))` 编译，新增一个ignored正常测试。空Keeper仅让既有 `state::audit_native_in_request` 在完整Native审核中封存真实Key/Counts/Binding。审核必须全部成功、无旧命中、cut数符合根绑定、proof数与完整审核cut数逐项相等。随后用既有 `Pool::build` 计算全部原费用，并保持完整capture owner活着。原Keeper预算、生产接纳、根播种、Ordinary/Owned路径均无改动。

Recorder逐次委托capture.reader，在read返回Found及checked_read返回Some时记录摘要。没有从wrapper返回旧值。三类均以独立调用 `audit_verify_many_refview` 创建各自全新Verifier/AuditMemo，Public模式，类内跨cut共享展开，类间不共享memo。报告的是类别总体闭包和总体并集，不将相邻cut读取差集当单cut完整proof。没有构造瘦capture。

`lookup_fields_refview` 调用 `path.rs:321` 的 `object_fields_output`。已逐行核查该入口只枚举顶层OBJECT、字段SEQ、FIELD_PAIR和完整键比较，并为三项选中值读header，不隐式递归验证整棵generated_state，因此该集合可单列navigation。类别全部digest在计费时必须由capture.original取得完整tag/body。出现非原件依赖即报 `CountsFootprintScopeError`，不补造overlay或正文。

类别与union费用沿原Pool的节点证书总费除以完整节点数求单位费，再checked_mul；正文逐原件body.len累加。保留原SQL Binding、完整Key/六Counts、8Bfrontier。原codec根费用另列，从Counts候选原料总额中减去。报告不导出原节点正文、SQL原行正文或Counts手填值。

本轮没有实施候选依赖元数据，故 `persistent_dependency_metadata_bytes` 与 `admissible_complete_proof_count` 为null。diagnostic摘要HashSet容量负载另行披露，不冒充候选持久元数据费用。能算的是全体测得原料是否低于512MiB扣除实测legacy后的余量；即便原料低于余量，也不宣布完整proof可接纳、完整资源资格或9011可容纳。没有逐cut独立closure，所以不猜超额时可接纳几个proof。

## 精确测试与环境

精确测试名为 `v3::cross_request_source_cache::counts_footprint_tests::counts_footprint_actual_owned_normal_diagnostic`。根编译后用 `--list` 核实只有此一项，再以 `--exact --ignored --nocapture --test-threads=1` 运行。

```bash
cd rust
cargo test --release --offline --bin s_structure_session --features s_capture_native_testonly --no-run
```

运行已编译的测试二进制时传入下列环境，副本绝对路径与报告路径由根准备；环境无默认值与路径fallback。

```text
COUNTS_FOOTPRINT_OWNER_DIR=/Volumes/AgentStorage/issue1394-counts-footprint-owned-20261005-r1
COUNTS_FOOTPRINT_DB=<owner直接子文件中的主DB绝对canonical路径>
COUNTS_FOOTPRINT_REPORT=<不存在的新MEASUREMENT.json绝对路径>
COUNTS_FOOTPRINT_LEGACY_BYTES=0
COUNTS_FOOTPRINT_EXPECTED_CUTS=151
```

LEGACY_BYTES必须与入口实际 `crate::cache::retained_bytes()` 相等，独立test进程预期0但仍现场核。EXPECTED_CUTS与完整审核实际cut数现场核，151副本根同时检查audited_generation=151。测试仅接受上面硬绑定的新owner目录；主DB和已存在WAL/SHM必须canonical、非symlink、nlink=1。数据库通过READ_ONLY打开，再设并核query_only，用正常只读transaction，不使用immutable、不checkpoint。主DB与WAL不写，正常新owner SHM读者锁/索引变化允许。不会打开任何封存原件，也不创建DB。

根runner在开库前核OWNER-CERTIFICATE完整来源/stat/hash链。测试只要求owner下 `OWNER-CERTIFICATE.json` 存在且JSON合法，并记录原证书字节SHA，不消费其字段作新准入判据。根建议证书schema为 `schema_revision=issue1394-counts-footprint-owner/1`，含qualification、owner_dir/db、source_result、source_files、copied_files、binding与test_parameters。报告路径须不存在，最后create_new写入；成功stdout仅一行报告路径及SHA。

## 报告校验与来源manifest

成功报告锁 `normal_complete_audit_success=true`，expected/actual/cut/counts_proof/source_calls均151，source_hits=0，legacy环境与实测均0，all_recorded_digests_are_capture_originals=true，overlay_dependencies=0，original_fee_accounting_success=true。categories是objects/witnesses/observations三元素数组，各root_occurrences=151及fresh_verifier=true。

navigation、categories[].closure、deduplicated_union均给unique_nodes、node_body_bytes、node_digest_tag_certificate_bytes、source_bytes。full_capture_source_cost保留原五项及total；codec_root_certificate_bytes_separate与其中codec项相等。候选原料额等于union.source_bytes + exact_rows_bytes + cut_key_counts_certificate_bytes + 8。每项节点证书费应等于97N。根检查union节点与body不超过完整capture，且至少包含各类别与navigation。

新helper全在既有 `cross_request_source_cache.rs` 内，没有额外Rust模块或依赖。该文件应照已有源码manifest算法重新纳入并重算源码聚合SHA；无需新增源码manifest文件路径。NOTE/patch/staged/SHA都是本票scratch交付，不入生产源码manifest，也不入仓。

当前缓存与生产/完整9011边界来自当前源码和本轮NOTE查证；记忆仅用于提醒不把来源体积测量等同完整资源资格。

## 主控编译前小修

新增模块加unix cfg，保持非Unix构建不引用Unix元数据接口；移除以无关生产常量值声称S7不变的字段，改为声明测量预算scope。R1原件保留，当前精确SHA见ROOT-REFINEMENT.json；实际测量尚未运行。

R3编译前修正：R2替换字段时一并改到了旧诊断字段，独评在实装前发现。已还原整个原文件前缀，重新逐字核前缀相同；仅新增模块保留unix cfg和s7_scope。R2 patch/SHA/NOTE作为被静态退回记录保存，未应用或运行。
