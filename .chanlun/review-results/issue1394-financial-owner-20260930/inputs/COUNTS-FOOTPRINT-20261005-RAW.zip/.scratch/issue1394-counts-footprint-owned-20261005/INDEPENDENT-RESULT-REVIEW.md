# #1394 独立 Counts 实际结果事实复核

结论：**PASS — 单次 CopyQualified151 离线来源材料测量已记录，证据链一致。** 本次仅读取真实 RESULT/MEASUREMENT、owner 证书、冻结绑定及已有 build/list/stdout，使用 jq/shasum/ps 核对；未运行新脚本、测试、SQL 或服务，未 SQLite-open 原件，只写本文。静态 R4 审查已通过，本次不重审实现。

## 实际执行与记录完整性

RESULT 为 `MEASUREMENT_RECORDED`，`exit_code=0`、`measurement_report_validated=true`、`same_Popen_reaped=true`，errors/cleanup_errors 均空，cleanup_actions 空。argv 为冻结 `frozen-dual --ignored --exact v3::cross_request_source_cache::counts_footprint_tests::counts_footprint_actual_owned_normal_diagnostic --nocapture`，只匹配既有 list 绑定的一项测试。

RUN.stdout 记录该具名测试 `ok`，1 passed、0 failed、674 filtered，测试耗时 13.16 秒；RESULT 观察耗时 13.245707999914885 秒，低于绑定观察限额 180 秒。owner 证书同样封住 180 秒参数及实际 env。RESULT 的 test PID 为 5998，authorizing runner PID 为 5983；实时 `ps -p 5983,5998,74662` 无进程（exit 1，无输出），测试、runner 与来源旧服务 PID 均不活。父会话的工具 session 34306 terminal 0 来自主控通知；本代理独立核实的是记录及 PID，不将工具 session 编号当 OS PID。

expected/actual/cut/proof/source calls/raw rows/audited generation 均为 151；source hits、legacy 环境值及实测值、overlay dependencies 均为 0。三类分别 151 root occurrences 且 fresh_verifier=true，unique roots 为 objects 151、witnesses 150、observations 151。witness root 重复不等于漏记录。

## 独立重算的费用

| 来源材料 | 唯一节点 | body B | 97N 证书 B | 节点来源合计 B |
|---|---:|---:|---:|---:|
| 完整 capture | 2,375,001 | 157,406,070 | 230,375,097 | 387,781,167 |
| navigation | 5,787 | 322,752 | 561,339 | 884,091 |
| objects | 547,221 | 32,808,353 | 53,080,437 | 85,888,790 |
| witnesses | 27,340 | 1,372,749 | 2,651,980 | 4,024,729 |
| observations | 4,412 | 228,869 | 427,964 | 656,833 |
| 去重 union | 573,916 | 34,280,978 | 55,669,852 | 89,950,830 |

每项证书费用都等于 97×唯一节点数，来源合计都等于 body+certificate。union 的节点数/body/certificate/source 四字段均处于四集合最大值与总和之间，并不超过完整 capture 对应材料；其去重成员真实性由既有冻结 Rust 实现和运行证据承载，本次没有另行运行遍历。

完整原配方：`157406070 + 230375097 + 965410(SQL) + 44998(Key/Counts) + 2159915(codec roots) + 8(frontier) = 390951498 B`。

Counts 候选材料：`89950830(union) + 965410(SQL) + 44998(Key/Counts) + 8(frontier) = 90961246 B`。codec roots 2,159,915 B 另列，未计入此候选。相对**包含 codec roots**的完整来源总费用，减少 `76.73336808649343%`；若两边都排除 codec roots，同口径减少 `76.60411130865454%`。76.7334% 不能省略比较分母口径。

声明的 S7 余量为 536,870,912 B，候选材料后尚余 445,909,666 B。`persistent_dependency_metadata_bytes` 与 `admissible_complete_proof_count` 仍为 null；材料 fit 和 material-only count=151 不等于完整证明准入。此测量没有逐 cut 独立闭包，没有认证生产资源、全部 heap/RSS/I/O 或正式 9011 可容纳性。

## 报告、来源与副本封条

- 原始 MEASUREMENT SHA 为 `1bfd4a05dc8d217319ae5a2f7c5bed6789129847461d34791069298fa66033b2`，与 RUN.stderr 摘要一致。MEASUREMENT-REPORT 为 runner 重新格式化副本，字节 SHA 不同，但 jq 对比 JSON 对象完全相等。
- owner 证书实时 SHA 为 `7bdc96ef006f6df46940a58655e9e84bce777e25d127d105d8f05a077d26539b`，同时等于 MEASUREMENT 的 owner_certificate_sha256、RESULT 初始证书 SHA 与 after SHA。证书 source_files/copied_files/实际 env 与 RESULT 一致。
- RESULT 的 source_before 与 source_after **完整对象相等**，含已记录的全部 stat 字段（dev/ino/uid/gid/size/mtime_ns/ctime_ns/mode/blocks/nlink）及 SHA；同时等于 INPUT sealed_files 和来源 RESULT.owned_after。来源 RESULT 实时 SHA `fc4df6b67bff5886ec1cab3a235f3fd83b27dcc3b4c0f043732cae0f82d9378e` 匹配封条，state COMPLETE、generation 151/idle、151 committed/published、clocks 453、next ordinal 152，all_processes_reaped=true。
- 重新以字节读取原件及新 owner 的三文件：两边 main DB SHA 都为 `de49f86803665e2a09130ddcf666f9e7d9c712f6f0753a9426866798a5e23cac`；WAL 都为 `9740019a87452b37c2b3519a2c38615c0d1c0bc31d5d33a15e4869fc28b076da`；SHM 都为 `cde4ddfa27aec46c6fdbb8a5b60437ee2b53976fea083806b675e799732e98df`。副本 DB/WAL 前后 hash 不变；本次 SHM hash 也相同。SHM 允许读者变化是许可边界，本次不声称实际发生变化。实时纳秒 stat 未另行采样，完整 stat 前后比较依赖 runner 落盘快照；实时 SHA 已独立重核。

## 冻结执行身份保持一致

RESULT.artifact_binding 与当前 BINARY-BINDING-dual 整对象相等。当前 runner/INPUT/PARAMETERS/binary binding/SOURCE/list binding/list output/frozen-dual 的实际 SHA 逐项重核，均与既有 seal 一致：

| 项目 | SHA-256 |
|---|---|
| runner | `2c00b53f94692beecb94816e970aec3d3446bde2b973d21bf9daf2a03a41245a` |
| INPUT | `112224408a5d7da15110dbb576d9108edd9cafbd22fc06f071fb0de7064978b7` |
| PARAMETERS | `d01594f9bbe8145ee8b743465c9296b0136d94fbfcd2ca161f0ca206fad4bab4` |
| binary binding | `683d210c5ec6ad7bad8b89bdd5004059993ce0a1cb9989d69efa6fb2733722cc` |
| SOURCE-r4 文件 | `afa44ae96a0bc9ad22f8f9c4b746da9494b0fbf7b10e5e80ea2dbb7105439a27` |
| test list binding | `5eafbfc810e28de76ac85921940031072fc9e71e91cb70796d2f7a34ed51cdc0` |
| test list 输出 | `046e5ebdeaa063fab6ddbaffaadffe75f331c2a370427508befa430396d56623` |
| frozen-dual | `dc7ccc01d322cba907b00aa4fa1cdde00c045c74c7a656b03d459556e0821c07` |

SOURCE-r4 entries canonical aggregate 独立重算为 `b699ab1f9f8acc78fee5a51ed46cede98c9fdf47b22cee63ad9c67f259b9ed98`，与 SOURCE/binding/INPUT/BUILD-r4 receipt 一致；BUILD-r4 receipt 记录 offline release no-run、具名 bin、目标 features 和 exit 0。既有 R3 失败不作为本次运行产物；本次承重的是 R4 冻结身份。本复核没有重新构建或重复所有 fixed-source 文件检查。

exit 0 之外，实际报告、费用/计数、证书、来源与副本不变性、同 Popen 回收及当前 PID 状态共同支持本次 PASS。RESULT 中 full9011_complete/whole_resources_qualified/service_started/requests_sent/original_SQL_opened 均维持 false。
