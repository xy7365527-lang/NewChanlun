# #1394 Counts runner 独立限定审查

审查范围：本域 `runner.py`、`PARAMETERS.draft.json`、`INPUT-MANIFEST.draft.json`，以及 staged `cross_request_source_cache.rs` 的新增 `counts_footprint_tests`。只读审查；未运行脚本、静态分析、测试、SQL 或服务，未打开来源 SQLite。`git diff -- '*.py'` 无输出；runner 为 scratch 域文件，结论来自直接读取。

结论：**定稿前须补一项绑定；补齐后可通过本次限定 runner 审查。** 未冻结的 test binding 和草稿 null 是待办，不能作为已运行或伪造证据。本文不认证真实 build/list、冻结产物或实际测量成功。

## 唯一必要修复

[HIGH] 源码 manifest 本身未入外部 seal，aggregate 仅比较自述值

File: `runner.py:247`

Issue: runner 加载 `binding['source_manifest']` 后，仅逐条核 `fixed_source / entry.path` 的文件 SHA，再比较 manifest 自述 aggregate 与 binding 自述 aggregate。manifest 未独立绑定 SHA，entries 可被删减而绕过逐文件检查；即使 aggregate 字符串保持原值，runner 也没有据 entries 重算它。最终 binary binding 的 SHA 不能间接封住它只按路径引用的 manifest 内容。

Fix: 最终 `INPUT-MANIFEST.json` 加入准确 `source_manifest_sha256`，该 INPUT 已由 `ORCHESTRATOR-BINDING.json` 封住。runner 在读取 source manifest 前校验其文件 SHA；用生成端同一明确、确定性的排序/编码规则据 entries 重算 aggregate，再同时对比 manifest 和 binary binding 的 aggregate。最后重落 runner/参数/INPUT/orchestrator seal。无需扩大到坏数据测试或其他域。

## 已核对的通过项

- 报告要求 151 个 cut、proof、source call，零 hit/legacy/overlay；三类名称恰为 objects/witnesses/observations，各 151 个 root occurrence，分别声明 fresh verifier；测试实际对每类别调用独立 verifier 入口。
- 每闭包和 union 校验 `body + 97N`；union 每字段处于各集合最大值与总和之间，且不超过完整 capture。完整来源总费用为五分项之和再加 frontier 8B；Counts 候选费用包含 union、原 exact rows、key/counts、frontier，codec roots 另列。
- `admissible_complete_proof_count` 和 `persistent_dependency_metadata_bytes` 强制 null。S7 使用固定 scope 文本，不冒称已测生产预算状态；材料是否 fit 不等于完整证明准入或资源资格化。
- 来源 RESULT SHA、COMPLETE/151 终态、接收 150/151、单 lifecycle、同 Popen reap、全部进程回收、controller closed、无 cleanup error、socket 回收及 DB argv 均检查；三文件封条与来源结果及当前完整 stat/SHA 对齐。
- 原件只用于 stat/SHA/字节复制；新 owner 0700、exclusive 文件创建、复制 SHA 核对。测试核 owner/DB canonical 路径及单硬链，SQL 只开新副本，READ_ONLY + query_only + 读事务，保留 WAL，不使用 immutable/checkpoint。
- 单一 frozen test Popen，180 秒观察，无重试；超时/失败进入 finally，通过同一 Popen terminate、必要时 kill、wait/reap。原件三文件完整 stat/SHA 必须不变；副本 DB/WAL SHA 必须不变，SHM 允许读者变化；owner certificate 前后 SHA 必须不变。
- 报告 owner certificate SHA 必须匹配本轮落盘证书。exit 0 后仍须通过完整报告 schema/费用/计数校验及 finally 不变性、回收检查，才能保留 `MEASUREMENT_RECORDED`；runner 自身正常退出码不能单独作为成功证据。

限制：未生成最终 test/source binding，未执行 build/list 或测量；union 具体去重结果依赖被冻结 Rust 实现和实际报告，本次仅核实现及 runner 算术边界。本审查不扩大为生产资源资格化、正式 9011 或逐 cut 独立 proof 闭包认证。

## 修复后限定复核：PASS

唯一 HIGH 已关闭。本次仅复核该修复与最终 seal，没有重复完整审查，也没有执行 runner、build/list、测试、SQL 或服务。

- runner 新增 source manifest 路径对齐 INPUT、读取前外部 SHA 校验、UTF-8 canonical entries aggregate 重算，并核 target/bin/test 与四项 compiler features；aggregate 必须同时等于重算值、SOURCE、binary binding 和 INPUT 值。
- 实际文件 SHA 与最终 seal 全部匹配，均已非 null：runner `2c00b53f94692beecb94816e970aec3d3446bde2b973d21bf9daf2a03a41245a`；INPUT `112224408a5d7da15110dbb576d9108edd9cafbd22fc06f071fb0de7064978b7`；PARAMETERS `d01594f9bbe8145ee8b743465c9296b0136d94fbfcd2ca161f0ca206fad4bab4`；binary binding `683d210c5ec6ad7bad8b89bdd5004059993ce0a1cb9989d69efa6fb2733722cc`；SOURCE 文件 `afa44ae96a0bc9ad22f8f9c4b746da9494b0fbf7b10e5e80ea2dbb7105439a27`；frozen-dual `dc7ccc01d322cba907b00aa4fa1cdde00c045c74c7a656b03d459556e0821c07`。
- 使用只读 `jq -cjS '.entries' | shasum -a 256` 重算 643 条 entries，得到 `b699ab1f9f8acc78fee5a51ed46cede98c9fdf47b22cee63ad9c67f259b9ed98`，与 SOURCE/binary binding/INPUT/build receipt 一致。
- BUILD-r4 receipt 记录 exit 0。真实 TEST-LIST.txt 恰有具名 1 test、0 benchmarks；输出 SHA `046e5ebdeaa063fab6ddbaffaadffe75f331c2a370427508befa430396d56623` 与 TEST-LIST-BINDING 对齐，后者实际 SHA `5eafbfc810e28de76ac85921940031072fc9e71e91cb70796d2f7a34ed51cdc0` 与 INPUT/PARAMETERS 对齐；PARAMETERS ready=true，pending/missing 为空。
- 复核时本轮 owner 与 RESULT 均不存在。PASS 仅指可启动首次测量的 runner 审查通过，尚无实际复制/SQL/测量成功证据。上文未冻结限制已由此次真实冻结文件复核解除，其余资格化限制保留。
