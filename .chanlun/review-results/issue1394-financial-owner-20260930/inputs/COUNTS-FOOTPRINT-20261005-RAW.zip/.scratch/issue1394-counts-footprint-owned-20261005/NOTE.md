# #1394 Counts 依赖闭包体积测量准备

这是离线只读测量的工作草稿，不是新服务窗口。本轮只生成runner、参数与输入manifest草稿，没有复制数据库、执行SQL、测试、服务或Cargo，没有生成owner证书或测量成功记录。

已读取来源窗口RESULT.json，其state为COMPLETE，终态generation151、idle、Committed151、published151、clocks453、next_attempt_ordinal152；实际收到150/151回复，同一Popen回收、controller关闭、socket清理且cleanup无误。来源结果hash为 `fc4df6b67bff5886ec1cab3a235f3fd83b27dcc3b4c0f043732cae0f82d9378e`。本轮没有对来源数据库执行SQL，数据库原件stat/hash封条将由runner运行时核验。

## 固定来源与新owner

来源是 `.scratch/issue1394-sqlite-pager-256m-window150-151-20261005/RESULT.json` 的owned_after151三文件，路径位于 `/Volumes/AgentStorage/issue1394-sqlite-pager-256m-window150-151-20261005-r1/`。封条和来源Popen argv/收尾链在 `INPUT-MANIFEST.draft.json`。

新owner必须是尚不存在的 `/Volumes/AgentStorage/issue1394-counts-footprint-owned-20261005-r1/`，创建权限0700。原件只允许byte读取/copy、stat与hash，永不SQLite-open。运行时复制主DB、WAL、SHM，每件copy初始hash与source相同，再核source完整stat/hash不变。必须保留WAL，禁止immutable=1和checkpoint。

测试只对新owner执行READ_ONLY、query_only、read txn；主DB/WAL收尾hash必须未变，SHM允许读者锁变化并记录最终stat/hash。原件三文件的完整stat/hash前后必须相等。CopyQualified151是本独立复制测量的身份，原件105、来源126/142/149既有Unknown不会改写，本测量不构成完整9011接续。

## 已确认的测试契约

精确test为：

```text
v3::cross_request_source_cache::counts_footprint_tests::counts_footprint_actual_owned_normal_diagnostic
```

实际env来自参数JSON：

- COUNTS_FOOTPRINT_DB为新owner的直接子文件s.sqlite。
- COUNTS_FOOTPRINT_OWNER_DIR为准确的新owner绝对路径。
- COUNTS_FOOTPRINT_REPORT为本目录尚不存在的MEASUREMENT.json。
- COUNTS_FOOTPRINT_LEGACY_BYTES=0。入口必须实测crate::cache::retained_bytes()并与0比对，env不是证据。
- COUNTS_FOOTPRINT_EXPECTED_CUTS=151。

实际冻结测试文件为 `.scratch/issue1394-counts-footprint-20261005/frozen-dual`。只读本次measurecode目录的 `BINARY-BINDING-dual.json`，不能搬用旧测试hash。binding字段复用既有dual格式，必须是实际profile_test=true产物并与本次冻结源码清单绑定。

运行时bytecopy成功后才生成新owner中的OWNER-CERTIFICATE.json。schema_revision为issue1394-counts-footprint-owner/1，qualification为CopyQualified151，包含owner_dir、db、source_result path/hash、source_files完整封条、copied_files初始封条、binding path/hash，以及exact_test、实际env和180秒观察限额。runner完整校验源链、copy和证书落盘；测试只读取证书并记录hash，不以测试的路径/hash核验替代runner。RESULT连接授域runner PID、runner/parameters hash、唯一测试argv/PID与证书hash，报告的证书hash须完全匹配。

## 尚需主控定稿

`PARAMETERS.draft.json.ready=false`，当前禁止运行。主控构建后用--list确认精确test仅一项，将真实BINARY-BINDING-dual.json及其hash/source绑定填入INPUT-MANIFEST.json，再定稿PARAMETERS.json和ORCHESTRATOR-BINDING.json。最终输入manifest须含参数JSON hash、source-result hash、source身份链和最终真实test binding hash；Orchestrator绑定runner与最终manifest。

参数和报告schema已按实施代理提供的字段写入草稿，不锁fits_material=true。若构建实际--list或报告字段与草稿不同，先核具体差异，不运行替代测试、不猜字段、不重试。

## 唯一预定命令

主控定稿所有输入后，从工作树单次执行：

```bash
cd /Users/silencehan/.codex/worktrees/issue1394-audit-prefix/NewChanlun
/Users/silencehan/.local/bin/python3.12 -B .scratch/issue1394-counts-footprint-owned-20261005/runner.py --params .scratch/issue1394-counts-footprint-owned-20261005/PARAMETERS.json
```

runner只调用一次 `[frozen-dual, --ignored, --exact, test_exact, --nocapture]`，不启动服务、不发请求。180秒是独立测量进程的私人观察限额，不放宽30秒服务约束。超过180秒或首次失败保存现场、不重试。未退出则terminate，必要时kill并由同一Popen wait回收，这是超时cleanup，不是故障探针。

## 报告验收与范围

test exit0只是一项条件。runner读取实际MEASUREMENT.json，核正常完整audit成功、全部151记录、source_hits=0、legacy实测0、overlay依赖0、原件来源计费、S7不变及诊断边界。categories必须恰为objects/witnesses/observations，各root_occurrences151且fresh_verifier=true。

三类closure、navigation与deduplicated_union均核unique_nodes/body/certificate/source费用，certificate为97乘节点数，source为body加certificate；union在各分类/navigation与full capture界内。full_capture_source_cost逐项求和，codec root费用另列一致，Counts candidate材料排除codec roots并包含8字节frontier。admissible_complete_proof_count和persistent_dependency_metadata_bytes必须仍为null，本次不能宣称瘦池准入或整体资源资格。

保留RUN.stdout/RUN.stderr、原始MEASUREMENT.json、解析报告、RESULT、source before/after和newowner各stat/hash、同Popen回收证据。首次异常及cleanup错误写原样。MEASUREMENT_RECORDED只表示本次离线报告完整性校验通过，不等于生产准入、完整9011或整体heap/RSS/I/O资格化。
