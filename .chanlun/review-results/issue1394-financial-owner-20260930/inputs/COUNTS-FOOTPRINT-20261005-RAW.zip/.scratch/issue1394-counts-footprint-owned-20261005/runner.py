"""#1394 独立自有副本的离线 Counts 测量。参数未定稿时拒绝运行。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import time

ROOT = Path('/Users/silencehan/.codex/worktrees/issue1394-audit-prefix/NewChanlun')
OUT = ROOT / '.scratch/issue1394-counts-footprint-owned-20261005'
OWN = Path('/Volumes/AgentStorage/issue1394-counts-footprint-owned-20261005-r1')
FROZEN = ROOT / '.scratch/issue1394-counts-footprint-20261005/frozen-dual'
FILES = ('s.sqlite', 's.sqlite-wal', 's.sqlite-shm')
STAT_KEYS = ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns',
             'st_ctime_ns', 'st_mode', 'st_blocks', 'st_nlink')
TERMINAL = {'generation': '151', 'advance_state': 'idle',
            'messages_by_status': {'Committed': 151}, 'published': 151,
            'clocks': 453, 'next_attempt_ordinal': 152}


def require(value, message):
    if not value:
        raise RuntimeError(message)


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            value.update(chunk)
    return value.hexdigest()


def identity(path):
    path = Path(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), '非普通文件: ' + str(path))
    digest = sha(path)
    after = path.lstat()
    require(all(getattr(before, key) == getattr(after, key) for key in STAT_KEYS),
            'hash期间文件变化: ' + str(path))
    return {'path': str(path), 'sha256': digest,
            'stat': {key: getattr(after, key) for key in STAT_KEYS}}


def problem(exc):
    return {'type': type(exc).__name__, 'message': str(exc)}


def at(report, dotted):
    value = report
    for key in dotted.split('.'):
        value = value[key]
    return value


def record_count(report, path):
    value = at(report, path)
    require(isinstance(value, int) and not isinstance(value, bool) and value >= 0,
            '记录数不是非负整数: ' + path)
    return value


def numeric(value, label):
    require(isinstance(value, int) and not isinstance(value, bool) and value >= 0,
            '费用/数量不是非负整数: ' + label)
    return value


def validate_footprint(report):
    fields = ('unique_nodes', 'node_body_bytes', 'node_digest_tag_certificate_bytes', 'source_bytes')

    def footprint(value, label):
        require(isinstance(value, dict), '闭包不是对象: ' + label)
        for field in fields:
            numeric(value[field], label + '.' + field)
        require(value['node_digest_tag_certificate_bytes'] == 97 * value['unique_nodes'],
                '节点digest/tag证书费用不完整: ' + label)
        require(value['source_bytes'] == value['node_body_bytes'] + value['node_digest_tag_certificate_bytes'],
                '闭包来源费用不完整: ' + label)
        return value

    categories = report['categories']
    require(isinstance(categories, list) and len(categories) == 3, 'categories必须正好三项')
    require({row['category'] for row in categories} == {'objects', 'witnesses', 'observations'},
            'categories名字不完整或重复')
    closures = []
    for row in categories:
        label = row['category']
        require(row['root_occurrences'] == 151 and row['fresh_verifier'] is True,
                '分类记录数或fresh verifier不完整: ' + label)
        require(numeric(row['unique_roots'], label + '.unique_roots') <= 151,
                '分类唯一root数超过记录数')
        require(isinstance(row['elapsed_ns'], str) and row['elapsed_ns'].isdigit(),
                '分类elapsed_ns不是十进制字符串')
        closures.append(footprint(row['closure'], label))
    navigation = footprint(report['navigation'], 'navigation')
    union = footprint(report['deduplicated_union'], 'deduplicated_union')
    full_nodes = numeric(report['full_capture_unique_nodes'], 'full_capture_unique_nodes')
    full = report['full_capture_source_cost']
    cost_fields = ('node_body_bytes', 'node_digest_tag_certificate_bytes', 'exact_rows_bytes',
                   'cut_key_counts_certificate_bytes', 'codec_root_certificate_bytes')
    for field in (*cost_fields, 'total'):
        numeric(full[field], 'full_capture_source_cost.' + field)
    require(full['node_digest_tag_certificate_bytes'] == 97 * full_nodes, 'full节点证书费用不完整')
    require(full['total'] == 8 + sum(full[field] for field in cost_fields), 'full capture总费用缺frontier或分项')
    require(report['codec_root_certificate_bytes_separate'] == full['codec_root_certificate_bytes'],
            'codec root另列费用不一致')
    for field in fields:
        values = [value[field] for value in (*closures, navigation)]
        require(max(values) <= union[field] <= sum(values), 'union边界不成立: ' + field)
    require(union['unique_nodes'] <= full_nodes and union['node_body_bytes'] <= full['node_body_bytes']
            and union['node_digest_tag_certificate_bytes'] <= full['node_digest_tag_certificate_bytes']
            and union['source_bytes'] <= full['node_body_bytes'] + full['node_digest_tag_certificate_bytes'],
            'union超过完整capture节点材料')
    frontier = numeric(report['frontier_certificate_bytes'], 'frontier_certificate_bytes')
    require(frontier == 8, 'frontier证书费用不匹配')
    require(report['candidate_material_source_bytes_without_codec_roots'] ==
            union['source_bytes'] + full['exact_rows_bytes'] + full['cut_key_counts_certificate_bytes'] + frontier,
            'Counts候选材料费用不完整')
    require(report['admissible_complete_proof_count'] is None and
            report['persistent_dependency_metadata_bytes'] is None,
            '测量不得冒充完整证明准入或持久依赖资格')


def validate_report(report_path, schema):
    require(Path(report_path).is_file() and not Path(report_path).is_symlink(), '缺实际测量JSON文件')
    report = load(report_path)
    require(isinstance(report, dict), '测量JSON报告必须是对象')
    for path in schema['required_fields']:
        at(report, path)
    for path, expected_keys in schema.get('exact_object_keys', {}).items():
        value = at(report, path)
        require(isinstance(value, dict) and set(value) == set(expected_keys), '报告对象键不完整: ' + path)
    for path, expected in schema['required_values'].items():
        require(at(report, path) == expected, '报告断言不成立: ' + path)
    for path in schema['count_fields']:
        record_count(report, path)
    for pair in schema['count_pairs']:
        require(record_count(report, pair['actual_path']) ==
                record_count(report, pair['expected_path']), '记录数不完整: ' + str(pair))
    if schema['counts_footprint_schema_v1'] is True:
        validate_footprint(report)
    return report


def reap(process, result):
    if process is None:
        result['same_Popen_reaped'] = False
        return
    actions = []
    try:
        if process.poll() is None:
            process.terminate()
            actions.append('terminate_for_cleanup')
        try:
            code = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            actions.append('kill_for_cleanup')
            code = process.wait(timeout=5)
        result['exit_code'] = code
        result['same_Popen_reaped'] = True
    except BaseException as exc:
        result['cleanup_errors'].append(problem(exc))
        result['same_Popen_reaped'] = False
    result['cleanup_actions'] = actions


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--params', type=Path, required=True)
    options = parser.parse_args()
    require(options.params.resolve() == OUT / 'PARAMETERS.json', '仅允许本具名域参数')
    params = load(options.params)
    require(params['ready'] is True, '精确test/env/report schema尚未定稿，禁止运行')
    require(params['observation_limit_seconds'] == 180, '私人观察限额必须180秒')
    require(isinstance(params['test_exact'], str) and params['test_exact'], '缺精确ignored test名')
    require(params['db_env_key'] == 'COUNTS_FOOTPRINT_DB', '自有DB env名不匹配')
    require(params['env'].get('COUNTS_FOOTPRINT_OWNER_DIR') == str(OWN) and
            params['env'].get('COUNTS_FOOTPRINT_REPORT') == str(OUT / 'MEASUREMENT.json') and
            params['env'].get('COUNTS_FOOTPRINT_LEGACY_BYTES') == '0' and
            params['env'].get('COUNTS_FOOTPRINT_EXPECTED_CUTS') == '151', '测量env不匹配本具名域参数')
    schema = params['report_schema']
    require(schema['counts_footprint_schema_v1'] is True, '必须核Counts费用与类别完整性')
    require(params['owner_certificate_schema_finalized'] is True, 'owner certificate schema尚未定稿')
    require(params['report_path'] == str(OUT / 'MEASUREMENT.json'), '报告必须写本具名域')
    require(not Path(params['report_path']).exists(), '实际报告已存在，不重试')
    require(schema['required_fields'] and schema['required_values'] and schema['count_fields']
            and schema['count_pairs'], '缺报告字段/成功断言/记录数完整性断言')
    require(not OWN.exists() and not (OUT / 'RESULT.json').exists(), '域或结果已存在；不重试')
    result = {'state': 'RUNNING', 'scope': '独立CopyQualified151离线Counts依赖闭包体积测量',
              'errors': [], 'cleanup_errors': [], 'measurement_report_validated': False,
              'full9011_complete': False, 'whole_resources_qualified': False,
              'service_started': False, 'requests_sent': False, 'original_SQL_opened': False}
    save(OUT / 'RESULT.json', result)
    process = None
    source = None
    expected = None
    copied_before = None
    try:
        orchestration = load(OUT / 'ORCHESTRATOR-BINDING.json')
        require(sha(__file__) == orchestration['runner_sha256'], 'runner绑定变化')
        manifest_path = OUT / 'INPUT-MANIFEST.json'
        require(sha(manifest_path) == orchestration['input_manifest_sha256'], '输入manifest绑定变化')
        manifest = load(manifest_path)
        require(sha(options.params) == manifest['parameters']['sha256'], '参数JSON绑定变化')
        sealed = manifest['source_result']
        require(sha(sealed['path']) == sealed['sha256'], 'source-result绑定变化')
        previous = load(sealed['path'])
        require(previous['state'] == 'COMPLETE' and previous['owned_terminal_state'] == TERMINAL,
                '来源不是完整151终态')
        require([row['ordinal'] for row in previous['received_window']] == [150, 151], '来源接收链不完整')
        lifecycle = previous['lifecycle']
        require(len(lifecycle) == 1 and lifecycle[0]['reaped_by_same_Popen'] and
                previous['all_processes_reaped'] and previous['controller_closed'] and
                not previous['cleanup_errors'], '来源收尾证据不完整')
        require(previous['socket_cleanup']['removed_stopped_service_socket'], '来源socket未回收')
        expected = previous['owned_after']
        require(expected == manifest['source_identity_chain']['sealed_files'], '来源封条绑定不一致')
        source = Path(expected['s.sqlite']['path']).parent
        require(all(Path(expected[name]['path']) == source / name for name in FILES), '来源不是同一域')
        argv = lifecycle[0]['argv']
        require(argv[argv.index('--db') + 1] == str(source / 's.sqlite'), '来源DB身份链不一致')
        original_before = {name: identity(source / name) for name in FILES}
        result['source_before'] = original_before
        require(original_before == expected, '来源完整stat/SHA不匹配封条')
        artifact = manifest['test_artifact_binding']
        require(Path(artifact['path']) == ROOT / '.scratch/issue1394-counts-footprint-20261005/BINARY-BINDING-dual.json',
                '最终test binding必须来自本次measurecode域')
        require(sha(artifact['path']) == artifact['sha256'], '最终测试产物binding变化')
        binding = load(artifact['path'])
        require(Path(binding['binary']['path']) == FROZEN and
                binding['compiler_artifact_profile_test'] is True, '必须是本域冻结test产物')
        require(binding['target_name'] == 's_structure_session' and binding['target_kind'] == ['bin'],
                '测试产物target不匹配')
        require(set(binding['compiler_features']) ==
                {'default', 's_session', 's_capture_native_testonly', 's_allocation_json_testonly'},
                '测试产物features不匹配')
        require(sha(FROZEN) == binding['binary']['sha256'], '冻结test binary变化')
        require(binding['source_manifest'] == artifact['source_manifest'] and
                sha(binding['source_manifest']) == artifact['source_manifest_sha256'],
                '源码清单文件外部封条变化')
        source_manifest = load(binding['source_manifest'])
        aggregate = hashlib.sha256(json.dumps(source_manifest['entries'], ensure_ascii=False,
                                               sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()
        require(aggregate == source_manifest['aggregate_sha256'] == binding['source_aggregate_sha256'] ==
                artifact['source_aggregate_sha256'], '源码聚合绑定不一致')
        for entry in source_manifest['entries']:
            require(sha(Path(binding['fixed_source']) / entry['path']) == entry['sha256'], '冻结源码变化')
        result['artifact_binding'] = binding
        OWN.mkdir(mode=0o700)
        require(stat.S_IMODE(OWN.lstat().st_mode) == 0o700, '新owner目录不是0700')
        for name in FILES:
            with (source / name).open('rb') as src, (OWN / name).open('xb') as dst:
                shutil.copyfileobj(src, dst, 1048576)
                dst.flush()
                os.fsync(dst.fileno())
            os.chmod(OWN / name, stat.S_IMODE(expected[name]['stat']['st_mode']))
            require(sha(OWN / name) == expected[name]['sha256'], '字节复制hash不一致: ' + name)
        require({name: identity(source / name) for name in FILES} == original_before, '复制后原件变化')
        copied_before = {name: identity(OWN / name) for name in FILES}
        result['copied_before'] = copied_before
        command = [str(FROZEN), '--ignored', '--exact', params['test_exact'], '--nocapture']
        env = dict(os.environ)
        for key in params['clear_env_keys']:
            env.pop(key, None)
        require(all(isinstance(key, str) and isinstance(value, str) for key, value in params['env'].items()),
                '显式env必须是字符串映射')
        env.update(params['env'])
        env[params['db_env_key']] = str(OWN / 's.sqlite')
        actual_env = {key: env.get(key) for key in
                      sorted(set(params['env']) | set(params['clear_env_keys']) | {params['db_env_key']})}
        certificate = {
            'schema_revision': 'issue1394-counts-footprint-owner/1',
            'qualification': 'CopyQualified151',
            'owner_dir': str(OWN),
            'db': str(OWN / 's.sqlite'),
            'source_result': {'path': sealed['path'], 'sha256': sealed['sha256']},
            'source_files': original_before,
            'copied_files': copied_before,
            'binding': {'path': artifact['path'], 'sha256': artifact['sha256']},
            'test_parameters': {'exact_test': params['test_exact'], 'env': actual_env,
                                'observation_timeout_seconds': 180},
        }
        certificate_path = OWN / 'OWNER-CERTIFICATE.json'
        save(certificate_path, certificate)
        require(load(certificate_path) == certificate, 'owner证书落盘不一致')
        result['owner_certificate'] = {'path': str(certificate_path), 'sha256': sha(certificate_path)}
        result['authorizing_runner_process'] = {'pid': os.getpid(), 'runner_sha256': sha(__file__),
                                               'parameters_sha256': sha(options.params), 'test_argv': command}
        result['argv'] = command
        result['actual_parameters'] = params
        result['actual_test_env'] = actual_env
        save(OUT / 'RESULT.json', result)
        begin = time.monotonic()
        with (OUT / 'RUN.stdout').open('xb') as stdout, (OUT / 'RUN.stderr').open('xb') as stderr:
            process = subprocess.Popen(command, stdout=stdout, stderr=stderr, env=env, cwd=ROOT)
            result['pid'] = process.pid
            result['process_begin_monotonic'] = begin
            save(OUT / 'RESULT.json', result)
            code = process.wait(timeout=max(0.001, 180 - (time.monotonic() - begin)))
        result['exit_code'] = code
        result['process_observed_seconds'] = time.monotonic() - begin
        require(code == 0, '测量test首次退出失败')
        report = validate_report(params['report_path'], schema)
        require(report['owner_certificate_sha256'] == result['owner_certificate']['sha256'],
                '测试报告的owner证书hash不匹配本次授权')
        save(OUT / 'MEASUREMENT-REPORT.json', report)
        result['measurement_report_validated'] = True
        result['state'] = 'MEASUREMENT_RECORDED'
    except BaseException as exc:
        result['state'] = 'FAILURE_PRESERVED'
        result['errors'].append(problem(exc))
    finally:
        reap(process, result)
        try:
            result['owned_after'] = {name: identity(OWN / name) for name in FILES if (OWN / name).exists()}
            if copied_before is not None:
                result['owned_DB_WAL_hash_unchanged'] = all(
                    result['owned_after'][name]['sha256'] == copied_before[name]['sha256']
                    for name in ('s.sqlite', 's.sqlite-wal'))
                require(result['owned_DB_WAL_hash_unchanged'], '新owner DB/WAL发生字节修改')
                result['owned_SHM_reader_change_allowed'] = True
                if result.get('owner_certificate') is not None:
                    result['owner_certificate_after_sha256'] = sha(OWN / 'OWNER-CERTIFICATE.json')
                    require(result['owner_certificate_after_sha256'] == result['owner_certificate']['sha256'], 'owner证书变化')
            if source is not None:
                result['source_after'] = {name: identity(source / name) for name in FILES}
                result['source_full_stat_SHA_unchanged'] = result['source_after'] == expected
                require(result['source_full_stat_SHA_unchanged'], '原件完整stat/SHA变化')
        except BaseException as exc:
            result['errors'].append(problem(exc))
        if result['state'] == 'MEASUREMENT_RECORDED' and (result['errors'] or result['cleanup_errors'] or
                not result.get('same_Popen_reaped') or not result.get('source_full_stat_SHA_unchanged')):
            result['state'] = 'FAILURE_PRESERVED'
        save(OUT / 'RESULT.json', result)


if __name__ == '__main__':
    main()
