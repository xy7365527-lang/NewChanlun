# #1394 来源证明保留：限定只读设计审计

本轮绑定源码 HEAD `ecd8371e8fe71f33d2af040d32c2aa3b1bacdfbe`。收尾时共享工作树 HEAD 已到 `a7ff573643914d5017b0207511529337c98a8996`，二者只增加 pager 证据归档，Rust 源码无差异。本轮没有打开任何数据库，没有执行 Cargo、服务、测试或故障注入；只读取指定源码及既有 JSON/日志。唯一新增文件是本笔记。未读取或恢复已取消的 birth-only、candidate、wire 实验。

## 结论及下一步

全 capture 原件不是 Counts 业务语义的最小依赖，却是当前「所有 Counts + 所有 codec 成功根」共同采用的保守证明载体。**不能删掉原件再照常播种全部旧 codec 根**；仅按当前 read-tracker 留材也不成立。

唯一推荐的下一步是先测一个 **Counts 专用保守依赖闭包**：每个成功 cut 的生成态顶层字段导航原件，加 `objects`、`witnesses`、`observations` 三棵完整子图；SQL Binding 暂不缩减。保留完整当前 capture 和所有独立审核。比较臂停止跨请求 codec 根播种，codec 继续原严格核；同 handler 完整原件相等的历史 slot 复用继续原路。现有 codec 两请求窗口改善约 3.61% / 2.37%，这个收益会有损失，不可把瘦池收益单算而隐去损失。

根据下面的一项正常域体积测量，再决定是否实装 Counts 专池及按整份证明接纳。当前没有三子图字节分项，**不声称它一定装得下完整 9011，也不声称改后30秒必过**。本轮给的是可直接实现的测量入口及证明边界，不是新的批准门。

## 当前 Pool 的成本

正本代码为 `rust/src/bin/s_session_v3/cross_request_source_cache.rs:77–94,133–251`。设保留唯一节点数 N、完整 body 总长度 B、成功 Public/Template Value 根数 R：

| 分项 | 当前源成本口径 | 缩减的含义 |
|---|---|---|
| `node_body_bytes` | B，完整正文长度 | 必须真的不再持有被排除的正文；压缩后物理容量小不等于源成本变小 |
| `node_digest_tag_certificate_bytes` | `97*N = (32+1+64)*N` | 唯一完整原件条目；不能因小 body 或共享根就免掉证书费 |
| `exact_rows_bytes` | SQL字符串、scope、列名、原行序及每个 SQL storage class/完整字段字节的编码成本 | 第一版保留现配方与负依赖，不为瘦池任意排除行 |
| `cut_key_counts_certificate_bytes` | 每 cut 的完整 Key、六个 usize Counts 及字符串长度前缀/字节 | 只删除未接纳的完整证明；不得保留结果却删其依据 |
| `codec_root_certificate_bytes` | `43 + 32*R` | 两集合的 Mode/Flavor、format、版本、长度及根；第一版不跨请求保存/播种这些证明 |
| 总计 | 上述五项 + frontier 8 B | 沿现 S7，不另加预算 |

capacity 另计 Native 索引、body Vec capacity、ExactRows 容器、Proof Vec、Key String、codec root set capacity；它不是 S7 来源成本，更不是完整 heap/RSS 资格。

当前正常150日志中的 old_pool=382405282 B，占 S7=536870912 B 的71.23%；workspace=42874531 B，二者合计425279813 B。原件为 `.scratch/issue1394-native-scan-window150-151-20261005/ROOT-RESULT.json` 及同目录 `SERVICE-DIAGNOSTICS.log`。它们没有提供当前 Pool 的逐项分解。

可复用的较早完整151副本分项来自 `.scratch/issue1394-cross-request-source-cache-20261004/DIAGNOSTIC.json` 的 `keeper_cold`，该原型尚未加 codec 根，不与当前150读数混合：

| 分项 | 字节 | 占该原型总量 |
|---|---:|---:|
| body | 157406070 | 40.49% |
| 2375001 个唯一节点的97B证书 | 230375097 | 59.25% |
| ExactRows | 965410 | 0.25% |
| Counts Keys | 44998 | 0.012% |
| frontier | 8 | — |
| 合计 | 388791583 | 100% |

所以值得先测的是减少被持有的唯一完整节点，而不是只裁 Counts 的六个数字或SQL元数据。

## Counts 实际依赖

`source_audit.rs:1297–1814` 的业务核只从 `state` 取三项：`:1362` objects、`:1702` witnesses、`:1794` observations。Counts 是 objects、groups、windows、effective、insufficient、outside_domain 六项（`:694–700`），但它不是单纯计数器：结果表示之前的对象来源、覆盖、身份、见证等全部成功。

| 必需材料/判据 | 源码依据 | 保守闭包里怎样保存 |
|---|---|---|
| 对象全集、重复身份/修订、typed及shape字段、payload、input_refs、source_coords、组覆盖与证据并集 | `source_audit.rs:1362–1568`；字段清单 `:844–865` | objects 数组及全部后代完整原件；第一版不再细裁字段 |
| shape连续三组、依赖差集、窗口锚、比较规范文本、obj3身份 | `:1573–1700` | 同上，包括0x07 JsonText内值、字节/元素序列、所有键与声明 |
| 完整三槽见证、重复/缺见证、真实raw_bars及witness身份 | `:1702–1792` | witnesses 数组及全部后代完整原件 |
| insufficient / outside_domain 数量 | `:1794–1805` | observations 数组及全部后代；虽然业务只看kind，第一版保留整棵 |
| 顶层字段选择与完整成员/缺字段边界 | `s_content/path.rs:321–414` | state OBJECT正文、字段SEQ骨架、FIELD_PAIR正文、所有键的完整闭包，以及被触碰的值header。只排除未选值的更深子图 |
| profile、rule、frontier、generated_state完整声明、generation | `cross_request_source_cache.rs:38–61` | 沿现完整Key逐项匹配；判据/提取器版本也须封闭绑定 |
| 独立真实raw prefix：修订赢家、coord、wire/numeric/raw内容；有效账的全集覆盖/坐标冲突 | `source_audit.rs:1050–1148,1332–1360,1567–1568` | 沿现SQL Binding保存原行序、rowid、storage class及完整字段。不是只存生成态raw数组或赢家摘要 |

`NativeRawLedger` 对真实raw生成的三个摘要从不用于读取持久节点（`:1124–1129`）；`history::hash_json_in_store` 走只写 Discard（`history.rs:1328–1338,1361–1385`）。这些不引入三子图之外的 SQL content 读取；它们的独立输入仍必须由 raw Binding 完整覆盖。

现有 Binding 还保留 `sqlite_schema`、非动态meta及未知meta、s_content_meta、protocol的冻结身份/clock plan、截至 frontier 的 raw_events，以及独立 raw_ohlc 负依赖（`cross_request_source_cache.rs:18–32`）。raw_ohlc 的排除仅针对合法尾部关联行；孤立OHLC、重复/删除/重插行、未知字段、非TEXT键不应被过滤掉。第一版全部保留，不在本次推导更细SQL证书。

独立 control/raw全账、publications/deltas、对象/aux索引、source消息/attempt/clock、writer、catalog及当前代变化仍属于 fresh 完整审核，不由 Counts 证书替代（`history.rs:368–422,529–535,650–685`；`state.rs:675–710,768–810`）。

## 为什么可以排除其余生成态/公开子图，又不能继续保存全部 codec 根

Counts 业务核开头还有完整 `s.verify_ref(state, Public)`（`source_audit.rs:1313`）。**这项义务不能随缩减的证书消失。** 当前请求在查询 Counts 之前，history 对每 cut assemble manifest：`history.rs:447–469` 调用既有构造核，`content_manifest.rs:1103–1110` 现场完整核生成态、scope、publication_template、delta_template。关闭跨请求 codec 播种后，这项严格当前闭包核仍由原核完成；到 `state.rs:741–766` 才可能命中 Counts。因此可以只让缓存证明来源业务语义，完整 codec 资格由 fresh 原核提供。

raw_events/effective_events、relations、catalog_axes、scope等未选子图仍当场取得与验证；公开 snapshot/Delta/manifest/life wire也继续取得、投影、比较和核验。**排除它们的跨请求持有不是排除它们的当前审计。** 缩减后的 Pool 只保存 Counts 所依赖的原字节，不再被当作完整当前读集。

现有 codec 根集合 `s_content.rs:2110–2119` 只存成功根及 Mode/Flavor/版本，没有每根依赖列表。播种 API `:2192–2231` 恰靠旧 capture 全tuple被当前逐字包含才安全；Verifier命中后 `:4014–4015` 不再下行。保留manifest/snapshot成功根却删除其后代，将失去该API的前提。第一版应清掉所有跨请求 codec 根，复用 `into_originals_only_for_testonly`（`:2145–2148`）的语义；同 handler 的全capture仍可按原完整绑定复用其codec结果。

## memo/read-tracker 的明确陷阱

Codec `seen`、bytes_memo、elem_memo会省掉下行读取（`s_content.rs:3441–3443,3596–3598,4014–4015`）。Counts本身命中时根本不调用 source核。NativeRecordFields交接与field/scalar memo、coords/references memo、witness身份memo还会直接返回先前结果（`source_audit.rs:369–372,448–450,464–469,968–987`；`source_prefix.rs:489–495,520–530`）。目前 CaptureReader 的digest trace仅cfg(test)，且它记录实际读取，不记录这些隐含依赖（`s_content.rs:2773–2778`）。

因此 `actual reads this cut`、相邻read集合差集、`seen`只有根、某节点proof槽为Some，都不能作为可删材判据。不能先根据这类集合裁剪，再用原codec资格证明裁剪正确。

## 必须补的最少一项体积测量：正常域三子图保守闭包

只在**新正常自有副本**按既有流程完整audit成功之后、slot capture仍持有时测量；不打开或变更任何封存DB。测量入口不需要新源码判据或手写tag解码器：

1. 用只读 `NodeSource` 记录包装器委托 `capture.reader()`；read与checked_read都记录成功取得的digest。包装器不持资格、不播种旧memo、不写SQL、不能从wrapper返回旧值。
2. 对每个成功 cut 的完整 generated_state ref，用现有 `sc::path::lookup_fields_refview`（`s_content/path.rs:1523–1529`）和这个wrapper现场取三个字段。保存该步实际触碰的导航原件。此入口不走 NativeFieldMemo/NativeRecordFields，因此不会把字段骨架省掉；键比较/缺字段/成员边界保持原实现。
3. 对所有选出的三类根调用 **`sc::audit_verify_many_refview`**（`s_content.rs:5818–5827`），Mode=Public。这个入口明确 `Verifier::new`，创建全新 AuditMemo（`:3391–3392`），不调用 `AuditCapture.verify_refview` 所持旧memo，不播种旧codec根。共享子图只首次展开，已展开依赖已在总集合内，跨cut无需复制body。
4. 取导航集合与完整三子图读取集合的并集 D。只从 `AuditCapture::original`（`:2359`）借完整 `(tag,body)` 算 `sum(body.len()) + 97*|D|`；加原ExactRows、保留的完整Key/Counts、8B frontier及实际新增依赖元数据成本。只报告字节/节点数/根计数，不导出原件正文。先不构造第二份稀疏capture。

这**一项测量**必须同时输出：full capture N/B/cost、三类闭包及去重union N/B/cost、导航分项、每完整Counts证明加入union的边际N/B、原SQL/Key分项、依赖元数据分项、在原S7 remainder内能接纳的完整proof数量。codec原核比较臂的成本/耗时另据现成正常窗口比较，不把测量器的额外遍历耗时当服务耗时。

总union可共用一个全新Verifier，但其相邻cut新增read集合只能称边际新增，不是那个cut的完整D_g。若要试不同proof接纳顺序，须对每个proof用独立fresh Verifier取得完整D_g，或者保存经过完整展开的依赖DAG再作闭包；不能把共享memo省掉的读数当该proof无依赖。第一项可先只测总union，显著缩减才增加按组计量，避免诊断自身变成重复全历史跑批。

如果省下的主要只是孤儿/临时不可达节点，或者三子图union仍接近全池，就不值得为一个小差异实装。当前没有这项测量，不能用32/151既有正确性测试或捕获总量替代它。无需追加坏数据/故障测试才能回答这个正常体积问题。

## 测量支持后，最小实装及证明

只改来源池的持有范围：Pending为成功cut保存私有三根及导航依赖描述；完整handler成功后，从最终slot的**完整capture**移出D里的body owner，余下drop。`Pool.nodes`改为保留依赖数量，slot.node_count仍为真实全capture数量，不能混用。

下一请求继续 `capture_with_original_subset_for_source_cache` 的原全表SQL、全部行解码、digest去重、扫描到尾、stmt.finalize（`content_store.rs:2166–2207`）。其既有逐tuple比较可直接比较稀疏旧池；要求D每一条旧原件完整匹配且没有遗漏。不能将SELECT改为只查D，也不能在mismatch后提早结束；新capture仍全量建立。SQL Binding仍按旧frontier现场完整比较；Key不变；然后完整history照旧执行。只有这些条件通过才用旧Counts。

依赖证明是：上一完整业务核成功 + 三子图/导航完整闭包 + 独立SQL Binding逐字相同 + 完整Key相同 + 本次fresh codec/history已通过 ⇒ 来源业务核的全部实际语义输入相同 ⇒ 同一严格核会给出相同成功结果/Counts。未持有子图的当前codec/索引审核不是该蕴含中的旧证书，而是此次新事实。

若union超额，只按**完整proof组**接纳，确定顺序可先选较新的cut，再把接纳proof按generation排序供既有binary_search。每次接纳必须连同该proof所有原件、导航、SQL范围及新增元数据一起计费；D按唯一节点共享。整组装不下则省去该优化，该cut继续原source核；不得缩短依赖后保留Counts。至少仍能保留可装下的完整证明，避免当前 `Keeper::finish:325–329` 一处超额导致全部旧复用归零。哪种选择最划算先由边际成本测量决定，不新设预算。

沿 `RequestAuditContext::finish_source_keeper:137–157` 的post-COMMIT可丢弃收尾；计算/分配不成只不保留，不改业务Result。Error、restart、Ordinary/Owned、S7=1原路保持。沿现共享S7账：`driver.rs:383–399` 和 `request_audit.rs:87–109` 的 `legacy+old_pool+workspace≤total`，瘦池少用多少才释放多少workspace余量；不得把剩余S7误当新增第二预算。

## 对完整9011的现实限制

该方案直接针对全池的body与97B唯一原件费，保护已有Counts复用，并减少它对manifest workspace的挤占；它不是泛泛的leaf缓存。按完整proof接纳解决「某一代超额导致全部证明归零」，但不保证每个晚期proof都能装下，更不保证9011所有历史Counts同时命中。

尤其 `object_records.rs:466–468,646–715` 的生成态三件套随cut写入当代generation/cut；三数组的保守closure仍保存这些不同代的record及序列骨架。去掉公开/模板闭包不自动去掉这个累计增长。第一版不假称仅按object_id就能共享所有生成态原件，也不把这些未精裁记录改成另一套出生/历史判据。

原全库捕获、每请求独立索引/raw/control、完整历史业务核的其他重复项、现场全部字节读取下界仍在。瘦池可能显著推迟保留cliff，也可能用codec约3%收益换来不够大的空间；必须由上述正常体积测量作决定。它是现授权范围内的一项可测保守方案，尚无实装或新的9011通过结论。

## 发现工具及核查范围

先查询已知图项目 `Users-silencehan-Projects-NewChanlun-rust` 的 AuditCapture / NativeCodecRootCertificates / NativeSourceAudit / Pool，返回0匹配；故按项目「图不足」例外读指定源码。没有声称图证明了当前实现。除本NOTE外无代码/配置/规范写入。
