# #1394 Counts sparse pool 正常150/151窗口独立事实复核

判定：**PASS，限定正常窗口输出、绑定、来源预算与生命周期事实**。窗口ROOT的 `PASS_NORMAL_COUNTS_SUBSET_WINDOW150_151` 和NORMAL-VERIFICATION-HANDOFF的 `PASS_REQUESTED_NORMAL_SCOPE` 与实际证据一致。两代old_pool均降至88768569字节，完整回复和持久oracle保持相同；本次耗时分别比256MiB基线**慢13.2642%和10.9790%**，不是加速。

范围仅为本代码产物目录、`.scratch/issue1394-counts-subset-window150-151-20261005/` 及指定256MiB基线。等最终ROOT落盘后一次集中复核，仅读JSON、文件字节、SHA、stat和PID状态，未SQLite-open任何数据库、未执行runner/验证产物脚本、测试、Cargo或服务，未改其他产物，未重新运行窗口或扩大到9011。本报告是限定事实复核，产品静态审查沿用既有INDEPENDENT-REVIEW。

## 完整正常输出与30秒门

RESULT为COMPLETE，errors/cleanup_errors为空，received_window严格为150、151且整个对象与基线相同。两条exchange均为Received、error=null。独立逐字节核对完整request.wire、reply.wire、persistent.json，与 `.scratch/issue1394-sqlite-pager-256m-window150-151-20261005/` 全部相同；实际request/reply SHA匹配RESULT，完整reply envelope等于exchange.response，payload等于RESULT记录，持久证据中的完整canonical oracle SHA匹配RESULT及基线。没有用旧signature或选取几个字段代替完整对照。

| 请求 | 256MiB基线秒 | Counts sparse pool秒 | 本次变慢 |
|---|---:|---:|---:|
| 150 | 17.691335209 | 20.037953583 | 13.2642242% |
| 151 | 17.030979916 | 18.900813833 | 10.9790155% |

exchange原始纳秒、基线值及ROOT的负reduction百分比独立重算一致，两条完整交换均小于30秒。唯一成功Ready wire与START-RESULT完整reply及SHA相同，ready、initialization=null，control_instance_id匹配实际运行身份。从真实Popen begin_ns至成功Ready wire end_ns为 **26.356801208秒**，也小于30秒。217次启动连接探测中只一次发送Ready请求，其余request_bytes=0，未重发150/151或重新启动窗口。

终态严格为generation151、idle、Committed151、published151、clocks453、next_attempt_ordinal152。起点仍为CopyQualified149；来源149未收到回复、original105 DeliveryUnknown及既有Unknown边界保留，没有拼接成original9011完成。

## 实际来源保留费、metadata与观测限度

SERVICE-DIAGNOSTICS.log与本次owned/controller-state/s.log哈希相同，SHA为 `b655edd19255d59e8ec335ae1e314a71461f5042f66d2aec80566fdc813af7ee`，匹配ROOT和SUMMARY。日志schema也逐项匹配SUMMARY。每代均恰有一条request-budget-entry、prepare-issued和owner-dropped，三处budget相等，keeper_cap及total均为 **536870912**。

| 代 | old_pool | allowance | workspace_source_cost | source_sum | 相对基线减少保留费 |
|---|---:|---:|---:|---:|---:|
| 150 | 88768569 | 448102343 | 42874531 | 131643100 | 293636713 |
| 151 | 88768569 | 448102343 | 43267617 | 132036186 | 293447145 |

legacy均为0；allowance+old_pool+legacy=536870912，workspace_source_cost≤allowance，source_sum=workspace+old_pool+legacy且未超额。基线old_pool为382405282/382215714，费用差、allowance增加量及source_sum差独立重算匹配ROOT/HANDOFF。没有把旧382MB数值硬套到新池，也没有把来源费当作heap或RSS。

两代既有publication owner诊断分别为owner_drops=1、reused_original_reads=1273104/1283045、unknown_write_invalidations=0；全部scope_*字段与ROOT一致。这些字段描述既有workspace/material owner，不是新增稀疏keeper的指针别名证明。

新选择/计费实现的静态及指定正常测试证据覆盖完整Proof闭包、pool费用/tuple原字节、原Vec身份、排除原件、完整cold对照及共享S7；静态审查已登记每节点body.len+97B及正常完整证书metadata费用。**真实窗口没有单列每组metadata费、实际被选Counts组清单、keeper别名身份或codec根清空读数**，不能从88768569总额独立拆出它们，也不能以源码意图或旧signature推成现场已观测。跨请求codec根清零的适用证据限于当前r3生产源码的已审实现及指定正常结果/重投/restart对照；本窗口未直接测其清零事件或独立收益损失。ROOT/SUMMARY对此限制写实，不构成伪造资格。

## pager、RSS与持久性

实际环境保留Native TestOnly、diagnostics=1和私有cache变量262144。启动有效回读与基线逐项相同：requested_cache_kib=262144、cache_size=-262144、cache_spill=63429、page_size=4096、journal_mode=wal、synchronous=2、fullfsync=1、wal_autocheckpoint=1000、mmap_size=0。cache_spill仍启用，未把零spill差值解释成关闭spill；pager hint不变，也不是RSS硬上限。

三条handle分别为Ready、150、151；四项累计端点差值独立从before/after重算匹配ROOT，与基线相同。150的hit/miss/write/spill为18409594/500929/24307/0，151为15309392/499846/35909/0。端点非负、不下降，reset_flag=0、业务成功；i32采样间wrap/reset仍不能排除。miss×page_size不是SSD实际字节，write计数在SQLite IO/write错误后可能未定义，rc=0本身不是排除历史I/O错误的证明。

截至末次诊断的kernel进程生命周期maxrss为 **2421145600字节**，基线为2588622848字节，观测差为−167477248字节。macOS各采样raw_unit=bytes、bytes=raw_maxrss、rc=0且序列非下降，ROOT的max正确；这是进程生命周期高水位截至采样时的读数，不是请求独立峰值、Rust heap或退出后的最终采样。cache_used最大样本为276057728近似字节，pager_strict_peak=null，各db_status highwater=0仍代表不支持峰值。没有声称严格内存峰值、全资源资格或已证稳定性能收益。

## 输入、代码、服务与编译缓存绑定

实际runner差异与SCRIPT.diff逐字一致，仅更换具名域、socket、服务路径及范围说明；30秒、S7、首次异常保留不重试、完整oracle与Popen回收代码保持基线。Controller实际等于proposed，启动和请求截止均30000ms，audit_cache_source_bytes=536870912。

脚本/ORCHESTRATOR/PYTHON及57项Python/材料哈希相符；EXPERIMENT哈希、基线ROOT/RESULT/runner seal及封存来源RESULT seal均匹配。三原件original_before=original_after，并与基线来源封条相同；独立用二进制读取/lstat/SHA核对三原件及三owned文件，完整stat/SHA全部匹配，没有打开数据库连接。

SOURCE-r3聚合为 `63ae89d62f67c3f27e065495617bca753c55bd80f08632a9eb20b45d316e4d11`，643项当前和冻结源码逐项匹配。窗口与codeout服务binding相同，实际frozen-service SHA为 `4154968619d9abb5f3039c0e6ff531b7dadc588f1145caa4397a334191fc8275`，为profile.test=false的s_structure_session bin。r3 frozen-dual SHA为 `cf603eaaf8ca37f1c25020a2a8541929ba612514d8c95cf43fcbd78add144936`，profile.test=true。两者实际compiler artifact、features、binary SHA和各自冻结源码绑定相符；feature-off记录exit=0、build-finished.success=true且未包含Native/JSON TestOnly features。

服务构建后同路径libnewchan_rust.rlib/dylib已变为服务构建字节；旧dual绑定保留构建时指纹，当前缓存不再相同，此事实独立重算与HANDOFF一致。它们是可变编译缓存，不能要求永远等于旧dual的build-time SHA。`FROZEN-LINK-IDENTITY-r3.txt`保存的otool读数列出两份frozen可执行文件的依赖，均无libnewchan动态依赖；冻结dual/service本身及固定源码哈希仍相符。本补审没有重编、重测或覆写旧binding。

## 正常测试证据与首次失败保留

r3 TEST-r3-RESULT绑定上述SOURCE-r3和frozen-dual-r3；六项各自--exact日志均显示1 passed、0 failed，exit=0、SHA相符。涵盖owner原件/tuple保留、合法无关append、driver完整行与append/repost/restart/shared-S7、既有正常请求复用、非空old_pool共享预算及measured cap只改变保留。

另复用R2第一项multicut预算测试PASS：旧TEST-RESULT的exit=0和日志seal成立，旧冻结dual仍匹配自身binding。R2至r3四文件字节差异重建与PATCH-r3逐字一致，只改新增owner正常测试的OHLC价格夹具；生产实现和该第一项正常测试不变。因此共有 **六项r3实跑正常证据＋一项R2复用正常证据**，不称七项都在同一r3二进制运行。

R2第二项owner同价fixture先在原SourceAudit完整覆盖门报错，exit=101、原日志SHA及旧binding保留。r3只将OHLC改成已通过序列6+n/12+n/3+n/7+n，未改审核或跳过失败，也未资格化同价一般域。旧unrelated-original-change负例仍保留历史全池cache策略断言，本次未执行；negative_tests_run=false、all_regression_tests_run=false，不能宣称完整回归通过。没有新增故障注入或坏数据测试。

## 实际回收与最终边界

唯一真实Popen PID41280，argv等于RUNNING-IDENTITY.command，Ready control_instance_id对应，stop PID相同；同Popen回收记录exit_code=-15，controller_closed=true、cleanup_errors为空、cleanup为0.0866311660502106秒。补审时PID不存在、socket不存在，清理socket的device/inode/uid与运行身份匹配。controller_stop原始「服务完整参数与本次启动命令不符」观察警告照实保留，未删成无警告；最终判据依据同Popen退出、真实命令、PID消失及socket身份回收。

ROOT、SUMMARY和HANDOFF的费用/耗时/RSS及窗口ROOT seal一致。此次证明正常150/151完整输出保持与来源保留费降低；耗时变慢必须同时报告。strict_peaks=UNMEASURED，full9011_complete、whole_resources_qualified、goal_complete均为false。没有将派发/编译/正常测试完成扩成全部9011、生产默认采用或整体heap/RSS/I/O资格化，也未恢复取消的算法方案。
