# #1394 Counts 完整闭包稀疏池 r2 独立代码审查报告

结论：**PASS，限定静态审查**。首轮发现的正常测试期望错误已由 r2 修正，当前没有剩余可信阻断。未运行编译、测试、SQL、服务或故障/坏数据验收；没有修改源码。真实运行及性能验收由根任务负责。

## 冻结对象

- 基线 HEAD：`bf859f1f3410e8231c51bdb283bfa36bddf556fa`。
- 补丁：`PATCH-r2.diff`。
- 补丁 SHA256：`1a64e6e79bf8cf4a39d344526574a9f29a0d5b0c5523b28dcecc4296be1f6a16`。
- 文件清单与基线/r1/r2 字节哈希：`SHA-r2.json`，均已读取实际文件重新计算并核对。

| staged 文件 | SHA256 |
| --- | --- |
| rust/src/s_content.rs | `1cd3e727943a20ab8ab4855f4689ea25ab63e6587b506ccd1620ca710d8aa2fd` |
| rust/src/bin/s_session_v3/cross_request_source_cache.rs | `f931930994845e4b04f6d006269ecd015be24b0a7a9e3c737804f2334ad2fd68` |
| rust/src/bin/s_session_v3/state.rs | `e06c4572930df354884a53002712540782a3ec3873fb9891b0f7d88470eecf07` |
| rust/src/bin/s_session_v3/driver.rs | `1e94297d4e0cd4f3568ce942cb290a8c8f2a12a69ebd08e9bcecbc8e4d17dbba` |

真实工位的 tracked `git diff` 与 `git diff --staged` 都为空；审查对象是上述四份源码副本。代码图未包含本隔离对象，使用指定文件与周边实现直接读取。

## 概念层质询结果

通过。改动处理来源 Counts 闭包、原件持有和可弃缓存，不改变缠论领域定义或分类判据，因此不从 `docs/spec/` 的缠论定义推导新缓存资格。审查按本次 #1394 明确授权范围核对，并回读原 `state`、`request_audit`、`content_store`、`prepared` 与 codec/path 实现。

1. 新证书只描述完整 Counts 依赖闭包。固定 Public/Value 核由内部构造决定，证书包含完整 state 及三根 ContentRef、两个 revision；`matches_state` 比较 format/root/kind/extent 全部字段。业务成功仍来自同一次完整审计保存的 Counts，lookup 继续要求完整 Key、原 Binding 以及当前原件重绑定。
2. 单个全新 Verifier 先完成顶层导航，再完整核 objects/witnesses/observations 三根。collector 覆盖 read/checked_read；共享 memo 跳过的依赖已经存在于此前完整组的 D 并集中。组接纳不把本组实际 read 差集说成该组完整依赖。
3. 边界推演一致：空历史不保留缓存；首组超额没有证书或依赖残留；后组超额撤回 checkpoint 后新增 D，立即结束整个 Verifier，不再利用失败组 seen 尝试其他组。此前完整组的证书与物料不变。
4. 跨请求 codec 根全部清零。稀疏 owner 不具有 full slot 身份；同 handler slot 仍持有完整 capture，当前 cold capture 仍读取全表。没有恢复 birth-only、candidate 或 wire 路径。

没有发现需要谱系裁定的概念矛盾。首轮测试把提交的新 head 误算进写前证明，是验收断言错误；r2 按原审计边界修正，没有扩大生产资格。

## 工程层审查

| 严重级别 | 数量 | 状态 |
| --- | --- | --- |
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | info |
| LOW | 0 | note |

已核对的承重条件：

- `capture_with_original_subset_for_source_cache` 保留全表扫描、逐行解码错误、去重与遗漏检查、完整 digest/tag/body 比较。发现 mismatch 后继续读取，SQL/type 错误原样返回；原 Binding SQL、负依赖与完整 Key 不变。
- 从旧 HashMap drain 按值移动所选 NativeNode，保留 body Vec 的原地址；排除节点在迭代中 drop，旧表替换后释放。最终再清 Public/Template memo、所有 Native F proof 和 codec 根；临时 collector、Verifier 与字段容器均退出，不携带完整旧 owner、overlay 或正文边表。
- 保留费覆盖 frontier、原 SQL、Key/Counts、每节点 body.len+97B、空 codec 证书结构费和新增四份完整 ContentRef 证书。每组正常证书为 428B；Pool 重算费用须与接纳 ledger 一致并不超过 cap。String/Vec/index capacity 另披露，inline proof 与选择报告由 `size_of<Pool>` 覆盖。未把 source cost 当 heap/RSS 资格。
- 运行保留构造在原 source_prior 已退出、历史 result/binding 已 drop、publication workspace owner 已退出后发生。入口 legacy+old_pool+workspace 继续使用同一 S7；post-COMMIT 缓存失败仅丢缓存，不覆盖 Committed 回复。普通、Owned、S7=1、错误和 restart 入口保留。
- proofs 先按 generation 排序，再从新到旧尝试；保留段恢复升序，binary_search 与完整 Key 比较继续成立。

## r2 正常验收修正复核

首轮 HIGH 已解决：ingest(n) 的 Handle/Advance/Prepare 只审核写前历史，因此收尾最多持有 n−1 个已审 cut。r2 第一请求明确要求来源费为 0、retained_capture/selection 为 null；后续请求按 n−1 核对。两次重投的命中增量修为 2+3=5；restart 仍冷核 3cut。两个既有正常 driver 测试同步处理空池，三次 append 只有第三次入口带非空旧池，nonempty_shared 改为 1。

静态核对新增正常测试的实际类型与 Fixture 边界：prepared Fixture 的 3cut 加第4cut合法追加未超出四事件时钟；driver Fixture 只调用三个已有输入；owner 使用实际 PublishedCut 的字段。完整 cold 输出、全部表行、可达 tuple、保留 tuple 字节与原 Vec 指针对拍均有断言。新增合法无关原件测试经原 TxStore/write_value 追加正常材料，再核完整输出和旧 Counts 命中，没有故意坏数据或故障注入。

r2 相对 r1 仅改变正常测试，生产闭包与缓存实现逐字不变。旧负例全部保留且未执行。尤其旧 `cross_request_source_cache_unrelated_original_change_is_conservative_miss` 仍带全池时代的无关材料变化失效断言；本次按已授权 D 闭包策略审核，不宣称该历史策略断言或完整旧负例回归通过。

结论：**PASS，限定静态**。90,961,246B 是之前的正常151材料测量，尚未包含本实现新增证书与构造成本。CPU、codec 根清零的收益损失、256MiB pager / S7=512MiB / 30秒实际窗口均须由根任务实测；本报告不证明生产资源资格或正式9011完成。

## r3 正常夹具差异复核

**PASS，仅 r2 至 r3 的有限静态差异。** r2 编译及首个预算测试通过由根的 `BUILD-RESULT.json` / `TEST-RESULT.json` 记录；owner 测试在原夹具 publish 失败，日志保留于 `TEST-normal-2.txt`，SHA256 为 `962e27e614618f847e83e3bfea8c6c4cc6471a4363dd7204879e4e0251b50911`。此处 PASS 指夹具调整符合已授权范围，不表示 r3 已执行通过，也不撤销 r2 的失败事实。

已回读真实日志和调用链：panic 在 cache.rs 的 `f.publish(...).unwrap()`；Fixture.publish 调用 Runtime.commit，以 context=None 构造生成态，原 `source_audit::audit_generated` 的 partition/raw 完整覆盖门报 `SourceAuditInvalid：同cut组未完整覆盖生效原始账`。owner 测试必须先完成三次 publish，之后才创建 Native context/Keeper，最终才调用新有界构造。因此该次失败早于 Counts subset retention、原件裁剪与 owner 断言。只凭这次日志不裁定同价一般输入域的正确性。

实际四文件比对确认，r3 唯一非格式差异是新增 owner 测试的 OHLC 从 `(6,12,3,7)` 改为已通过预算测试使用的 `(6+n,12+n,3+n,7+n)`。cut 数、identity、时间、revision、全部业务审核与完整输出/tuple/Vec指针/节点排除/费用断言逐字不变。unrelated 新正常测试、旧测试、生产闭包及缓存实现均保持原字节。

- r3 增量补丁 SHA256：`2d619814471529d6f878ccfdb1a9fb6bb38a912d5f35055ff6b762393a511c99`。
- r3 cache.rs SHA256：`39a8d5ab5f6b302a098abc3a27f0377dfcc83560269db4fbe1365c99d0367116`。
- 其余三文件仍为上述 r2 SHA；四文件 r2/staged 历史快照、r3 staged、增量补丁、NOTE-r3 与原失败日志均已实际重新计算并核对 `SHA-r3.json`。

本轮没有编译、测试、SQL、服务或重跑失败；不要求执行同价负例，不改来源审核，不把后续变价正常验收提升为同价域通过。原 r2 SOURCE、二进制绑定及失败证据由根任务保留；后续实际结果应绑定 r3 源码另行报告。
