# #1394 Counts 稀疏池 r2 正常验收修正

r1 的 `PATCH.diff`、`SHA.json`、`NOTE.md` 保留不动；r1 完整 staged 快照恢复并校验于 `r1/staged/`。当前 `staged/` 是 r2，以 `PATCH-r2.diff` 和 `SHA-r2.json` 为验收对象。

修正来自独评的可信 HIGH：Driver 的 Handle/Advance/Prepare 先审核写前历史，post-COMMIT 只移交已封存证明，不重新审核新 head。请求n结束时最多保留n-1个已审cut；第1次请求的空组不留pool，因此 retained_capture/counts_subset_selection 为null、retained_counts_proofs与来源费均为0。没有改变审计时序，也没有认证尚未审核的新head。

本次只修改正常测试：新增driver验收期望改n-1并处理空池；第一次repost命中cut1/2，第二次repost才可命中cut1/2/3，两次合计增加5次hit；restart仍冷核3cut。既有正常 `source_keeper_driver_append_repost_restart_preserves_results_and_request_reuse` 放在非空池分支检查memo与body费；既有正常共享S7测试第1次结束保留0，第3次入口才有非空旧pool，nonempty_shared应为1。measured_cap重投已存在cut1的测试不变。

新增纯正常 `v3::cross_request_source_cache::tests::counts_subset_normal_unrelated_legal_append_keeps_complete_counts`：经原TxStore/write_value入口增加合法完整F原件，完整audit与旧冷核输出相等、既有完整Counts命中，新增无关根不由稀疏owner持有。它与r1正常owner排除模板根验收共同说明新D策略，没有伪造、坏数据、故障注入或新heap门。

生产实现及原codec/cache/checkpoint/正文移交逻辑相对r1逐字不变。旧故障/坏数据测试全部逐字保留。旧unrelated_original_change要求“无关原件变化也应conservative miss”的策略断言继续保留、未执行，不以本次正常验收声称完整旧回归通过。r1的CPU/codec收益损失与正常实窗待验证边界保持。

仅运行rustfmt和git apply --check，对staged作语法解析/格式及补丁适用性检查；没有编译、测试、SQL或服务。
