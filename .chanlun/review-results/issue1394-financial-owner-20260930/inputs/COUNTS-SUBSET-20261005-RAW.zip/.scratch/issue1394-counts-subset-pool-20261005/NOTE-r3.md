# #1394 Counts 稀疏池 r3 正常夹具修正

r2编译成功由根的BUILD-RESULT.json记录，首个新正常多cut预算测试通过。第二个owner测试在publish helper（实装cross_request_source_cache.rs579）失败，报SourceAuditInvalid：同cut组未完整覆盖生效原始账；TEST-normal-2.txt和原SOURCE/BUILD/frozen r2证据全部保留。后续测试尚未运行。

只读定位：Fixture.publish（prepared.rs818-825）调用Runtime.commit，commit_impl使用context=None（prepared.rs148-155）；prepare构造本次生成态时在prepared.rs537调用原source_audit::audit_generated，source_audit.rs1567-1568对组partition与有效raw全集作原严格检查。owner测试必须先完成三次publish，之后才创建Native审核context并取得capture，最终再调用build_bounded_counts。因此日志中的错误早于本次新bounded retention和owner裁剪断言。三条同价bar的正常夹具触发了既有生成态组覆盖门，本轮没有复现或查SQL，不说明同价一般域正确或错误。

r3只改已失败的新增owner正常测试的价格夹具。owner仍为3cut、a/b/c、时间0/10/20和revision1，OHLC改用首个已通过测试的逐cut6+n/12+n/3+n/7+n。unrelated合法append仅使用单cut seeded，未出现这项失败，保持逐字不动。旧seeded和所有旧测试不变。

r3不修改任何生产实现、来源审核、裁剪或预算判据，不跳过报错。owner的全部完整冷对拍、保留tuple原字节/Vec指针、排除节点、97B节点费和完整源费断言保留。未新增坏数据、故障或heap门；不把夹具调整当作同价一般域资格化，也不把尚未执行的r3验收称为通过。

r1/r2补丁与SHA保留。r2/staged已按SHA-r2.json恢复4文件快照。当前staged为r3；PATCH-r3.diff是对当前已应用r2源码的增量补丁，仅已失败新增owner正常测试的价格夹具变化，SHA-r3.json绑定r2与r3每文件字节及既有失败记录摘要。根应用此差异后重新freeze/编译；本代理仅rustfmt与git apply --check，没有运行Cargo、测试、SQL或服务。
