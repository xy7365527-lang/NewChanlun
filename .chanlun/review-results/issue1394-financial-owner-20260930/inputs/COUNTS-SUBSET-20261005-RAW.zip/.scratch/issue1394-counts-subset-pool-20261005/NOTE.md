# #1394 Counts 完整闭包稀疏池 staged 实施

基线为 `SHA.json` 的 HEAD。只改本目录 `staged/` 下四份源码副本，交付 `PATCH.diff` 与 SHA。没有修改真实 Rust 源码、旧 SQLite pager 配置、SQL 配方、服务或数据库。没有运行 Cargo、测试或服务；rustfmt 只解析并格式化 staged，`git apply --check` 只校验补丁可应用性。编译、独评与正常实窗由根任务负责。

## 改动与依赖证明

`AuditCapture::into_counts_original_subset_for_testonly` 按值消费 Native capture，清旧 request memo/F/codec 根。一个新 Public Verifier 与一个 collector 从新到旧处理各 Key.state：原 path 核完整枚举顶层字段骨架与键，选择 objects/witnesses/observations 三声明，随后原 verifier 对三根完整展开。collector 同时覆盖 read 与 checked_read，每个 D 必须对应同一 capture 原完整 tag/body。跨组 memo 只可指向此前已完整接纳的 union；不是用单组 actual-read 差集冒充单组完整闭包。

每组保存新增 D 顺序长度与费用 checkpoint；三根核完后，才由 codec 内部私有构造 Counts 依赖证书。材料+固定SQL/frontier+该组原 Key/Counts+新增证书总费用超过 cap 时，撤销该组新增 D，并立即停止和丢弃整个 verifier。此前完整组保留；最大组单独超额或空组不保留任何 Counts proof。缓存 proof 按 generation 排序后反向尝试，保留段仍为升序，旧 binary_search 不变。

依赖证书保存完整 state ContentRef，以及三个完整根 ContentRef 和 codec/dependency 两个 u32 revision；matches_state 比较 format/root/kind/extent 全部，不接受 caller supplied success/bool。Trial.lookup 还要求对应私有证书版本和完整 state 声明匹配。

D 构成最终稀疏 HashMap。通过旧 HashMap.drain 把保留 NativeNode/body Vec 移进新表，排除节点在 drain 迭代直接 drop；旧索引随后也释放。没有 clone 全正文、共享旧全池 owner 或保留排除 body 的边表。collector 新生成的 F proof 在移交后再次清空。

原全表 capture 与所有行解码/去重/错误处理、旧 D 全 tuple 完整匹配、原 Binding SQL、完整 Key、fresh control/raw/history/index、真实 put/publish 及最终 codec 门均未改变。同 handler 原完整 capture 的 codec 根复用保持原路；跨请求的稀疏 Keeper codec 根为零。Ordinary/Owned 未接入。

## 源费与共享预算

旧 Pool::build 保留给 footprint 离线测量；运行 Keeper 改调 build_bounded_counts。fixed = frontier 8B + 原 ExactRows 完整字节费 + 空 codec 证书结构原费43B。D 的费仍是 body.len + 97B/node；原 Key/Counts 配方不变。

新增每组证书费为两 u32 revision 的8B，加4份完整 ContentRef。每份收费 `8+format.len+8+root.len+1+9`，包含两个文本长度前缀、全部格式/根字节、kind、Option extent。正常 s-content/1、68字符根为428B/组。没有独立持久化的逐组 digest 差集或依赖边表；D owner 即保留的 union。Proof inline 和4份声明 String capacity 另进 retained capacity，临时 collector/set/order 与 verifier workset 不被伪装成持久证书或 heap/RSS 资格。

构造后原 Pool 计费再次重算，必须逐项等于 collector 接纳总费且 ≤cap，才可保留。原 legacy+old_pool+manifest workspace 的 S7=536870912 入口账及 post-COMMIT 可丢弃收尾不动；原 request context 在移交前 drop 历史 result/binding，并且旧 source_prior 已退出本次完整 audit。新增 retained 池无新额度。仅隔离 test helper 的 Trial.complete 增加既有 keeper cap 参数，和运行保留使用同一构造。

## 新增正常验收草稿

- `v3::cross_request_source_cache::tests::counts_subset_normal_multicut_bounded_groups_match_complete_cold`：真实3cut，完整 cold audit 输出相等；实测可容纳1个最新完整组的正常 cap，第二组超额撤销并停止；其余2cut原核、合法第4cut追加、重启冷核；两个合法不同 state 声明的证书分别只匹配自身。
- `v3::cross_request_source_cache::tests::counts_subset_normal_owner_releases_unselected_originals_and_keeps_exact_tuples`：正常3cut独立保守闭包 D 与稀疏 owner 数量相等；保留 tag/body字节和原Vec指针相等，未选 template 根不再由 owner 持有，body费下降；节点97B与证书总费精确对账。
- `v3::driver::tests::counts_subset_driver_normal_rows_append_repost_restart_and_shared_s7`：3次真实 Native请求与旧冷Native/Ordinary回复、完整rows及可达原字节相等；两个repost与restart完整rows；原 legacy+old_pool+workspace≤S7，跨请求codec根为0。

以上仅为写好的验收，不代表通过。没有新增故意坏数据、故障注入、malloc或全heap门。旧测试函数全部保留，既有负例未运行。旧“无关原件也全部保留”的负例断言来自全池策略；本版D刻意不持有无关子图，根需要据本次授权边界评估该历史断言，不能拿它宣称本版已覆盖所有旧负例。

## 代价与未验证

实测正常151的90,961,246B是材料测量，不是本 staged 构造实窗读数；新增完整证书每组428B还须由新正常实窗验证。新 collector 增加一次导航和保守完整闭包展开，跨请求清codec根还会失去先前约3%的codec复用收益。必须测请求CPU、保留费和workspace变化；当前不声称30秒可过、完整9011完成或全资源资格。
