# #1394 Counts 完整proof组subset pool正常窗口准备

本目录是 #1394 的工作草稿，只准备正常150/151窗口。候选构造按完整源Proof依赖闭包保留，并清空跨request codec roots；实际正常输出必须与已通过的256MiB pager窗口相同。尚未运行本候选，不宣称收益或生产准入。

复用 `.scratch/issue1394-sqlite-pager-256m-window150-151-20261005/window.py`，仅替换新具名域、服务路径、socket与scope说明。完整请求/reply/persistent oracle、来源stat/hash、lifecycle、首次失败不重试和cleanup照旧。脚本差异见SCRIPT.diff，输入与材料引用差异见BINDINGS.diff。本轮未复制数据库、运行SQL、服务、Cargo或测试，未生成新service binding。

## 固定配置、来源与基准

- 新窗口：`.scratch/issue1394-counts-subset-window150-151-20261005/`。
- 冻结服务：`.scratch/issue1394-counts-subset-pool-20261005/frozen-service`，runner硬锁此路径。
- 新自有域：`/Volumes/AgentStorage/issue1394-counts-subset-window150-151-20261005-r1/`。
- socket：`/private/tmp/nc1394-csubset150-151-20261005-r1.sock`。
- env继续为S_CAPTURE_NATIVE_TESTONLY=1、S_MANIFEST_WORKSPACE_DIAGNOSTICS=1、S_NATIVE_SQLITE_CACHE_KIB=262144。Observed Popen保留实际env，finally恢复原值。
- 启动与每次完整请求均为30秒；S7继续为536870912字节来源预算，pager hint不是RSS上限。

来源仍是 `.scratch/issue1394-root-text-window143-160-20261004/RESULT.json` 封存的CopyQualified149，原件三文件在 `/Volumes/AgentStorage/issue1394-root-text-window143-160-20261004-r1/`。本窗口不使用刚测的151副本，否则输入150会重复。原件只允许bytecopy/stat/hash，禁止SQLite-open；SQL仅在本次新副本执行。来源149及原件105、来源126/142的既有Unknown保留，独立窗口不拼接完整9011。

完整对照是已通过的256MiB窗口RESULT/ROOT-RESULT，实际耗时为150的17.691335209秒、151的17.030979916秒。SOURCE-LIST与Python binding记录其原始result/root/runner hash；EXPERIMENT-INPUT也已绑定。

## 运行前条件

主控完成本次candidate的独立验收、冻结源码与实际服务构建，在本窗口写真实BINARY-BINDING-service.json。必须绑定本次非test的s_structure_session bin、真实binary/source SHA、source_manifest及fixed_source；不可搬用旧service hash。runner运行前重新核实际binary、冻结源码逐项、脚本及Python/材料绑定，收尾主控重新核。

确认新OWN/socket/RESULT.json/execution尚不存在，AgentStorage已挂载且有复制空间。原来源生命周期及三原件stat/hash封条由runner运行时核。保留既有资源和正常输入，禁止故障注入、坏数据及恢复取消的birth-only/candidate/wire方案。

## 唯一运行命令

主控完成前置条件后，从工作树单次执行：

```bash
cd /Users/silencehan/.codex/worktrees/issue1394-audit-prefix/NewChanlun
/Users/silencehan/.local/bin/python3.12 -B .scratch/issue1394-counts-subset-window150-151-20261005/window.py > .scratch/issue1394-counts-subset-window150-151-20261005/RUN.stdout 2> .scratch/issue1394-counts-subset-window150-151-20261005/RUN.stderr
```

首次意外失败保留现场、完整证据和未发送尾部，不重试、不重发。退出码0不能代替RESULT与完整oracle验收。

## 主控独立验收

- RESULT为COMPLETE，Ready对应唯一serve Popen，received严格为150/151。完整wire请求/回复、payload及persistent oracle通过既有evidence校验，并与256MiB基准逐条相同。
- 两条完整交换均在30秒内。最终generation151、idle、Committed151、published151、clocks453、next_attempt_ordinal152。失败时持久提交不推成收到回复。
- 原样保存SERVICE-DIAGNOSTICS.log并登记SHA。核实际262144 pager env/startup readback与原WAL/FULL/fullfsync/autocheckpoint；比较pager统计、完整耗时与RSS快照时保留量纲及单次窗口局限。
- old_pool和allowance允许与基准不同，不能硬写旧382MB数值。S7仍为536870912，主控根据两次实际预算日志比较省下的来源额、新收费和新keeper别名。完整proof组保留、依赖metadata收费与codec roots清空的生产行为须按实际证据记录，未观测项写明，不以补丁说明代替运行证据。
- 三原件完整stat/SHA前后不变；源码/binary/材料绑定收尾重核。SQL始终只在本次新副本，保留全部execution、新副本、stdout/stderr与首次失败原状。
- 同一Popen全部回收、controller关闭、socket移除，cleanup_errors为空；主控写ROOT-RESULT并列明oracle、deadline、真实预算、keeper、源封条、绑定和cleanup观察。

通过本窗口只覆盖同来源正常150/151；不代表完整9011、稳定性能增益或整体heap/RSS/I/O资格化。本准备不扩大资源门，不涉及前端。
