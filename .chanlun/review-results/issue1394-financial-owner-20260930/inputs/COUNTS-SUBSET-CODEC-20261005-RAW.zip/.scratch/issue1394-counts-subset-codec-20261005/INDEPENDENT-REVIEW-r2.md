# #1394 Counts codec r2 Driver 正常测试增量独评

**结论：PASS。** 本轮只审查 `rust/src/bin/s_session_v3/driver.rs` 中 `counts_subset_driver_normal_rows_append_repost_restart_and_shared_s7` 的断言修正，不重复生产实现全审。r1 的 `INDEPENDENT-REVIEW.md` 继续适用于逐字未变的两个原文件。

## 固定绑定

- 完整 PATCH-r2.diff SHA-256：`7f7e0309509edc6c8bf033376f44b30d02be1252a6501fa0d3178b0c5a3792f4`，已独立计算并核实。
- SOURCE-r2.json aggregate：`01c89caba489e75372e82ba0437618b173ea628ba9ef9f46c37e41d1fb282f3c`，已按其声明的 entries JSON 公式独立计算并核实。
- Driver 当前完整文件 SHA-256：`0b39c5e60a5a2e43571907d05b5d2ebfa22754fa37e043ec9c37193122620ed3`，与冻结清单一致；新增补丁区块的新侧与当前 Driver 源码逐项一致。
- 与 PATCH.diff 按文件区块比较，r2 唯一新增区块属于 Driver；`s_content.rs` 和 `cross_request_source_cache.rs` 的全部原补丁区块逐字相同。两文件现哈希仍分别为 `862b87884855d4be61d58a8077c30de1cd6109fdf62548ecc807196b93526a65` 和 `19bc401adf0a385f85ecd7f99f64467f9bae628e8967b7394fa7c9b0ed63edef`。
- 根任务已明确声明 r2 冻结。评审没有要求工蜂恢复改码，没有修改任何源码。

## 概念与断言审查

**通过。** 已接纳的 n−1 组，每组保存至多三个经完整 Public/Value 核验的根，组内及跨组共享根去重。因此在 n>1 的分支，`1..=3*(n-1)` 是有限唯一根数的正确范围；n=1 仍单独检查零缓存和空 selection/capture，未被此范围覆盖。原 `public_roots==0` 与批准的有限根复用设计相冲突，改掉该断言属于适配设计，未删除需要保留的业务行为。

新增 `codec_root_certificate_bytes == 43 + 32*public_roots` 检查实际保留集合计费，新增 `retained_source_cost == selection.retained_source_bytes` 检查最终 Pool 与提取器费用全等。它们与 r1 已独评的精确根集合及去重费用正常测试互补，没有声称这个范围断言独自证明根集合身份。

Template 根仍严格为 0；已接纳组数和 retained Counts proof 数仍为 n−1。周边全部 reply 与普通/冷 Native 结果等价、持久表逐项一致、完整可达材料一致、共享 S7 预算、重复提交命中数、重启冷起点和重启后的表及材料比较断言均原样保留。PATCH 没有改生产代码、断言 fixture 或旧故障测试。

## 工程层审查

| 严重级别 | 数量 | 状态 |
| --- | --- | --- |
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | info |
| LOW | 0 | note |

本次有限循环 n=1..3，根计数读取为 u64，边界和 43+32R 运算在该测试输入域内无溢出问题。未发现必要缺陷。

## 验证与原失败边界

根任务提供的 r1 结果为 lib 三项和 bin 前三项正常通过，第四项 Driver 因旧零根断言失败（实际值 3）；本评审没有运行 Cargo、测试、SQL 或 git，也没有覆盖、重写或删除第一次失败证据。r2 Driver 仍需由已指派验证代理在新冻结 bin 上执行正常检查；不新增故障注入或坏数据验收门，旧负例保持且不运行。

**最终结论：PASS（Driver 正常测试断言增量静态独评通过，可继续已授权正常验证）。**

## r3 单行类型修正复核

r2 实际编译报 E0308：`Fixture::ingest` 使 n 为 i64，而 public_roots 为 u64，原 range.contains 因此类型不匹配。此前静态审查漏看此类型约束，r2 PASS 不能作为编译或类型检查通过的证据；首次 r2 BUILD-dual-r2 失败保持原件，本评审没有覆盖它。r3 唯一代码变化是 Driver `:1356` 改为 `1..=3 * u64::try_from(n - 1).unwrap()`（另有 PATCH 的 index 元数据自然变化），明确把 range 端点统一为 u64。该断言仍只在 n=2/3 分支执行，n−1 为 1/2，转换可成立，上限、唯一根范围及 43+32R/Pool 全等费用语义不变。原两文件完整 SHA 与 r2 相同，所有其他补丁文本不变。独立核实完整 PATCH-r3 SHA `71d607a7b3580873e5e492b46451472f9ca1fbcb15d19872282936f2592142be`、SOURCE-r3 entries aggregate `f5e596ab408531dac56de7142b323b4ee5ac1d24bcf8a9348d0ea218e682c194`，以及 Driver 当前 SHA `4f66617909bfb129a2813192b4321a2c8b2e938a8c73128e4f6235c640662314` 与冻结清单一致。**r3 单行增量静态复核 PASS，可继续已授权编译验证**；本评审未运行编译、测试或 SQL，不宣称实际编译通过。
