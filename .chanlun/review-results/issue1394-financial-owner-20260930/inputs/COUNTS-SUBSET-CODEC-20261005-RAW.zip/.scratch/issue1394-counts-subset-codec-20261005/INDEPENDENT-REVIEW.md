# #1394 Counts 子集 codec 有限成功根独立审查

## 代码审查报告

**结论：PASS。** 固定补丁满足已批准最小设计，未发现置信度超过 80% 的必要缺陷。本报告是源码与正常测试内容的独立静态审查；没有运行 Cargo、测试、SQL、服务或实窗，也没有执行 git 操作或修改源码。

审查依据：`.scratch/issue1394-counts-codec-roots-analysis-20261005/NOTE.md`，以及当前指派明确的有限 Counts codec 根复用验收条件。

### 固定补丁与冻结确认

- PATCH：`.scratch/issue1394-counts-subset-codec-20261005/PATCH.diff`
- 完整 PATCH SHA-256：`b65e7a2339a38cb7cc66f12e69e2ba83d19995d55526ce0f2df9ca8474ca5454`
- 工蜂 `counts_codec_impl` 明确声明「源码已冻结，我不再改码」，同时提供上述路径及 SHA。
- 独立计算的 PATCH SHA 与声明一致；补丁全部 10 个区块的新侧内容与当前源码逐项一致。PATCH 仅含以下两份授权文件，第二份文件只有正常测试断言变更。

| 文件 | 当前完整文件 SHA-256 |
| --- | --- |
| `rust/src/s_content.rs` | `862b87884855d4be61d58a8077c30de1cd6109fdf62548ecc807196b93526a65` |
| `rust/src/bin/s_session_v3/cross_request_source_cache.rs` | `19bc401adf0a385f85ecd7f99f64467f9bae628e8967b7394fa7c9b0ed63edef` |

### 概念层质询结果

**通过。** 本次变更涉及 codec 证明、原件依赖与费用接纳，不改变笔、中枢、背驰或其他缠论领域定义。概念依据是批准 NOTE 中的同一严格判据、完整闭包、真实原件绑定和整组接纳条件；没有以生产现状替代定义。

| 质询 | 源码证据与结果 |
| --- | --- |
| 根资格来自完整核验 | `s_content.rs:2284` 建立全新 Public Verifier；三个 objects/witnesses/observations 根在 `:2311` 循环完整 `verify_refview` 成功后构造私有证书。新增根仅从证书的三根提取，未新增 setter 或外来资格 bool。所有资格保持 Value。 |
| 去重与接纳门 | `s_content.rs:2324` 的候选数组先组内去重，再排除先前已接纳集合；`:2337` 以唯一 digest 数乘 32 B，`:2344` 将其纳入整组 required。`:2350` 超额门之后才 reserve、接纳证书并扩展持久集合。 |
| 边界与共享根 | 正常低 cap、第一组预算缺少根费、两组重复根是可具体推演的边界。超额分支只回滚 checkpoint 后的新 D，候选根未插入，已有共享根未删除；随后 break，块退出即丢弃含半组 seen 的 Verifier。没有继续处理后组的路径。 |
| 费用推论一致 | `cross_request_source_cache.rs:179` 的 fixed 包含一次 `codec_root_source_bytes(0)`，按 `:165` 配方为 43 B；提取器只增收 32 B/唯一根。Pool `:254` 以实际 Public/Template 根数按同一配方重算，`:208` 检查非空接纳集合的最终 total 与 selection 精确全等且不超过 cap。四个完整 ContentRef 的 Counts 证书费用仍独立计入。 |
| 清理与范围 | `s_content.rs:2388` 保持 `into_originals_only_for_testonly`，清空 codec、Public/Template 所有语义 memo 与全部 Frame proof；`:2390` 随后只私有赋值 admitted Public 集合，Template 默认空。generated_state 只参与导航，没有作为完整成功根发行；旧全集根没有恢复。 |
| 下一请求同判据 | 未改 `s_content.rs:2455` 的封闭播种接口；它仍逐个比较 previous owner 的真实 digest/tag/body 与 current owner，检查 format/revision/flavor 后才播种。`:4439` 仍逐根检查 digest/format、当前 Frame、kind 和 extent，再执行闭包核，seen 不跳过根声明。没有宽松重判通道。 |
| 业务与错误边界 | PATCH 没有改业务、Fresh、SQL、put 或提交顺序。根集合与证书 Vec 先 try_reserve，失败返回现有错误；`cross_request_source_cache.rs:450` 的 post-COMMIT retain_completed 仍消费该错误并丢弃可选缓存，不改变成功业务回复。 |

未发现概念不一致，因此无须把本次变更登记为新矛盾或援引历史矛盾作为通过依据；工程层可以继续。

### 工程层审查

| 严重级别 | 数量 | 状态 |
| --- | --- | --- |
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | info |
| LOW | 0 | note |

新增生产逻辑局限在已有提取器；候选至多三根，数组索引与新增数上界一致。费用使用 checked 运算；新增持久容器分配使用 try_reserve。既有 retention 继续报告真实根数量和 HashSet capacity，Pool capacity 按原配方披露，没有把逻辑源费用包装为总 heap/RSS/I/O 资格。

### 正常测试内容审查与执行边界

新增 lib 正常测试覆盖精确三根集合、generated_state 排除、旧 collector/Template 根清除、组内及跨组共享根去重、43 + 32R 精确费用、清空 Frame/memo、真实成功播种及当前 header 仍读取、低 cap 只留先前完整共享根，以及第一组根费不足时零接纳。更新的两项 bin 正常测试核对完整组低 cap 费用、428 B/Counts 证书、实际根 capacity 和 Pool/selection 全等。

上述内容已静态审阅，**本评审没有执行这些测试，不声称测试运行通过**。工蜂报告限定 rustfmt 检查与 diff 空白检查通过；该运行结果属于工蜂报告，主控的正常验证结果应另行绑定相同固定 PATCH。

没有新增、修改或运行故障注入或坏数据测试；既有负例保留且未运行。未恢复已取消的 birth-only、candidate 或 wire 工作。不推算性能收益，不宣称整个 #1394、正式 9011 双跑、生产捕获或完整资源资格已完成。

**最终结论：PASS（固定补丁的独立概念与工程静态审查通过）。**
