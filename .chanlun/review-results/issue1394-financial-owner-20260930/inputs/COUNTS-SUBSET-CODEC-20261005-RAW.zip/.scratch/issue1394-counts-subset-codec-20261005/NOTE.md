# #1394 Counts子集codec有限成功根：ready待独评

源码已冻结。仅改 `rust/src/s_content.rs` 和 `rust/src/bin/s_session_v3/cross_request_source_cache.rs`；PATCH.diff 只含这两份差异，不含其他代理的证据归档。

`admitted_public_roots` 为提取器局部私有集合。三个完整Public/Value闭包核验后，先算组内与跨组去重的新增根，再将32 B/唯一根计入整组预算。调用方 fixed 已含一次43 B，提取器不重复加。超额组回滚新增D并停止，候选根不入集合，既有共享根保留。证书Vec及根集合先try_reserve，错误仍交由已有post-COMMIT收尾丢弃可选缓存。

最终保留原有清Frame/memo/codec调用，清完仅将已接纳Public根私有赋值。Template保持空；generated_state没有完整根资格。CountsSubsetCertificate原428 B配方不变，Pool最终精确费用与selection全等检查不变，原retention继续披露根数及HashSet capacity。封闭真实tuple播种路径及SQL/业务核验/put/错误顺序均未修改。

已运行限定 rustfmt 与 rustfmt --check，通过；git diff --check通过。未运行任何cargo、SQL、测试、服务或实窗，未提交、push或merge。没有新增或修改故障注入/损坏数据测试。

## lib：新增的精确正常测试

- s_content::counts_subset_codec_root_tests::counts_subset_codec_normal_exact_roots_dedup_fees_and_success_seed
- s_content::counts_subset_codec_root_tests::counts_subset_codec_normal_low_cap_keeps_admitted_shared_roots_only
- s_content::counts_subset_codec_root_tests::counts_subset_codec_normal_first_group_cap_includes_unique_root_fee

feature: s_capture_native_testonly。

## bin s_structure_session：更新的精确正常测试

- v3::cross_request_source_cache::tests::counts_subset_normal_multicut_bounded_groups_match_complete_cold
- v3::cross_request_source_cache::tests::counts_subset_normal_owner_releases_unselected_originals_and_keeps_exact_tuples

feature: s_capture_native_testonly，与现行service feature集保持一致。
