//! 回测数据加载层——`analysis/data_cache/*.json` → 清洗 → 量化为整数 tick [`Bar`]。
//!
//! ## 认识论等级：**L1**（管线正确性，零信息增量）
//!
//! 本模块只做"读 JSON → 清洗坏 bar → 量化为 tick"——确定性数据变换，验证管线无 bug，
//! 不验证 Θ 在市场有效（formalization-validity-domain 231号）。
//!
//! ## 数据快照（协议 §1.1，只读，看结果前冻结）
//!
//! 10 个品种全部为 1min OHLCV 真实行情（databento / Binance 归档）。本模块加载时**独立
//! 核实** bar 数与时间边界（不照搬协议表格），与协议 §1.1 不符则 fail-loud（数据漂移）。
//!
//! ## schema（独立核实，2026-06-25）
//!
//! 全 10 品种为 parallel-array schema：`{opens,highs,lows,closes,volumes,dates,symbol}`。
//! `dates` 为逐 bar 字符串：databento 品种 tz-aware（`"2016-01-03 23:00:00+00:00"`），
//! BTC 无 tz（`"2017-08-17 04:00:00"`，协议 §1.2 [设计选择] 按 UTC 解释）。**10 品种统一
//! 用 `dates[..10]` 字典序切日期窗**（ISO 日期串字典序 = 时间序）——无 `timestamps_ns` 列。
//!
//! ## 不可交易判据（协议 §1.2 + reference-theta-v0.md:53，Θ_exec 继承）
//!
//! 缺 OHLC / `high<max(open,close,low)` / `low>min(open,close,high)` / volume=0 ⇒ bar
//! 标 `untradable=true`（**不删除**，进 [`Bar`] 但执行层不在其上成交）。这与
//! `recursive_t/backtest_run.rs::load_clean_ohlc` 的"删除坏 bar"口径**不同**——Θ_exec
//! 要求保留 bar 序列连续性 + 标注不可交易（§1.2"统计占比，不豁免只标注"）。

use super::super::config::ThetaConfig;
use super::super::types::{quantize, Bar, Timestamp};
use serde::Deserialize;
use std::path::{Path, PathBuf};

/// parallel-array schema（10 品种统一）。`Option<f64>` 容忍 Python `json(allow_nan)`
/// 写出的 NaN/Inf（预处理替换为 null → None）。
#[derive(Deserialize, Default)]
struct RawData {
    #[serde(default)]
    opens: Vec<Option<f64>>,
    #[serde(default)]
    highs: Vec<Option<f64>>,
    #[serde(default)]
    lows: Vec<Option<f64>>,
    #[serde(default)]
    closes: Vec<Option<f64>>,
    #[serde(default)]
    volumes: Vec<Option<f64>>,
    #[serde(default)]
    dates: Vec<String>,
}

/// 10 品种 → (数据文件名, bar 粒度秒数)（协议 §1.1 锁定 + #1281 §9 补录 ZN/6E）。文件名与
/// `recursive_t/backtest_run.rs::SYMBOLS` 一致（ZN/6E 为该表 §9 补录的同名文件）。
/// 粒度列让 load_by_symbol 随品种取粒度（C 点）——现有 10 品种全 1min 文件 ⟹ 60，对
/// load_symbol 仍传 60 ⟹ 1m 路径 bit-exact。1s 数据接入时此表追加 1s 条目（task-a 落盘后），
/// bar_seconds=1。
pub const SYMBOLS: [(&str, &str, u32); 10] = [
    ("BTC", "btc_1m_full.json", 60),
    ("ES", "es_1m_databento_10y.json", 60),
    ("CL", "cl_1m_databento_10y.json", 60),
    ("GC", "gc_1m_databento_10y.json", 60),
    ("BRN", "brn_1m_databento_10y.json", 60),
    ("DX", "dx_1m_databento_10y.json", 60),
    ("QQQ", "qqq_1m_databento_full.json", 60),
    ("OKLO", "oklo_1m_databento.json", 60),
    // #1281 §9 补录（prereg-windows-v0 冻结值扩展池）：17y 全量 1min 快照。
    ("ZN", "zn_1m_databento_10y.json", 60),
    ("6E", "usd6e_1m_databento_10y.json", 60),
];

/// `analysis/data_cache` 绝对路径（crate manifest 上一级）。
pub fn data_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 的父目录 = 项目根")
        .join("analysis/data_cache")
}

/// 已加载的数据集（量化后的整数 tick bar 序列 + 原始日期串，供日期窗切片）。
///
/// `bars` 与 `dates` 同长、同索引（一一对应）。`dates[i][..10]` = bar i 的 ISO 日期。
#[derive(Debug, Clone)]
pub struct Dataset {
    pub symbol: String,
    /// 量化后的整数 tick bar（含 `untradable` 标注，**不删除坏 bar**，保序列连续）。
    pub bars: Vec<Bar>,
    /// 逐 bar 日期串（与 `bars` 同索引）。用于日期窗切片（OOS/Holdout/walk-forward）。
    pub dates: Vec<String>,
    /// bar 粒度（秒）。数据事实∉Θ自由度（不进 config，避免扫描器把粒度当 Θ 维度扫，
    /// config.rs:3-7）。1min=60，1s=1。年化基数 `bars_per_year` 从此算（barspec-impl A 点）。
    pub bar_seconds: u32,
}

/// 一年的 bar 数（CAGR 年化基数）= 一年秒数 / bar 粒度秒数（barspec-impl A 点）。
///
/// 旧硬编码 `365.25*24*60`（一年分钟数）= `bars_per_year(60)` bit-exact。1s 数据 ×60。
/// `bar_seconds=0` 不可能（数据加载层保证 ≥1）。
pub fn bars_per_year(bar_seconds: u32) -> f64 {
    365.25 * 24.0 * 3600.0 / bar_seconds as f64
}

impl Dataset {
    /// 不可交易 bar 占比（协议 §5.5：>20% 该品种判据不评估；§1.2：>5% 标数据质量警告）。
    pub fn untradable_ratio(&self) -> f64 {
        if self.bars.is_empty() {
            return 0.0;
        }
        let n_bad = self.bars.iter().filter(|b| b.untradable).count();
        n_bad as f64 / self.bars.len() as f64
    }

    /// 按 ISO 日期闭区间 `[day_start, day_end]` 切片（协议 §2 样本切分）。
    ///
    /// 判据：`day_start <= dates[i][..10] <= day_end`（ISO 字典序 = 时间序，闭区间）。
    /// 返回新 `Dataset`（immutable，coding-style：不就地改）。窗为空时返回空 bars 的
    /// Dataset（调用方据 §5.5 判 inconclusive，**不 panic**——空窗是合法的"该品种该窗无
    /// 数据"，区别于切片口径错误）。
    ///
    /// ## source_index 重置为切片局部下标（坐标系契约，acceptance #5 实证坐实）
    ///
    /// `Bar.source_index` 在本系统承担**双语义**，二者在切片后必须一致：
    /// 1. **局部数组下标**：下游 `exec::fill_bar_index(source_index, bars, ..)` 用
    ///    `bars[source_index]` **直接索引当前 Dataset 的 bars 数组**（非跨 Dataset 溯源）。
    /// 2. **平局裁决键**（reference:16）：`(timestamp, source_index)` 单序列内唯一单调裁平局。
    ///
    /// `load_symbol` 对全集 Dataset 赋 `source_index = i`（全集数组下标），二语义在全集上一致。
    /// 切片若只 `push(*b)` **保留全集偏移**，则切片后 `source_index ≠ 局部数组下标`
    /// （OOS 首 bar 的全集偏移可达数百万 > `bars.len()`），下游 `bars[source_index]` 越界、
    /// `fill_bar_index` 对**每个** point 返 `None` ⟹ 全决策被吞（acceptance #5 实测：8 品种
    /// 全部 `decisions=0`，反事实重置 source_index 后 7 品种 decisions 转百万级，坐实根因唯一）。
    ///
    /// 故切片**重置 `source_index` 为局部 enumerate 下标 `0..len`**：既复原「= 局部数组下标」
    /// 语义（下游索引合法），又仍满足 reference:16（`0..len` 严格单调唯一，是合法平局键）——
    /// 不改 source_index 的任何**定义**含义，只把切片实现对齐到既有契约。
    pub fn slice_date_window(&self, day_start: &str, day_end: &str) -> Dataset {
        assert!(
            day_start <= day_end,
            "窗口非法：day_start `{day_start}` > day_end `{day_end}`"
        );
        let mut bars = Vec::new();
        let mut dates = Vec::new();
        for (i, b) in self.bars.iter().enumerate() {
            let day = self.dates[i].get(..10).unwrap_or("");
            if day >= day_start && day <= day_end {
                // source_index ← 切片局部下标（= 新 bars 数组下标，下游 bars[source_index]
                // 合法），复原全集 Dataset 上 `source_index == 数组下标` 的契约。
                let local_index = bars.len();
                bars.push(Bar {
                    source_index: local_index,
                    ..*b
                });
                dates.push(self.dates[i].clone());
            }
        }
        Dataset {
            symbol: self.symbol.clone(),
            bars,
            dates,
            bar_seconds: self.bar_seconds,
        }
    }

    /// 按 bar 索引半开区间 `[start, end)` 切片（时间序不打乱，train/OOS 切分用）。
    ///
    /// 半开区间保证相邻切片（train=[0,split), holdout=[split,n)）**无重叠**——区别于
    /// `slice_date_window` 的闭区间（边界天会被两侧重复包含）。`source_index` 重置为局部下标，
    /// 复原 `source_index == 数组下标` 契约（下游 `bars[source_index]` 合法，见 slice_date_window 文档）。
    pub fn slice_bar_range(&self, start: usize, end: usize) -> Dataset {
        let end = end.min(self.bars.len());
        let (mut bars, mut dates) = (Vec::new(), Vec::new());
        for i in start..end {
            bars.push(Bar {
                source_index: bars.len(),
                ..self.bars[i]
            });
            dates.push(self.dates[i].clone());
        }
        Dataset {
            symbol: self.symbol.clone(),
            bars,
            dates,
            bar_seconds: self.bar_seconds,
        }
    }
}

/// 把 ISO 日期串解析为单调时间戳（仅用于排序，不参与价格运算，types.rs:17）。
///
/// 取数字部分前 14 位 `YYYYMMDDHHMMSS` 作单调键——同序列内严格单调即可（协议平局裁决按
/// `(timestamp, source_index)`，source_index 已唯一裁平局）。秒位保留是 1s 数据的前提：
/// 1min bar 秒位恒 00（旧 12 位值 ×100，相对序不变 ⟹ 1m 路径 bit-exact），1s bar 秒位
/// 区分同分钟内的 60 根（否则时间戳塌缩，违反 reference:16 单调性，barspec-impl B 点）。
/// 不做完整历法换算（无 chrono 依赖；时间戳只用于排序，绝对值无语义）。
/// **本值单调但非度量** —— 差值不是时间间隔（`23:59:59`→次日 `00:00:00` 差 **1**，
/// 而 `23:00:00`→`23:01:00` 差 **100**）。
///
/// **#935 裁定（2026-08-07，map #931）：结构层不引入时间。** 依据是缠论基础判据里
/// 一个时间量都没有（`018:24` 中枢＝纯价格区间 max/min、`065:24` 包含＝纯高低比较、
/// `077:38` 笔的间隔**数 K 根数**），以及 `075:137`【答疑】逐字「跳空不改变任何事情，
/// 如果这缺口在线段里，还是线段；在笔里，还是笔」。⟹ 结构判据**不消费本值做度量**，
/// 故本编码**无需改**，`qujiantao.md` 残余风险第 25 条的结构层那一半按此免测。
///
/// ⚠️ **若将来有代码要拿它算真实时间间隔，必须先改编码** —— 且本函数在仓内有
/// **31 份各自复制**（检索式 `grep -rn "fn date_to_timestamp" rust/ | grep -v target`，
/// 2026-08-07 实测：本处 1 份 + `rust/src/bin/` 下 30 份），**改一处不够**。
fn date_to_timestamp(date: &str) -> Timestamp {
    // "2016-01-03 23:00:01+00:00" → 取 "20160103230001" 数字部分（年月日时分秒，单调）。
    let digits: String = date
        .chars()
        .take_while(|c| *c != '+') // 去掉 tz 后缀
        .filter(|c| c.is_ascii_digit())
        .take(14) // YYYYMMDDHHMMSS
        .collect();
    digits.parse::<i64>().unwrap_or(0)
}

/// 加载单品种全量数据（量化为整数 tick bar，标注不可交易）。
///
/// `tick_size` 来自 [`ThetaConfig`]（默认 1e-8，types.rs:24 `quantize`）。**不删除坏 bar**
/// （区别于 recursive_t 口径）——保序列连续 + 标 `untradable`（Θ_exec §1.2 要求）。
///
/// 边界条件：文件不存在 ⇒ `Err`；JSON 解析失败 ⇒ `Err`；五列长度不一致 ⇒ `Err`
/// （fail-loud，no-patch）。
pub fn load_symbol(
    path: &Path,
    symbol: &str,
    config: &ThetaConfig,
    bar_seconds: u32,
) -> Result<Dataset, String> {
    if bar_seconds == 0 {
        return Err("bar_seconds 必须 ≥1（粒度秒数，bars_per_year 分母）".to_string());
    }
    let text = std::fs::read_to_string(path).map_err(|e| format!("读取 {path:?} 失败: {e}"))?;
    // Python json(allow_nan) 写出 NaN/Infinity（serde_json 硬拒）→ null。
    let text = text
        .replace("-Infinity", "null")
        .replace("Infinity", "null")
        .replace("NaN", "null");
    let raw: RawData =
        serde_json::from_str(&text).map_err(|e| format!("解析 {path:?} 失败: {e}"))?;
    drop(text);

    let n = raw.closes.len();
    if n == 0 {
        return Err(format!("{path:?} 无 closes 数据"));
    }
    for (name, len) in [
        ("opens", raw.opens.len()),
        ("highs", raw.highs.len()),
        ("lows", raw.lows.len()),
        ("dates", raw.dates.len()),
    ] {
        if len != n {
            return Err(format!("{path:?} 列长度不一致：{name}={len} vs closes={n}"));
        }
    }

    let tick_size = config.tick.tick_size;
    let mut bars: Vec<Bar> = Vec::with_capacity(n);
    for i in 0..n {
        let o = raw.opens[i];
        let h = raw.highs[i];
        let l = raw.lows[i];
        let c = raw.closes[i];
        // volume 列可能缺失（部分 schema），缺失按 0（→ untradable）。
        let v = raw.volumes.get(i).and_then(|x| *x).unwrap_or(0.0);

        // 不可交易判据（协议 §1.2 / reference:53）。缺 OHLC 或越界或 vol=0 ⇒ untradable。
        // 坏 bar 用前一根 close 填充价格（保序列连续，但标 untradable 不在其上成交）；
        // 首根坏 bar 无前值时用 0（量化后 tick=0，untradable 已标注，执行层不触碰）。
        let valid_ohlc = matches!((o, h, l, c), (Some(_), Some(_), Some(_), Some(_)));
        let (oq, hq, lq, cq, untradable) = if let (Some(o), Some(h), Some(l), Some(c)) =
            (o, h, l, c)
        {
            let bad_range = h < o.max(c).max(l) || l > o.min(c).min(h);
            let bad_price = o <= 0.0 || h <= 0.0 || l <= 0.0 || c <= 0.0;
            let mut untradable = bad_range || bad_price || v <= 0.0;
            let (mut oq, mut hq, mut lq, mut cq) = (
                quantize(o, tick_size),
                quantize(h, tick_size),
                quantize(l, tick_size),
                quantize(c, tick_size),
            );
            // ★#922 坏 tick 闸：bar 四价对**前收（已净化）**的最大偏离 > 80% ⟹ 数据损坏
            // （价格坍缩至近零的坏 print），按缺 OHLC 同款处置——前收填充 + untradable，
            // 统计层（σ_GK 等）与执行层都不再见到坏值。对净化前收比较 ⟹ 坏 tick 次根的
            // 正常回弹不被误伤（BRN 2024-02-19 17:42 实证）。
            // 阈值依据（全品种存量扫描，chanlun/review-results/issue922-bad-tick-scan-20260816.md）：
            // 合法极端 ≤0.40x（CL 2020-04 负油价时代、BRN 2019-09 沙特遇袭跳空）；
            // 坏 tick ≥0.999x（坍缩近零）——空档 (0.40, 0.999) 取 0.80，双侧余量 ≥2×。
            if !untradable {
                if let Some(prev) = bars.last() {
                    if prev.close > 0 {
                        let pc = prev.close;
                        let max_dev = [oq, hq, lq, cq]
                            .iter()
                            .map(|q| (*q - pc).unsigned_abs() as f64 / pc as f64)
                            .fold(0.0_f64, f64::max);
                        if max_dev > 0.80 {
                            eprintln!(
                                    "[data] #922 坏 tick 闸：{symbol} bar#{i}（{}）四价对前收偏离 {max_dev:.2}x > 0.80——前收填充 + untradable",
                                    raw.dates[i]
                                );
                            untradable = true;
                            oq = pc;
                            hq = pc;
                            lq = pc;
                            cq = pc;
                        }
                    }
                }
            }
            (oq, hq, lq, cq, untradable)
        } else {
            // 缺 OHLC：用前一根 close 占位（连续性），标 untradable。
            let prev = bars.last().map(|b: &Bar| b.close).unwrap_or(0);
            (prev, prev, prev, prev, true)
        };
        let _ = valid_ohlc; // 语义已并入上面的 if let

        bars.push(Bar {
            source_index: i,
            timestamp: date_to_timestamp(&raw.dates[i]),
            open: oq,
            high: hq,
            low: lq,
            close: cq,
            volume: v as f64, // #919：f64 直存
            untradable,
        });
    }

    Ok(Dataset {
        symbol: symbol.to_string(),
        bars,
        dates: raw.dates,
        bar_seconds,
    })
}

/// 便捷：从默认 `data_dir()` 按品种名加载（SYMBOLS 表查文件名）。
pub fn load_by_symbol(symbol: &str, config: &ThetaConfig) -> Result<Dataset, String> {
    let (file, bar_seconds) = SYMBOLS
        .iter()
        .find(|(s, _, _)| s.eq_ignore_ascii_case(symbol))
        .map(|(_, f, g)| (*f, *g))
        .ok_or_else(|| format!("未知品种 `{symbol}`（不在 SYMBOLS 表）"))?;
    // ★#360 venue 费率档与品种的绑定校验（fail-loud，禁跨品种借档）：`ExecConfig::fee_schedule`
    //   是**按品种分档**的 datum 条目（票体 What to build 第一条），而成交回路无 symbol 上下文
    //   ⟹ 唯一能对上号的地方就是这里（数据集品种与配置在此相遇）。不校验的话，把 OKLO 的
    //   per-share 档（$0.0035/**股**）配到 BTC 跑批不会报错，静默产出无意义费用。
    if let Some(sched) = &config.exec.fee_schedule {
        if !sched.symbol.eq_ignore_ascii_case(symbol) {
            return Err(format!(
                "venue 费率档品种不符：schedule.symbol=`{}`（venue={} tier={}）≠ 数据集 `{symbol}`\
                 ——per-share/名义额档位对另一品种无意义，禁静默借档（#360）",
                sched.symbol, sched.venue, sched.tier
            ));
        }
    }
    let path = data_dir().join(file);
    // 粒度随品种取自 SYMBOLS 表（C 点）。现有 10 品种 bar_seconds=60 ⟹ 仍传 60 ⟹ 1m 路径 bit-exact。
    load_symbol(&path, symbol, config, bar_seconds)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// ★#360：venue 费率档品种与数据集品种不符 ⟹ fail-loud（校验先于读盘 ⟹ 不依赖数据文件）。
    ///
    /// **认识论 L1**（管线校验正确性，零市场信息增量）。
    #[test]
    fn fee_schedule_symbol_must_match_dataset() {
        use super::super::super::venue_fee::{FeeUnit, PerShareFees, VenueFeeSchedule};
        let mut cfg = ThetaConfig::default();
        cfg.exec.fee_schedule = Some(VenueFeeSchedule {
            venue: "IBKR_PRO_US_EQUITY".into(),
            symbol: "OKLO".into(),
            tier: "PRO_TIERED_LE_300K_SHARES".into(),
            unit: FeeUnit::PerShare(PerShareFees {
                commission_per_share_usd: 0.0035,
                min_commission_usd: 0.35,
                max_commission_frac_of_notional: 0.01,
                clearing_per_share_usd: 0.0002,
                cat_per_share_usd: 0.000003,
                sell_sec_fee_frac: 0.0000206,
                sell_taf_per_share_usd: 0.000195,
                sell_taf_cap_usd: 9.79,
                passthru_exchange_frac_of_commission: 0.000175,
                passthru_finra_frac_of_commission: 0.000565,
            }),
            datum_sha256: "0".repeat(64),
        });
        let err = load_by_symbol("BTC", &cfg).expect_err("跨品种借档必须 Err");
        assert!(err.contains("品种不符"), "错误须点名品种不符：{err}");
        // 同品种（大小写不敏感，与 SYMBOLS 查表同口径）⟹ 不被本校验拦下。
        let mut ok_cfg = cfg.clone();
        if let Some(s) = ok_cfg.exec.fee_schedule.as_mut() {
            s.symbol = "oklo".into();
        }
        let r = load_by_symbol("OKLO", &ok_cfg);
        assert!(
            r.is_ok() || !r.as_ref().unwrap_err().contains("品种不符"),
            "同品种不得被品种校验拦下：{r:?}"
        );
    }

    /// date_to_timestamp 单调性（同序列内严格递增即可，绝对值无语义）。
    #[test]
    fn date_timestamp_monotonic_within_day() {
        let t0 = date_to_timestamp("2016-01-03 23:00:00+00:00");
        let t1 = date_to_timestamp("2016-01-03 23:01:00+00:00");
        let t2 = date_to_timestamp("2016-01-04 00:00:00+00:00");
        assert!(t0 < t1, "同日相邻分钟单调");
        assert!(t1 < t2, "跨日单调");
    }

    /// 秒级分辨率（barspec-impl B 点）：同一分钟内相邻秒 bar 时间戳**严格区分**。
    ///
    /// 旧实现取 `YYYYMMDDHHMM` 12 位 → 同分钟 60 根秒 bar 时间戳全塌缩为同值，
    /// 平局键 `(timestamp, source_index)` 退化为只靠 source_index 单调。扩到
    /// `YYYYMMDDHHMMSS` 14 位后秒被保留，1s 数据下时间戳恢复严格单调（reference:16）。
    #[test]
    fn date_timestamp_distinguishes_seconds() {
        let s0 = date_to_timestamp("2024-01-01 09:30:00");
        let s1 = date_to_timestamp("2024-01-01 09:30:01");
        let s59 = date_to_timestamp("2024-01-01 09:30:59");
        let next_min = date_to_timestamp("2024-01-01 09:31:00");
        assert!(s0 < s1, "同分钟相邻秒严格单调（1s 平局键不退化）");
        assert!(s1 < s59, "同分钟内秒级单调");
        assert!(s59 < next_min, "跨分钟单调（秒位不溢出干扰分钟序）");
    }

    /// BTC 无 tz 与 databento 有 tz 的日期串都能解析（协议 §1.2 BTC 按 UTC）。
    #[test]
    fn date_timestamp_handles_tz_and_no_tz() {
        let no_tz = date_to_timestamp("2017-08-17 04:00:00");
        let with_tz = date_to_timestamp("2017-08-17 04:00:00+00:00");
        assert_eq!(no_tz, with_tz, "tz 后缀不影响单调键（取数字前 14 位）");
        assert_eq!(no_tz, 20_170_817_040_000, "YYYYMMDDHHMMSS");
    }

    /// 1m 数据 14 位扩展 bit-exact 守卫（barspec-impl 硬约束）：1m bar 秒位恒 00，
    /// 扩位后时间戳 = 旧 12 位值 × 100，**相对序与单调性不变** ⟹ 1m 路径 tape-equality 保持。
    #[test]
    fn minute_data_14digit_preserves_relative_order() {
        let m0 = date_to_timestamp("2016-01-03 23:00:00+00:00");
        let m1 = date_to_timestamp("2016-01-03 23:01:00+00:00");
        // 旧 12 位值 ×100（秒=00），相对差比例不变 ⟹ 排序结果同。
        assert_eq!(
            m0,
            201_601_032_300 * 100,
            "1m bar 秒=00 ⟹ 14 位 = 旧 12 位 ×100"
        );
        assert!(m0 < m1, "1m 相对序不变（bit-exact 平局键不受影响）");
    }

    /// 日期窗切片闭区间语义（L1：切片口径正确性）。
    #[test]
    fn slice_date_window_closed_interval() {
        let ds = Dataset {
            symbol: "TEST".to_string(),
            bars: (0..5)
                .map(|i| Bar {
                    source_index: i,
                    timestamp: i as i64,
                    open: 1,
                    high: 1,
                    low: 1,
                    close: 1,
                    volume: 1.0,
                    untradable: false,
                })
                .collect(),
            dates: vec![
                "2022-12-30 00:00:00".to_string(),
                "2022-12-31 00:00:00".to_string(),
                "2023-01-01 00:00:00".to_string(),
                "2023-01-02 00:00:00".to_string(),
                "2025-07-01 00:00:00".to_string(),
            ],
            bar_seconds: 60,
        };
        // OOS 窗（协议 §2.1）：2023-01-01 → 2025-06-30。
        let oos = ds.slice_date_window("2023-01-01", "2025-06-30");
        assert_eq!(
            oos.bars.len(),
            2,
            "含 2023-01-01 与 2023-01-02，不含 2022/2025-07"
        );
        // Holdout 窗：2025-07-01 → 末尾。
        let holdout = ds.slice_date_window("2025-07-01", "2030-01-01");
        assert_eq!(holdout.bars.len(), 1, "仅 2025-07-01");
        // 空窗合法（不 panic）。
        let empty = ds.slice_date_window("2099-01-01", "2099-12-31");
        assert_eq!(empty.bars.len(), 0, "空窗返回空 Dataset，不 panic");
    }

    /// bars_per_year 粒度参数化守卫（barspec-impl A 点）：1m(60s) 必须 bit-exact 等于
    /// 旧硬编码常数 `365.25*24*60`；1s(1s) = 旧值 ×60（粒度 60 倍 ⟹ 年化基数 60 倍）。
    #[test]
    fn bars_per_year_parameterized_by_granularity() {
        let one_min = bars_per_year(60);
        assert_eq!(one_min, 365.25 * 24.0 * 60.0, "1m bit-exact = 旧硬编码常数");
        let one_sec = bars_per_year(1);
        assert_eq!(one_sec, 365.25 * 24.0 * 60.0 * 60.0, "1s = 1m ×60");
    }

    /// load_by_symbol 默认粒度 = 60s（SYMBOLS 全 1m）——Dataset 携带粒度事实。
    #[test]
    fn dataset_carries_bar_seconds() {
        let ds = Dataset {
            symbol: "T".into(),
            bars: vec![],
            dates: vec![],
            bar_seconds: 60,
        };
        assert_eq!(ds.bar_seconds, 60);
    }

    /// C 点 bit-exact 守卫：SYMBOLS 表全 10 品种 bar_seconds==60，且查表取出的粒度恒 60
    /// （= 改前 load_by_symbol 写死的 60）⟹ load_by_symbol 对 1m 路径逐 bit 等价（不读文件，
    /// 纯查表，roadmap.yaml:988 硬约束）。1s 接入新增条目时此断言会暴露（守卫不被默默放过）。
    #[test]
    fn symbols_table_bit_exact_60s() {
        assert_eq!(
            SYMBOLS.len(),
            10,
            "现有 10 品种（8 原版 + ZN/6E 补录；1s 接入前）"
        );
        for (sym, _, bar_seconds) in SYMBOLS.iter() {
            assert_eq!(*bar_seconds, 60, "{sym} 为 1m 文件 ⟹ 60s（bit-exact）");
        }
        // load_by_symbol 查表逻辑（与生产同路径）取出的粒度 = 60，与改前写死值一致。
        let btc = SYMBOLS
            .iter()
            .find(|(s, _, _)| s.eq_ignore_ascii_case("BTC"))
            .map(|(_, _, g)| *g)
            .expect("BTC 在 SYMBOLS 表");
        assert_eq!(
            btc, 60,
            "load_by_symbol(\"BTC\") 传给 load_symbol 的粒度 = 60"
        );
    }

    /// untradable_ratio 计算（协议 §5.5/§1.2）。
    #[test]
    fn untradable_ratio_counts_flagged_bars() {
        let mk = |untradable: bool, idx: usize| Bar {
            source_index: idx,
            timestamp: idx as i64,
            open: 1,
            high: 1,
            low: 1,
            close: 1,
            volume: 1.0,
            untradable,
        };
        let ds = Dataset {
            symbol: "T".to_string(),
            bars: vec![mk(false, 0), mk(true, 1), mk(false, 2), mk(true, 3)],
            dates: vec!["x".into(); 4],
            bar_seconds: 60,
        };
        assert!((ds.untradable_ratio() - 0.5).abs() < 1e-12, "2/4 不可交易");
    }

    /// ★#922 坏 tick 闸：四价对前收（净化后）偏离 >80% ⟹ 前收填充 + untradable；
    /// 合法极端（30% 跳空）不拦；坏 tick 次根的正常回弹不误伤（BRN 2024-02-19 构型）。
    #[test]
    fn bad_tick_gate_fills_and_marks_untradable() {
        let dir = std::env::temp_dir().join("issue922_bad_tick_test.json");
        let json = r#"{
            "opens":  [83.0, 83.5, 0.08, 83.56, 110.0],
            "highs":  [83.1, 83.6, 0.08, 83.60, 110.5],
            "lows":   [82.9, 83.4, 0.08, 83.50, 109.5],
            "closes": [83.0, 83.56, 0.08, 83.59, 110.2],
            "volumes":[100.0, 100.0, 100.0, 100.0, 100.0],
            "dates":  ["2024-01-01 00:00:00+00:00","2024-01-01 00:01:00+00:00","2024-01-01 00:02:00+00:00","2024-01-01 00:03:00+00:00","2024-01-01 00:04:00+00:00"]
        }"#;
        std::fs::write(&dir, json).expect("写临时夹具");
        let cfg = ThetaConfig::default();
        let ds = load_symbol(&dir, "TEST", &cfg, 60).expect("加载");
        let tk = cfg.tick.tick_size;
        let q = |p: f64| (p / tk).round() as i64;
        // bar2（坏 tick，四价坍缩 0.08）：前收填充 + untradable。
        assert!(ds.bars[2].untradable, "坏 tick 标 untradable");
        assert_eq!(ds.bars[2].close, q(83.56), "坏 tick 前收填充");
        assert_eq!(ds.bars[2].low, q(83.56), "low 同填（σ 不再见坏值）");
        // bar3（回弹到 83.59）：对净化前收比较 ⟹ 不拦、可交易。
        assert!(!ds.bars[3].untradable, "回弹 bar 不误伤（净化前收参照）");
        assert_eq!(ds.bars[3].close, q(83.59));
        // bar4（30% 跳空，合法极端 < 0.80 阈值）：不拦。
        assert!(
            !ds.bars[4].untradable,
            "30% 跳空合法（CL 2020-04 级极端余量内）"
        );
        assert_eq!(ds.bars[4].close, q(110.2));
        // bar0/bar1 不受影响。
        assert!(!ds.bars[0].untradable && !ds.bars[1].untradable);
        let _ = std::fs::remove_file(&dir);
    }

    /// ★#922 存量扫描探针（#[ignore]，真实数据）：全品种走加载路径，闸命中经 eprintln
    /// 逐根打印（品种/bar 号/日期/偏离倍数）——存量命中清单的生产路径实证。
    #[test]
    #[ignore]
    fn issue922_bad_tick_scan_all_symbols() {
        let cfg = ThetaConfig::default();
        for (sym, _file, _bs) in super::SYMBOLS {
            let ds = load_by_symbol(sym, &cfg).expect("加载");
            eprintln!("[scan] {sym}: {} bar 加载完成", ds.bars.len());
        }
    }
}
