use super::super::super::classifier::divergence::DivergenceGauge;
use super::*;

// ── ★#399（#786 Q4 改写稿）：ECON_L2_MAX_BARS 截窗骨架共享 helper——八点收敛 ──
// （l2_btc_capturable_spread_diagnosis / acc_level0sell_oos / acc_walkforward_trainonly /
// acc_multilevel_highlevel_mu / acc_classification_level_hole_dx /
// acc_bottomup_nest_parity_probe / acc_nest_trigger_quality_probe / h2_sample_exclusion_dx）。
// C2 纪律（#746 单源裁定）：env 读取走 env_registry::ECON_L2_MAX_BARS 注册表键，
// 禁裸字符串字面量；常量名统一 MAX_BARS_DEFAULT（旧 MAX_BARS/MAX_BARS_DEFAULT 两名并一）。
const MAX_BARS_DEFAULT: usize = 300_000; // 默认截断窗（时间墙保护，O(n²) 非 OOM——fullhist-oom-fix-20260630 已订正误诊）

/// ECON_L2_MAX_BARS env 解析：合法值覆盖，缺省/非法回退 MAX_BARS_DEFAULT。
fn econ_l2_max_bars() -> usize {
    std::env::var(crate::theta_v0::env_registry::ECON_L2_MAX_BARS)
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(MAX_BARS_DEFAULT)
}

/// 截断边界算术：n_full > max_bars ⟹ Some(尾窗起点)；n_full <= max_bars ⟹ None（全量不截）。
/// 三态由 `tail_window_start_boundary_three_states` 独立单测锁定（合成输入，不依赖真实数据）。
fn tail_window_start(n_full: usize, max_bars: usize) -> Option<usize> {
    (n_full > max_bars).then(|| n_full - max_bars)
}

/// 尾窗截断：保留最后 max_bars 根 bar（半开区间切片，复用 Dataset::slice_bar_range 契约）。
fn truncate_tail_bars(ds_full: Dataset, max_bars: usize) -> Dataset {
    let n_full = ds_full.bars.len();
    match tail_window_start(n_full, max_bars) {
        Some(start) => ds_full.slice_bar_range(start, n_full),
        None => ds_full,
    }
}

/// ★#399 验收：截断边界算术三态独立单测（合成输入，不依赖真实数据）——
/// 此前该算术只嵌在跑真实 BTC 数据的 #[ignore] 测试里，算错了没有任何测试先发现。
#[test]
fn tail_window_start_boundary_three_states() {
    // n_full > max_bars：截断，尾窗起点 = n_full - max_bars。
    assert_eq!(tail_window_start(1000, 300), Some(700));
    // n_full == max_bars：不截断（边界等号归全量）。
    assert_eq!(tail_window_start(300, 300), None);
    // n_full < max_bars：不截断（含 n_full=0 退化）。
    assert_eq!(tail_window_start(299, 300), None);
    assert_eq!(tail_window_start(0, 300), None);
}

// ── 小转大通道阶段2（xiaozhuanda）：C2 跨条目 / C3 as-of 最后次级中枢 / gate_pass 二通道 ──

fn xzd_bsp(source_index: usize, bits: BspBits, center: Option<Center>) -> BspPoint {
    // #218 面 A 载体形态机械适配：Center 变体包装。
    BspPoint {
        source_index,
        bits,
        pivot_low: 0,
        pivot_high: 0,
        center: center.map(crate::theta_v0::classifier::bsp::OwnerRef::Center),
        struct_break_dir: None,
        force: None,
        retrace_breaks_type1: None,
    }
}

fn xzd_center(zd: i64, zg: i64, s: usize, e: usize) -> Center {
    Center {
        zd,
        zg,
        dd: zd,
        gg: zg,
        start_index: s,
        end_index: e,
    }
}

fn xzd_seg(s: usize, e: usize) -> LeveledMove {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::ElementId;
    LeveledMove {
        rmove: RMove::Segment {
            direction: super::super::super::types::Direction::Down,
            lo: 0,
            hi: 100,
        },
        start_index: s,
        end_index: e,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 1,
            ordinal: 0,
        },
    }
}

/// 次级走势，配置 hi（C3 突破判据测试用：`m.rmove.hi() > z.zg` 是否成立由此控制）。
fn xzd_seg_hi(s: usize, e: usize, hi: i64) -> LeveledMove {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::ElementId;
    LeveledMove {
        rmove: RMove::Segment {
            direction: super::super::super::types::Direction::Up,
            lo: 0,
            hi,
        },
        start_index: s,
        end_index: e,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 1,
            ordinal: 0,
        },
    }
}

/// ★#100 问题① 验收（分歧案例，ChatGPT 裁决）：J0⊂J1⊂J2 但 end(J1)≠source(J0)——旧「端点
/// 相等」口径（`find_move_by_end_index`，end==src）定位不到上级 rung；#77 现「区间包含」口径
/// （`build_nest_certificate` line 812-813，start≤src≤end）正确定位。补 #77 探针只测两口径**等价**、
/// 未测**分歧案例上新口径正确**的缺口。
#[test]
fn nest_containment_locates_rung_where_endpoint_equality_fails() {
    use super::super::super::classifier::recursive_tower::find_move_by_end_index;
    let src = 50usize;
    // 三层塔：J0(exec,end==src) ⊂ J1(含 src,end 80≠50) ⊂ J2(含 src,end 100≠50)。
    let tower: Vec<Rc<Vec<LeveledMove>>> = vec![
        Rc::new(vec![xzd_seg(40, 50)]), // tower[0]=J0 执行级：end==src
        Rc::new(vec![xzd_seg(20, 80)]), // tower[1]=J1：含 50，end 80≠50
        Rc::new(vec![xzd_seg(0, 100)]), // tower[2]=J2：含 50，end 100≠50
    ];
    let hist: Vec<f64> = vec![];
    let bits = BspBits {
        buy1: true,
        ..Default::default()
    };

    // 旧「端点相等」口径：上级 tower[1]/tower[2] 无 end==src 段 ⟹ 定位失败（旧会漏掉 J1/J2）。
    assert!(
        find_move_by_end_index(&tower[1], src).is_none(),
        "J1 end 80≠src 50，端点相等应定位失败"
    );
    assert!(
        find_move_by_end_index(&tower[2], src).is_none(),
        "J2 end 100≠src 50，端点相等应定位失败"
    );

    // 新「区间包含」口径：build_nest_certificate 定位到两级 rung，三层嵌套 J0⊂J1⊂J2 可见。
    let cert = build_nest_certificate(
        &tower,
        0,
        src,
        Side::Long,
        &bits,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    )
    .expect("区间包含口径应定位到执行级段");
    assert_eq!(
        cert.rungs().len(),
        2,
        "含 src 的两上级 rung 均被区间包含口径定位（端点相等口径为 0）"
    );
    // rungs 从高到低：rungs[0]=J2[0,100]、rungs[1]=J1[20,80]，且 end≠src（分歧标记）。
    assert_eq!(
        (
            cert.rungs()[0].interval().start_index,
            cert.rungs()[0].interval().end_index
        ),
        (0, 100)
    );
    assert_eq!(
        (
            cert.rungs()[1].interval().start_index,
            cert.rungs()[1].interval().end_index
        ),
        (20, 80)
    );
    assert_ne!(cert.rungs()[0].interval().end_index, src as u64);
    assert_ne!(cert.rungs()[1].interval().end_index, src as u64);
    // 嵌套链 J0⊆J1⊆J2（区间包含口径下才可见的三层套）——同时验证 build_nest_certificate 内看守放行。
    assert!(
        is_sub(&cert.base_interval(), &cert.rungs()[1].interval()),
        "J0⊆J1"
    );
    assert!(
        is_sub(&cert.rungs()[1].interval(), &cert.rungs()[0].interval()),
        "J1⊆J2"
    );
}

/// ★#100 问题① 验收（边界等号 source==end(m)）：上级 rung 的 end 恰等于 source_index——
/// 旧「端点相等」（`find_move_by_end_index`）与新「区间包含」（`build_nest_certificate`）口径
/// **定位到同一段**（新口径是旧口径的真扩展，边界重合处一致，非分歧）。
#[test]
fn nest_boundary_source_equals_end_both_criteria_agree() {
    use super::super::super::classifier::recursive_tower::find_move_by_end_index;
    let src = 50usize;
    let tower: Vec<Rc<Vec<LeveledMove>>> = vec![
        Rc::new(vec![xzd_seg(40, 50)]), // exec：end==src
        Rc::new(vec![xzd_seg(10, 50)]), // J1：end==src（边界等号）
    ];
    let hist: Vec<f64> = vec![];
    let bits = BspBits {
        buy1: true,
        ..Default::default()
    };
    // 旧端点相等口径定位到 tower[1] move[0]（end==src）。
    assert_eq!(find_move_by_end_index(&tower[1], src), Some(0));
    // 新区间包含口径定位到同一段——rung interval == tower[1][0]，且 end_index==src（与旧一致）。
    let cert = build_nest_certificate(
        &tower,
        0,
        src,
        Side::Long,
        &bits,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    )
    .expect("定位成功");
    assert_eq!(cert.rungs().len(), 1);
    assert_eq!(
        (
            cert.rungs()[0].interval().start_index,
            cert.rungs()[0].interval().end_index
        ),
        (10, 50)
    );
    assert_eq!(
        cert.rungs()[0].interval().end_index,
        src as u64,
        "边界等号：新口径与旧端点相等一致"
    );
}

/// C2 跨条目（codex §6-1）：Type3-only 信号自身无 buy2，须在同级列表查共生 B2 条目。
#[test]
fn xzd_c2_cross_entry_finds_cobsp_second() {
    let src = 42;
    // 同级列表：Type3-only 信号条目 + 独立 B2 条目（同 source_index，分离提取）。
    let list = vec![
        xzd_bsp(
            src,
            BspBits {
                buy3: true,
                ..Default::default()
            },
            Some(xzd_center(10, 20, 0, 30)),
        ),
        xzd_bsp(
            src,
            BspBits {
                buy2: true,
                ..Default::default()
            },
            None,
        ),
    ];
    assert!(
        xzd_type2_confirmed(&list, src, Side::Long),
        "跨条目查到共生 B2 ⟹ C2 成立"
    );
    // 无共生 B2（另一 source_index 的 B2 不算）⟹ C2 假。
    let list2 = vec![
        xzd_bsp(
            src,
            BspBits {
                buy3: true,
                ..Default::default()
            },
            None,
        ),
        xzd_bsp(
            src + 1,
            BspBits {
                buy2: true,
                ..Default::default()
            },
            None,
        ),
    ];
    assert!(
        !xzd_type2_confirmed(&list2, src, Side::Long),
        "无同 source_index B2 ⟹ C2 假"
    );
    // 侧向匹配：Long 只看 buy2，卖侧 sell2 不误命中。
    let list3 = vec![xzd_bsp(
        src,
        BspBits {
            sell2: true,
            ..Default::default()
        },
        None,
    )];
    assert!(
        !xzd_type2_confirmed(&list3, src, Side::Long),
        "sell2 不满足 Long 的 C2"
    );
    assert!(
        xzd_type2_confirmed(&list3, src, Side::Short),
        "sell2 满足 Short 的 C2"
    );
}

/// C3 as-of（codex §6-3/思维导图 128）：仅当**最后一个**次级中枢出现三类点才成立。
#[test]
fn xzd_c3_last_sublevel_zs_type3_only() {
    let s = xzd_seg(0, 100); // 本级走势跨度 [0,100]
                             // 两个次级中枢：早 [10,30]、晚 [60,90]（最后中枢=[60,90]）。
    let centers = vec![xzd_center(10, 20, 10, 30), xzd_center(30, 40, 60, 90)];
    // 三类点挂在最后中枢 [60,90] ⟹ C3 成立。
    let bsp_last = vec![xzd_bsp(
        88,
        BspBits {
            buy3: true,
            ..Default::default()
        },
        Some(xzd_center(30, 40, 60, 90)),
    )];
    assert!(
        xzd_sub_last_zs_type3(&s, &centers, &bsp_last, Side::Long),
        "最后次级中枢出现三类点 ⟹ C3"
    );
    // 三类点挂在**早**中枢 [10,30]（非最后）⟹ C3 假（no-patch：不接受非最后中枢的三类点）。
    let bsp_early = vec![xzd_bsp(
        28,
        BspBits {
            buy3: true,
            ..Default::default()
        },
        Some(xzd_center(10, 20, 10, 30)),
    )];
    assert!(
        !xzd_sub_last_zs_type3(&s, &centers, &bsp_early, Side::Long),
        "非最后中枢的三类点 ⟹ C3 假"
    );
    // s 内无次级中枢 ⟹ C3 假。
    assert!(
        !xzd_sub_last_zs_type3(&s, &[], &bsp_last, Side::Long),
        "无次级中枢 ⟹ C3 假"
    );
}

/// C3 新判据（codex #44(c)）：新中枢存在+突破 / 存在未突破 / 无新中枢 三态。
#[test]
fn xzd_c3_new_center_breakout_cases() {
    let source_index = 50;
    let confirm_index = 100;
    // 新中枢 [55,70]（start>=source_index, end<=confirm_index），其后走势 [71,90] 上破 ZG=20。
    let centers = vec![xzd_center(10, 20, 55, 70)];
    let moves_break = vec![xzd_seg_hi(71, 90, 25)]; // hi=25 > zg=20 ⟹ 突破
    let diag = xzd_c3_new_center_breakout(
        source_index,
        confirm_index,
        Side::Long,
        &centers,
        &moves_break,
    );
    assert!(
        diag.new_center_exists,
        "新中枢在 [source_index,confirm_index] 区间内 ⟹ 存在"
    );
    assert!(diag.new_center_breakout_ok, "其后走势 hi>zg ⟹ 突破成立");

    // 中枢存在但其后走势未突破（hi=15 <= zg=20）。
    let moves_no_break = vec![xzd_seg_hi(71, 90, 15)];
    let diag2 = xzd_c3_new_center_breakout(
        source_index,
        confirm_index,
        Side::Long,
        &centers,
        &moves_no_break,
    );
    assert!(diag2.new_center_exists, "新中枢仍存在");
    assert!(!diag2.new_center_breakout_ok, "未破 ZG ⟹ 突破假");

    // 无新中枢（中枢 start_index < source_index，不满足 off-by-one 硬约束）。
    let centers_old = vec![xzd_center(10, 20, 40, 45)];
    let diag3 = xzd_c3_new_center_breakout(
        source_index,
        confirm_index,
        Side::Long,
        &centers_old,
        &moves_break,
    );
    assert!(
        !diag3.new_center_exists,
        "中枢 start_index<source_index ⟹ 非新中枢"
    );
    assert!(!diag3.new_center_breakout_ok, "无新中枢 ⟹ 突破假");

    // off-by-one：start_index == source_index 仍算「source 之后已确认」（硬约束用 >=，非 >）。
    let centers_eq = vec![xzd_center(10, 20, source_index, 70)];
    let diag4 = xzd_c3_new_center_breakout(
        source_index,
        confirm_index,
        Side::Long,
        &centers_eq,
        &moves_break,
    );
    assert!(
        diag4.new_center_exists,
        "start_index==source_index ⟹ 新中枢存在（>= 非 >）"
    );
}

/// gate_pass（#1220 / #1204 裁定 a）：每级同一个判据 C2∧C3(突破)∧¬例外臂。
#[test]
fn xzd_gate_pass_level1_c3_breakout_hard_gate() {
    let mk = |level, c2, c3_breakout, exception| XzdEvidence {
        source_index: 1,
        level,
        side: Side::Long,
        confirm_index: 5,
        type2_confirmed: c2,
        sub_last_zs_type3: false,
        last_zs_exists: false,
        same_side_l0_type3_any: false,
        same_center_any: false,
        same_side_causal_ok: false,
        sub_bsp_type3_count: 0,
        c3_new_center_exists: c3_breakout,
        c3_new_center_breakout_ok: c3_breakout,
        force_exception_ok: exception,
    };
    // 每级同一个判据：C2∧C3 硬门（level 不再分流）。
    assert!(
        mk(1, true, true, false).gate_pass(),
        "C2 真∧C3 真∧无例外 ⟹ 通过"
    );
    assert!(
        !mk(1, true, false, false).gate_pass(),
        "C2 真、C3 假 ⟹ 拒（三卖未出，中枢继续）"
    );
    assert!(!mk(1, false, true, false).gate_pass(), "C2 假 ⟹ 仍拒");
    // 例外臂：三买卖坐实后强力不背驰创新高 ⟹ 拒（43 课唯一例外）。
    assert!(
        !mk(1, true, true, true).gate_pass(),
        "C2 真∧C3 真∧例外臂 ⟹ 拒（持有）"
    );
    // level>=2 与 level==1 同一判据（消灭宽严两档 #799/#804）。
    assert!(
        mk(2, true, true, false).gate_pass(),
        "level2 C2 真∧C3 真∧无例外 ⟹ 通过（每级同一个判据）"
    );
    assert!(
        !mk(2, true, false, false).gate_pass(),
        "level2 C2 真、C3 假 ⟹ 拒（不再 C2-only）"
    );
    assert!(!mk(2, false, true, false).gate_pass(), "level2 C2 假 ⟹ 拒");
    assert!(
        !mk(2, true, true, true).gate_pass(),
        "level2 例外臂 ⟹ 拒（同 level1）"
    );
}

/// 例外臂（#1220 / #1204 裁定 a + 问 2 裁定「判据形态钉死」）：三卖坐实后「向上离开不背驰
/// 且后续发展出新的上涨走势类型」——结构判据（三买确认 / 新中枢上移），价格新高本身不构成判据。
#[test]
fn xzd_force_exception_structural_short() {
    use super::super::super::types::{Direction, Stroke};

    let source_index = 50;
    let confirm_index = 100;
    // 新中枢 z=[55,70]，zd=10/zg=20；三卖 = 其后 Down 走势跌破 zd（lo=0 < 10）。
    let z = xzd_center(10, 20, 55, 70);
    // sub_moves：prev_up=[0,40]（前一同向走势，比较基准）；break=[71,80] Down（三卖）；
    // up=[81,90] Up（离开中枢，hi=25 > zg=20）。
    let prev_up = xzd_seg_hi(0, 40, 15);
    let brk = xzd_seg(71, 80);
    let up = xzd_seg_hi(81, 90, 25);
    let sub_moves = vec![prev_up.clone(), brk.clone(), up.clone()];

    // 无笔 ⟹ 无源不判，不触发例外（即便离开几何成立）。
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z],
            &[],
            &sub_moves,
            &[],
        ),
        "无笔 ⟹ 无源不判 ⟹ 不触发例外臂"
    );

    // 不背驰笔序列：L(prev_up)=v(s1)-v(s0)=-10/21，L(up)=v(s3)-v(s2)=50/6 ⟹ L(up) >= L(prev_up)。
    let strokes_strong = vec![
        Stroke {
            direction: Direction::Up,
            start_index: 0,
            end_index: 20,
            start_price: 100,
            end_price: 120,
        },
        Stroke {
            direction: Direction::Up,
            start_index: 20,
            end_index: 40,
            start_price: 120,
            end_price: 130,
        },
        Stroke {
            direction: Direction::Up,
            start_index: 80,
            end_index: 85,
            start_price: 130,
            end_price: 140,
        },
        Stroke {
            direction: Direction::Up,
            start_index: 85,
            end_index: 90,
            start_price: 140,
            end_price: 200,
        },
    ];

    // 触发前件成立（离开不背驰）但无后续走势类型发展 ⟹ 不触发例外臂（新高本身不构成判据）。
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z],
            &[],
            &sub_moves,
            &strokes_strong,
        ),
        "触发前件成立、无结构发展 ⟹ 不触发例外臂（价格新高不构成判据）"
    );

    // 结构判据一：三买确认（buy3 中心即 z，source_index=95 在离开走势 [81,90] 之后）⟹ 例外臂。
    let mut buy3 = BspBits::default();
    buy3.buy3 = true;
    let bsp_buy3_after = vec![xzd_bsp(95, buy3, Some(z))];
    assert!(
        super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z],
            &bsp_buy3_after,
            &sub_moves,
            &strokes_strong,
        ),
        "三买确认（buy3 中心即 z，且在离开走势之后）⟹ 例外臂"
    );

    // buy3 在离开走势之内/之前（source_index=88 <= up.end=90）⟹ 非「后续」发展 ⟹ 不触发。
    let bsp_buy3_before = vec![xzd_bsp(88, buy3, Some(z))];
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z],
            &bsp_buy3_before,
            &sub_moves,
            &strokes_strong,
        ),
        "buy3 不在离开走势之后 ⟹ 无「后续」发展 ⟹ 不触发"
    );

    // buy3 中心非 z ⟹ 不确认该新中枢的三买 ⟹ 不触发。
    let other = xzd_center(30, 40, 90, 99);
    let bsp_buy3_other = vec![xzd_bsp(95, buy3, Some(other))];
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z],
            &bsp_buy3_other,
            &sub_moves,
            &strokes_strong,
        ),
        "buy3 中心非 z ⟹ 不触发"
    );

    // 结构判据二：新中枢上移（z2=[91,99] dd=25 > z.gg=20 ⟹ UpContinuation）⟹ 例外臂。
    let z2_up = xzd_center(25, 35, 91, 99);
    assert!(
        super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z, z2_up],
            &[],
            &sub_moves,
            &strokes_strong,
        ),
        "新中枢上移（UpContinuation）⟹ 例外臂"
    );

    // z2 核心与 z 重叠（zd=15 <= zg=20 ⟹ CoreOverlap）⟹ 非新走势类型 ⟹ 不触发。
    let z2_overlap = xzd_center(15, 30, 91, 99);
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z, z2_overlap],
            &[],
            &sub_moves,
            &strokes_strong,
        ),
        "后中枢与前中枢核心重叠 ⟹ 非新走势类型 ⟹ 不触发"
    );

    // z2 下移（gg=8 < z.dd=10 ⟹ DownContinuation）⟹ 方向不对 ⟹ 不触发。
    let z2_down = xzd_center(1, 8, 91, 99);
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z, z2_down],
            &[],
            &sub_moves,
            &strokes_strong,
        ),
        "后中枢下移（DownContinuation）⟹ 方向不对 ⟹ 不触发"
    );

    // 背驰（L(up) < L(prev_up)）：末笔终点价从 200 降到 130 ⟹ L(up)=-20/6 < L(prev_up) ⟹
    // 离开成立但力度背驰 ⟹ 不触发例外臂（即便结构判据成立，放行侧真三卖）。
    let strokes_weak = vec![
        strokes_strong[0],
        strokes_strong[1],
        strokes_strong[2],
        Stroke {
            direction: Direction::Up,
            start_index: 85,
            end_index: 90,
            start_price: 140,
            end_price: 130,
        },
    ];
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z],
            &bsp_buy3_after,
            &sub_moves,
            &strokes_weak,
        ),
        "力度背驰（L(up) < L(prev_up)）⟹ 不触发例外臂"
    );

    // 三卖未出（无跌破 zd 的次级走势）⟹ 无坐实 ⟹ 无例外臂。
    let sub_moves_no_break = vec![prev_up.clone(), up.clone()];
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z],
            &bsp_buy3_after,
            &sub_moves_no_break,
            &strokes_strong,
        ),
        "三卖未出（无反向突破）⟹ 无例外臂"
    );

    // 离开走势与三卖走势重叠（up.start < brk.end）⟹ 事件序不满足 ⟹ 无例外臂。
    let up_overlap = xzd_seg_hi(78, 90, 25);
    let sub_moves_overlap = vec![prev_up.clone(), brk.clone(), up_overlap.clone()];
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Short,
            &[z],
            &bsp_buy3_after,
            &sub_moves_overlap,
            &strokes_strong,
        ),
        "离开须在三卖之后（up.start >= brk.end）⟹ 重叠走势不触发"
    );
}

/// 例外臂 Long 侧镜像（每级同一个判据 #799/#804）：三买坐实后「向下离开不背驰且后续发展出
/// 新的下跌走势类型」（三卖确认 / 新中枢下移）。
#[test]
fn xzd_force_exception_structural_long() {
    use super::super::super::types::{Direction, Stroke};

    let source_index = 50;
    let confirm_index = 100;
    // 新中枢 z=[55,70]，zd=10/zg=20；三买 = 其后 Up 走势升破 zg（hi=25 > 20）。
    let z = xzd_center(10, 20, 55, 70);
    // sub_moves：prev_down=[0,40]（前一同向走势，比较基准）；break=[71,80] Up（三买）；
    // down=[81,90] Down（离开中枢，lo=0 < zd=10）。
    let prev_down = xzd_seg(0, 40);
    let brk = xzd_seg_hi(71, 80, 25);
    let down = xzd_seg(81, 90);
    let sub_moves = vec![prev_down.clone(), brk.clone(), down.clone()];

    // 不背驰笔序列（Down 笔速沿走势方向恒正）：L(prev_down)=10/21-30/21=-20/21，
    // L(down)=60/6-10/6=50/6 ⟹ L(down) >= L(prev_down)。
    let strokes_strong = vec![
        Stroke {
            direction: Direction::Down,
            start_index: 0,
            end_index: 20,
            start_price: 130,
            end_price: 100,
        },
        Stroke {
            direction: Direction::Down,
            start_index: 20,
            end_index: 40,
            start_price: 100,
            end_price: 90,
        },
        Stroke {
            direction: Direction::Down,
            start_index: 80,
            end_index: 85,
            start_price: 90,
            end_price: 80,
        },
        Stroke {
            direction: Direction::Down,
            start_index: 85,
            end_index: 90,
            start_price: 80,
            end_price: 20,
        },
    ];
    // 触发前件成立、无结构发展 ⟹ 不触发（新低本身不构成判据）。
    assert!(
        !super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Long,
            &[z],
            &[],
            &sub_moves,
            &strokes_strong,
        ),
        "触发前件成立、无结构发展 ⟹ 不触发（价格新低不构成判据）"
    );
    // 三卖确认（sell3 中心即 z，source_index=95 在离开走势之后）⟹ 例外臂。
    let mut sell3 = BspBits::default();
    sell3.sell3 = true;
    let bsp_sell3 = vec![xzd_bsp(95, sell3, Some(z))];
    assert!(
        super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Long,
            &[z],
            &bsp_sell3,
            &sub_moves,
            &strokes_strong,
        ),
        "三卖确认（sell3 中心即 z，且在离开走势之后）⟹ 例外臂"
    );
    // 新中枢下移（z2=[91,99] gg=8 < z.dd=10 ⟹ DownContinuation）⟹ 例外臂。
    let z2_down = xzd_center(1, 8, 91, 99);
    assert!(
        super::xzd_force_exception(
            source_index,
            confirm_index,
            Side::Long,
            &[z, z2_down],
            &[],
            &sub_moves,
            &strokes_strong,
        ),
        "新中枢下移（DownContinuation）⟹ 例外臂"
    );
}

// ── P7 正规出场口径测试（RED→GREEN：exit_decision_from_bits 派生，接 interp ExitType CloseRoot/ReduceCore）────

/// **P7 多头入场 exit_decision_from_bits：sell1 → CloseRoot（优先级最高）**。
///
/// 定义依据：interp `exit_type_of_classes` 第一分支「type1=顶背驰 → CloseRoot」。
/// 边界条件：sell1=1 即触发，不看 sell3/sell2（第一类优先）。
#[test]
fn p7_exit_decision_long_sell1_close_root() {
    // bit3=sell1
    let exit_class: u8 = 1 << 3;
    assert_eq!(
        exit_decision_from_bits(exit_class, 1),
        ExitDecision::CloseRoot,
        "多头入场 sell1 → CloseRoot"
    );
}

/// **P7 多头入场 exit_decision_from_bits：sell3（无 sell1）→ ReduceCore**。
///
/// 定义依据：interp `exit_type_of_classes` 第二分支「type3=第三类 → ReduceCore」（type1=false 前提）。
#[test]
fn p7_exit_decision_long_sell3_reduce_core() {
    // bit5=sell3，bit3=sell1=0
    let exit_class: u8 = 1 << 5;
    assert_eq!(
        exit_decision_from_bits(exit_class, 1),
        ExitDecision::ReduceCore,
        "多头入场 sell3（无 sell1）→ ReduceCore"
    );
}

/// **P7 多头入场 exit_decision_from_bits：sell1+sell3 同时 → CloseRoot（第一类优先）**。
///
/// 边界条件：sell1 与 sell3 共存时，第一类优先（镜像 interp `exit_type_of_classes` 分支顺序）。
#[test]
fn p7_exit_decision_long_sell1_sell3_priority() {
    let exit_class: u8 = (1 << 3) | (1 << 5); // sell1+sell3
    assert_eq!(
        exit_decision_from_bits(exit_class, 1),
        ExitDecision::CloseRoot,
        "sell1+sell3 共存 → CloseRoot（第一类优先）"
    );
}

/// **P7 多头入场 exit_decision_from_bits：sell2（无 sell1/3）→ Type2Missing（still-MISSING 诚实标注）**。
///
/// 定义依据：第二类卖点闭环 still-MISSING 诚实边界（见 [`ExitDecision`] docstring，需次级别递归）。
/// 边界条件：Type2Missing 不改账本，只记入统计（no-patch）。
#[test]
fn p7_exit_decision_long_sell2_type2_missing() {
    let exit_class: u8 = 1 << 4; // sell2
    assert_eq!(
        exit_decision_from_bits(exit_class, 1),
        ExitDecision::Type2Missing,
        "多头入场 sell2 → Type2Missing（第二类闭环 still-MISSING）"
    );
}

/// **P7 多头入场 exit_decision_from_bits：bsp_class=0（无任何 bit）→ Hold**。
///
/// 边界条件：exit 信号无正规卖点 bit → Hold（无出场依据，不改账本）。
#[test]
fn p7_exit_decision_long_no_bit_hold() {
    assert_eq!(
        exit_decision_from_bits(0, 1),
        ExitDecision::Hold,
        "多头入场 bsp_class=0 → Hold"
    );
}

/// **P7 空头入场 exit_decision_from_bits：买侧镜像判据**。
///
/// 定义依据：空头入场 exit 是 Long 信号，buy1/3/2 镜像 sell1/3/2。
#[test]
fn p7_exit_decision_short_buy_mirror() {
    // buy1 → CloseRoot
    assert_eq!(
        exit_decision_from_bits(1 << 0, -1),
        ExitDecision::CloseRoot,
        "空头入场 buy1 → CloseRoot"
    );
    // buy3 → ReduceCore
    assert_eq!(
        exit_decision_from_bits(1 << 2, -1),
        ExitDecision::ReduceCore,
        "空头入场 buy3 → ReduceCore"
    );
    // buy2 → Type2Missing
    assert_eq!(
        exit_decision_from_bits(1 << 1, -1),
        ExitDecision::Type2Missing,
        "空头入场 buy2 → Type2Missing"
    );
    // 0 → Hold
    assert_eq!(
        exit_decision_from_bits(0, -1),
        ExitDecision::Hold,
        "空头入场 bsp_class=0 → Hold"
    );
}

/// **P7 ExitDecision 穷举分类完整性（多头）**：所有可能的 exit bsp_class（0..64）都映射到四态之一。
///
/// 边界条件：完整覆盖 64 种 bsp_class，无 panic 无未定义。
#[test]
fn p7_exit_decision_exhaustive_long() {
    for cls in 0u8..64 {
        let d = exit_decision_from_bits(cls, 1);
        assert!(
            matches!(
                d,
                ExitDecision::CloseRoot
                    | ExitDecision::ReduceCore
                    | ExitDecision::Type2Missing
                    | ExitDecision::Hold
            ),
            "bsp_class={cls:#04x} delta=+1 应映射到四态之一"
        );
    }
}

/// **P7 SpreadAttribution 统计字段完整性（L1）**：SignalDecomp 含 exit_decision 字段，
/// 四种出场决策可加入 agg 统计。
#[test]
fn p7_spread_attribution_exit_decision_fields() {
    let mut agg = SpreadAttribution::default();
    // 验证四个统计字段可正常累加
    agg.n_exit_close_root += 1;
    agg.n_exit_reduce_core += 2;
    agg.n_exit_type2_missing += 3;
    agg.n_exit_hold += 4;
    assert_eq!(agg.n_exit_close_root, 1);
    assert_eq!(agg.n_exit_reduce_core, 2);
    assert_eq!(agg.n_exit_type2_missing, 3);
    assert_eq!(agg.n_exit_hold, 4);
    // 验证 SignalDecomp 含 exit_decision 字段
    let d = SignalDecomp {
        entry_bar: 0,
        exit_bar: 1,
        level: 0,
        delta: 1,
        a_b: 0.0,
        x_in: 0.0,
        y_out: 0.0,
        eta_in: 0.0,
        eta_out: 0.0,
        actual_spread: 0.0,
        ce_unit: 0.0,
        captured: 0.0,
        actual_pnl: 0.0,
        sigma_higher: 0,
        bsp_class: 1 << 3, // sell1
        z: MuClass::from_certificate(
            0,
            1,
            BspBits::from_class_index(1 << 3),
            0,
            PositionState::Root,
        ),
        exit_decision: ExitDecision::CloseRoot,
        trigger: NestTrigger::Type1TrendDivergence,
    };
    assert_eq!(
        d.exit_decision,
        ExitDecision::CloseRoot,
        "SignalDecomp.exit_decision 字段可读写（P7 接口存在）"
    );
}

// ── 生产路径测试（RED→GREEN：W1 返工，多级 N^δ 递归真调用） ─────────────────

/// **生产路径：build_multilevel_nest_cert 存在且可调用（RED：函数不存在则编译失败）**。
///
/// 验证 `build_multilevel_nest_cert` 函数签名正确：接受 tower + lvl + source_index +
/// delta + BspBits + macd_hist，返回 bool。基例（lvl=0，rungs 空，纯 Conf^δ_e）。
///
/// **认识论 L1**（生产路径结构验证，非 L0 fixture 同义反复）：函数存在 + 接口正确。
#[test]
fn multilevel_nest_cert_function_exists() {
    use super::super::super::classifier::recursive_tower::LeveledMove;
    use super::super::super::types::{BspBits, Side};
    use std::rc::Rc;

    let tower: Vec<Rc<Vec<LeveledMove>>> = vec![];
    let mut bits = BspBits::default();
    bits.buy1 = true;
    let hist: Vec<f64> = vec![];
    // 空塔 → lvl=0 无法从塔拿区间 → false（无上级语境）。
    // 函数本身必须存在（否则 RED）。
    let result = build_multilevel_nest_cert(
        &tower,
        0,
        0,
        Side::Long,
        &bits,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    // 空塔 ⟹ false（无上级 context，N^δ 不成立）。
    assert!(!result, "空塔 ⟹ false（基例无 confirm 来源）");
}

/// **生产路径：多级 rungs 链（≥2 级），J 嵌套收缩验证（RED→GREEN 核心测试）**。
///
/// 构造合成 2 级塔：L0 有 4 段（up/down/up/down），L1 有 1 个 Compose 包含全部 4 段。
/// 信号在 L1（lvl=1），source_index=19（最后 Down 段的 end_index），δ=Long。
/// 验证 `build_multilevel_nest_cert` 真调用 `n_delta()`（≥1 rung，非单级 bsp_div_cand）。
///
/// **认识论 L1**：合成塔 + 合成 hist（条件4 力度满足），验证多级构造路径正确，
/// 非 alpha 声明（L2/L3 待 W-VERIFY）。
#[test]
fn multilevel_nest_cert_two_level_rung_chain() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::{ElementId, LeveledMove};
    use super::super::super::types::{BspBits, Center, Direction, Side};
    use std::rc::Rc;

    // helper：构造 L0 Segment LeveledMove
    let seg = |dir: Direction, lo: i64, hi: i64, s: usize, e: usize, ord: u64| -> LeveledMove {
        LeveledMove {
            rmove: RMove::Segment {
                direction: dir,
                lo,
                hi,
            },
            start_index: s,
            end_index: e,
            sub_moves: Rc::new(vec![]),
            id: ElementId {
                level: 0,
                ordinal: ord,
            },
        }
    };

    // L0 四段：up(0-4) / down(5-9) / up(10-14) / down(15-19)
    let s0 = seg(Direction::Up, 50, 100, 0, 4, 0);
    let s1 = seg(Direction::Down, 40, 90, 5, 9, 1); // s'：lo=40
    let s2 = seg(Direction::Up, 45, 95, 10, 14, 2);
    let s3 = seg(Direction::Down, 30, 85, 15, 19, 3); // s：lo=30 < 40，Extreme ✓

    // L1 Compose 包含全部4段
    let sub_rmoves: Vec<RMove> = vec![
        s0.rmove.clone(),
        s1.rmove.clone(),
        s2.rmove.clone(),
        s3.rmove.clone(),
    ];
    let lo = 30i64;
    let hi = 100i64;
    let parent = LeveledMove {
        rmove: RMove::Compose {
            subs: Rc::new(sub_rmoves),
            // ★#883：D-3 取段的「界」——s3(lo=30) 破核心 zd=45 跨界、s1(end=9≤10) 命中
            // 进入段口径，本测试语义（四条件全过 ⟹ n_delta=true）不变。
            centers: vec![Center {
                zd: 45,
                zg: 92,
                dd: lo,
                gg: hi,
                start_index: 10,
                end_index: 19,
            }],
            level: 1,
        },
        start_index: 0,
        end_index: 19,
        sub_moves: Rc::new(vec![s0.clone(), s1.clone(), s2.clone(), s3.clone()]),
        id: ElementId {
            level: 1,
            ordinal: 0,
        },
    };

    let tower: Vec<Rc<Vec<LeveledMove>>> = vec![
        Rc::new(vec![s0, s1, s2, s3]), // level 0
        Rc::new(vec![parent]),         // level 1
    ];

    // hist（#988 同色：Side::Long ⟹ 绿柱负衰减）：s'(5-9) area=10，s(15-19) area=5（条件4 Weak ✓）
    let hist: Vec<f64> = (0..20usize)
        .map(|i| if i < 10 { -2.0 } else { -1.0 })
        .collect();

    // 买侧 bits（基例 Conf^+）：buy1=true
    let mut bits = BspBits::default();
    bits.buy1 = true;

    // lvl=0，source_index=19（s3 的 end_index），δ=Long
    // 期望：L0 基例 Conf^+ = bits.conf_plus() = true（buy1=true）
    // 且 bsp_div_cand 四条件满足（Down，Extreme lo=30<40，Weak area=5<10）
    // ⟹ build_multilevel_nest_cert ⟹ n_delta() = true
    let result = build_multilevel_nest_cert(
        &tower,
        0,
        19,
        Side::Long,
        &bits,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    assert!(
        result,
        "两级塔 + 四条件满足 + Conf^+ ⟹ n_delta()=true（多级链 J 嵌套收缩）"
    );
}

// ── 673-fix：接口级三分拆独立单元测试（Type1/2/3 分派 + Type2/3 谓词） ──────────

/// **bsp_cand_type 优先级分派（Type1>Type2>Type3，保持旧 is_type1 语义）**。
#[test]
fn bsp_cand_type_priority_dispatch() {
    use super::super::super::types::{BspBits, Side};
    let mk = |b1, b2, b3| {
        let mut bits = BspBits::default();
        bits.buy1 = b1;
        bits.buy2 = b2;
        bits.buy3 = b3;
        bits
    };
    // buy1 置位 ⟹ Type1（即使 buy2/buy3 同置，非互斥 P4§5，优先级坍缩）。
    assert_eq!(
        bsp_cand_type(&mk(true, true, true), Side::Long),
        BspCandType::Type1
    );
    assert_eq!(
        bsp_cand_type(&mk(false, true, true), Side::Long),
        BspCandType::Type2
    );
    assert_eq!(
        bsp_cand_type(&mk(false, false, true), Side::Long),
        BspCandType::Type3
    );
    // 卖侧对称。
    let mut sb = BspBits::default();
    sb.sell2 = true;
    assert_eq!(bsp_cand_type(&sb, Side::Short), BspCandType::Type2);
}

/// **StructBreak 分派（codex 终局裁决A）：六 bit 全零 ⟹ StructBreak，优先于 Type1>2>3**。
///
/// 真三类候选（buy3/sell3 置位，class_index()!=0）不受影响，仍走 Type3——
/// StructBreak 判别只截获零 bit 候选，不改变既有三类分派逻辑。
#[test]
fn bsp_cand_type_structbreak_zero_bits_dispatch() {
    use super::super::super::types::{BspBits, Side};
    assert_eq!(
        bsp_cand_type(&BspBits::default(), Side::Long),
        BspCandType::StructBreak
    );
    assert_eq!(
        bsp_cand_type(&BspBits::default(), Side::Short),
        BspCandType::StructBreak
    );

    let mut b3 = BspBits::default();
    b3.buy3 = true;
    assert_eq!(
        bsp_cand_type(&b3, Side::Long),
        BspCandType::Type3,
        "真三类 buy3 置位仍走 Type3，不受 StructBreak 影响"
    );
    let mut s3 = BspBits::default();
    s3.sell3 = true;
    assert_eq!(
        bsp_cand_type(&s3, Side::Short),
        BspCandType::Type3,
        "真三类 sell3 置位仍走 Type3，不受 StructBreak 影响"
    );
}

/// **build_gate_certificate 护栏（codex 终局裁决A）：零 bit 候选恒 None（门拒）**。
///
/// lvl==0 场景下 Type2/Type3 本有存在性免门（自由通道），但 StructBreak 候选即使在 lvl==0
/// 也恒被 `cand_delta_base_gate` 拒绝——证明 StructBreak 不会被免门通道误纳。
/// 对照组：同一 fixture 换成真三类 bits（buy3=true）时，lvl==0 正常放行 ⟹ Some（回归保护，
/// 证明本次改动只截获零 bit 候选，不影响真三类通路）。
#[test]
fn build_gate_certificate_structbreak_zero_bits_always_none() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::{ElementId, LeveledMove};
    use super::super::super::types::{BspBits, Side};
    use std::rc::Rc;

    let s = LeveledMove {
        rmove: RMove::Segment {
            direction: super::super::super::types::Direction::Down,
            lo: 30,
            hi: 85,
        },
        start_index: 15,
        end_index: 19,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 0,
            ordinal: 0,
        },
    };
    let tower: Vec<Rc<Vec<LeveledMove>>> = vec![Rc::new(vec![s])];
    let hist: Vec<f64> = (0..20).map(|_| 1.0).collect();

    // 零 bit（StructBreak）：即使 lvl==0（Type2/3 免门场景）也恒 None。
    let zero_bits = BspBits::default();
    assert!(
        build_gate_certificate(
            &tower,
            0,
            19,
            Side::Long,
            &zero_bits,
            &hist,
            19,
            &[],
            &[],
            &[],
            &[], // ★#883：测试无笔源
            DivergenceGauge::MacdArea,
        )
        .is_none(),
        "零 bit 破中枢未背驰候选（StructBreak）恒门拒，不复用 Type3 lvl==0 免门通道"
    );

    // 对照：真三类（buy3 置位，class_index()!=0）同 fixture 下 lvl==0 正常放行 ⟹ Some。
    let mut real_type3 = BspBits::default();
    real_type3.buy3 = true;
    assert!(
        build_gate_certificate(
            &tower,
            0,
            19,
            Side::Long,
            &real_type3,
            &hist,
            19,
            &[],
            &[],
            &[],
            &[], // ★#883：测试无笔源
            DivergenceGauge::MacdArea,
        )
        .is_some(),
        "真三类 buy3 置位候选不受 StructBreak 分流影响，仍走 Type3 正常放行"
    );
}

/// **Type2/Type3 base gate：lvl==0 存在性免门；lvl>=1 无次级别锚 ⟹ 小转大门拒**。
///
/// Type2/3 谓词是**独立函数**（codex 裁决①），但当前存在性锚共用 `descend_type1_anchor_depth`
/// （codex 允许复用反向走势完成 helper），故对同一 fixture 行为一致——语义分离体现于保护边界
/// 归属（Type2=一类点极值 / Type3=中枢 ZG/ZD），记录于各 docstring，非本级信号集差。
#[test]
fn cand_delta_type23_base_gate_level0_and_small_to_big() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::{ElementId, LeveledMove};
    use super::super::super::types::Side;
    use std::rc::Rc;

    // 递归底段（无 sub_moves）：lvl==0 免门 ⟹ true；lvl>=1 无锚 ⟹ 小转大 false。
    let s = LeveledMove {
        rmove: RMove::Segment {
            direction: super::super::super::types::Direction::Down,
            lo: 30,
            hi: 85,
        },
        start_index: 15,
        end_index: 19,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 0,
            ordinal: 3,
        },
    };
    let hist: Vec<f64> = (0..20).map(|_| 1.0).collect();

    // lvl==0：存在性免门 ⟹ Type2/Type3 均 true。
    assert!(cand_delta_type2_completion(
        &s,
        19,
        Side::Long,
        &hist,
        0,
        &[],
        DivergenceGauge::MacdArea
    ));
    assert!(cand_delta_type3_retest(
        &s,
        19,
        Side::Long,
        &hist,
        0,
        &[],
        DivergenceGauge::MacdArea
    ));
    // lvl>=1 但 s.sub_moves 空（无次级别 Type1 锚）⟹ 小转大 ⟹ false。
    assert!(!cand_delta_type2_completion(
        &s,
        19,
        Side::Long,
        &hist,
        1,
        &[],
        DivergenceGauge::MacdArea
    ));
    assert!(!cand_delta_type3_retest(
        &s,
        19,
        Side::Long,
        &hist,
        1,
        &[],
        DivergenceGauge::MacdArea
    ));
    // dispatcher：base gate Type1 恒 true（判据在 per-rung），Type2/3 委托上述。
    assert!(cand_delta_base_gate(
        BspCandType::Type1,
        &s,
        19,
        Side::Long,
        &hist,
        1,
        &[],
        DivergenceGauge::MacdArea,
    ));
    assert!(!cand_delta_base_gate(
        BspCandType::Type2,
        &s,
        19,
        Side::Long,
        &hist,
        1,
        &[],
        DivergenceGauge::MacdArea,
    ));
}

/// **cand_delta per-rung dispatcher：Type1→div_cand，Type2/3→true（存在性已 base 门控）**。
#[test]
fn cand_delta_rung_dispatch() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::{ElementId, LeveledMove};
    use super::super::super::types::{Direction, Side};
    use std::rc::Rc;
    let seg = |dir, lo, hi, s, e, ord| LeveledMove {
        rmove: RMove::Segment {
            direction: dir,
            lo,
            hi,
        },
        start_index: s,
        end_index: e,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 0,
            ordinal: ord,
        },
    };
    // rung 次级别序列：s'(down lo=40) ... s(down lo=30<40 Extreme✓)，hist 力度衰减 Weak✓。
    let subs = vec![
        seg(Direction::Down, 40, 90, 5, 9, 1),
        seg(Direction::Up, 45, 95, 10, 14, 2),
        seg(Direction::Down, 30, 85, 15, 19, 3),
    ];
    // #988 同色口径：Side::Long ⟹ Down ⟹ 绿柱（负衰减）。
    let hist: Vec<f64> = (0..20usize)
        .map(|i| if i < 10 { -2.0 } else { -1.0 })
        .collect();
    // ★#883：D-3 取段的「界」——s(down,lo=30) 破核心 zd=45；s'(end=9≤10) 进入段。
    let pan_c = Center {
        dd: 45,
        zd: 45,
        zg: 92,
        gg: 92,
        start_index: 10,
        end_index: 14,
    };
    // Type1 → div_cand（四条件满足 ⟹ true）。
    assert!(cand_delta(
        BspCandType::Type1,
        &subs,
        19,
        Side::Long,
        &hist,
        &[],
        Some(&pan_c),
        DivergenceGauge::MacdArea
    ));
    // Type2/Type3 → true（per-rung 存在性已 base 门控，rung 载上级语境）。
    assert!(cand_delta(
        BspCandType::Type2,
        &subs,
        19,
        Side::Long,
        &hist,
        &[],
        Some(&pan_c),
        DivergenceGauge::MacdArea
    ));
    assert!(cand_delta(
        BspCandType::Type3,
        &subs,
        19,
        Side::Long,
        &hist,
        &[],
        Some(&pan_c),
        DivergenceGauge::MacdArea
    ));
    // Type1 无对齐候选段（source_index 不存在）⟹ false。
    assert!(!cand_delta(
        BspCandType::Type1,
        &subs,
        99,
        Side::Long,
        &hist,
        &[],
        Some(&pan_c),
        DivergenceGauge::MacdArea
    ));
}

/// **Cand=false ⟹ N^δ 整体=false（Cand 传播测试）**。
///
/// 同塔结构，但 hist=0（条件4 area=0 < 0 = false ⟹ Cand=false）。
/// 验证 build_multilevel_nest_cert 真走 N^δ 路径（任一级 Cand=0 ⟹ 整体 0）。
#[test]
fn multilevel_nest_cert_cand_false_propagates_zero() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::{ElementId, LeveledMove};
    use super::super::super::types::{BspBits, Center, Direction, Side};
    use std::rc::Rc;

    let seg = |dir: Direction, lo: i64, hi: i64, s: usize, e: usize, ord: u64| -> LeveledMove {
        LeveledMove {
            rmove: RMove::Segment {
                direction: dir,
                lo,
                hi,
            },
            start_index: s,
            end_index: e,
            sub_moves: Rc::new(vec![]),
            id: ElementId {
                level: 0,
                ordinal: ord,
            },
        }
    };
    let s0 = seg(Direction::Up, 50, 100, 0, 4, 0);
    let s1 = seg(Direction::Down, 40, 90, 5, 9, 1);
    let s2 = seg(Direction::Up, 45, 95, 10, 14, 2);
    let s3 = seg(Direction::Down, 30, 85, 15, 19, 3);
    let sub_rmoves: Vec<RMove> = vec![
        s0.rmove.clone(),
        s1.rmove.clone(),
        s2.rmove.clone(),
        s3.rmove.clone(),
    ];
    let lo = 30i64;
    let hi = 100i64;
    let parent = LeveledMove {
        rmove: RMove::Compose {
            subs: Rc::new(sub_rmoves),
            centers: vec![Center {
                zd: lo,
                zg: hi,
                dd: lo,
                gg: hi,
                start_index: 0,
                end_index: 19,
            }],
            level: 1,
        },
        start_index: 0,
        end_index: 19,
        sub_moves: Rc::new(vec![s0.clone(), s1.clone(), s2.clone(), s3.clone()]),
        id: ElementId {
            level: 1,
            ordinal: 0,
        },
    };
    let tower: Vec<Rc<Vec<LeveledMove>>> =
        vec![Rc::new(vec![s0, s1, s2, s3]), Rc::new(vec![parent])];
    // hist 全 0 ⟹ area=0 ⟹ 条件4 0 < 0 = false ⟹ Cand=false ⟹ n_delta()=false
    let hist = vec![0.0f64; 20];
    let mut bits = BspBits::default();
    bits.buy1 = true;
    let result = build_multilevel_nest_cert(
        &tower,
        0,
        19,
        Side::Long,
        &bits,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    assert!(
        !result,
        "Cand=false（hist=0）⟹ n_delta()=false（Cand 传播路径）"
    );
}

/// **673 号段1：Type2 存在性免本级背驰段门**。
///
/// 与 `multilevel_nest_cert_cand_false_propagates_zero` 同塔（hist=0 ⟹ div_cand 条件4 false），
/// 对照两类信号：Type1（buy1）div_cand 守门 ⟹ false（bit-exact 不动）；Type2（buy2）存在性由
/// 结构分类前提保证（第17课L60 完备性），不经本级背驰段谓词 ⟹ 免门 ⟹ n_delta()=true。
#[test]
fn multilevel_nest_cert_type2_bypasses_divergence_gate() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::{ElementId, LeveledMove};
    use super::super::super::types::{BspBits, Center, Direction, Side};
    use std::rc::Rc;

    let seg = |dir: Direction, lo: i64, hi: i64, s: usize, e: usize, ord: u64| -> LeveledMove {
        LeveledMove {
            rmove: RMove::Segment {
                direction: dir,
                lo,
                hi,
            },
            start_index: s,
            end_index: e,
            sub_moves: Rc::new(vec![]),
            id: ElementId {
                level: 0,
                ordinal: ord,
            },
        }
    };
    let s0 = seg(Direction::Up, 50, 100, 0, 4, 0);
    let s1 = seg(Direction::Down, 40, 90, 5, 9, 1);
    let s2 = seg(Direction::Up, 45, 95, 10, 14, 2);
    let s3 = seg(Direction::Down, 30, 85, 15, 19, 3);
    let sub_rmoves: Vec<RMove> = vec![
        s0.rmove.clone(),
        s1.rmove.clone(),
        s2.rmove.clone(),
        s3.rmove.clone(),
    ];
    let lo = 30i64;
    let hi = 100i64;
    let parent = LeveledMove {
        rmove: RMove::Compose {
            subs: Rc::new(sub_rmoves),
            centers: vec![Center {
                zd: lo,
                zg: hi,
                dd: lo,
                gg: hi,
                start_index: 0,
                end_index: 19,
            }],
            level: 1,
        },
        start_index: 0,
        end_index: 19,
        sub_moves: Rc::new(vec![s0.clone(), s1.clone(), s2.clone(), s3.clone()]),
        id: ElementId {
            level: 1,
            ordinal: 0,
        },
    };
    let tower: Vec<Rc<Vec<LeveledMove>>> =
        vec![Rc::new(vec![s0, s1, s2, s3]), Rc::new(vec![parent])];
    let hist = vec![0.0f64; 20]; // div_cand 条件4 area=0<0=false（Type1 会被守门）

    // Type1（buy1）：div_cand 守门不变 ⟹ false。
    let mut t1 = BspBits::default();
    t1.buy1 = true;
    assert!(
        !build_multilevel_nest_cert(
            &tower,
            0,
            19,
            Side::Long,
            &t1,
            &hist,
            &[],
            DivergenceGauge::MacdArea
        ),
        "Type1 div_cand 条件4 false ⟹ n_delta()=false（本级背驰段门守 Type1 bit-exact）"
    );

    // Type2（buy2）：存在性免本级背驰段门 ⟹ true。
    let mut t2 = BspBits::default();
    t2.buy2 = true;
    assert!(
        build_multilevel_nest_cert(
            &tower,
            0,
            19,
            Side::Long,
            &t2,
            &hist,
            &[],
            DivergenceGauge::MacdArea
        ),
        "Type2 存在性免本级背驰段门（673 段1）⟹ n_delta()=true"
    );
}

/// **方向 dir=−δ 反测试**：信号 δ=Long 但 source_index 指向 Up 段（dir 不反）⟹ false。
#[test]
fn multilevel_nest_cert_wrong_direction_returns_false() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::{ElementId, LeveledMove};
    use super::super::super::types::{BspBits, Center, Direction, Side};
    use std::rc::Rc;

    let seg = |dir: Direction, lo: i64, hi: i64, s: usize, e: usize, ord: u64| -> LeveledMove {
        LeveledMove {
            rmove: RMove::Segment {
                direction: dir,
                lo,
                hi,
            },
            start_index: s,
            end_index: e,
            sub_moves: Rc::new(vec![]),
            id: ElementId {
                level: 0,
                ordinal: ord,
            },
        }
    };
    // 最后一段是 Up（非 Down），δ=Long 要求 Down → 条件1 失败
    let s0 = seg(Direction::Down, 30, 90, 0, 4, 0);
    let s1 = seg(Direction::Up, 40, 100, 5, 9, 1); // s'
    let s2 = seg(Direction::Down, 35, 95, 10, 14, 2);
    let s3 = seg(Direction::Up, 50, 110, 15, 19, 3); // s：Up，δ=Long 要求 Down → 失败
    let sub_rmoves: Vec<RMove> = vec![
        s0.rmove.clone(),
        s1.rmove.clone(),
        s2.rmove.clone(),
        s3.rmove.clone(),
    ];
    let lo = 30i64;
    let hi = 110i64;
    let parent = LeveledMove {
        rmove: RMove::Compose {
            subs: Rc::new(sub_rmoves),
            centers: vec![Center {
                zd: lo,
                zg: hi,
                dd: lo,
                gg: hi,
                start_index: 0,
                end_index: 19,
            }],
            level: 1,
        },
        start_index: 0,
        end_index: 19,
        sub_moves: Rc::new(vec![s0.clone(), s1.clone(), s2.clone(), s3.clone()]),
        id: ElementId {
            level: 1,
            ordinal: 0,
        },
    };
    let tower: Vec<Rc<Vec<LeveledMove>>> =
        vec![Rc::new(vec![s0, s1, s2, s3]), Rc::new(vec![parent])];
    let hist: Vec<f64> = (0..20).map(|_| 2.0).collect();
    let mut bits = BspBits::default();
    bits.buy1 = true;
    // s3 是 Up 段，δ=Long 要求 Down → 条件1 失败 → false
    let result = build_multilevel_nest_cert(
        &tower,
        0,
        19,
        Side::Long,
        &bits,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    assert!(!result, "dir(s)≠−δ（Up 段但 δ=Long）⟹ false（条件1 失败）");
}

// ── 673 号段2：定律一下沉锚定（Type2/3 精确定位锚次级别 Type1）─────────────────

use super::super::super::classifier::descend::RMove as RM2;
use super::super::super::classifier::recursive_tower::{ElementId as EId2, LeveledMove as LM2};
use super::super::super::types::{Center as Ct2, Direction as Dir2};
use std::rc::Rc as Rc2;

fn seg2(dir: Dir2, lo: i64, hi: i64, s: usize, e: usize, ord: u64) -> LM2 {
    LM2 {
        rmove: RM2::Segment {
            direction: dir,
            lo,
            hi,
        },
        start_index: s,
        end_index: e,
        sub_moves: Rc2::new(vec![]),
        id: EId2 {
            level: 0,
            ordinal: ord,
        },
    }
}

/// ★#883：中枢改显式入参——D-3 取段要求「界」可用（目标段破核心、前同向段命中
/// 进入段/破核心段），旧「核心=全体外缘」夹具下 `lo < zd` 恒假、条件2 不可达。
/// 进入段口径快捷构造：`center(zd, zg, start, end)` 取 `start` 使前同向段
/// `end_index ≤ start`（进入段）、`zd`/`zg` 使目标段破核心。
fn compose2(subs: Vec<LM2>, center: Ct2, level: u32, ord: u64) -> LM2 {
    let start = subs.first().map(|m| m.start_index).unwrap_or(0);
    let end = subs.last().map(|m| m.end_index).unwrap_or(0);
    let sub_rmoves: Vec<RM2> = subs.iter().map(|m| m.rmove.clone()).collect();
    LM2 {
        rmove: RM2::Compose {
            subs: Rc::new(sub_rmoves),
            centers: vec![center],
            level,
        },
        start_index: start,
        end_index: end,
        sub_moves: Rc2::new(subs),
        id: EId2 {
            level,
            ordinal: ord,
        },
    }
}

/// #883 测试中枢快捷构造（外缘取核心值，本组测试不消费外缘）。
fn ct2(zd: i64, zg: i64, start: usize, end: usize) -> Ct2 {
    Ct2 {
        dd: zd,
        zd,
        zg,
        gg: zg,
        start_index: start,
        end_index: end,
    }
}

/// #1052 回归锁（#1028 裁定 A）：一类点点锚迁移到 departure 单元终点后，`source_index`
/// 落在 C 段**内部**（末子段为回抽反趋势段）——gate 的执行段定位必须用「区间包含」
/// （[`find_move_containing_index`]）命中 C 段；`end ==` 精确匹配对 interior 锚 MISS，
/// 是迁移前会把此类 L≥1 一类点误拒的病灶。
#[test]
fn gate_locates_exec_segment_by_containment_after_anchor_migration() {
    use super::super::super::classifier::cand_predicate::departure_unit_end;
    // L0：趋势两段 Down + 尾段回抽 Up（pullback）——C 段末子段是反趋势段。
    let s0 = seg2(Dir2::Down, 100, 80, 0, 5, 0);
    let s1 = seg2(Dir2::Down, 90, 70, 5, 9, 1);
    let s2 = seg2(Dir2::Up, 70, 85, 9, 13, 2);
    let c = compose2(
        vec![s0.clone(), s1.clone(), s2.clone()],
        ct2(70, 85, 9, 13),
        1,
        0,
    );
    assert_eq!(c.end_index, 13, "C 段 end = 末子段(回抽)终点");
    let departure = departure_unit_end(&c, Dir2::Down).expect("存在趋势方向子段");
    assert_eq!(
        departure, 9,
        "departure 终点 = 最后趋势子段终点 9（interior）"
    );

    let tower: Vec<Rc2<Vec<LM2>>> = vec![Rc2::new(vec![s0, s1, s2]), Rc2::new(vec![c])];
    // 迁移后 interior 锚：`end ==` MISS，`区间包含` 命中 C 段（tower[1] 唯一段）。
    assert_eq!(find_move_by_end_index(&tower[1], departure), None);
    assert_eq!(find_move_containing_index(&tower[1], departure), Some(0));
    // 段终点锚（无 pullback 的退化情形）：两者同值，`区间包含` 不改旧行为。
    assert_eq!(find_move_by_end_index(&tower[1], 13), Some(0));
    assert_eq!(find_move_containing_index(&tower[1], 13), Some(0));

    // 端到端：gate 以迁移后的 interior 锚定位执行段，证书非 None（修前此处返回 None ⟹ 误拒）。
    let hist: Vec<f64> = (0..14).map(|_| -1.0).collect();
    let mut bits = BspBits::default();
    bits.buy1 = true;
    let cert = build_nest_certificate(
        &tower,
        1,
        departure,
        Side::Long,
        &bits,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    assert!(
        cert.is_some(),
        "gate 须以 interior 锚命中 C 段（修前 find_move_by_end_index MISS ⟹ None）"
    );
    assert_eq!(
        cert.as_ref().map(|c| c.base_interval().start_index),
        Some(0),
        "base_interval 仍是 C 段全区间（锚迁移只动点、不动区间套语义）"
    );
}

/// ★#1234 回归锁（#1052/#1028 裁定 A 同口径）：点锚迁移后 `source_index` 可能落在执行段**内部**
/// （departure 单元终点 = 末趋势子段终点，非 C 段 `end_index`）。`build_xzd_fallback` 的小转大
/// 执行段定位须用「区间包含」（[`find_move_containing_index`]）命中 C 段；`end ==` 精确匹配
/// 对 interior 锚 MISS ⟹ 修前会把 Type2/3 小转大域误拒为 None。
#[test]
fn xzd_fallback_locates_exec_segment_by_containment_after_anchor_migration() {
    use super::super::super::classifier::cand_predicate::departure_unit_end;
    // 同 gate_locates 夹具：L0 趋势两段 Down + 尾段回抽 Up——C 段末子段是反趋势段。
    let s0 = seg2(Dir2::Down, 100, 80, 0, 5, 0);
    let s1 = seg2(Dir2::Down, 90, 70, 5, 9, 1);
    let s2 = seg2(Dir2::Up, 70, 85, 9, 13, 2);
    let c = compose2(
        vec![s0.clone(), s1.clone(), s2.clone()],
        ct2(70, 85, 9, 13),
        1,
        0,
    );
    let departure = departure_unit_end(&c, Dir2::Down).expect("存在趋势方向子段");
    assert_eq!(
        departure, 9,
        "departure 终点 = 最后趋势子段终点 9（interior）"
    );

    let tower: Vec<Rc2<Vec<LM2>>> = vec![Rc2::new(vec![s0, s1, s2]), Rc2::new(vec![c])];
    // 迁移后 interior 锚：`end ==` MISS，`区间包含` 命中 C 段（tower[1] 唯一段）。
    assert_eq!(find_move_by_end_index(&tower[1], departure), None);
    assert_eq!(find_move_containing_index(&tower[1], departure), Some(0));

    // Type3 位（buy3）：修前 find_move_by_end_index MISS ⟹ None 误拒；修后区间包含命中 C 段
    // ⟹ 进入小转大域（Type2/3 ⟹ Some(XzdEvidence)）。
    let bits = BspBits {
        buy3: true,
        ..Default::default()
    };
    let ev = build_xzd_fallback(
        &tower,
        1,
        departure,
        Side::Long,
        &bits,
        departure,
        &[],
        &[],
        &[],
        &[],
    );
    assert!(
        ev.is_some(),
        "xzd 回退须以 interior 锚命中 C 段（修前 find_move_by_end_index MISS ⟹ None 误拒）"
    );
    assert_eq!(
        ev.map(|e| e.source_index),
        Some(departure),
        "证据锚 = departure 终点"
    );
}

/// 段2 正例：Type2@lvl1 的回抽次级别走势 m2 内部含次级别 Type1 背驰段（end==source_index）
/// ⟹ 下沉锚定 Some(1) ⟹ 证书非 None ⟹ n_delta=true（存在性 buy2 基例 + 精确定位已门控）。
#[test]
fn nest_cert_type2_sublevel_type1_anchor_passes() {
    // m2（level1 回抽走势）的次级别（level0）：up/down(s')/up/down(s@19)，趋势背驰。
    let s0 = seg2(Dir2::Up, 50, 100, 0, 4, 0);
    let s1 = seg2(Dir2::Down, 40, 90, 5, 9, 1); // s'：Down lo=40
    let s2 = seg2(Dir2::Up, 45, 95, 10, 14, 2);
    let s3 = seg2(Dir2::Down, 30, 85, 15, 19, 3); // s：Down lo=30<40 Extreme，end=19
    let m2 = compose2(
        vec![s0.clone(), s1.clone(), s2.clone(), s3.clone()],
        ct2(45, 92, 10, 14),
        1,
        0,
    );
    let tower: Vec<Rc2<Vec<LM2>>> =
        vec![Rc2::new(vec![s0, s1, s2, s3]), Rc2::new(vec![m2.clone()])];
    // s3(15-19) area=5*1=5 < s1(5-9) area=5*2=10（Weak ✓）。
    let hist: Vec<f64> = (0..20).map(|i| if i < 10 { -2.0 } else { -1.0 }).collect();

    let locator = super::descend_type1_anchor_depth(
        &m2,
        19,
        Side::Long,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    assert_eq!(locator.depth(), 1, "次级别 Type1 锚点成立 ⟹ 下沉深度 1");
    assert_eq!(
        locator.stop(),
        DescendStop::BaseL0,
        "s3 是 L0 段（sub_moves 空）⟹ 终止 = L0 天花板（#520 基底选择）"
    );
    let mut buy2 = super::super::super::types::BspBits::default();
    buy2.buy2 = true;
    assert!(
        build_multilevel_nest_cert(
            &tower,
            1,
            19,
            Side::Long,
            &buy2,
            &hist,
            &[],
            DivergenceGauge::MacdArea
        ),
        "Type2@lvl1 次级别锚点成立 ⟹ 证书非 None ⟹ n_delta=true"
    );
}

/// 段2 小转大（可证伪判别）：同结构但次级别无一类背驰锚点（hist=0 ⟹ div_cand Weak 假）
/// ⟹ 下沉锚定 None ⟹ 证书 None ⟹ 门拒（build_multilevel_nest_cert=false）。
#[test]
fn nest_cert_type2_no_sublevel_anchor_is_xiaozhuandaa_none() {
    let s0 = seg2(Dir2::Up, 50, 100, 0, 4, 0);
    let s1 = seg2(Dir2::Down, 40, 90, 5, 9, 1);
    let s2 = seg2(Dir2::Up, 45, 95, 10, 14, 2);
    let s3 = seg2(Dir2::Down, 30, 85, 15, 19, 3);
    let m2 = compose2(
        vec![s0.clone(), s1.clone(), s2.clone(), s3.clone()],
        ct2(45, 92, 10, 14),
        1,
        0,
    );
    let tower: Vec<Rc2<Vec<LM2>>> =
        vec![Rc2::new(vec![s0, s1, s2, s3]), Rc2::new(vec![m2.clone()])];
    let hist = vec![0.0f64; 20]; // area=0 ⟹ 0<0 false ⟹ div_cand 假 ⟹ 次级别无一类锚点

    let locator = super::descend_type1_anchor_depth(
        &m2,
        19,
        Side::Long,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    assert_eq!(locator.depth(), 0, "次级别无一类背驰锚点 ⟹ 未下沉");
    assert_eq!(
        locator.stop(),
        DescendStop::NoDivergence,
        "hist=0 ⟹ div_cand 假 ⟹ 判据层终止（小转大，显式可测判别）"
    );
    let mut buy2 = super::super::super::types::BspBits::default();
    buy2.buy2 = true;
    assert!(
        !build_multilevel_nest_cert(
            &tower,
            1,
            19,
            Side::Long,
            &buy2,
            &hist,
            &[],
            DivergenceGauge::MacdArea
        ),
        "小转大（次级别无 Type1）⟹ 证书 None ⟹ 门拒"
    );
}

/// 段2 真递归下沉：次级别 Type1 段本身内部再含次次级别 Type1 背驰段（end 同为 source_index）
/// ⟹ 逐级收缩到最低可用级别，深度 Some(2)（不是只下沉一级就停）。
#[test]
fn descend_anchor_recurses_below_one_level() {
    // hist 递减：靠后 bar 力度更小（Weak 各级满足）。
    // #988：Side::Long ⟹ 绿柱（负衰减）。
    let hist: Vec<f64> = (0..20).map(|i| -(20 - i) as f64).collect();
    // A0（level1 Down @0-9）：a0(Up)/a1(Down)。
    let a0 = seg2(Dir2::Up, 60, 100, 0, 4, 0);
    let a1 = seg2(Dir2::Down, 40, 95, 5, 9, 1);
    let big_a0 = compose2(vec![a0, a1], ct2(45, 92, 10, 10), 1, 0); // lo=40
                                                                    // Amid（level1 Up @10-13）。
    let am0 = seg2(Dir2::Down, 45, 90, 10, 11, 2);
    let am1 = seg2(Dir2::Up, 50, 110, 12, 13, 3);
    let amid = compose2(vec![am0, am1], ct2(45, 92, 10, 13), 1, 1);
    // A1（level1 Down @14-19，内部 level0 趋势背驰 @19）。
    let b0 = seg2(Dir2::Up, 48, 105, 14, 15, 4);
    let b1 = seg2(Dir2::Down, 42, 92, 16, 16, 5); // 次次级别 s' Down lo=42
    let b2 = seg2(Dir2::Up, 46, 96, 17, 17, 6);
    let b3 = seg2(Dir2::Down, 30, 85, 18, 19, 7); // 次次级别 s Down lo=30<42，end=19
    let big_a1 = compose2(vec![b0, b1, b2, b3], ct2(45, 92, 17, 19), 1, 2); // lo=30
                                                                            // s（level2）：[A0(Down), Amid(Up), A1(Down@19)]。
    let s = compose2(vec![big_a0, amid, big_a1], ct2(45, 92, 10, 19), 2, 0);

    let locator = super::descend_type1_anchor_depth(
        &s,
        19,
        Side::Long,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    assert_eq!(
        locator.depth(),
        2,
        "次级别 Type1 + 次次级别 Type1 ⟹ 真递归下沉深度 2"
    );
    assert_eq!(
        locator.stop(),
        DescendStop::BaseL0,
        "最深层是 L0 段（sub_moves 空）⟹ 终止 = L0 天花板"
    );
}

/// ★S4 接线测试锁（#802 空洞①/②）：下钻纯函数在「L0 以上取不到包含段」时返回
/// [`DescendStop::NoAlign`]（B 类，#846 零反例）——函数保持纯返回不 panic，
/// 报错守卫在生产消费层 `debug_assert_ne!` 落地（见下一个 `#[should_panic]` 锁）。
#[test]
fn descend_locator_reports_noalign_for_malformed_sub_moves() {
    // m 的 sub_moves 非空，但没有任何段 end_index == source_index（19）且无包含段
    // （19 > 末段 end=14）——塔构造不变量（父段末尾恒等于子段末尾）违反的合成反例
    // （#846 B 类零反例 ⟹ 真实数据不可达）。
    let s0 = seg2(Dir2::Up, 50, 100, 0, 4, 0);
    let s1 = seg2(Dir2::Down, 40, 90, 5, 9, 1);
    let s2 = seg2(Dir2::Up, 45, 95, 10, 14, 2); // 末段 end=14 ≠ 19
    let m = compose2(vec![s0, s1, s2], ct2(45, 92, 10, 14), 1, 0);
    let hist = vec![0.0f64; 20];
    let locator = super::descend_type1_anchor_depth(
        &m,
        19,
        Side::Long,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    assert_eq!(locator.depth(), 0, "无对齐段 ⟹ 未下沉");
    assert_eq!(
        locator.stop(),
        DescendStop::NoAlign,
        "sub_moves 非空但无 end== 对齐段也无包含段 ⟹ B 类（结构不变量违反）"
    );
}

/// #1076 回归锁（#1028 终局）：departure 终点落次级别走势**内部**（非段边界）时，下钻锚定位
/// 从 `end ==` 精确匹配回退「区间包含」定位（[`find_move_containing_index`]）——不再落
/// [`DescendStop::NoAlign`] 误断（修前 54 例对齐回退被排除）。只动锚定位，`div_cand` 判据链逐字不动。
#[test]
fn descend_anchor_falls_back_to_containment_for_interior_anchor() {
    // m 的 sub_moves：[0..4],[5..9],[10..14]；source_index=12 落末段**内部**（非 9/14 段边界）。
    let s0 = seg2(Dir2::Up, 50, 100, 0, 4, 0);
    let s1 = seg2(Dir2::Down, 40, 90, 5, 9, 1);
    let s2 = seg2(Dir2::Up, 45, 95, 10, 14, 2);
    let m = compose2(vec![s0, s1, s2], ct2(45, 92, 10, 14), 1, 0);
    let subs = m.sub_moves.as_slice();
    // 精确匹配 MISS（12 非任何段 end_index）；区间包含 HIT（末段 [10..14] 含 12）。
    assert_eq!(find_move_by_end_index(subs, 12), None);
    assert_eq!(find_move_containing_index(subs, 12), Some(2));

    let hist = vec![0.0f64; 20];
    let locator = super::descend_type1_anchor_depth(
        &m,
        12,
        Side::Long,
        &hist,
        &[],
        DivergenceGauge::MacdArea,
    );
    // 回退生效：不再落 NoAlign（修前此处 = NoAlign ⟹ Type2/3 门拒、Type1 不变式误报）。
    assert_ne!(
        locator.stop(),
        DescendStop::NoAlign,
        "interior 锚须由区间包含回退消化，不得落 NoAlign"
    );
}

/// ★S4 接线测试锁（#802 空洞③「Type1 从不下钻」）：Type1 的 base gate **确实执行**了下钻
/// ——malformed 塔（NoAlign）会使消费层不变式 `debug_assert_ne!` 报错。若 Type1 退回恒
/// `true` 不下钻，本测试将因「期望 panic 但未 panic」而失败（debug 构建；release 下该
/// 断言编译掉，故本锁仅在 `cargo test` 默认 debug 档有效）。
#[test]
#[should_panic(expected = "Type1 下钻：L0 以上取不到包含段")]
fn type1_base_gate_fires_noalign_invariant_on_malformed_tower() {
    let s0 = seg2(Dir2::Up, 50, 100, 0, 4, 0);
    let s1 = seg2(Dir2::Down, 40, 90, 5, 9, 1);
    let s2 = seg2(Dir2::Up, 45, 95, 10, 14, 2); // 末段 end=14 ≠ 19
    let m = compose2(vec![s0, s1, s2], ct2(45, 92, 10, 14), 1, 0);
    let hist = vec![0.0f64; 20];
    let _ = super::cand_delta_base_gate(
        BspCandType::Type1,
        &m,
        19,
        Side::Long,
        &hist,
        1,
        &[],
        DivergenceGauge::MacdArea,
    );
}

/// ★S4 接线测试锁（#802 空洞③）：Type1 下钻是**定位读数**不是准入门——即使 div_cand 判假
/// （NoDivergence，探针 #852/#870 实测首步 ≈92.7%），base gate 仍 true（背驰判定在
/// per-rung `div_cand`），不误杀 Type1 信号。
#[test]
fn type1_base_gate_descends_but_never_rejects() {
    let s0 = seg2(Dir2::Up, 50, 100, 0, 4, 0);
    let s1 = seg2(Dir2::Down, 40, 90, 5, 9, 1);
    let s2 = seg2(Dir2::Up, 45, 95, 10, 14, 2);
    let s3 = seg2(Dir2::Down, 30, 85, 15, 19, 3); // end==19 对齐，但 hist=0 ⟹ div_cand 假
    let m2 = compose2(vec![s0, s1, s2, s3], ct2(45, 92, 10, 14), 1, 0);
    let hist = vec![0.0f64; 20]; // div_cand 条件4 假 ⟹ NoDivergence
    assert!(
        super::cand_delta_base_gate(
            BspCandType::Type1,
            &m2,
            19,
            Side::Long,
            &hist,
            1,
            &[],
            DivergenceGauge::MacdArea,
        ),
        "Type1 下钻结果不作准入门——NoDivergence 时 base gate 仍 true（不误杀 Type1）"
    );
}

// ── Q4（task #145）：盘整背驰承接门 pan_div_gate_pass（Nest/XZD 二通道）─────────

fn pan_cert(source_index: usize, side: Side) -> PanDivCert {
    PanDivCert {
        source_index,
        side,
        center: xzd_center(40, 50, 0, 4),
        seg_a: (5, 9),
        seg_c: (15, 19),
    }
}

/// Nest 通道正例：复用 `nest_cert_type2_sublevel_type1_anchor_passes` 的塔——m2@tower[1]
/// 的次级别含 Type1 背驰锚（descend Some(1)）⟹ ∃e<ℓ Conf^δ_e ⟹ PanDiv 承接成立
/// （collect_signals 据此组 RawSignal，trigger=PanDivConsolidation）。
#[test]
fn pan_div_gate_nest_channel_passes_via_sublevel_type1_anchor() {
    let s0 = seg2(Dir2::Up, 50, 100, 0, 4, 0);
    let s1 = seg2(Dir2::Down, 40, 90, 5, 9, 1);
    let s2 = seg2(Dir2::Up, 45, 95, 10, 14, 2);
    let s3 = seg2(Dir2::Down, 30, 85, 15, 19, 3);
    let m2 = compose2(
        vec![s0.clone(), s1.clone(), s2.clone(), s3.clone()],
        ct2(45, 92, 10, 14),
        1,
        0,
    );
    let tower: Vec<Rc2<Vec<LM2>>> = vec![Rc2::new(vec![s0, s1, s2, s3]), Rc2::new(vec![m2])];
    let hist: Vec<f64> = (0..20).map(|i| if i < 10 { -2.0 } else { -1.0 }).collect();
    assert!(
        super::pan_div_gate_pass(
            &tower,
            1,
            &pan_cert(19, Side::Long),
            &hist,
            19,
            &[],
            &[],
            &[],
            &[], // ★#883：测试无笔源
            DivergenceGauge::MacdArea,
        ),
        "Nest 通道：次级别 Type1 锚（descend Some）⟹ PanDiv^δ_ℓ ⟹ ∃e<ℓ Conf^δ_e 承接成立"
    );
}

/// XZD 通道正例（#1220 每级同一个判据后）：Nest 闭（下钻 cond1 方向假）+ C2 共生 buy2 +
/// C3 新中枢反向突破（三买坐实，level1）⟹ XZD^δ 承接成立。
#[test]
fn pan_div_gate_xzd_channel_passes_via_type2_confirmed() {
    // tower[0]（次级别走势）：前段供下钻锚定位，后段承载 C3 新中枢 + 反向突破。
    let m0 = seg2(Dir2::Up, 45, 55, 0, 5, 0);
    let m1 = seg2(Dir2::Down, 30, 40, 6, 10, 1);
    let m2 = seg2(Dir2::Up, 45, 55, 11, 15, 2); // end==15（δ=Long 要求 Down ⟹ cond1 假 ⟹ Nest 闭）
    let m3 = seg2(Dir2::Up, 45, 55, 16, 18, 3); // 新中枢内部段（不参门）
    let m4 = seg2(Dir2::Up, 45, 60, 19, 19, 4); // 反向突破段：hi=60 > zg=50
    let s = compose2(
        vec![m0.clone(), m1.clone(), m2.clone()],
        ct2(45, 55, 11, 15),
        1,
        0,
    );
    let tower: Vec<Rc2<Vec<LM2>>> = vec![Rc2::new(vec![m0, m1, m2, m3, m4]), Rc2::new(vec![s])];
    let hist = vec![0.0f64; 20];
    let mut buy2 = BspBits::default();
    buy2.buy2 = true;
    let bsp_of_level = vec![xzd_bsp(15, buy2, None)];
    // C3 新中枢 [16,18]（start>=source=15，end<=confirm=19），其后 [19,19] hi=60>zg=50 反向突破。
    let sub_centers = vec![xzd_center(40, 50, 16, 18)];
    assert!(
        super::pan_div_gate_pass(
            &tower,
            1,
            &pan_cert(15, Side::Long),
            &hist,
            19,
            &bsp_of_level,
            &sub_centers,
            &[],
            &[], // 测试无笔源（例外臂无源不判 ⟹ 不触发）
            DivergenceGauge::MacdArea,
        ),
        "XZD 通道：Nest 闭（cond1 方向假）+ C2 共生 buy2 + C3 三买坐实 ⟹ 承接成立"
    );
}

/// #82 DC-E：XZD 任一门通过后，强类型生产门恰产一个引用，身份字段逐值保留。
#[test]
fn pan_div_gate_pass_emits_one_production_candidate() {
    let m0 = seg2(Dir2::Up, 45, 55, 0, 5, 0);
    let m1 = seg2(Dir2::Down, 30, 40, 6, 10, 1);
    let m2 = seg2(Dir2::Up, 45, 55, 11, 15, 2);
    let m3 = seg2(Dir2::Up, 45, 55, 16, 18, 3);
    let m4 = seg2(Dir2::Up, 45, 60, 19, 19, 4);
    let s = compose2(
        vec![m0.clone(), m1.clone(), m2.clone()],
        ct2(45, 55, 11, 15),
        1,
        0,
    );
    let tower: Vec<Rc2<Vec<LM2>>> = vec![Rc2::new(vec![m0, m1, m2, m3, m4]), Rc2::new(vec![s])];
    let hist = vec![0.0f64; 20];
    let mut buy2 = BspBits::default();
    buy2.buy2 = true;
    let bsp_of_level = vec![xzd_bsp(15, buy2, None)];
    let sub_centers = vec![xzd_center(40, 50, 16, 18)];
    let raw = pan_cert(15, Side::Long);
    let gated = super::gate_pan_div_for_production(
        &tower,
        1,
        &raw,
        &hist,
        19,
        &bsp_of_level,
        &sub_centers,
        &[],
        &[],
        DivergenceGauge::MacdArea,
    )
    .expect("XZD 门通过必须恰产一个 GatedPanDivCert");
    assert_eq!(gated.level(), 1);
    assert_eq!(gated.cert(), raw);
}

/// 两门皆闭：递归底无次级别锚（Nest 闭）∧ 无共生 buy2（XZD C2 假）⟹ 承接失败 ⟹
/// collect_signals 诚实丢弃该 PanDiv（不入信号流，不兜底）。
#[test]
fn pan_div_gate_both_channels_closed_rejects() {
    let tower: Vec<Rc2<Vec<LM2>>> = vec![Rc2::new(vec![xzd_seg(10, 19)])];
    let hist = vec![0.0f64; 20];
    assert!(
        !super::pan_div_gate_pass(
            &tower,
            0,
            &pan_cert(19, Side::Long),
            &hist,
            19,
            &[],
            &[],
            &[],
            &[], // ★#883：测试无笔源
            DivergenceGauge::MacdArea,
        ),
        "两门皆闭 ⟹ PanDiv 承接失败（诚实丢弃）"
    );
    // 执行段缺失（tower[lvl] 无包含 source_index 的段）⟹ 同样拒。
    assert!(
        !super::pan_div_gate_pass(
            &tower,
            0,
            &pan_cert(7, Side::Long),
            &hist,
            7,
            &[],
            &[],
            &[],
            &[],
            DivergenceGauge::MacdArea
        ),
        "无执行段定位 ⟹ 承接失败"
    );
}

/// #82 DC-E：裸证在两门皆闭时只能得到 None，不能绕过门直接进入生产候选。
#[test]
fn pan_div_raw_cert_never_directly_orders_when_gate_closed() {
    let tower: Vec<Rc2<Vec<LM2>>> = vec![Rc2::new(vec![xzd_seg(10, 19)])];
    let hist = vec![0.0f64; 20];
    assert_eq!(
        super::gate_pan_div_for_production(
            &tower,
            0,
            &pan_cert(19, Side::Long),
            &hist,
            19,
            &[],
            &[],
            &[],
            &[], // ★#883：测试无笔源
            DivergenceGauge::MacdArea,
        ),
        None
    );
}

/// PDF §4 反例的分解算术自检（合成，L1 验证分解算术正确）：
/// 多头反转交易腿 P[λ_rev]=10, P[ρ_rev]=12（Ab_rev=δ·2=2，δ=+1）；确认滞后 Pτin=11.8, Pτout=11.1。
/// ηin=max(0,11.8−10)=1.8, ηout=max(0,12−11.1)=0.9, captured=2−1.8−0.9−Ce<0（执行吃光）。
/// 664 号：λ_rev/ρ_rev 是入场/出场信号挂靠 pivot 端点价，δ=交易方向（非触发段笔方向 ε）。
#[test]
fn pdf_counterexample_decomp() {
    let eps = 1.0_f64; // 多头反转腿 δ=+1
    let (p_lambda, p_rho, p_tau_in, p_tau_out) = (10.0, 12.0, 11.8, 11.1);
    let a_b = eps * (p_rho - p_lambda);
    let eta_in = (eps * (p_tau_in - p_lambda)).max(0.0);
    let eta_out = (eps * (p_rho - p_tau_out)).max(0.0);
    let captured = a_b - eta_in - eta_out; // 无成本版
    assert!((a_b - 2.0).abs() < 1e-9);
    assert!((eta_in - 1.8).abs() < 1e-9);
    assert!((eta_out - 0.9).abs() < 1e-9);
    // 2 − 1.8 − 0.9 = −0.7 < 0：执行损耗吃光结构价差（PDF §4 因果亏 −0.7 的分解归因）。
    assert!(
        captured < 0.0,
        "captured={captured} 应 <0（PDF §4 反例：执行吃光价差）"
    );
    assert!((captured - (-0.7)).abs() < 1e-9);
}

/// 664 号反转交易腿方向语义自检（合成，L1）：底背驰买点 δ=+1，入场 pivot 低、出场 pivot 高
/// ⟹ Ab_rev=δ(P[ρ_rev]−P[λ_rev])>0；顶背驰卖点 δ=−1，入场 pivot 高、出场 pivot 低 ⟹ Ab_rev>0。
/// 两侧反转腿价差都为正——证明 δ 作用在 post-signal 腿（入场→出场 pivot）上，不与触发段方向 ε 耦合。
#[test]
fn reversal_leg_direction_semantics() {
    // 底买反转腿：λ_rev=入场低点 pivot 100，ρ_rev=出场高点 pivot 120，δ=+1。
    let ab_buy = 1.0_f64 * (120.0 - 100.0);
    assert!(
        ab_buy > 0.0,
        "底买反转腿 Ab_rev 应 >0（入场低点→出场高点），实得 {ab_buy}"
    );
    // 顶卖反转腿：λ_rev=入场高点 pivot 120，ρ_rev=出场低点 pivot 100，δ=−1。
    let ab_sell = (-1.0_f64) * (100.0 - 120.0);
    assert!(
        ab_sell > 0.0,
        "顶卖反转腿 Ab_rev 应 >0（入场高点→出场低点，δ=−1 翻正），实得 {ab_sell}"
    );
    // 对照（664 号错配示意）：δ 作用在触发段（底买出现在下跌段末端，触发段 Pρ<Pλ）⟹ δ·(Pρ−Pλ)<0
    // ——这正是旧实装系统性 ΣAb<0 的来源（测错对象，非判据被否证）。
    let ab_old_trigger = 1.0_f64 * (100.0 - 120.0);
    assert!(
        ab_old_trigger < 0.0,
        "旧触发段对象 δ·(Pρ−Pλ) 系统性负（对象错配示意）"
    );
}

/// spread_eaten 判据自检：Σcaptured≤0 ⟺ 损耗吃光。
#[test]
fn spread_eaten_iff_captured_nonpositive() {
    let mut agg = SpreadAttribution::default();
    agg.sum_captured = -0.1;
    assert!(agg.spread_eaten());
    agg.sum_captured = 0.1;
    assert!(!agg.spread_eaten());
}

/// 664-Q3 signed 分解恒等式自检（合成，L1）：actual_spread = Ab_rev − x_in − y_out 恒成立，
/// 覆盖有利滑移（x<0/y<0）——证明 actual_spread 含全部滑移，而 captured(adverse-only)=Ab−max(0,x)−max(0,y) 丢有利滑移。
#[test]
fn signed_decomp_actual_spread_identity() {
    // 多头：λ_rev=100, ρ_rev=120 ⟹ Ab_rev=20。Pτin=98（确认价比入场 pivot 更优，x<0 有利），
    // Pτout=125（出场比 pivot 更高，y<0 有利）。δ=+1。
    for &(p_lambda, p_rho, p_tau_in, p_tau_out, delta) in &[
        (100.0, 120.0, 98.0, 125.0, 1.0_f64), // 双侧有利滑移
        (100.0, 120.0, 105.0, 110.0, 1.0),    // 双侧不利滑移
        (120.0, 100.0, 122.0, 95.0, -1.0),    // 空头：入场更高(有利)、出场更低(有利)
    ] {
        let a_b = delta * (p_rho - p_lambda);
        let x_in = delta * (p_tau_in - p_lambda);
        let y_out = delta * (p_rho - p_tau_out);
        let actual_spread = delta * (p_tau_out - p_tau_in);
        // 恒等式：actual_spread = Ab_rev − x_in − y_out（codex Q3）。
        assert!(
            (actual_spread - (a_b - x_in - y_out)).abs() < 1e-9,
            "signed 分解恒等式破：actual_spread={actual_spread} ≠ Ab−x−y={}",
            a_b - x_in - y_out
        );
        // adverse-only captured 与 actual_spread 的差 = min(x,0)+min(y,0) ≤ 0（系统性低估）。
        let captured_no_cost = a_b - x_in.max(0.0) - y_out.max(0.0);
        let diff = captured_no_cost - actual_spread;
        assert!(
            diff <= 1e-9,
            "adverse-only captured 应 ≤ actual_spread（丢有利滑移），diff={diff}"
        );
        assert!(
            (diff - (x_in.min(0.0) + y_out.min(0.0))).abs() < 1e-9,
            "captured−actual 应 = min(x,0)+min(y,0)"
        );
    }
}

/// actual_pnl_proxy / actual_pnl_eaten 判据自检：与 spread_eaten 可分歧（codex Q3 核心）。
#[test]
fn actual_pnl_proxy_diverges_from_adverse_only() {
    let mut agg = SpreadAttribution::default();
    // 构造：actual_spread 正、但 adverse-only captured 负（有利滑移被丢导致伪「吃光」）。
    agg.sum_actual_spread = 100.0;
    agg.sum_ce = 30.0;
    agg.sum_captured = -50.0; // adverse-only 判定「吃光」
    assert!(agg.spread_eaten(), "adverse-only 判吃光");
    assert!((agg.actual_pnl_proxy() - 70.0).abs() < 1e-9);
    assert!(
        !agg.actual_pnl_eaten(),
        "真实成交口径未吃光 ⟹ adverse-only 是伪结论"
    );
}

/// L2 重测「钱去哪了」：BTC 全历史逐信号反转交易腿 Ab_rev 可捕获价差分解（真实数据，可产否定性结果；664 号）。
///
/// `#[ignore]`：需 BTC 全量数据（314M）+ O(n²) 逐 bar 重分类，`--release` 必须。重跑由 Lead。
/// 报告落盘 `.chanlun/review-results/econ-abrev-l2-btc-20260630.md`（确定性，可复算；不覆盖旧触发段报告）。
///
/// **L2 纪律**：spread_eaten=true ⟹ 该信号集执行损耗吃光反转交易腿价差（否证可交易，有效域收窄）；
/// spread_eaten=false ⟹ 该级别有可捕获 alpha——两者照实报，不粉饰（161/formalization-validity-domain）。
#[test]
#[ignore]
fn l2_btc_capturable_spread_diagnosis() {
    use super::super::data;
    use std::collections::BTreeMap;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();

    // 截断窗（显式有效域边界，非全窗结论；l3_delta_r_alpha::MAX_BARS 同纪律）：
    // ★fullhist-oom-fix-20260630 订正：旧注释「500K OOM 被杀=内存上限」是**误诊**（错误归因，090号）。
    // /usr/bin/time -l 实测峰值 RSS：100K=1990MB、200K=2010MB、400K=2034MB、600K=2083MB——
    // 内存随 bar **平坦**（100K→600K 仅 +5%），无 OOM。塔状态（TowerCache.upper_moves）累积是塔元素数
    // （走势/中枢，亚线性于 bar），不是「每 bar 一份 Rc 副本」。旧「500K OOM」实为 **O(n²) 时间墙超时被
    // kill** 被误报为 OOM。真瓶颈 = classify_incremental 的 O(tree)/bar 续算（profile_classify_at
    // 已坐实 t_exp≈2.0；归 Task #104/#105 classifier 核心优化）。截断窗在此**为时间非内存**：实测
    // 100K=8.7s、200K=31.8s、400K=124.5s、600K=283s（O(n²)），全量 461万≈数小时可跑通但慢。
    // env ECON_L2_MAX_BARS 覆盖供 Lead 调窗（>4.6M=不截断跑全量）。
    // #399：env 解析与截断边界算术收敛至共享 helper（mod tests 顶部）；
    // 本点保留 date-window 切片形态（带窗口 eprintln），算术与此前逐位一致。
    let max_bars = econ_l2_max_bars();
    let ds = match tail_window_start(n_full, max_bars) {
        Some(tail_start) => {
            let start = ds_full.dates[tail_start]
                .get(..10)
                .unwrap_or("")
                .to_string();
            let end = ds_full.dates[n_full - 1]
                .get(..10)
                .unwrap_or("")
                .to_string();
            eprintln!(
                "截断窗 [{start}→{end}]（最后 {max_bars} bar / 全量 {n_full}）= 显式有效域边界"
            );
            ds_full.slice_date_window(&start, &end)
        }
        None => ds_full,
    };
    let untradable = ds.untradable_ratio();
    let n_bars = ds.bars.len();
    let window_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let window_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();

    let (decomps, agg) = decompose_capturable_spread(&ds, &config);
    crate::theta_v0::classifier::stage_profile::dump();

    // b2（task #83）：per-class 分桶键从粗投影 Y=(level,δ,bsp_class) 升到完整状态 Z=[`MuClass`]
    // （含 σ_p/短差/仓位态/H=完整 R(g)）——编排者点破「回测跑在 Y 粗投影上」的接入点闭合。
    // 分桶载体 `d.z`（`MuClass` 派生 Ord ⟹ BTreeMap 有序）；同 (level,δ,I_γ) 按 σ_p/role 再细分。
    // codex #81 修正2：z 的类型位用 `z.i_class`（未压缩 6-bit），报告列展示避免 `bsp_class()` 压主类。
    // value=(n, Σab, Σηin, Σηout, Σce, Σcaptured, n_cap_pos, Σactual_spread, Σactual_pnl, n_act_pos)。
    type Bucket = (usize, f64, f64, f64, f64, f64, usize, f64, f64, usize);
    let mut buckets: BTreeMap<MuClass, Bucket> = BTreeMap::new();
    for d in &decomps {
        let e = buckets.entry(d.z).or_default();
        e.0 += 1;
        e.1 += d.a_b;
        e.2 += d.eta_in;
        e.3 += d.eta_out;
        e.4 += d.ce_unit;
        e.5 += d.captured;
        if d.captured > 0.0 {
            e.6 += 1;
        }
        e.7 += d.actual_spread;
        e.8 += d.actual_pnl;
        if d.actual_pnl > 0.0 {
            e.9 += 1;
        }
    }

    // ── dx 守恒（分划细化保 Σ，codex #81 修正5：细 key 求和回粗 key，写维度无关通用形式）──
    // Z 桶是 Y=(level,δ,bsp_class) 桶的不相交细分（同 Y 按 σ_p/role/H 再分）⟹ 分划细化。
    // 逐笔 actual_pnl 与分桶无关 ⟹ Σ_{z∈Z} 桶内和 == Σ_{y∈Y} 桶内和 == Σ_全体 decomps（守恒）。
    // 不写死 σ_p 一维——对任意细化维（σ_p/role/H/未来新维）恒成立（维度无关）。
    {
        let sum_z: f64 = buckets.values().map(|b| b.8).sum(); // Σ over Z 桶
        let sum_flat: f64 = decomps.iter().map(|d| d.actual_pnl).sum(); // Σ over 全体（粗 key 极限）
        debug_assert!(
            (sum_z - sum_flat).abs() <= 1e-6 * (1.0 + sum_flat.abs()),
            "dx 守恒破：Σ_Z 桶 actual_pnl={sum_z} ≠ Σ 全体={sum_flat}（分划细化应保 Σ）"
        );
    }

    // 失血三源占比（分母 = Σ(ηin+ηout+Ce) 总损耗；ΣAb 为正分母比对结构价差）。
    let total_drain = agg.sum_eta_in + agg.sum_eta_out + agg.sum_ce;
    let pct = |x: f64| {
        if total_drain > 0.0 {
            100.0 * x / total_drain
        } else {
            0.0
        }
    };

    let actual_pnl_proxy = agg.actual_pnl_proxy();

    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# 663 判据：BTC 全级别×方向逐信号 μ̂>0 + 全历史长窗累积净值"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "**认识论等级**：L2（真实数据单标的逐信号确定性分解，可产否定性结果）。"
    );
    let _ = writeln!(rpt, "**663 判据**：可交易性=μ(z,a)>0（正条件期望，出现就做不统计显著），**非** p<0.05 统计显著/跨品种符号检验。全级别 0..L 照报（级别是缠论全互斥定义构成部分，稀疏高级别不剔不判 Le Cam 硬墙——663 收窄 Le Cam 有效域至短窗单品种区分±Δ）。全历史长窗累积净值（O(n²) 已解锁 exp1.18，461万 bar ~2.6min）。");
    let _ = writeln!(rpt, "**664-Q3 修正**：旧 captured=Ab_rev−max(0,x)−max(0,y)−Ce 用 max(0,·) **丢有利滑移、全计不利滑移** ⟹ 系统性低估真实 PnL（captured−actual_pnl=min(x,0)+min(y,0)≤0）= **adverse-only 保守压力测试，非真实成交**。本报告补 signed Σx/Σy 与真实成交价差 actual_spread=δ(Pτout−Pτin)=Ab_rev−x−y。");
    let _ = writeln!(
        rpt,
        "**两口径**：x=δ(Pτin−Pλ_rev)（signed 入场滑移）、y=δ(Pρ_rev−Pτout)（signed 出场滑移）。"
    );
    let _ = writeln!(rpt, "- **adverse-only captured** = Ab_rev−max(0,x)−max(0,y)−Ce（压力测试，保守，保留兼容旧口径）。");
    let _ = writeln!(rpt, "- **真实成交 actual_pnl** = actual_spread−Ce = δ(Pτout−Pτin)−Ce（含全部滑移，更接近真实成交）。");
    let _ = writeln!(rpt, "**复算**：`cargo test -p <crate> --release l2_btc_capturable_spread_diagnosis -- --ignored --nocapture`（确定性）。");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 数据");
    let _ = writeln!(
        rpt,
        "- 品种：BTC（btc_1m_full.json，全量 {n_full} bar，2017-08→2026-05）"
    );
    let _ = writeln!(rpt, "- **截断窗 [{window_start}→{window_end}]，bars={n_bars}**（最后 {max_bars} bar；全量 461万 OOM 不可行 ⟹ 截断窗=显式有效域边界，非全窗结论，l3 同纪律）");
    let _ = writeln!(rpt, "- untradable_ratio={:.4}", untradable);
    let _ = writeln!(rpt, "- 收集信号数 n_signals={}（无配对出场反转信号的入场信号被诚实跳过，不入此集——无 ρ_rev 不兜底）", agg.n_signals);
    // #115 (e) fill-rate 断言（防 β^div 路由全 None 静默）。历史：曾 re-scope 到本报告，因当时
    // Candidate 边界无 force 源（fill loop 侧断言必误报，见 g2-impl-20260703.md）；A6（#159）后
    // Candidate 携 force、fill loop z_of_candidate 同样装配真值——fill loop 侧对应断言见
    // wverify_run::wverify_fullz（records 探针）。零一类信号的窗不假失败（force 仅一类 A/C 对候选有源）。
    let n_type1 = decomps
        .iter()
        .filter(|d| d.z.i_class & 0b001_001 != 0)
        .count();
    let n_force_some = decomps.iter().filter(|d| d.z.force_state.is_some()).count();
    assert!(
        n_type1 == 0 || n_force_some > 0,
        "β^div 路由静默断裂：{n_type1} 条一类信号 force_state 全 None"
    );
    let _ = writeln!(
        rpt,
        "- β^div force fill-rate：{}/{}（一类信号 {} 条；断言=有一类则 force 非全 None，#115 (e)）",
        n_force_some, agg.n_signals, n_type1
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 三审计统计（codex #97 要求）");
    let _ = writeln!(rpt, "| 统计 | 值 | 说明 |");
    let _ = writeln!(rpt, "|---|---|---|");
    let _ = writeln!(rpt, "| n_rho_after_lambda | {}/{} | rho_rev_bar>lambda_rev_bar（codex Q1 不变量：出场 pivot 端点在入场 pivot 之后） |", agg.n_rho_after_lambda, agg.n_signals);
    let _ = writeln!(rpt, "| n_same_bar_opposite | {} | 同 bar 出现反向信号（被 eb>entry_bar 排除的边界，codex Q2） |", agg.n_same_bar_opposite);
    let _ = writeln!(
        rpt,
        "| n_unpaired | {} | 无配对出场反转信号（右删失诚实跳过，codex Q4） |",
        agg.n_unpaired
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## P7 正规出场口径统计（接 interp ExitType CloseRoot/ReduceCore，n={}）",
        agg.n_signals
    );
    let _ = writeln!(rpt, "| 出场决策 | 信号数 | 占比 | 说明 |");
    let _ = writeln!(rpt, "|---|---|---|---|");
    let pct_sig = |x: usize| {
        if agg.n_signals > 0 {
            100.0 * x as f64 / agg.n_signals as f64
        } else {
            0.0
        }
    };
    let _ = writeln!(
        rpt,
        "| CloseRoot（第一类顶背驰） | {} | {:.1}% | interp ExitType::CloseRoot |",
        agg.n_exit_close_root,
        pct_sig(agg.n_exit_close_root)
    );
    let _ = writeln!(
        rpt,
        "| ReduceCore（第三类减核） | {} | {:.1}% | interp ExitType::ReduceCore |",
        agg.n_exit_reduce_core,
        pct_sig(agg.n_exit_reduce_core)
    );
    let _ = writeln!(rpt, "| Type2Missing（第二类 still-MISSING） | {} | {:.1}% | 第二类闭环诚实边界（见 ExitDecision docstring），不改账本口径 |", agg.n_exit_type2_missing, pct_sig(agg.n_exit_type2_missing));
    let _ = writeln!(
        rpt,
        "| Hold（无正规卖点 bit） | {} | {:.1}% | exit 信号无正规卖侧/买侧 bit |",
        agg.n_exit_hold,
        pct_sig(agg.n_exit_hold)
    );
    let _ = writeln!(rpt, "（认识论 L0：口径结构变，不声明 alpha；alpha 待 W-VERIFY L2/L3。第二类闭环 still-MISSING（需次级别递归，见 descend.rs），不碰 TW 三阶段/576。）");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 全局归因（双口径）");
    let _ = writeln!(rpt, "| 量 | 值 |");
    let _ = writeln!(rpt, "|---|---|");
    let _ = writeln!(
        rpt,
        "| ΣAb_rev（反转交易腿理想总价差） | {:.6e} |",
        agg.sum_a_b
    );
    let _ = writeln!(rpt, "| Σx（signed 入场滑移） | {:.6e} |", agg.sum_x_in);
    let _ = writeln!(rpt, "| Σy（signed 出场滑移） | {:.6e} |", agg.sum_y_out);
    let _ = writeln!(
        rpt,
        "| Σmax(0,x)=Σηin（adverse-only 入场） | {:.6e} ({:.1}%) |",
        agg.sum_eta_in,
        pct(agg.sum_eta_in)
    );
    let _ = writeln!(
        rpt,
        "| Σmax(0,y)=Σηout（adverse-only 出场） | {:.6e} ({:.1}%) |",
        agg.sum_eta_out,
        pct(agg.sum_eta_out)
    );
    let _ = writeln!(
        rpt,
        "| ΣCe（成本） | {:.6e} ({:.1}%) |",
        agg.sum_ce,
        pct(agg.sum_ce)
    );
    let _ = writeln!(
        rpt,
        "| Σactual_spread（真实成交价差 δ(Pτout−Pτin)） | {:.6e} |",
        agg.sum_actual_spread
    );
    let _ = writeln!(
        rpt,
        "| **Σcaptured（adverse-only 压力测试剩余）** | {:.6e} |",
        agg.sum_captured
    );
    let _ = writeln!(
        rpt,
        "| **actual_pnl_proxy=Σactual_spread−ΣCe（真实成交 PnL 代理）** | {:.6e} |",
        actual_pnl_proxy
    );
    let _ = writeln!(
        rpt,
        "| n_captured_positive/n（adverse-only 正占比） | {}/{} ({:.1}%) |",
        agg.n_captured_positive,
        agg.n_signals,
        if agg.n_signals > 0 {
            100.0 * agg.n_captured_positive as f64 / agg.n_signals as f64
        } else {
            0.0
        }
    );
    let _ = writeln!(
        rpt,
        "| n_actual_positive/n（真实成交正占比） | {}/{} ({:.1}%) |",
        agg.n_actual_positive,
        agg.n_signals,
        if agg.n_signals > 0 {
            100.0 * agg.n_actual_positive as f64 / agg.n_signals as f64
        } else {
            0.0
        }
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## L2 判定（关键：两口径分歧 = codex Q3 核心）");
    let _ = writeln!(
        rpt,
        "- **adverse-only spread_eaten = {}**（Σcaptured {} 0）",
        agg.spread_eaten(),
        if agg.spread_eaten() { "≤" } else { ">" }
    );
    let _ = writeln!(
        rpt,
        "- **真实成交 actual_pnl_eaten = {}**（actual_pnl_proxy {} 0）",
        agg.actual_pnl_eaten(),
        if agg.actual_pnl_eaten() { "≤" } else { ">" }
    );
    if agg.spread_eaten() && !agg.actual_pnl_eaten() {
        let _ = writeln!(rpt, "- **翻案（codex Q3 坐实）**：adverse-only 判「执行吃光」但真实成交 actual_pnl_proxy>0 ⟹ 之前「执行滞后吃光」(Σcaptured=−2.33e5) 是 **adverse-only 伪结论**——有利滑移被 max(0,·) 丢弃所致。真实成交口径下反转腿可捕获。");
    } else if agg.actual_pnl_eaten() {
        let _ = writeln!(rpt, "- **「执行吃光」成立（真实成交口径）**：actual_pnl_proxy≤0 ⟹ 即便不丢有利滑移，真实成交价差减成本仍非正 ⟹ 该信号集真实亏（否定性结果，缩小有效域边界，161/formalization-validity-domain）。");
    } else {
        let _ = writeln!(rpt, "- **两口径一致正**：adverse-only 与真实成交均 >0 ⟹ 反转腿价差未被吃光（保守口径都过 ⟹ 真实更宽松）。仅 BTC 单标的 L2，非跨品种功效。");
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 失血三源对比（ΣAb_rev 为反转腿结构上限）");
    let _ = writeln!(
        rpt,
        "- 反转腿价差：ΣAb_rev={:.6e}（664 号测对了对象——可正可负，非触发段同义反复）",
        agg.sum_a_b
    );
    let _ = writeln!(
        rpt,
        "- 执行吃光：Ση={:.6e}（入场+出场滞后）",
        agg.sum_eta_in + agg.sum_eta_out
    );
    let _ = writeln!(rpt, "- 成本：ΣCe={:.6e}", agg.sum_ce);
    if agg.sum_a_b < 0.0 {
        let _ = writeln!(rpt);
        let _ = writeln!(rpt, "**ΣAb_rev<0（反转交易腿）：** 664 号修复后仍为负 ⟹ 不是对象错配（已测对反转腿），是反转交易腿");
        let _ = writeln!(rpt, "本身的真实价差为负——配对出场信号 pivot 相对入场信号 pivot 在交易方向 δ 上整体不利。这是测对");
        let _ = writeln!(rpt, "对象之后的真实否定性结果（231：缩小有效域边界），不靠改符号修复（改 eps=恢复同义反复，090+no-patch）。");
        let _ = writeln!(rpt, "即使零滞后零成本（Ση=ΣCe=0），captured=ΣAb_rev<0 仍无 alpha——但这次测的是反转交易腿，不是触发段。");
    } else {
        let _ = writeln!(rpt);
        let _ = writeln!(rpt, "**ΣAb_rev>0（反转交易腿）：** 664 号修复后反转腿理想价差为正 ⟹ 结构给了可捕获价差（与旧触发段 ΣAb=−1.8e4");
        let _ = writeln!(rpt, "形成对照——后者是测错对象的伪否证）。剩余 alpha = ΣAb_rev − Ση − ΣCe（执行/成本是否吃光见上表 Σcaptured）。");
    }
    let _ = writeln!(rpt);
    // b2（task #83）：z 角色维紧凑格式化（σ_p / 短差 / 仓位态 / H）——报告展示 Z 细分，
    // 使同 (level,δ,I_γ) 按 σ_p/role/H 再分的桶不显示为重复行（诚实展示分桶键升维）。
    let z_role_str = |z: &MuClass| -> String {
        let h = match z.horizontal {
            Some(Horizontal::First) => "F",
            Some(Horizontal::SameFollow) => "SF",
            Some(Horizontal::SameReverse) => "SR",
            None => "-", // 裸证书口径未定 H（本 alpha 路径 z_of_candidate 恒 Some，None 不应现）
        };
        let pos = match z.position {
            PositionState::Root => "R",
            PositionState::Child => "C",
        };
        format!(
            "{:+}|{}|{}|{}",
            z.parent_dir,
            if z.short_swing { "sw" } else { "tr" },
            pos,
            h
        )
    };
    let _ = writeln!(rpt, "## per-class 完整状态 Z=(level, δ, I_γ, σ_p, 短差, 仓位态, H) 分桶（b2 #83：Y 粗投影→Z 细状态）");
    let _ = writeln!(rpt, "μ̂(z,a)=Σactual_pnl/n = 逐信号正条件期望估计（663 判据：>0 即可交易，不需统计显著/不判稀疏硬墙）。");
    let _ = writeln!(rpt, "I_γ=u8 位掩码（bit0=buy1,bit1=buy2,bit2=buy3,bit3=sell1,bit4=sell2,bit5=sell3，未压缩 6-bit=z.i_class）。");
    let _ = writeln!(rpt, "role=σ_p|短差(sw/tr)|仓位态(R/C)|H(F/SF/SR)——R(g)=(H,V,δ) 完整角色（codex #81 H 进 canonical Z）。");
    let _ = writeln!(rpt, "| level | δ | I_γ | role(σ_p\\|sw\\|pos\\|H) | n | μ̂=Σactual_pnl/n | Σactual_pnl | ΣAb_rev | Ση(adv) | ΣCe | Σcaptured(adv) | n_act+/n |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|---|---|");
    for (z, (n, sab, sin, sout, sce, scap, _ncap, _sact, sactpnl, nact)) in &buckets {
        let mu_hat = if *n > 0 { sactpnl / *n as f64 } else { 0.0 };
        let _ = writeln!(rpt, "| {} | {:+} | 0x{:02x} | {} | {} | {:.4e} | {:.4e} | {:.4e} | {:.4e} | {:.4e} | {:.4e} | {}/{} ({:.0}%) |",
                z.level, z.delta, z.i_class, z_role_str(z), n, mu_hat, sactpnl, sab, sin + sout, sce, scap,
                nact, n, if *n > 0 { 100.0 * *nact as f64 / *n as f64 } else { 0.0 });
    }
    let _ = writeln!(rpt);
    // ── 663 判据：全级别×方向×类型 μ̂>0 分类（正条件期望，出现就做不统计显著）。 ──
    let _ = writeln!(
        rpt,
        "## 663 判据：全级别×方向×类型 μ̂(z,a)>0（正条件期望，出现就做不统计显著）"
    );
    let max_level = buckets.keys().map(|z| z.level).max().unwrap_or(0);
    let _ = writeln!(
        rpt,
        "涌现最高级别 L={max_level}（全级别 0..{max_level} 均列；稀疏高级别照报不判硬墙，663）。"
    );
    let _ = writeln!(
        rpt,
        "**有效域**：本窗 bars={n_bars}（{window_start}→{window_end}）。663 要求全历史长窗——"
    );
    let _ = writeln!(rpt, "若 bars<461万，高级别 L3+ 仍稀疏（n=个位数），累积净值是**本窗**结论非全历史（ECON_L2_MAX_BARS=5000000 跑全量，~6-7min）。");
    let _ = writeln!(
        rpt,
        "μ̂>0 类 = 该完整状态 z 逐信号正条件期望——出现即做累积正期望（非 p<0.05 统计显著）："
    );
    let mut n_pos_class = 0usize;
    let mut n_total_class = 0usize;
    for (z, (n, _, _, _, _, _, _, _, sactpnl, nact)) in &buckets {
        n_total_class += 1;
        let mu_hat = if *n > 0 { sactpnl / *n as f64 } else { 0.0 };
        let mark = if mu_hat > 0.0 {
            n_pos_class += 1;
            "✓μ̂>0"
        } else {
            "✗μ̂≤0"
        };
        let _ = writeln!(rpt, "- (level={}, δ={:+}, I_γ=0x{:02x}, role={}) {mark}: μ̂={mu_hat:.4e}, Σ={sactpnl:.4e}, n_act+/n={nact}/{n}",
                z.level, z.delta, z.i_class, z_role_str(z));
    }
    let _ = writeln!(rpt, "**{n_pos_class}/{n_total_class} 类 μ̂>0**（663 判据：正期望类可交易，不因稀疏判 inconclusive）。");
    let _ = writeln!(rpt);

    // ── 全历史累积净值曲线（长窗，按时间 entry_bar 序）：全级别 + per-level 分层。 ──
    // 663：全历史长窗累积净值——每级别按时间累加 actual_pnl，看是否正期望累积。
    let _ = writeln!(rpt, "## 全历史累积净值曲线（长窗，按 entry_bar 时间序）");
    {
        let mut ordered: Vec<&SignalDecomp> = decomps.iter().collect();
        ordered.sort_by_key(|d| d.entry_bar);
        // 全局累积 + per-level 累积（终值 + 是否单调正向）。
        let mut cum_all = 0.0f64;
        let mut cum_by_level: BTreeMap<u32, f64> = BTreeMap::new();
        let mut min_cum_all = 0.0f64; // 最大回撤参考（累积曲线最低点）。
        for d in &ordered {
            cum_all += d.actual_pnl;
            if cum_all < min_cum_all {
                min_cum_all = cum_all;
            }
            *cum_by_level.entry(d.level).or_default() += d.actual_pnl;
        }
        let _ = writeln!(rpt, "- **全级别累积净值终值 = {cum_all:.4e}**（{} 信号，min 累积={min_cum_all:.4e} 曲线最低点）", ordered.len());
        let _ = writeln!(rpt, "| level | 该级别累积净值 | 正期望? |");
        let _ = writeln!(rpt, "|---|---|---|");
        for (lvl, cum) in &cum_by_level {
            let _ = writeln!(
                rpt,
                "| {} | {:.4e} | {} |",
                lvl,
                cum,
                if *cum > 0.0 { "✓" } else { "✗" }
            );
        }
        // 曲线采样（10 点等信号间隔）——看累积轨迹形状（单调正 vs 前正后回吐）。
        if ordered.len() >= 10 {
            let _ = writeln!(rpt);
            let _ = writeln!(rpt, "累积净值曲线采样（10 等分点，全级别）：");
            let step = ordered.len() / 10;
            let mut c = 0.0f64;
            for (i, d) in ordered.iter().enumerate() {
                c += d.actual_pnl;
                if (i + 1) % step == 0 || i + 1 == ordered.len() {
                    let _ = writeln!(
                        rpt,
                        "- [{}/{}] entry_bar={} 累积={:.4e}",
                        i + 1,
                        ordered.len(),
                        d.entry_bar,
                        c
                    );
                }
            }
        }
    }

    // ── 666 号 σ_higher 分布 + 逐信号台账 CSV dump。 ──
    // σ_higher 顺/逆/无：δ 与上级方向态一致(δ==σ_higher)/相反/上级无方向(σ_higher==0)。
    let (mut n_align, mut n_against, mut n_none) = (0usize, 0usize, 0usize);
    for d in &decomps {
        match d.sigma_higher {
            0 => n_none += 1,
            s if s == d.delta => n_align += 1,
            _ => n_against += 1,
        }
    }
    let _ = writeln!(rpt, "## 666 号 σ_higher 分布（上级方向态 vs δ）");
    let nsig = decomps.len().max(1);
    let _ = writeln!(
        rpt,
        "- 顺上级（δ==σ_higher）：{n_align}/{} ({:.1}%)",
        decomps.len(),
        100.0 * n_align as f64 / nsig as f64
    );
    let _ = writeln!(
        rpt,
        "- 逆上级（δ==−σ_higher）：{n_against}/{} ({:.1}%)",
        decomps.len(),
        100.0 * n_against as f64 / nsig as f64
    );
    let _ = writeln!(
        rpt,
        "- 无上级（σ_higher==0）：{n_none}/{} ({:.1}%)",
        decomps.len(),
        100.0 * n_none as f64 / nsig as f64
    );
    let _ = writeln!(rpt);

    eprint!("{rpt}");

    // 逐信号台账 CSV（666 号：alpha 分离下游依赖，15 列含 sigma_higher）。输出到 /tmp。
    let csv_path = std::env::var(crate::theta_v0::env_registry::ECON_LEDGER_CSV)
        .unwrap_or_else(|_| "/tmp/btc_663_ledger_sigma.csv".to_string());
    // W4 类型透传：bsp_class（buy1/2/3+sell1/2/3 位掩码 u8）+ side（买/卖，delta 派生）+ exit_decision（P7）列。
    let mut csv = String::from(
            "idx,entry_bar,exit_bar,level,delta,a_b,x_in,y_out,eta_in,eta_out,actual_spread,ce_unit,captured,actual_pnl,sigma_higher,bsp_class,side,exit_decision\n",
        );
    for (i, d) in decomps.iter().enumerate() {
        let side = if d.delta > 0 { "buy" } else { "sell" };
        // #182：加 `Econ` 前缀与 interp::ExitType 序列化标签（runner.rs exit_type_str
        // "CloseRoot"/"ReduceCore"/"Hold"）区分，消除下游按字符串聚合的混桶风险。
        let exit_dec = match d.exit_decision {
            ExitDecision::CloseRoot => "EconCloseRoot",
            ExitDecision::ReduceCore => "EconReduceCore",
            ExitDecision::Type2Missing => "EconType2Missing",
            ExitDecision::Hold => "EconHold",
        };
        let _ = writeln!(csv, "{},{},{},{},{},{:.10e},{:.10e},{:.10e},{:.10e},{:.10e},{:.10e},{:.10e},{:.10e},{:.10e},{},{},{},{}",
                i, d.entry_bar, d.exit_bar, d.level, d.delta,
                d.a_b, d.x_in, d.y_out, d.eta_in, d.eta_out, d.actual_spread,
                d.ce_unit, d.captured, d.actual_pnl, d.sigma_higher, d.bsp_class, side, exit_dec);
    }
    std::fs::write(&csv_path, &csv).unwrap_or_else(|e| panic!("写台账 CSV {csv_path} 失败：{e}"));
    eprintln!(
        "逐信号台账 CSV 已落盘：{csv_path}（{} 行 + 表头）",
        decomps.len()
    );

    // 落盘 signed 报告（664-Q3，不覆盖 econ-abrev-l2-btc-20260630.md 旧 adverse-only-only 报告）。
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/econ-663-full-level-mu-20260701.md");
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告 {out:?} 失败：{e}"));
    eprintln!("\n报告已落盘：{out:?}");

    // 真封①：adverse-only captured 分解恒等式逐信号成立。
    for d in &decomps {
        let recomputed = d.a_b - d.eta_in - d.eta_out - d.ce_unit;
        assert!(
            (d.captured - recomputed).abs() < 1e-6,
            "captured 分解恒等式破：level={} δ={} captured={} ≠ {}",
            d.level,
            d.delta,
            d.captured,
            recomputed
        );
        // 真封②（664-Q3 核心）：actual_spread = Ab_rev − x − y 逐信号恒成立（signed 分解）。
        assert!(
            (d.actual_spread - (d.a_b - d.x_in - d.y_out)).abs() < 1e-6,
            "actual_spread 恒等式破：level={} δ={} actual_spread={} ≠ Ab−x−y={}",
            d.level,
            d.delta,
            d.actual_spread,
            d.a_b - d.x_in - d.y_out
        );
        // 真封③：eta = max(0, signed) 一致。
        assert!(
            (d.eta_in - d.x_in.max(0.0)).abs() < 1e-9
                && (d.eta_out - d.y_out.max(0.0)).abs() < 1e-9,
            "η 应 = max(0, signed)：level={} δ={}",
            d.level,
            d.delta
        );
        // 真封④：captured ≤ actual_pnl（adverse-only 系统性 ≤ 真实成交；丢有利滑移）。
        assert!(
            d.captured <= d.actual_pnl + 1e-6,
            "adverse-only captured 应 ≤ actual_pnl：level={} δ={} captured={} > actual_pnl={}",
            d.level,
            d.delta,
            d.captured,
            d.actual_pnl
        );
    }
    // 聚合 Σ 无丢失。
    let sum_check: f64 = decomps.iter().map(|d| d.captured).sum();
    assert!(
        (agg.sum_captured - sum_check).abs() < 1e-3,
        "Σcaptured 聚合 {} ≠ 逐信号和 {}",
        agg.sum_captured,
        sum_check
    );
    let sum_act: f64 = decomps.iter().map(|d| d.actual_spread).sum();
    assert!(
        (agg.sum_actual_spread - sum_act).abs() < 1e-3,
        "Σactual_spread 聚合 {} ≠ 逐信号和 {}",
        agg.sum_actual_spread,
        sum_act
    );
}

/// per-class `(level, δ, bsp_class)` 真实成交统计：(n, Σactual_pnl, n_act+, Σab_rev)。
/// P4（codex E-3）：分桶键含 bsp_class ⟹ 单类型 α 可辨——混合 (level,δ) 池会把 buy1/buy2/buy3
/// 混一桶，桶均值只给混合均值（稀释是 L0 结构必然，codex E-2）。estimand 桶键 `(ℓ,δ,bsp_class)`。
fn class_actual_pnl(
    decomps: &[SignalDecomp],
    level: u32,
    delta: i8,
    bsp_class: u8,
) -> (usize, f64, usize, f64) {
    decomps
        .iter()
        .filter(|d| d.level == level && d.delta == delta && d.bsp_class == bsp_class)
        .fold((0usize, 0.0f64, 0usize, 0.0f64), |(n, pnl, npos, ab), d| {
            (
                n + 1,
                pnl + d.actual_pnl,
                npos + (d.actual_pnl > 0.0) as usize,
                ab + d.a_b,
            )
        })
}

/// `(level, δ)` 聚合（Σ over bsp_class）真实成交统计——用于 δ 方向不对称对照（level0 卖 vs 买，
/// 与 bsp_class 正交）+ 诊断报告。**非 estimand 桶**（estimand 桶是 per-class [`class_actual_pnl`]）。
fn class_actual_pnl_agg(
    decomps: &[SignalDecomp],
    level: u32,
    delta: i8,
) -> (usize, f64, usize, f64) {
    decomps
        .iter()
        .filter(|d| d.level == level && d.delta == delta)
        .fold((0usize, 0.0f64, 0usize, 0.0f64), |(n, pnl, npos, ab), d| {
            (
                n + 1,
                pnl + d.actual_pnl,
                npos + (d.actual_pnl > 0.0) as usize,
                ab + d.a_b,
            )
        })
}

/// 窗口净涨跌方向：首尾 close 总收益**百分数**（>0 涨段 / <0 跌段）。tick 抵消，直接用 close 整数比。
fn window_net_return(ds: &Dataset) -> f64 {
    let (first, last) = (ds.bars.first(), ds.bars.last());
    match (first, last) {
        (Some(f), Some(l)) if f.close > 0 => {
            100.0 * (l.close as f64 - f.close as f64) / f.close as f64
        }
        _ => 0.0,
    }
}

/// **663 推论 OOS 验证（防 winner's curse）**：对 in-sample 最强正类 level0卖（level=0,δ=−1，
/// in-sample actual_pnl=+3.47e4）做 train/holdout 时间切分 + 方向不对称分解。
///
/// `#[ignore]`：同 l2_btc 需 BTC 全量 + O(n²) 重分类，`--release`。
///
/// **L2 纪律**：holdout level0卖 actual_pnl≤0 ⟹ +3.47e4 是窗口/挑赢家产物（否证 alpha，照实报）；
/// >0 ⟹ OOS 初步稳健（仍单标的单切分，标有效域）。否定性结果照实报（161/formalization-validity-domain）。
#[test]
#[ignore]
fn acc_level0sell_oos() {
    use super::super::data;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();

    // 截断窗（同 l2_btc_capturable_spread_diagnosis：最后 MAX_BARS，OOM 边界=显式有效域）。
    // #399：骨架收敛至共享 helper（mod tests 顶部），行为不变。
    let max_bars = econ_l2_max_bars();
    let ds = truncate_tail_bars(ds_full, max_bars);
    let n = ds.bars.len();
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();

    // ── 任务1：train(前 frac)/holdout(后 1−frac) 时间切分（半开区间无重叠，时间序不打乱）。 ──
    let train_frac = std::env::var(crate::theta_v0::env_registry::ECON_L2_TRAIN_FRAC)
        .ok()
        .and_then(|s| s.parse::<f64>().ok())
        .unwrap_or(0.6);
    let split = (n as f64 * train_frac) as usize;
    let ds_train = ds.slice_bar_range(0, split);
    let ds_hold = ds.slice_bar_range(split, n);
    let train_split_day = ds.dates[split].get(..10).unwrap_or("").to_string();

    let (decomps_train, _) = decompose_capturable_spread(&ds_train, &config);
    let (decomps_hold, _) = decompose_capturable_spread(&ds_hold, &config);
    let (tr_n, tr_pnl, tr_pos, tr_ab) = class_actual_pnl_agg(&decomps_train, 0, -1);
    let (hd_n, hd_pnl, hd_pos, hd_ab) = class_actual_pnl_agg(&decomps_hold, 0, -1);
    // 对照：买（δ=+1，in-sample 亏损主源）OOS 是否仍亏。
    let (hd_buy_n, hd_buy_pnl, hd_buy_pos, _) = class_actual_pnl_agg(&decomps_hold, 0, 1);

    let train_ret = window_net_return(&ds_train);
    let hold_ret = window_net_return(&ds_hold);
    let full_ret = window_net_return(&ds);

    // ── 任务2：2 个不重叠子窗（前半/后半，各 n/2），分别算 level0卖 vs level0买。 ──
    let half = n / 2;
    let ds_w1 = ds.slice_bar_range(0, half);
    let ds_w2 = ds.slice_bar_range(half, n);
    let (dw1, _) = decompose_capturable_spread(&ds_w1, &config);
    let (dw2, _) = decompose_capturable_spread(&ds_w2, &config);
    let (w1_s_n, w1_sell, _, _) = class_actual_pnl_agg(&dw1, 0, -1);
    let (w1_b_n, w1_buy, _, _) = class_actual_pnl_agg(&dw1, 0, 1);
    let (w2_s_n, w2_sell, _, _) = class_actual_pnl_agg(&dw2, 0, -1);
    let (w2_b_n, w2_buy, _, _) = class_actual_pnl_agg(&dw2, 0, 1);
    let w1_ret = window_net_return(&ds_w1);
    let w2_ret = window_net_return(&ds_w2);

    // ── 判定 ──
    let oos_robust = hd_pnl > 0.0; // holdout 卖正 ⟹ 初步稳健
                                   // 方向不对称结构性 ⟺ 两个不重叠子窗 level0卖都优于买（不论子窗涨跌）。
    let sell_beats_buy_w1 = w1_sell > w1_buy;
    let sell_beats_buy_w2 = w2_sell > w2_buy;
    let asym_structural = sell_beats_buy_w1 && sell_beats_buy_w2;

    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# 663 推论 OOS 验证：level0卖 train/holdout 切分 + 方向不对称（防 winner's curse）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "**认识论等级**：L2（真实数据单标的单切分，可产否定性结果；非 L3 跨标的）。"
    );
    let _ = writeln!(rpt, "**对象**：in-sample 最强正类 level0卖（level=0, δ=−1，in-sample actual_pnl=+3.47e4/349/36%）。");
    let _ = writeln!(rpt, "**复算**：`cargo test -p <crate> --release acc_level0sell_oos -- --ignored --nocapture`（确定性）。");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 数据 / 窗口");
    let _ = writeln!(rpt, "- BTC 全量 {n_full} bar；**截断窗 [{win_start}→{win_end}]，bars={n}**（最后 {max_bars} bar；OOM 边界=显式有效域，非全历史，同 l2_btc 纪律）。");
    let _ = writeln!(rpt, "- train_frac={train_frac}，切分 bar 索引={split}（切分日 {train_split_day}，半开区间 train=[0,{split}) / holdout=[{split},{n}) 无重叠）。");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 窗净涨跌方向（首尾 close 总收益）");
    let _ = writeln!(rpt, "| 窗 | 净收益 | 方向 |");
    let _ = writeln!(rpt, "|---|---|---|");
    let _ = writeln!(
        rpt,
        "| 截断全窗 | {full_ret:+.2}% | {} |",
        if full_ret > 0.0 { "涨" } else { "跌" }
    );
    let _ = writeln!(
        rpt,
        "| train | {train_ret:+.2}% | {} |",
        if train_ret > 0.0 { "涨" } else { "跌" }
    );
    let _ = writeln!(
        rpt,
        "| holdout | {hold_ret:+.2}% | {} |",
        if hold_ret > 0.0 { "涨" } else { "跌" }
    );
    let _ = writeln!(
        rpt,
        "| 子窗1（前半） | {w1_ret:+.2}% | {} |",
        if w1_ret > 0.0 { "涨" } else { "跌" }
    );
    let _ = writeln!(
        rpt,
        "| 子窗2（后半） | {w2_ret:+.2}% | {} |",
        if w2_ret > 0.0 { "涨" } else { "跌" }
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## 任务1：level0卖 train vs holdout（关键——正负决定 winner's curse 判定）"
    );
    let _ = writeln!(rpt, "| 窗 | n | Σactual_pnl | n_act+/n（胜率） | Σab_rev |");
    let _ = writeln!(rpt, "|---|---|---|---|---|");
    let _ = writeln!(
        rpt,
        "| train | {tr_n} | {tr_pnl:.4e} | {tr_pos}/{tr_n} ({:.0}%) | {tr_ab:.4e} |",
        winrate(tr_pos, tr_n)
    );
    let _ = writeln!(
        rpt,
        "| **holdout** | {hd_n} | **{hd_pnl:.4e}** | {hd_pos}/{hd_n} ({:.0}%) | {hd_ab:.4e} |",
        winrate(hd_pos, hd_n)
    );
    let _ = writeln!(rpt, "| holdout 对照·买(δ+1) | {hd_buy_n} | {hd_buy_pnl:.4e} | {hd_buy_pos}/{hd_buy_n} ({:.0}%) | — |", winrate(hd_buy_pos, hd_buy_n));
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "**判定**：holdout level0卖 actual_pnl = {hd_pnl:.4e} {} 0",
        if hd_pnl > 0.0 { ">" } else { "≤" }
    );
    if oos_robust {
        let _ = writeln!(rpt, "→ **OOS 初步稳健**：holdout 卖仍正，+3.47e4 不是纯挑赢家产物。**但仅 BTC 单标的单切分 L2，非 L3**——holdout 窗净涨跌={hold_ret:+.2}%，若 holdout 仍跌段则方向效应未排除（见任务2）。");
    } else {
        let _ = writeln!(rpt, "→ **否证 alpha（winner's curse 坐实）**：holdout 卖 actual_pnl≤0 ⟹ in-sample +3.47e4 是窗口/挑赢家产物。这是有价值的否定性结果（缩小有效域边界，161/formalization-validity-domain）——照实报，不粉饰。");
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## 任务2：方向不对称（2 个不重叠子窗，结构性 vs 窗口效应）"
    );
    let _ = writeln!(
        rpt,
        "| 子窗 | 净涨跌 | 卖(δ−1) actual_pnl | n卖 | 买(δ+1) actual_pnl | n买 | 卖>买? |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
    let _ = writeln!(
        rpt,
        "| 1（前半） | {w1_ret:+.2}% | {w1_sell:.4e} | {w1_s_n} | {w1_buy:.4e} | {w1_b_n} | {} |",
        if sell_beats_buy_w1 { "是" } else { "否" }
    );
    let _ = writeln!(
        rpt,
        "| 2（后半） | {w2_ret:+.2}% | {w2_sell:.4e} | {w2_s_n} | {w2_buy:.4e} | {w2_b_n} | {} |",
        if sell_beats_buy_w2 { "是" } else { "否" }
    );
    let _ = writeln!(rpt);
    if asym_structural {
        let _ = writeln!(rpt, "**判定**：两个不重叠子窗 level0卖均优于买。");
        if w1_ret * w2_ret < 0.0 {
            let _ = writeln!(rpt, "→ **结构性（跨涨跌都卖优）**：子窗1/子窗2 净涨跌符号相反（一涨一跌）卖仍都优 ⟹ 卖优势非单纯下跌段做空产物，是结构性方向不对称。L2 单标的。");
        } else {
            let _ = writeln!(rpt, "→ **方向同号，未充分隔离**：两子窗净涨跌同号（{w1_ret:+.2}%/{w2_ret:+.2}%），卖优势可能仍含方向效应——结构性结论需跨涨跌子窗或 L3 跨标的。");
        }
    } else {
        let _ = writeln!(rpt, "**判定**：卖优势在子窗间不一致（子窗1卖>买={sell_beats_buy_w1}，子窗2={sell_beats_buy_w2}）。");
        let _ = writeln!(rpt, "→ **窗口效应**：卖优势依赖特定子窗（很可能是下跌子窗做空），非结构性。否定性结果照实报。");
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 结果包六要素");
    let _ = writeln!(
        rpt,
        "1. **结论**：holdout level0卖 actual_pnl={hd_pnl:.4e}（{}），方向不对称={}。",
        if oos_robust {
            "OOS 初步稳健"
        } else {
            "winner's curse 否证"
        },
        if asym_structural {
            "结构性候选"
        } else {
            "窗口效应"
        }
    );
    let _ = writeln!(rpt, "2. **定义依据**：level0卖=663 in-sample 最强正类（level=0/δ=−1/顶背驰卖空反转腿）；actual_pnl=δ(Pτout−Pτin)−Ce 真实成交口径（664-Q3）。");
    let _ = writeln!(rpt, "3. **边界条件**：holdout 窗净涨跌={hold_ret:+.2}%；若 holdout 为下跌段（做空天然赚），OOS 正不足以证 alpha（需跨涨跌子窗，见任务2）。train_frac={train_frac} 改变切分点结论可能翻转（单切分脆弱）。");
    let _ = writeln!(
        rpt,
        "4. **下游推论**：{}",
        if oos_robust {
            "level0卖可作信号层 entry 候选，但须 L3 跨标的 + 涨段验证后才升基座（防方向效应）。"
        } else {
            "level0卖不可单独作 entry——in-sample 正是窗口产物，下游策略勿基于此类升基座。"
        }
    );
    let _ = writeln!(rpt, "5. **谱系引用**：663 econpositive 推论；664 对象错配修复（δ=反转腿方向）；formalization-validity-domain（L2 有效域 < 定义域）；161（务实=把缺口留后面）。");
    let _ = writeln!(rpt, "6. **影响声明**：新增 Dataset::slice_bar_range（半开区间切片，复用 source_index 重置契约）+ acc_level0sell_oos 测试；不改 decompose_capturable_spread/TradeRecord/Order。");

    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/econpositive-oos-level0sell-20260630.md");
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告 {out:?} 失败：{e}"));
    eprintln!("\n报告已落盘：{out:?}");

    // 真封：train+holdout 信号数之和与全窗同口径无丢失（半开切分无重叠无遗漏 ⟹ 级别涌现局部性除外，
    // 切窗会改变级别涌现 ⟹ 不强求 n 守恒；仅断言切片本身非空、actual_pnl 与逐信号和一致）。
    let recomputed_hold: f64 = decomps_hold
        .iter()
        .filter(|d| d.level == 0 && d.delta == -1)
        .map(|d| d.actual_pnl)
        .sum();
    assert!(
        (hd_pnl - recomputed_hold).abs() < 1e-6,
        "holdout level0卖 Σactual_pnl 聚合不一致"
    );
    assert!(
        ds_train.bars.len() + ds_hold.bars.len() == n,
        "train+holdout bar 数 ≠ 全窗（半开区间应无重叠无遗漏）"
    );
}

fn winrate(pos: usize, n: usize) -> f64 {
    if n > 0 {
        100.0 * pos as f64 / n as f64
    } else {
        0.0
    }
}

/// **PDF §11 正确 OOS 验收（除 codex Q2 BIAS-FATAL 选择偏差）**：train-only 挑类 → 锁 holdout
/// 评估 + 多窗滚动 walk-forward + neff + block bootstrap + 剔最大赢家。
///
/// ★663 降级（判据错误更正）：neff/LCB/block_bootstrap/剔赢家/符号检验 = 统计显著性判据，
/// 663 裁定非 alpha 判据（统计显著性误当可交易性，系统性惩罚低频高级别）。真判据 = 逐信号
/// mu_hat>0（见 l2_btc_capturable_spread_diagnosis）。本测试保留作参考数据（过拟合诊断维度），
/// 不作 alpha 确认判据。ponytail: 不删（663 明确可保留作参考），仅标注判据降级。
///
/// 与 `acc_level0sell_oos`（被否证：从含 holdout 全样本挑 level0卖）的关键差异：
/// **选类只用 train 段**（codex/PDF§6：用挑赢家同一数据验证不能反驳挑赢家）。train 赢家可能 ≠ level0卖。
///
/// `#[ignore]`：同上需 BTC 全量 + O(n²) 重分类 ×（1 主切分 + K 滚动窗），`--release`。
///
/// **L2 纪律（161/formalization-validity-domain）**：任一结果照实报——
/// train 赢家=level0卖 且 holdout 正 ⟹ 缠论买卖点首个干净 OOS alpha 证据；
/// train 赢家≠level0卖 或 holdout 翻负 ⟹ +7.87e3 是选择偏差产物（诚实否证，缩有效域）。
#[test]
#[ignore]
fn acc_walkforward_trainonly() {
    use super::super::data;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    // #399：骨架收敛至共享 helper（mod tests 顶部），行为不变。
    let max_bars = econ_l2_max_bars();
    let ds = truncate_tail_bars(ds_full, max_bars);
    let n = ds.bars.len();
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();

    // ══ 任务1+2：主切分 train-only 挑类 → 锁 holdout 评估（除 Q2 选择偏差核心）══
    let train_frac = std::env::var(crate::theta_v0::env_registry::ECON_L2_TRAIN_FRAC)
        .ok()
        .and_then(|s| s.parse::<f64>().ok())
        .unwrap_or(0.6);
    let split = (n as f64 * train_frac) as usize;
    let ds_train = ds.slice_bar_range(0, split);
    let ds_hold = ds.slice_bar_range(split, n);
    let split_day = ds.dates[split].get(..10).unwrap_or("").to_string();

    let (decomps_train, _) = decompose_capturable_spread(&ds_train, &config);
    let (decomps_hold, _) = decompose_capturable_spread(&ds_hold, &config);

    // train-only 挑赢家（不看 holdout）。记录是否 level0卖。
    let winner = train_winner_class(&decomps_train);
    let is_level0_sell = matches!(winner, Some((0, -1, _)));
    let train_l0sell = class_actual_pnl_agg(&decomps_train, 0, -1);

    // 锁 holdout 评估 train 选出的类。
    let (hd_n, hd_pnl, hd_pos, hd_ab, hd_pnls) = match winner {
        Some((lv, dl, bc)) => {
            let (n_, pnl, npos, ab) = class_actual_pnl(&decomps_hold, lv, dl, bc);
            let pnls: Vec<f64> = decomps_hold
                .iter()
                .filter(|d| d.level == lv && d.delta == dl && d.bsp_class == bc)
                .map(|d| d.actual_pnl)
                .collect();
            (n_, pnl, npos, ab, pnls)
        }
        None => (0, 0.0, 0, 0.0, Vec::new()),
    };
    let oos_mu_positive = hd_pnl > 0.0 && winner.is_some(); // μ_OOS>0（弱：未扣不确定性）

    // 任务4：neff vs nraw（holdout 赢家类逐笔 PnL 自相关）。
    let nraw = hd_pnls.len();
    let (neff, sum_rho) = neff_autocorr(&hd_pnls, 20);
    let (mu_oos, se_oos, lcb_oos) = mean_se_lcb(&hd_pnls, neff);

    // 任务5/Q4：剔最大赢家 + block bootstrap p。
    let (q4_full, q4_d1, q4_d3, q4_d5) = drop_top_winners(&hd_pnls);
    let q4_p = block_bootstrap_pvalue(&hd_pnls, 20, 2000);

    // ══ 任务3：多窗滚动 walk-forward（除 Q5 单切分脆弱）══
    let k_windows: usize = std::env::var(crate::theta_v0::env_registry::ECON_WF_WINDOWS)
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(4);
    let wf_train_frac = 0.6;
    let win_len = n / k_windows;
    let mut wf_rows: Vec<(Option<(u32, i8, u8)>, bool, usize, f64, f64, bool)> = Vec::new();
    let mut lcb_pos_count = 0usize;
    let mut l0sell_winner_count = 0usize;
    for w in 0..k_windows {
        let w_start = w * win_len;
        let w_end = if w + 1 == k_windows {
            n
        } else {
            (w + 1) * win_len
        };
        let w_mid = w_start + ((w_end - w_start) as f64 * wf_train_frac) as usize;
        if w_mid <= w_start || w_end <= w_mid {
            continue;
        }
        let dtr = decompose_capturable_spread(&ds.slice_bar_range(w_start, w_mid), &config).0;
        let dos = decompose_capturable_spread(&ds.slice_bar_range(w_mid, w_end), &config).0;
        let wwin = train_winner_class(&dtr);
        let w_is_l0 = matches!(wwin, Some((0, -1, _)));
        if w_is_l0 {
            l0sell_winner_count += 1;
        }
        let (on, opnl, lcb) = match wwin {
            Some((lv, dl, bc)) => {
                let pnls: Vec<f64> = dos
                    .iter()
                    .filter(|d| d.level == lv && d.delta == dl && d.bsp_class == bc)
                    .map(|d| d.actual_pnl)
                    .collect();
                let (nf, _) = neff_autocorr(&pnls, 20);
                let (_, _, lcb) = mean_se_lcb(&pnls, nf);
                (pnls.len(), pnls.iter().sum::<f64>(), lcb)
            }
            None => (0, 0.0, 0.0),
        };
        if lcb > 0.0 {
            lcb_pos_count += 1;
        }
        wf_rows.push((wwin, w_is_l0, on, opnl, lcb, opnl > 0.0));
    }
    let n_wf = wf_rows.len();
    let lcb_pos_ratio = if n_wf > 0 {
        100.0 * lcb_pos_count as f64 / n_wf as f64
    } else {
        0.0
    };

    // PDF §7.3 强判据 χ=1[LCB>θ]（θ=0）：μ>0 不够，须扣除不确定性后仍正。
    // §11 全验收 = LCB>0 ∧ Q4 剔最大5仍正 ∧ bootstrap p<0.05 ∧ 多窗 LCB>0 占比高。
    let oos_robust = lcb_oos > 0.0 && q4_d5 > 0.0 && q4_p < 0.05 && lcb_pos_ratio >= 100.0;

    // ══ 报告 ══
    let cls_str = |c: Option<(u32, i8, u8)>| {
        c.map(|(l, d, b)| format!("(level={l},δ={d:+},cls={b:#04x})"))
            .unwrap_or_else(|| "None(train无正类)".into())
    };
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# PDF §11 walk-forward 验收：train-only 挑类（除 codex Q2 BIAS-FATAL 选择偏差）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "**认识论等级**：L2（真实数据单标的，train-only 选类已除选择偏差；仍单标的，非 L3 跨品种）。");
    let _ = writeln!(rpt, "**与被否证 acc_level0sell_oos 的差异**：选类只用 train 段（PDF§6/codex：用挑赢家同一数据验证不能反驳挑赢家）。");
    let _ = writeln!(rpt, "**复算**：`cargo test -p <crate> --release acc_walkforward_trainonly -- --ignored --nocapture`（确定性，含固定种子 bootstrap）。");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 数据 / 窗口");
    let _ = writeln!(rpt, "- BTC 全量 {n_full} bar；截断窗 [{win_start}→{win_end}]，bars={n}（最后 {max_bars}，OOM 边界=显式有效域）。");
    let _ = writeln!(rpt, "- 主切分 train_frac={train_frac}，split={split}（{split_day}，半开 train=[0,{split}) / holdout=[{split},{n}) 无重叠）。");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## 任务1+2：train-only 挑类 → 锁 holdout 评估（核心：除 Q2）"
    );
    let _ = writeln!(rpt, "- **train 期最强正类 = {}**", cls_str(winner));
    let _ = writeln!(
        rpt,
        "- **train 赢家是否 level0卖？{}**（level0卖 train 期 Σpnl={:.4e}/n={}）",
        if is_level0_sell {
            "是"
        } else {
            "否（⟹ level0卖不是 train-only 赢家！）"
        },
        train_l0sell.1,
        train_l0sell.0
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| holdout 评估 train 选定类 {} | 值 |",
        cls_str(winner)
    );
    let _ = writeln!(rpt, "|---|---|");
    let _ = writeln!(rpt, "| holdout n (=nraw) | {hd_n} |");
    let _ = writeln!(rpt, "| **holdout Σactual_pnl** | **{hd_pnl:.4e}** |");
    let _ = writeln!(
        rpt,
        "| holdout 胜率 | {hd_pos}/{hd_n} ({:.0}%) |",
        winrate(hd_pos, hd_n)
    );
    let _ = writeln!(rpt, "| holdout Σab_rev | {hd_ab:.4e} |");
    let _ = writeln!(rpt, "| μ_OOS | {mu_oos:.4e} |");
    let _ = writeln!(rpt, "| se（用 neff） | {se_oos:.4e} |");
    let _ = writeln!(rpt, "| **LCB（μ−1.645·se，单侧5%）** | **{lcb_oos:.4e}** |");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "**判定**：holdout μ_OOS {} 0，**LCB {} 0**（PDF§7.3 强判据 χ=1[LCB>0]={}）",
        if mu_oos > 0.0 { ">" } else { "≤" },
        if lcb_oos > 0.0 { ">" } else { "≤" },
        lcb_oos > 0.0
    );
    if !is_level0_sell {
        let _ = writeln!(rpt, "→ **train 赢家变了（level0卖被否证为选择偏差产物）**：train-only 选出的是 {}，不是 level0卖。+7.87e3 是「从含 holdout 全样本挑 level0卖」的选择偏差产物（codex Q2/PDF§6 坐实）。", cls_str(winner));
    } else if !oos_mu_positive {
        let _ = writeln!(rpt, "→ **holdout 翻负（否证）**：level0卖虽是 train-only 赢家，但 holdout Σpnl≤0 ⟹ 无 OOS alpha。+7.87e3 是窗口/选择偏差产物（诚实否证，缩有效域，161）。");
    } else if lcb_oos > 0.0 {
        let _ = writeln!(rpt, "→ **Q2 消除 + μ_OOS 正 + LCB>0**：level0卖是 train-only 赢家、holdout μ 正且扣除不确定性（neff 修正）后仍正 ⟹ 初步通过 §7.3 强判据。但 §11 全验收还需 Q4/bootstrap/多窗全过（见下，综合判定在结果包）。仍 BTC 单标的 L2。");
    } else {
        let _ = writeln!(rpt, "→ **Q2 消除，但 μ_OOS 正而 LCB≤0（未通过 §7.3 强判据）**：level0卖确是 train-only 赢家（选择偏差消除，这一点为正），但 holdout μ_OOS={mu_oos:.2e} 扣除不确定性后 LCB={lcb_oos:.2e}≤0 ⟹ **+7.87e3 不达可交易阈值**。neff/nraw 见下（事件聚集致有效样本远小于 nraw）。这不是「干净 OOS 正」——是「选择偏差消除后，弱正信号被不确定性吞没」。");
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 任务4：neff vs nraw（PDF§6 条件二，自相关修正）");
    let _ = writeln!(rpt, "| 量 | 值 |");
    let _ = writeln!(rpt, "|---|---|");
    let _ = writeln!(rpt, "| nraw（holdout 赢家类原始信号数） | {nraw} |");
    let _ = writeln!(rpt, "| Σρk（k=1..20，仅正自相关） | {sum_rho:.4} |");
    let _ = writeln!(rpt, "| **neff = nraw/(1+2Σρk)** | **{neff:.1}** |");
    let _ = writeln!(
        rpt,
        "| neff/nraw | {:.2} |",
        if nraw > 0 { neff / nraw as f64 } else { 0.0 }
    );
    let _ = writeln!(
        rpt,
        "（neff≪nraw ⟹ 事件高度聚集，有效检验力远低于原始 n；se 已用 neff）。"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## 任务5/Q4：赢家集中度（剔最大赢家 + block bootstrap）"
    );
    let _ = writeln!(rpt, "| 剔除 | 剩余 Σpnl | 仍正? |");
    let _ = writeln!(rpt, "|---|---|---|");
    let _ = writeln!(
        rpt,
        "| 不剔（全量） | {q4_full:.4e} | {} |",
        if q4_full > 0.0 { "是" } else { "否" }
    );
    let _ = writeln!(
        rpt,
        "| 剔最大 1 | {q4_d1:.4e} | {} |",
        if q4_d1 > 0.0 { "是" } else { "否" }
    );
    let _ = writeln!(
        rpt,
        "| 剔最大 3 | {q4_d3:.4e} | {} |",
        if q4_d3 > 0.0 { "是" } else { "否" }
    );
    let _ = writeln!(
        rpt,
        "| 剔最大 5 | {q4_d5:.4e} | {} |",
        if q4_d5 > 0.0 { "是" } else { "否" }
    );
    let _ = writeln!(rpt, "- **block bootstrap p（H0:μ≤0，block_len=20，B=2000，固定种子）= {q4_p:.4}**（p<0.05 ⟹ 正均值稳健远离 0）。");
    if q4_d5 <= 0.0 && q4_full > 0.0 {
        let _ = writeln!(rpt, "→ **Q4 坐实少数大赢家驱动**：剔最大 5 后转负 ⟹ holdout 正总和由极少数大赢家撑起，非稳健 alpha。");
    } else if q4_d5 > 0.0 {
        let _ = writeln!(
            rpt,
            "→ **Q4 排除少数大赢家**：剔最大 5 仍正 ⟹ 正收益非单一赢家驱动。"
        );
    } else {
        let _ = writeln!(rpt, "→ holdout 全量已非正，Q4 剔赢家不适用（无正可剔）。");
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## 任务3：多窗滚动 walk-forward（除 Q5 单切分脆弱，K={k_windows}）"
    );
    let _ = writeln!(
        rpt,
        "每窗：窗内 train(前{:.0}%) 挑类 → OOS(后{:.0}%) 评估该类（每 train 只用窗内过去）。",
        wf_train_frac * 100.0,
        (1.0 - wf_train_frac) * 100.0
    );
    let _ = writeln!(
        rpt,
        "| 窗 | train赢家 | =level0卖? | OOS n | OOS Σpnl | OOS LCB | LCB>0? |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
    for (i, (w, isl0, on, opnl, lcb, _)) in wf_rows.iter().enumerate() {
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {on} | {opnl:.4e} | {lcb:.4e} | {} |",
            i + 1,
            cls_str(*w),
            if *isl0 { "是" } else { "否" },
            if *lcb > 0.0 { "是" } else { "否" }
        );
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- **各窗 OOS LCB>0 占比 = {lcb_pos_count}/{n_wf} ({lcb_pos_ratio:.0}%)**"
    );
    let _ = writeln!(
        rpt,
        "- level0卖为 train 赢家的窗数 = {l0sell_winner_count}/{n_wf}"
    );
    if lcb_pos_ratio >= 100.0 && n_wf > 0 {
        let _ = writeln!(
            rpt,
            "→ 全窗 LCB>0 ⟹ Q5 单切分脆弱被排除，OOS 跨窗稳健正（仍单标的）。"
        );
    } else if lcb_pos_count > 0 {
        let _ = writeln!(rpt, "→ 部分窗 LCB>0（{lcb_pos_ratio:.0}%）⟹ 非全窗稳健，单切分脆弱未完全排除（Q5 部分成立）。");
    } else {
        let _ = writeln!(
            rpt,
            "→ 无窗 LCB>0 ⟹ 扣除不确定性后无窗稳健正，OOS 不稳健（Q5 坐实）。"
        );
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 结果包六要素（完整版）");
    let _ = writeln!(rpt, "1. **结论**：train-only 赢家={}（{}level0卖，Q2 选择偏差{}），holdout μ_OOS={mu_oos:.4e}/**LCB={lcb_oos:.4e}**；多窗 LCB>0 占比={lcb_pos_ratio:.0}%（{lcb_pos_count}/{n_wf}）；neff/nraw={:.2}（{neff:.0}/{nraw}）；剔最大5 {}；bootstrap p={q4_p:.3}。**综合判定：{}**",
            cls_str(winner), if is_level0_sell { "=" } else { "≠" },
            if is_level0_sell { "消除" } else { "坐实——非 train 赢家" },
            if nraw > 0 { neff / nraw as f64 } else { 0.0 },
            if q4_d5 > 0.0 { "仍正" } else { "转负" },
            if oos_robust { "通过 §11 全验收（缠论买卖点首个干净稳健 OOS alpha 证据，单标的 L2）" }
            else if is_level0_sell && oos_mu_positive { "Q2 选择偏差消除（level0卖确为 train-only 赢家），但 §11 稳健性验收未过——LCB≤0/少数大赢家驱动/多窗不稳之一以上成立 ⟹ +7.87e3 不达可交易 alpha 阈值（诚实否证，161/formalization-validity-domain）" }
            else { "level0卖 +7.87e3 是选择偏差/窗口产物（否证）" });
    let _ = writeln!(rpt, "2. **定义依据**：actual_pnl=δ(Pτout−Pτin)−Ce（664-Q3 真实成交口径）；train-only 挑类=PDF§11「train 决定规则」；neff=nraw/(1+2Σρk)=PDF§6 条件二；LCB=μ−1.645se=PDF§7.3。");
    let _ = writeln!(rpt, "3. **边界条件**：单标的 BTC L2——结论翻转条件：(a) L3 跨标的若 level0卖不普遍赢则 BTC 是品种特例；(b) train_frac/窗数 K 改变 train 赢家身份则选类不稳；(c) holdout 仍为下跌段则卖优势含方向效应。");
    let _ = writeln!(
        rpt,
        "4. **下游推论**：{}",
        if oos_robust {
            "level0卖可作信号层 entry 候选（§11 全验收过），但升基座仍需 L3 跨标的。"
        } else {
            "level0卖不可单独作 entry——§11 稳健性验收未过（LCB≤0/赢家集中/多窗不稳），下游策略勿基于 +7.87e3 升基座。Q2 消除只证「不是挑赢家产物」，不证「是可交易 alpha」——二者独立。"
        }
    );
    let _ = writeln!(rpt, "5. **谱系引用**：663 econpositive；664-Q3 真实成交口径；codex Q2 BIAS-FATAL（codex-oos-level0sell-audit-20260630.md）；PDF§6/§11（overfit-consult-20260630.txt）；161（务实=留缺口）；formalization-validity-domain（L2 有效域<定义域）。");
    let _ = writeln!(rpt, "6. **影响声明**：新增 acc_walkforward_trainonly 测试 + train_winner_class/neff_autocorr/mean_se_lcb/drop_top_winners/block_bootstrap_pvalue helper（均纯函数，L1 自检 walkforward_helpers_l1）；复用 slice_bar_range/decompose_capturable_spread/class_actual_pnl；不改生产代码/TradeRecord/Order。被否证的 acc_level0sell_oos 保留（谱系：选择偏差的发生史）。");

    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/econpositive-walkforward-20260630.md");
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告 {out:?} 失败：{e}"));
    eprintln!("\n报告已落盘：{out:?}");

    // 真封：切片无重叠无遗漏 + holdout 聚合一致 + neff≤nraw。
    assert!(
        ds_train.bars.len() + ds_hold.bars.len() == n,
        "train+holdout bar 数 ≠ 全窗（半开应无重叠无遗漏）"
    );
    let recomputed: f64 = hd_pnls.iter().sum();
    assert!(
        (hd_pnl - recomputed).abs() < 1e-6,
        "holdout 赢家类 Σpnl 聚合不一致"
    );
    assert!(neff <= nraw as f64 + 1e-9, "neff 应 ≤ nraw");
}

// ── PDF §11 walk-forward 验收 helper（纯函数，L1 自检见 mod 末 #[test]）──

/// train 段 per-class 选最强正类（PDF §11「train 决定规则」）：扫所有出现的 `(level, δ, bsp_class)`
/// （P4/codex E-3：含类型 ⟹ 与 estimand 桶键一致，选类不跨 buy1/buy2/buy3 稀释），
/// 取 Σactual_pnl 最大者；若全非正返 None（train 期无可交易候选）。
/// **关键反偏差**：选类只用 train 段 decomps，holdout 信息不进入选择环节（消 codex Q2 BIAS-FATAL）。
fn train_winner_class(decomps_train: &[SignalDecomp]) -> Option<(u32, i8, u8)> {
    use std::collections::BTreeMap;
    let mut sums: BTreeMap<(u32, i8, u8), f64> = BTreeMap::new();
    for d in decomps_train {
        *sums.entry((d.level, d.delta, d.bsp_class)).or_default() += d.actual_pnl;
    }
    sums.into_iter()
        .filter(|(_, pnl)| *pnl > 0.0)
        .max_by(|a, b| a.1.partial_cmp(&b.1).unwrap())
        .map(|(cls, _)| cls)
}

/// 有效样本数 neff = nraw/(1+2Σρk)（PDF §6 条件二）。ρk=逐笔 PnL 序列样本自相关，
/// k=1..=lag_max，仅累加 ρk>0（正自相关才膨胀方差；负自相关不缩 neff 以保守）。
/// 退化：n<2 或方差≈0 ⟹ neff=nraw（无相关信息）。返回 (neff, sum_rho_pos)。
fn neff_autocorr(pnls: &[f64], lag_max: usize) -> (f64, f64) {
    let n = pnls.len();
    if n < 2 {
        return (n as f64, 0.0);
    }
    let mean = pnls.iter().sum::<f64>() / n as f64;
    let var = pnls.iter().map(|x| (x - mean).powi(2)).sum::<f64>() / n as f64;
    if var <= 1e-12 {
        return (n as f64, 0.0);
    }
    let mut sum_rho = 0.0;
    for k in 1..=lag_max.min(n - 1) {
        let cov: f64 = (0..n - k)
            .map(|i| (pnls[i] - mean) * (pnls[i + k] - mean))
            .sum::<f64>()
            / n as f64;
        let rho = cov / var;
        if rho > 0.0 {
            sum_rho += rho;
        }
    }
    let neff = n as f64 / (1.0 + 2.0 * sum_rho);
    (neff.max(1.0).min(n as f64), sum_rho)
}

/// 单侧 5% LCB = μ − 1.645·se，se=σ/√neff（PDF §7.3，neff 而非 nraw）。返回 (mu, se, lcb)。
fn mean_se_lcb(pnls: &[f64], neff: f64) -> (f64, f64, f64) {
    let n = pnls.len();
    if n == 0 {
        return (0.0, 0.0, 0.0);
    }
    let mu = pnls.iter().sum::<f64>() / n as f64;
    let var = pnls.iter().map(|x| (x - mu).powi(2)).sum::<f64>() / n as f64;
    let se = if neff > 1.0 {
        (var / neff).sqrt()
    } else {
        f64::INFINITY
    };
    (mu, se, mu - 1.645 * se)
}

/// Q4 剔最大赢家：降序剔除 top-k 后剩余 Σ（>0 ⟹ 非少数大赢家驱动）。返回 (sum_full, sum_drop1, sum_drop3, sum_drop5)。
fn drop_top_winners(pnls: &[f64]) -> (f64, f64, f64, f64) {
    let mut v = pnls.to_vec();
    v.sort_by(|a, b| b.partial_cmp(a).unwrap()); // 降序
    let full: f64 = v.iter().sum();
    let drop = |k: usize| -> f64 { v.iter().skip(k.min(v.len())).sum() };
    (full, drop(1), drop(3), drop(5))
}

/// Block bootstrap 右尾 p-value（H0:μ≤0，移动块重采样保留逐笔 PnL 自相关）：
/// 对原始序列做循环移动块重采样得 B 个 boot_mean，p = (#{boot_mean ≤ 0}+1)/(B+1)
/// = 重采样分布落在 0 及以下的占比 ⟹ 正均值越稳健远离 0 则 p 越小（PDF §11 block bootstrap）。
/// block_len 保块内时间相关（缠论同趋势段多信号相关，PDF §6）。确定性：固定 LCG（bit-exact 可复算）。
fn block_bootstrap_pvalue(pnls: &[f64], block_len: usize, b_iters: usize) -> f64 {
    let n = pnls.len();
    if n < 2 {
        return 1.0;
    }
    let blk = block_len.max(1).min(n);
    let mut seed: u64 = 0x9E3779B97F4A7C15; // 固定种子（确定性，无外部 rng）
    let next = |seed: &mut u64| -> usize {
        *seed = seed
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        ((*seed >> 33) as usize) % n
    };
    let mut le_zero = 0usize;
    for _ in 0..b_iters {
        let (mut acc, mut cnt) = (0.0f64, 0usize);
        while cnt < n {
            let start = next(&mut seed);
            for j in 0..blk {
                if cnt >= n {
                    break;
                }
                acc += pnls[(start + j) % n]; // 循环移动块（原始序列，未居中）
                cnt += 1;
            }
        }
        if acc / n as f64 <= 0.0 {
            le_zero += 1;
        }
    }
    (le_zero as f64 + 1.0) / (b_iters as f64 + 1.0)
}

/// b2 完整状态 Z 分桶键 L1 自检（task #83，升级自 W4 bsp_class 三键版）：
/// 桶键 = 完整 [`MuClass`] z（含 I_γ + σ_p/role），同 (level,δ) 按 I_γ **和** σ_p 均细分。
///
/// 五个合成信号：buy1×2 + buy2×1（同 σ_p=0 Root）验 I_γ 细分；再 buy1×2 中一条改 σ_p=+1 Child
/// 验 σ_p 细分（b2 相对旧 Y=(level,δ,bsp_class) 的新增维——同 (0,+1,buy1) 按 σ_p 再分两桶）。
#[test]
fn bucket_key_is_full_z_l1() {
    use std::collections::BTreeMap;

    // z 由 (level,δ,bsp_class,parent_dir,position) 构（合成路径 horizontal=None，同一路径恒定不改分桶）。
    let mk =
        |bsp_class: u8, parent_dir: i8, position: PositionState, actual_pnl: f64| SignalDecomp {
            entry_bar: 0,
            exit_bar: 1,
            level: 0,
            delta: 1,
            a_b: 0.0,
            x_in: 0.0,
            y_out: 0.0,
            eta_in: 0.0,
            eta_out: 0.0,
            actual_spread: 0.0,
            ce_unit: 0.0,
            captured: 0.0,
            actual_pnl,
            sigma_higher: 0,
            bsp_class,
            z: MuClass::from_certificate(
                0,
                1,
                BspBits::from_class_index(bsp_class),
                parent_dir,
                position,
            ),
            exit_decision: ExitDecision::Hold,
            trigger: NestTrigger::Type1TrendDivergence,
        };
    // buy1 Root ×2, buy2 Root ×1, buy1 Child(σ_p=+1) ×1：同 (level=0,δ=+1)，按 I_γ+σ_p 应分 3 桶。
    let decomps = vec![
        mk(0x01, 0, PositionState::Root, 1.0),
        mk(0x02, 0, PositionState::Root, 2.0),
        mk(0x01, 0, PositionState::Root, 3.0),
        mk(0x01, 1, PositionState::Child, 5.0), // σ_p=+1：与 buy1 Root 同 Y 桶、异 Z 桶（b2 细分）
    ];

    type Bucket = (usize, f64);
    let mut buckets: BTreeMap<MuClass, Bucket> = BTreeMap::new();
    for d in &decomps {
        let e = buckets.entry(d.z).or_insert((0, 0.0));
        e.0 += 1;
        e.1 += d.actual_pnl;
    }

    assert_eq!(
        buckets.len(),
        3,
        "buy1-Root / buy2-Root / buy1-Child(σ_p+1) 应分 3 桶（I_γ+σ_p 细分）"
    );
    let buy1_root = MuClass::from_certificate(
        0,
        1,
        BspBits::from_class_index(0x01),
        0,
        PositionState::Root,
    );
    let e = buckets.get(&buy1_root).expect("桶 buy1-Root 应存在");
    assert_eq!(e.0, 2, "buy1-Root 桶 n=2");
    assert!((e.1 - 4.0).abs() < 1e-9, "buy1-Root Σactual_pnl=1+3=4");
    let buy1_child = MuClass::from_certificate(
        0,
        1,
        BspBits::from_class_index(0x01),
        1,
        PositionState::Child,
    );
    assert_eq!(
        buckets.get(&buy1_child).expect("桶 buy1-Child 应存在").0,
        1,
        "buy1-Child(σ_p=+1) 独立成桶——b2 相对旧 Y 桶的新增 σ_p 细分维"
    );
}

/// neff/LCB/bootstrap helper L1 自检（合成数据，验证算术，零信息增量但保非平凡逻辑不破）。
#[test]
fn walkforward_helpers_l1() {
    // train_winner：(0,-1) Σ=+5 最强，(1,1) Σ=−2 被滤。
    let synth = |level: u32, delta: i8, pnl: f64| SignalDecomp {
        entry_bar: 0,
        exit_bar: 1,
        level,
        delta,
        a_b: 0.0,
        x_in: 0.0,
        y_out: 0.0,
        eta_in: 0.0,
        eta_out: 0.0,
        actual_spread: 0.0,
        ce_unit: 0.0,
        captured: 0.0,
        actual_pnl: pnl,
        sigma_higher: 0,
        bsp_class: 0,
        z: MuClass::from_certificate(
            level,
            delta,
            BspBits::from_class_index(0),
            0,
            PositionState::Root,
        ),
        exit_decision: ExitDecision::Hold,
        trigger: NestTrigger::XiaoZhuanDa,
    };
    let ds = vec![synth(0, -1, 3.0), synth(0, -1, 2.0), synth(1, 1, -2.0)];
    assert_eq!(
        train_winner_class(&ds),
        Some((0, -1, 0)),
        "train 应选 Σpnl 最大正类 (0,-1,cls=0)"
    );
    let all_neg = vec![synth(0, -1, -1.0)];
    assert_eq!(train_winner_class(&all_neg), None, "全非正应返 None");

    // neff 边界：始终 ∈[1, nraw]。块状正相关 ⟹ neff<nraw（事件聚集缩有效样本，PDF§6）。
    let pos_corr = vec![1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0]; // 块状正相关 lag1>0
    let (neff_pc, sr_pc) = neff_autocorr(&pos_corr, 4);
    assert!(
        neff_pc < 8.0 && neff_pc >= 1.0 && sr_pc > 0.0,
        "正自相关应缩 neff∈[1,nraw)，实得 neff={neff_pc} sr={sr_pc}"
    );
    // 常量序列方差≈0 ⟹ 退化 neff=nraw（无相关信息可缩）。
    let (neff_const, _) = neff_autocorr(&[2.0; 6], 4);
    assert!(
        (neff_const - 6.0).abs() < 1e-9,
        "零方差退化 neff=nraw，实得 {neff_const}"
    );

    // LCB：μ>0 但 se 大 ⟹ LCB 可能<0（压制噪声赢家）。
    let (mu, se, lcb) = mean_se_lcb(&[2.0, -1.0, 3.0, -2.0], 4.0);
    assert!(
        (mu - 0.5).abs() < 1e-9 && se > 0.0 && lcb < mu,
        "LCB=μ−1.645se<μ，实得 mu={mu} lcb={lcb}"
    );

    // drop_top：[10,1,1,1] 剔最大后 Σ=3>0（非单一赢家）；[10,-1,-1,-1] 剔后 Σ=−3<0（单一赢家驱动）。
    let (f1, d1, _, _) = drop_top_winners(&[10.0, 1.0, 1.0, 1.0]);
    assert!(
        (f1 - 13.0).abs() < 1e-9 && (d1 - 3.0).abs() < 1e-9,
        "剔最大后剩余"
    );
    let (_, d1b, _, _) = drop_top_winners(&[10.0, -1.0, -1.0, -1.0]);
    assert!(d1b < 0.0, "单一大赢家驱动：剔后转负");

    // bootstrap：强正信号 p 小；纯噪声 p 接近 0.5（确定性，固定种子）。
    let strong_pos = vec![5.0; 20];
    let p_pos = block_bootstrap_pvalue(&strong_pos, 3, 500);
    assert!(
        p_pos <= 0.05,
        "强正信号 block bootstrap p 应小，实得 {p_pos}"
    );
}

/// **全历史多级别信号分布 + level2+ 逐级别 train-only holdout μ̂/LCB/p（acc-multilevel-sample + acc-highlevel-mu）**。
///
/// 同一次全量跑（ECON_L2_MAX_BARS=5000000，BTC 461万 bar）产出两条 acceptance 所需数据，避免重跑。
///
/// ## acc-multilevel-sample（信号数分布）
/// 输出 level0-5 全历史信号数分布表。Le Cam 硬墙判定：
/// - level3+ 全历史 n < 30 ⟹ 结构性稀疏（高级别本身低频，Le Cam 硬墙；有效域 < 定义域）。
/// - level3+ n ≥ 50 ⟹ 窗口截断证实可 OOS 验（若截断窗则为截断窗结论，全量则为全历史结论）。
///
/// ## acc-highlevel-mu（level2+ 逐级别 train-only holdout alpha）
/// 对 level>=2 的每个 (level,δ)：
/// - train_frac=0.6 按 bar 顺序切分（半开区间无重叠）。
/// - train 段全量跑 decompose，holdout 段全量跑 decompose（**不**从 train-only 挑类——每个 (level,δ) 独立评估）。
/// - holdout neff_autocorr + mean_se_lcb (LCB 单侧5%) + block_bootstrap_pvalue(block=20, B=2000)。
/// - 照实报 LCB>0 占比 + p 值（否定性结果 = 有效域收窄，161/formalization-validity-domain）。
///
/// **认识论等级 L2**（真实数据单标的，可产否定性结果，非 L3 跨品种）。
/// **testing-override 生成态例外**：测试目的是产出可证伪经济结果，不是通过。
///
/// `#[ignore]`：需 BTC 全量数据（314M）+ O(n²) 重分类 × 2（train/holdout 各跑一次），`--release`。
/// 命令：`ECON_L2_MAX_BARS=5000000 cargo test --release acc_multilevel_highlevel_mu -- --ignored --nocapture`。
#[test]
#[ignore]
fn acc_multilevel_highlevel_mu() {
    use super::super::data;
    use std::collections::BTreeMap;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();

    // 显式有效域：全量为 ECON_L2_MAX_BARS=5000000（>4.6M=不截断）。
    // #399：骨架收敛至共享 helper（mod tests 顶部），行为不变。
    let max_bars = econ_l2_max_bars();
    let ds = truncate_tail_bars(ds_full, max_bars);
    let n = ds.bars.len();
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!("全量跑：bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}");

    // ── Step1：全窗跑一次，产 level0-5 信号数分布表（acc-multilevel-sample）。 ──
    eprintln!("[Step1] 全窗 decompose（信号分布表）...");
    let (decomps_full, agg_full) = decompose_capturable_spread(&ds, &config);
    eprintln!("[Step1] 完成：n_signals={}", agg_full.n_signals);

    // per-(level,δ) 信号数 + μ̂（全窗，仅用于信号分布表，不作 OOS alpha）。
    let mut dist: BTreeMap<(u32, i8), (usize, f64)> = BTreeMap::new();
    for d in &decomps_full {
        let e = dist.entry((d.level, d.delta)).or_default();
        e.0 += 1;
        e.1 += d.actual_pnl;
    }
    let max_level = dist.keys().map(|(l, _)| *l).max().unwrap_or(0);

    // ── Step2：train/holdout 切分，分别跑 decompose（acc-highlevel-mu 防选择偏差）。 ──
    let train_frac = std::env::var(crate::theta_v0::env_registry::ECON_L2_TRAIN_FRAC)
        .ok()
        .and_then(|s| s.parse::<f64>().ok())
        .unwrap_or(0.6);
    let split = (n as f64 * train_frac) as usize;
    let split_day = if split < ds.dates.len() {
        ds.dates[split].get(..10).unwrap_or("").to_string()
    } else {
        "末端".to_string()
    };
    eprintln!("[Step2] train=[0,{split})，holdout=[{split},{n})，切分日={split_day}");

    let ds_train = ds.slice_bar_range(0, split);
    let ds_hold = ds.slice_bar_range(split, n);
    let (decomps_train, _) = decompose_capturable_spread(&ds_train, &config);
    let (decomps_hold, _) = decompose_capturable_spread(&ds_hold, &config);
    eprintln!(
        "[Step2] train n_signals={}，holdout n_signals={}",
        decomps_train.len(),
        decomps_hold.len()
    );

    // level2+ 每个 (level,δ)：holdout 段的 μ̂/neff/LCB/p。
    // 遍历全窗出现过的 level>=2 的 (level,δ)（train 中未出现的 holdout 也可能出现，照报）。
    let high_keys: Vec<(u32, i8)> = {
        let mut ks: std::collections::BTreeSet<(u32, i8)> = Default::default();
        for d in decomps_full
            .iter()
            .chain(decomps_train.iter())
            .chain(decomps_hold.iter())
        {
            if d.level >= 2 {
                ks.insert((d.level, d.delta));
            }
        }
        ks.into_iter().collect()
    };

    // per-(level,δ) holdout 评估（train 段只用于「知道该 level 是否出现」，不挑赢家——每级独立评估）。
    struct HighLevelResult {
        level: u32,
        delta: i8,
        tr_n: usize,
        tr_pnl: f64,
        hd_n: usize,
        hd_pnl: f64,
        hd_pos: usize,
        mu_oos: f64,
        se_oos: f64,
        lcb: f64,
        neff: f64,
        nraw: usize,
        sum_rho: f64,
        drop_d5: f64,
        bootstrap_p: f64,
    }
    let mut hl_results: Vec<HighLevelResult> = Vec::new();
    for &(lv, dl) in &high_keys {
        let (tr_n, tr_pnl, _, _) = class_actual_pnl_agg(&decomps_train, lv, dl);
        let (hd_n, hd_pnl, hd_pos, _) = class_actual_pnl_agg(&decomps_hold, lv, dl);
        let pnls: Vec<f64> = decomps_hold
            .iter()
            .filter(|d| d.level == lv && d.delta == dl)
            .map(|d| d.actual_pnl)
            .collect();
        let nraw = pnls.len();
        let (neff, sum_rho) = neff_autocorr(&pnls, 20);
        let (mu_oos, se_oos, lcb) = mean_se_lcb(&pnls, neff);
        let (_, _, _, drop_d5) = drop_top_winners(&pnls);
        let bootstrap_p = block_bootstrap_pvalue(&pnls, 20, 2000);
        hl_results.push(HighLevelResult {
            level: lv,
            delta: dl,
            tr_n,
            tr_pnl,
            hd_n,
            hd_pnl,
            hd_pos,
            mu_oos,
            se_oos,
            lcb,
            neff,
            nraw,
            sum_rho,
            drop_d5,
            bootstrap_p,
        });
    }

    // ── 报告 ──
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# acc-multilevel-sample + acc-highlevel-mu：BTC 全历史多级别 alpha 检验"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "**认识论等级**：L2（真实数据单标的 BTC 2017-2026 全历史，可产否定性结果，非 L3 跨品种）。"
    );
    let _ = writeln!(
        rpt,
        "**目的**：同一次全量跑产出两条 acceptance 判定，避免重跑。"
    );
    let _ = writeln!(rpt, "**复算**：`ECON_L2_MAX_BARS=5000000 cargo test --release acc_multilevel_highlevel_mu -- --ignored --nocapture`");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 数据");
    let _ = writeln!(
        rpt,
        "- 品种：BTC（btc_1m_full.json，全量 {n_full} bar，2017-08→2026-05）"
    );
    let _ = writeln!(
        rpt,
        "- 本次窗口：bars={n}（{win_start}→{win_end}，max_bars={max_bars}）"
    );
    let _ = writeln!(rpt, "- train_frac={train_frac}，切分 bar={split}（{split_day}），train=[0,{split}) / holdout=[{split},{n}) 无重叠");
    let _ = writeln!(rpt, "- 全窗 n_signals={}", agg_full.n_signals);
    let _ = writeln!(rpt);

    // ── acc-multilevel-sample：信号数分布表 ──
    let _ = writeln!(
        rpt,
        "## acc-multilevel-sample：level0-{max_level} 全历史信号数分布"
    );
    let _ = writeln!(
        rpt,
        "Le Cam 硬墙判定（level3+）：n<30 ⟹ 结构性稀疏；n≥50 ⟹ 可 OOS 验。"
    );
    let _ = writeln!(rpt, "| level | δ | n（全窗） | μ̂=Σactual_pnl/n（全窗，含选择偏差，仅参考） | Le Cam 判定（level3+）|");
    let _ = writeln!(rpt, "|---|---|---|---|---|");
    for ((lvl, dlt), (n_cls, pnl_cls)) in &dist {
        let mu = if *n_cls > 0 {
            pnl_cls / *n_cls as f64
        } else {
            0.0
        };
        let lecam = if *lvl >= 3 {
            if *n_cls < 30 {
                "结构性稀疏（<30，Le Cam 硬墙）"
            } else if *n_cls >= 50 {
                "可 OOS 验（≥50）"
            } else {
                "边界（30-49）"
            }
        } else {
            "—"
        };
        let _ = writeln!(rpt, "| {lvl} | {dlt:+} | {n_cls} | {mu:.4e} | {lecam} |");
    }
    let _ = writeln!(rpt);

    // acc-multilevel-sample 判定
    let high_level_sparse = {
        let level3plus: Vec<_> = dist.iter().filter(|((l, _), _)| *l >= 3).collect();
        level3plus.iter().all(|(_, (n, _))| *n < 30)
    };
    let _ = writeln!(
        rpt,
        "**acc-multilevel-sample 判定**：level3+ 全历史 n 分布——"
    );
    if high_level_sparse {
        let _ = writeln!(rpt, "→ **level3+ 均 <30（Le Cam 硬墙成立）**：高级别结构性稀疏，全历史长窗也无足够样本做 OOS 验（有效域：高级别 alpha 可存在但不可功效检验）。");
    } else {
        let _ = writeln!(rpt, "→ **level3+ 存在 ≥30 的级别**：窗口截断导致的稀疏已排除（全量足够），level3+ 具备 OOS 验证能力。");
    }
    let _ = writeln!(rpt);

    // ── acc-highlevel-mu：level2+ 逐级别 holdout alpha ──
    let _ = writeln!(
        rpt,
        "## acc-highlevel-mu：level2+ 逐级别 train-only holdout μ̂/LCB/p"
    );
    let _ = writeln!(rpt, "train_frac={train_frac}，切分日 {split_day}。每个 (level,δ) 独立评估（不从 train-only 挑类——无跨级别选择偏差）。");
    let _ = writeln!(rpt, "LCB=μ−1.645·se（单侧5%，se 用 neff），block bootstrap p（H0:μ≤0，block=20，B=2000，固定种子）。");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| level | δ | train_n | train_Σpnl | holdout_n | holdout_Σpnl | μ̂_OOS | se | LCB | neff/nraw | drop_d5 | bootstrap_p | LCB>0? |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|---|---|---|");
    let mut lcb_pos_count = 0usize;
    let mut total_hl = 0usize;
    for r in &hl_results {
        let wr = |pos: usize, n: usize| {
            if n > 0 {
                format!("{pos}/{n} ({:.0}%)", 100.0 * pos as f64 / n as f64)
            } else {
                "0/0".to_string()
            }
        };
        let neff_ratio = if r.nraw > 0 {
            format!("{:.2}/{}", r.neff, r.nraw)
        } else {
            "—".to_string()
        };
        let _ = writeln!(rpt, "| {} | {:+} | {} | {:.4e} | {} | {:.4e} | {:.4e} | {:.4e} | **{:.4e}** | {} | {:.4e} | {:.3} | {} |",
                r.level, r.delta, r.tr_n, r.tr_pnl, r.hd_n, r.hd_pnl,
                r.mu_oos, r.se_oos, r.lcb, neff_ratio, r.drop_d5, r.bootstrap_p,
                if r.lcb > 0.0 { "✓" } else { "✗" });
        let _ = writeln!(rpt, "  胜率={}", wr(r.hd_pos, r.hd_n));
        total_hl += 1;
        if r.lcb > 0.0 {
            lcb_pos_count += 1;
        }
    }
    let _ = writeln!(rpt);
    let lcb_pos_ratio = if total_hl > 0 {
        100.0 * lcb_pos_count as f64 / total_hl as f64
    } else {
        0.0
    };
    let _ = writeln!(rpt, "**acc-highlevel-mu 判定**：");
    let _ = writeln!(
        rpt,
        "- level2+ holdout LCB>0 占比 = {lcb_pos_count}/{total_hl} ({lcb_pos_ratio:.0}%)"
    );

    // 判定逻辑：LCB>0 ⟹ 高级别 holdout alpha 成立；LCB≤0 ⟹ 否证（照实报）
    if lcb_pos_count == 0 {
        let _ = writeln!(rpt, "→ **否证（level2+ 全部 LCB≤0）**：高级别 holdout μ̂ 扣除不确定性后无一正 ⟹ 高级别无稳健 OOS alpha（否定性结果，缩小有效域边界，161/formalization-validity-domain）。");
        let _ = writeln!(rpt, "→ 否定性结果价值：高级别 alpha 不存在于 BTC 单标的 L2，仅低级别候选（level0/1 待 L3 验）。");
    } else if lcb_pos_count == total_hl {
        let _ = writeln!(rpt, "→ **全部 LCB>0**：level2+ 每个 (level,δ) holdout μ̂ 均通过 §7.3 强判据 ⟹ 高级别具备稳健 OOS alpha 候选（仍 BTC 单标的 L2，需 L3 跨品种确认）。");
    } else {
        let _ = writeln!(rpt, "→ **部分 LCB>0（{lcb_pos_count}/{total_hl}）**：高级别 alpha 非全域稳健——部分 (level,δ) 通过强判据，其余否证。分别报告（见上表）。");
    }
    let _ = writeln!(rpt);

    // ── 结果包六要素 ──
    let _ = writeln!(rpt, "## 结果包六要素");
    let _ = writeln!(rpt, "1. **结论**：");
    let _ = writeln!(
        rpt,
        "   - acc-multilevel-sample：level0-{max_level} 全历史信号数分布见上表。level3+ {}。",
        if high_level_sparse {
            "全部 <30（Le Cam 硬墙，结构性稀疏）"
        } else {
            "存在 ≥30（可 OOS 验）"
        }
    );
    let _ = writeln!(rpt, "   - acc-highlevel-mu：level2+ holdout LCB>0 占比={lcb_pos_count}/{total_hl}（{lcb_pos_ratio:.0}%）。{}",
            if lcb_pos_count == 0 { "全否证，高级别无稳健 OOS alpha（L2）。" }
            else { "部分或全部通过 §7.3 强判据（见明细表）。" });
    let _ = writeln!(rpt, "2. **定义依据**：actual_pnl=δ(Pτout−Pτin)−Ce（664-Q3 真实成交口径）；LCB=μ−1.645se（PDF §7.3，se 用 neff_autocorr 修正）；train-only 每级独立评估（无跨级选择偏差）；Le Cam 硬墙判定（n<30）。");
    let _ = writeln!(rpt, "3. **边界条件**：单标的 BTC L2——结论翻转条件：(a) max_bars={max_bars}（若<461万则为截断窗结论）；(b) train_frac={train_frac} 改变切分点结论可能变化；(c) 高级别 n 过少（Le Cam 约束）时 LCB 由 se 主导而非 μ；(d) 不同 bootstrap 种子理论上可影响 p（本实现固定 LCG 种子确定性）。");
    let _ = writeln!(rpt, "4. **下游推论**：若 level2+ 全否证 ⟹ 策略信号层仅可依赖 level0/1（需 L3 跨品种升基座）。若存在 LCB>0 ⟹ 该 (level,δ) 可作 entry 候选（仍需 L3）。否定性结果意味着高级别配额应为 0 或纯结构性（不依赖 alpha 预期）。");
    let _ = writeln!(rpt, "5. **谱系引用**：663 econpositive（可交易性=μ(z,a)>0）；664-Q3（真实成交口径）；formalization-validity-domain（L2 有效域<定义域，L3 待 L2 完成后）；testing-override 生成态例外（测试目的=产出可证伪结果，非通过）；161（否定性结果照实报）。不确定是否有 level2+ alpha 的独立谱系记录，保守声明无关联已知谱系。");
    let _ = writeln!(rpt, "6. **影响声明**：新增 acc_multilevel_highlevel_mu 测试；复用 decompose_capturable_spread/class_actual_pnl/neff_autocorr/mean_se_lcb/drop_top_winners/block_bootstrap_pvalue；不改任何生产代码/TradeRecord/Order/信号收集逻辑。报告落盘 econ-multilevel-mu-20260701.md。");

    // 落盘
    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/econ-multilevel-mu-20260701.md");
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n报告已落盘：{out:?}");

    // 真封：切片无重叠 + neff≤nraw 逐结果。
    assert_eq!(
        ds_train.bars.len() + ds_hold.bars.len(),
        n,
        "train+holdout bar 数 ≠ 全窗（半开区间应无重叠无遗漏）"
    );
    for r in &hl_results {
        assert!(
            r.neff <= r.nraw as f64 + 1e-9,
            "neff({:.1}) 应 ≤ nraw({})：level={} δ={}",
            r.neff,
            r.nraw,
            r.level,
            r.delta
        );
        // holdout Σpnl 与逐信号和一致（聚合完整性）。
        let recomp: f64 = decomps_hold
            .iter()
            .filter(|d| d.level == r.level && d.delta == r.delta)
            .map(|d| d.actual_pnl)
            .sum();
        assert!(
            (r.hd_pnl - recomp).abs() < 1e-6,
            "holdout Σpnl 聚合不一致：level={} δ={}",
            r.level,
            r.delta
        );
    }
}

/// **Task #7 acc-classification：level 塔中间级空洞 H1/H2/H3 判别（诊断，不预设）**。
///
/// 反演：Π_full 全历史 level 分布 7741→0→0→0→0→1 高度反常（level1-4 全空但 level5=1）。
/// w-verify 提交 8d45dc449b 假设真稀疏(H1)但**未做判别实验**。本测试三路 instrument 信号收集循环
/// （bit-exact 复制 decompose_capturable_spread 的收集路径），在 N^δ 门**前后**分级别计数：
///
/// | 计数点 | 语义 | 判别 |
/// |---|---|---|
/// | (a) bsp_pre[lvl] | classifier 该 level 提取的 bsp 总数（门前，按第一/二/三类分） | 门前是否有信号 |
/// | (b) gamma_nonflat[lvl] | Γ 组装非 Flat 候选数（N^δ 门前） | dir 是否可判 |
/// | (c) sig_post[lvl] | 通过 N^δ 门 push 进 signals 的数（门后） | 门滤了多少 |
/// | (d) tower_segs[lvl] | tower[lvl] 段数（结构存在性） | level 塔是否构造到该级 |
///
/// **判别规则**（三路，不预设 H1/H2 二分）：
/// - 中间级 bsp_pre>0 但 sig_post=0 ⟹ **H1**（N^δ 门滤空——[J_{ℓ-1}⊆J_ℓ] 嵌套链严格）。
/// - 中间级 bsp_pre=0 ⟹ **H3**（架构：原「上级层只产第二类 B2/S2」前提已被裁定A+#123 作废——
///   级别≥1 现产一/二/三类；若仍 bsp_pre=0 则是该窗结构稀疏，非提取禁闭）。
/// - 300K bsp_pre/sig_post≫0 但全历史=0（跨窗对比，两次跑）⟹ **H2**（全历史路径 bug）。
///
/// **结构 sanity（team-lead 要求③）**：level5 唯一信号的 rungs 链——它的 tower 各级 rung 存在吗？
/// 若 level5 结构含 level1-4 子结构却没算作 level1-4 信号 = 计数 bug。本测试 dump level5 信号的
/// N^δ 证书 rungs 层数 + 各级 cand。
///
/// **认识论 L2**：真实 BTC 数据逐信号分级别计数，可产否定性结果（H1 缩有效域 / H2 复活高级别）。
/// `#[ignore]`：需 BTC 全量 + O(n²) 重分类，`--release`。
/// 命令：`ECON_L2_MAX_BARS=<N> cargo test --release acc_classification_level_hole_dx -- --ignored --nocapture`
/// （默认 300K；跑全历史用 ECON_L2_MAX_BARS=5000000）。
#[test]
#[ignore]
fn acc_classification_level_hole_dx() {
    use super::super::super::classifier::divergence::compute_macd;
    use super::super::super::strategy::interp::assemble_gamma_with_tower;
    use super::super::super::strategy::voice::VoiceSide;
    use super::super::super::types::Side;
    use super::super::data;
    use super::super::incremental::IncrementalClassifier;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    // #399：骨架收敛至共享 helper（mod tests 顶部），行为不变。
    let max_bars = econ_l2_max_bars();
    let ds = truncate_tail_bars(ds_full, max_bars);
    let bars = &ds.bars;
    let n = bars.len();
    let tick = config.tick.tick_size;
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[level-hole-dx] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    let closes: Vec<f64> = bars.iter().map(|b| b.close as f64 / tick as f64).collect();
    let macd_hist = compute_macd(&closes, &config.macd).hist;

    // 分级别计数器（L=8 上限足够；实测最高 level5）。
    const LMAX: usize = 8;
    let mut bsp_pre = [0usize; LMAX]; // (a) 门前 bsp 提取总数
    let mut bsp_pre_first = [0usize; LMAX]; // 门前第一类（buy1/sell1）
    let mut bsp_pre_second = [0usize; LMAX]; // 门前第二类（buy2/sell2）
    let mut bsp_pre_third = [0usize; LMAX]; // 门前第三类（buy3/sell3）
    let mut gamma_nonflat = [0usize; LMAX]; // (b) Γ 非 Flat 候选
    let mut sig_post = [0usize; LMAX]; // (c) 通过 N^δ 门（bsp/Γ 通道，PanDiv 外计）
                                       // Q4（#147）：PanDiv 承接通过门计数（Γ 外通道——不经 assemble_gamma，混入 sig_post 会
                                       // 污染 H1 门滤诊断的 gamma_nonflat−sig_post 列）。真封①口径 = sig_post + sig_post_pan。
    let mut sig_post_pan = [0usize; LMAX];
    let mut tower_segs_max = [0usize; LMAX]; // (d) tower[lvl] 段数（末次分类快照）
    let mut levels_seen_max = 0usize; // cls.levels.len() 最大值

    // 结构 sanity：level≥1 通过门的信号，记其 (source_index, δ, bits, rung 层数)。
    let mut highlevel_hits: Vec<(usize, usize, i8, u8, usize)> = Vec::new(); // (lvl, src, δ, bits_u8, n_rungs)

    // ── P1 FullNest 验收（task #22）：通过门信号的**有效跨级深度**分布（含 level0）。 ──
    // effective_nest_depth(cert) = n_delta 递归实际穿越的连续 cand=true 跨级层数。
    // depth==0 ⟹ 纯 base-case confirm_side（退化，等价单 bit，无区间套跨级触达）；
    // depth>=1 ⟹ 真跨级 [J_{ℓ-1}⊆J_ℓ] 触达（≥2 层证书 e→ℓ）。用 build_nest_certificate
    // （与生产门共用构造）⟹ bit-exact 同源，非外部近似重算。索引=深度（LMAX 足够，实测塔≤6 级）。
    let mut nest_depth_hist_pass = [0usize; LMAX + 1]; // 通过门信号（n_delta=true）的有效深度分布
    let mut nest_depth_by_level_pass = [[0usize; LMAX + 1]; LMAX]; // [exec_level][depth]
    let mut n_gate_pass_total = 0usize; // 通过门信号总数（应=sig_post_sum）
    let mut n_xzd_pass = 0usize; // 小转大通道通过（无区间套 depth，设计 §2.3）——depth 直方图外计
                                 // StructBreak 收紧测量（task #62，codex 终局裁决A）：零 bit（bsp_class==0）候选中通过门的条数
                                 // ——这批此前经旧 else=>Type3 分派可能走 Nest/Xzd 通过门，收紧后 bsp_cand_type 恒 StructBreak
                                 // ⟹ build_gate_certificate 恒 None ⟹ 本计数器在新代码下恒为 0（收紧生效的直接证据）。
    let mut n_zerobit_gate_pass = 0usize;
    // 小转大分项（消歧「严格门真 0」vs「C3 死门伪影」）：路由到 Xzd 的总数 + C2/C3 单项命中。
    let mut n_xzd_routed = 0usize; // build_gate_certificate 返回 Xzd 的信号数（=小转大域触达）
    let mut n_xzd_c2 = 0usize; // 其中 C2（type2_confirmed）成立
    let mut n_xzd_c3 = 0usize; // 其中 C3（sub_last_zs_type3，诊断字段，不参门）成立
                               // ── C3 死门诊断探针（codex 终局裁定 §5.4，task #41）：按 level 聚合 + lvl==1/lvl>=2 分裂断点 ──
    let mut xzd_routed_by_level = [0usize; LMAX];
    let mut xzd_c2_by_level = [0usize; LMAX];
    let mut xzd_c3_by_level = [0usize; LMAX]; // = same_side_same_center
    let mut xzd_l1_last_zs_exists = 0usize;
    let mut xzd_l1_same_side_l0_type3_any = 0usize;
    let mut xzd_l1_same_center_any = 0usize;
    let mut xzd_l1_same_side_causal_ok = 0usize;
    let mut xzd_lge2_sub_bsp_type3_total = 0usize; // 死门重封（裁定A+#123）：lvl>=2 sub_bsp 可含 Type3，锁基线
                                                   // C3 新判据命中率探针（task #47，codex #44(c) 终局裁定）：level==1 子集「新中枢+突破」命中率。
    let mut xzd_l1_c3_new_center_exists = 0usize;
    let mut xzd_l1_c3_new_center_breakout_ok = 0usize;
    // XZD C2-only 口径复审探针（task #170，#148 后 C3 脱 0）：lvl>=2 子集同两字段命中数——
    // 供「level>=2 C2-only 保留 vs C3 硬门全 level 启用」codex 裁定的量化输入（报数不裁断，
    // 无断言不参门；#41 裁定 level>=2 C2-only 的前提是旧判据结构性死门，#148 升级重切后该
    // 前提在 level==1 已实证失效，level>=2 是否同失效由本探针测量）。
    let mut xzd_lge2_c3_new_center_exists = 0usize;
    let mut xzd_lge2_c3_new_center_breakout_ok = 0usize;
    // C3 L1 零命中根因判别探针（codex #55 终局裁定(5)，task #56）：默认关闭，只读旁路
    // （不写 Classification.levels[*].centers/tower/正常输出）。开关：ECON_C3_OVERLAP_PROBE=1。
    let overlap_probe_enabled = std::env::var(crate::theta_v0::env_registry::ECON_C3_OVERLAP_PROBE)
        .ok()
        .as_deref()
        == Some("1");
    let mut xzd_l1_overlap_rows: Vec<(usize, usize, usize, usize, Option<(usize, usize)>)> =
        Vec::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();
    // C1：dx 手写门循环复用为 collect_signals 的对拍源——门后 push 与生产同序同字段的信号元组。
    let mut signals_dx: Vec<RawSignal> = Vec::new();
    // Q4（task #145）：盘整背驰承接 dx 镜像去重集（与生产 seen_pan 同键同序）。
    let mut seen_pan_dx: std::collections::HashSet<(usize, usize, u8)> =
        std::collections::HashSet::new();
    // C2：与生产 collect_signals 同改——Rc::ptr_eq 命中跳级（同 Rc ⟹ 全键已 seen ⟹ 内层
    // bsp_pre/gamma_nonflat/sig_post 等计数均在 seen.insert 成功后，跳过 bit-exact）。
    let mut prev_bsp = Vec::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        // ★#883：取 l0.strokes 供 div_cand ForceL 数据源（与生产 collect_signals 同口径）。
        let __wl1 = classifier_incr.classify_at(i);
        let l0_i = classifier_incr
            .last_l0()
            .expect("classify_at 已推进 ParseLayer");
        let cls_i = __wl1.classification;
        let tower_i = __wl1.tower;
        levels_seen_max = levels_seen_max.max(cls_i.levels.len());
        for (l, rc) in tower_i.iter().enumerate() {
            if l < LMAX {
                tower_segs_max[l] = tower_segs_max[l].max(rc.len());
            }
        }
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if prev_bsp
                .get(lvl)
                .map_or(false, |prev| Rc::ptr_eq(prev, &ls.bsp))
            {
                continue; // C2：同 Rc ⟹ 全键已 seen，跳级
            }
            if lvl < prev_bsp.len() {
                prev_bsp[lvl] = Rc::clone(&ls.bsp);
            } else {
                prev_bsp.push(Rc::clone(&ls.bsp));
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                if lvl < LMAX {
                    bsp_pre[lvl] += 1;
                    if p.bits.buy1 || p.bits.sell1 {
                        bsp_pre_first[lvl] += 1;
                    }
                    if p.bits.buy2 || p.bits.sell2 {
                        bsp_pre_second[lvl] += 1;
                    }
                    if p.bits.buy3 || p.bits.sell3 {
                        bsp_pre_third[lvl] += 1;
                    }
                }
                // Γ 组装（bit-exact 复制生产路径）。
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()), // Q4：dx 与生产 single 同形（无盘整背驰载荷）
                            first_class_grades: Rc::new(Vec::new()), // #885：同 pan_div 口径（single 屏蔽层无分级记录载荷）
                            level_projection: None,                  // #110 门关口径
                        })
                        .collect(),
                };
                let sigma_higher = sigma_higher_at(&tower_i, bars, lvl); // 666 号：与生产 collect_signals 同口径
                for c in &assemble_gamma_with_tower(&single, &tower_i) {
                    if c.dir == VoiceSide::Flat {
                        continue;
                    }
                    if lvl < LMAX {
                        gamma_nonflat[lvl] += 1;
                    }
                    let delta_side = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    // 二通道准入门（与生产 collect_signals 同源）：Nest→n_delta+depth；Xzd→gate_pass（无 depth）。
                    let sub_centers: &[Center] = if lvl > 0 {
                        &cls_i.levels[lvl - 1].centers
                    } else {
                        &[]
                    };
                    let sub_bsp: &[BspPoint] = if lvl > 0 {
                        &cls_i.levels[lvl - 1].bsp
                    } else {
                        &[]
                    };
                    let gate_cert = build_gate_certificate(
                        &tower_i,
                        lvl,
                        p.source_index,
                        delta_side,
                        &p.bits,
                        &macd_hist,
                        i,
                        &ls.bsp,
                        sub_centers,
                        sub_bsp,
                        &l0_i.strokes, // ★#883
                        config.divergence_gauge,
                    );
                    let (pass, nest_depth, rungs_len) = match &gate_cert {
                        Some(GateCertificate::Nest(cert)) => (
                            cert.n_delta(),
                            Some(effective_nest_depth(cert)),
                            cert.rungs().len(),
                        ),
                        Some(GateCertificate::Xzd(ev)) => {
                            n_xzd_routed += 1; // 小转大域触达（消歧死门用）
                            if ev.type2_confirmed {
                                n_xzd_c2 += 1;
                            }
                            if ev.sub_last_zs_type3 {
                                n_xzd_c3 += 1;
                            }
                            // C3 死门诊断探针（§5.4）：按 level 聚合 + lvl==1/lvl>=2 分裂断点。
                            if lvl < LMAX {
                                xzd_routed_by_level[lvl] += 1;
                                if ev.type2_confirmed {
                                    xzd_c2_by_level[lvl] += 1;
                                }
                                if ev.sub_last_zs_type3 {
                                    xzd_c3_by_level[lvl] += 1;
                                }
                            }
                            if lvl == 1 {
                                if ev.last_zs_exists {
                                    xzd_l1_last_zs_exists += 1;
                                }
                                if ev.same_side_l0_type3_any {
                                    xzd_l1_same_side_l0_type3_any += 1;
                                }
                                if ev.same_center_any {
                                    xzd_l1_same_center_any += 1;
                                }
                                if ev.same_side_causal_ok {
                                    xzd_l1_same_side_causal_ok += 1;
                                }
                                if ev.c3_new_center_exists {
                                    xzd_l1_c3_new_center_exists += 1;
                                }
                                if ev.c3_new_center_breakout_ok {
                                    xzd_l1_c3_new_center_breakout_ok += 1;
                                }
                                // 探针（只读旁路，见函数头注）：lvl==1 时 sub_units=L0 段账本（tower[0]），
                                // sub_moves 同 build_gate_certificate 内部消费的 tower[lvl-1]。
                                if overlap_probe_enabled {
                                    let l0_moves: &[LeveledMove] =
                                        tower_i.get(0).map(|m| m.as_slice()).unwrap_or(&[]);
                                    let sub_units = l0_units_from_tower(l0_moves);
                                    let probe = xzd_c3_overlap_window_probe(
                                        p.source_index,
                                        i,
                                        delta_side,
                                        &sub_units,
                                        l0_moves,
                                    );
                                    xzd_l1_overlap_rows.push((
                                        p.source_index,
                                        i,
                                        probe.overlapping_new_center_count,
                                        probe.overlapping_breakout_count,
                                        probe.first_overlapping_center,
                                    ));
                                }
                            } else if lvl >= 2 {
                                xzd_lge2_sub_bsp_type3_total += ev.sub_bsp_type3_count; // 死门重封：裁定A+#123 后可非 0，尾部锁基线
                                                                                        // task #170 复审探针：lvl>=2 的 C3 新判据命中（gate_pass 在 level!=1 不读此二字段——
                                                                                        // 计数只测「若并入硬门会怎样」的量化空间，零行为影响）。
                                if ev.c3_new_center_exists {
                                    xzd_lge2_c3_new_center_exists += 1;
                                }
                                if ev.c3_new_center_breakout_ok {
                                    xzd_lge2_c3_new_center_breakout_ok += 1;
                                }
                            }
                            (ev.gate_pass(), None, 0) // 小转大无区间套 depth
                        }
                        None => (false, None, 0),
                    };
                    if bsp_class == 0 && pass {
                        n_zerobit_gate_pass += 1;
                    }
                    if !pass {
                        continue;
                    }
                    if lvl < LMAX {
                        sig_post[lvl] += 1;
                    }
                    // C1：与生产 collect_signals 同序同字段（含 b2 完整 z——z_of_candidate
                    // 同一桥，保证 dx 手写门与生产收集 bit-exact，尾部 signals_dx vs signals_prod 逐条对拍含 z）。
                    // P0-1：与生产 collect_signals 同源触发分类（pass ⟹ gate_cert Some）。
                    let trigger_dx = nest_trigger(
                        gate_cert.as_ref().expect("pass ⟹ gate_cert Some"),
                        bsp_cand_type(&p.bits, delta_side),
                    );
                    // ★G3 ext（#138，与生产装配 bit-exact 同源）：Nest→depth=rungs.len()（pass ⟹
                    // effective_nest_depth==rungs.len()，前缀定理）+ origin=lvl+depth；Xzd→无 rungs。
                    let ext_dx = match gate_cert.as_ref().expect("pass ⟹ gate_cert Some") {
                        GateCertificate::Nest(_) => ZExt {
                            cand_channel: Some(trigger_dx),
                            nest_depth: Some(rungs_len as u8),
                            origin_level: Some(lvl as u32 + rungs_len as u32),
                            risk_mode: None,
                            t_stage: None,    // #149：与生产同源，统计层诚实 None
                            eta_bucket: None, // #175：与生产同源，统计层诚实 None
                        },
                        GateCertificate::Xzd(_) => ZExt {
                            cand_channel: Some(trigger_dx),
                            nest_depth: None,
                            origin_level: None,
                            risk_mode: None,
                            t_stage: None,    // #149：与生产同源，统计层诚实 None
                            eta_bucket: None, // #175：与生产同源，统计层诚实 None
                        },
                    };
                    signals_dx.push(RawSignal {
                        entry_bar: i,
                        dir: c.dir,
                        pivot_bar: p.source_index,
                        level: lvl as u32,
                        sigma_higher,
                        bsp_class,
                        z: z_of_candidate(c, &tower_i, bars, &ext_dx), // ★force(c.force 透传 A6)+σ_higher+G3 ext（与生产同源）
                        trigger: trigger_dx,
                    });
                    match nest_depth {
                        Some(d) => {
                            // 区间套通过 ⟹ 所有 rung cand=true ⟹ depth=rungs.len()。
                            let depth = d.min(LMAX);
                            nest_depth_hist_pass[depth] += 1;
                            if lvl < LMAX {
                                nest_depth_by_level_pass[lvl][depth] += 1;
                            }
                        }
                        None => {
                            n_xzd_pass += 1;
                        } // 小转大通道通过（depth 直方图外计，设计 §2.3）
                    }
                    n_gate_pass_total += 1;
                    if lvl >= 1 {
                        let delta: i8 = if c.dir == VoiceSide::Long { 1 } else { -1 };
                        highlevel_hits.push((lvl, p.source_index, delta, bsp_class, rungs_len));
                    }
                }
            }

            // ── Q4（task #145）盘整背驰承接 dx 镜像（bit-exact 复制生产 collect_signals 的
            // pan_div 消费块——尾部 signals_dx vs signals_prod 逐条对拍含 PanDiv 信号）。──
            for cert in ls.pan_div.iter() {
                let side_disc = match cert.side {
                    Side::Long => 0u8,
                    Side::Short => 1u8,
                };
                if !seen_pan_dx.insert((lvl, cert.source_index, side_disc)) {
                    continue;
                }
                let sub_centers: &[Center] = if lvl > 0 {
                    &cls_i.levels[lvl - 1].centers
                } else {
                    &[]
                };
                let sub_bsp: &[BspPoint] = if lvl > 0 {
                    &cls_i.levels[lvl - 1].bsp
                } else {
                    &[]
                };
                if !pan_div_gate_pass(
                    &tower_i,
                    lvl,
                    cert,
                    &macd_hist,
                    i,
                    &ls.bsp,
                    sub_centers,
                    sub_bsp,
                    &l0_i.strokes, // ★#883
                    config.divergence_gauge,
                ) {
                    continue;
                }
                if lvl < LMAX {
                    sig_post_pan[lvl] += 1;
                } // Q4（#147）：门后记账与 push 同步
                let (dir, delta_i8): (VoiceSide, i8) = match cert.side {
                    Side::Long => (VoiceSide::Long, 1),
                    Side::Short => (VoiceSide::Short, -1),
                };
                let sigma_higher = sigma_higher_at(&tower_i, bars, lvl);
                let z = MuClass {
                    sigma_higher: Some(sigma_higher),
                    cand_channel: Some(NestTrigger::PanDivConsolidation),
                    origin_level: Some(lvl as u32),
                    ..MuClass::from_certificate(
                        lvl as u32,
                        delta_i8,
                        BspBits::default(),
                        0,
                        PositionState::Root,
                    )
                };
                signals_dx.push(RawSignal {
                    entry_bar: i,
                    dir,
                    pivot_bar: cert.source_index,
                    level: lvl as u32,
                    sigma_higher,
                    bsp_class: 0,
                    z,
                    trigger: NestTrigger::PanDivConsolidation,
                });
            }
        }
    }

    // ── 报告 ──
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# Task #7 acc-classification：level 塔中间级空洞 H1/H2/H3 判别"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "**认识论等级**：L2（真实 BTC 数据逐信号分级别计数，可产否定性结果）。"
    );
    let _ = writeln!(
        rpt,
        "**窗口**：bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}。"
    );
    let _ = writeln!(rpt, "**判别**：三路 instrument N^δ 门前后分级别计数（bit-exact 复制 decompose_capturable_spread 收集路径）。");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## 分级别计数表（cls.levels.len() 最大={levels_seen_max}）"
    );
    let _ = writeln!(rpt, "| level | tower段数 | bsp_pre(门前) | 第一类 | 第二类 | 第三类 | Γ非Flat | sig_post(门后) | 门滤除 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|");
    for l in 0..LMAX {
        if tower_segs_max[l] == 0 && bsp_pre[l] == 0 && gamma_nonflat[l] == 0 && sig_post[l] == 0 {
            continue;
        }
        let filtered = gamma_nonflat[l].saturating_sub(sig_post[l]);
        let _ = writeln!(
            rpt,
            "| {l} | {} | {} | {} | {} | {} | {} | {} | {} |",
            tower_segs_max[l],
            bsp_pre[l],
            bsp_pre_first[l],
            bsp_pre_second[l],
            bsp_pre_third[l],
            gamma_nonflat[l],
            sig_post[l],
            filtered
        );
    }
    let _ = writeln!(rpt);

    // ── 三路判别判定 ──
    let _ = writeln!(
        rpt,
        "## H1/H2/H3 判定（中间级 = level 1..levels_seen_max-1）"
    );
    let mid_hi = levels_seen_max.saturating_sub(1).min(LMAX);
    let mut any_mid_bsp = false; // 中间级门前有 bsp?
    let mut any_mid_gate_filter = false; // 中间级门前有 Γ 但门后=0?
    for l in 1..mid_hi {
        if bsp_pre[l] > 0 {
            any_mid_bsp = true;
        }
        if gamma_nonflat[l] > 0 && sig_post[l] == 0 {
            any_mid_gate_filter = true;
        }
        let _ = writeln!(
            rpt,
            "- level{l}: bsp_pre={} (一/二/三={}/{}/{}) Γ非Flat={} sig_post={} → {}",
            bsp_pre[l],
            bsp_pre_first[l],
            bsp_pre_second[l],
            bsp_pre_third[l],
            gamma_nonflat[l],
            sig_post[l],
            if bsp_pre[l] == 0 {
                "门前空(H3候选:架构)"
            } else if sig_post[l] == 0 {
                "门滤空(H1候选)"
            } else {
                "有信号"
            }
        );
    }
    let verdict = if !any_mid_bsp {
        "**H3（架构性，非运行时 bug）**：中间级 bsp_pre 全 0。注意：原「level≥1 只产第二类 B2/S2」\
             提取禁闭前提已被裁定A+#123（0a35f0167c）作废——级别≥1 现产一/二/三类；\
             此判仅意味着该窗中间级结构稀疏。**不是 N^δ 门滤空，不是全历史路径 bug**。"
    } else if any_mid_gate_filter {
        "**H1（N^δ 门滤空）**：中间级 bsp_pre>0 但门后 sig_post=0 ⟹ [J_{ℓ-1}⊆J_ℓ] 嵌套链\
             严格滤掉中间级。需 codex 异质确认（约束4）。"
    } else {
        "**中间级有信号**：与反演不符，可能 300K 窗与全历史窗差异（跨窗对比 H2 判别）。"
    };
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "### 判定：{verdict}");
    let _ = writeln!(rpt);

    // ── 结构 sanity（team-lead ③）：level≥1 通过门信号的 rung 链 ──
    let _ = writeln!(
        rpt,
        "## 结构 sanity：level≥1 通过门信号的 rung 链（team-lead ③）"
    );
    if highlevel_hits.is_empty() {
        let _ = writeln!(rpt, "- 无 level≥1 通过 N^δ 门的信号（本窗）。");
    } else {
        let _ = writeln!(
            rpt,
            "| lvl | source_index | δ | bits(u8) | rung层数(tower[lvl+1..]含src) |"
        );
        let _ = writeln!(rpt, "|---|---|---|---|---|");
        for (lvl, src, delta, bits, n_rungs) in &highlevel_hits {
            let _ = writeln!(rpt, "| {lvl} | {src} | {delta} | {bits:#04x} | {n_rungs} |");
        }
        let _ = writeln!(rpt, "\n**读解**：level_L 信号的 rung 层数 = 它上方 tower 各级含该 source_index 的段数。\
                这些是**上级语境**（N^δ 递归链），不是「该信号也算作 level_(L-1) 信号」——每个 bsp 只在\
                提取它的那个 classifier level 计一次（mod.rs 分级提取），rung 链是 N^δ 门的准入语境，非计数重复。");
    }

    // ── P1 FullNest 验收（task #22）：通过门信号的有效跨级深度分布（含 level0，bit-exact 同源）──
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## P1 FullNest 验收：通过门信号有效跨级深度分布（task #22，含 level0）"
    );
    let _ = writeln!(rpt, "**有效跨级深度** = n_delta 递归实际穿越的连续 cand=true 跨级层数（build_nest_certificate 与生产门共用构造，bit-exact）。");
    let _ = writeln!(rpt, "- depth=0 ⟹ 纯 base-case confirm_side（**退化**：等价单 bit 检查，**无区间套跨级触达**，与旧单级门弱化）。");
    let _ = writeln!(
        rpt,
        "- depth≥1 ⟹ 真跨级 [J_{{ℓ-1}}⊆J_ℓ] 触达（N^δ ≥2 层证书 e→ℓ，Q5 验收要求）。"
    );
    let _ = writeln!(rpt, "| 有效深度 | 通过门信号数 | 占比 |");
    let _ = writeln!(rpt, "|---|---|---|");
    for d in 0..=LMAX {
        if nest_depth_hist_pass[d] == 0 {
            continue;
        }
        let p = if n_gate_pass_total > 0 {
            100.0 * nest_depth_hist_pass[d] as f64 / n_gate_pass_total as f64
        } else {
            0.0
        };
        let _ = writeln!(rpt, "| {d} | {} | {p:.2}% |", nest_depth_hist_pass[d]);
    }
    let n_depth0 = nest_depth_hist_pass[0];
    let n_depth_ge1: usize = nest_depth_hist_pass[1..].iter().sum();
    let _ = writeln!(rpt, "\n**depth=0（退化 base-case）：{n_depth0}/{n_gate_pass_total}；depth≥1（真跨级触达）：{n_depth_ge1}/{n_gate_pass_total}**");
    let _ = writeln!(rpt, "\n### 逐执行级 × 深度矩阵");
    let _ = writeln!(
        rpt,
        "| exec_level | depth0 | depth1 | depth2 | depth3 | depth≥4 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for l in 0..LMAX {
        let row = &nest_depth_by_level_pass[l];
        if row.iter().sum::<usize>() == 0 {
            continue;
        }
        let ge4: usize = row[4..].iter().sum();
        let _ = writeln!(
            rpt,
            "| {l} | {} | {} | {} | {} | {} |",
            row[0], row[1], row[2], row[3], ge4
        );
    }
    let p1_verdict = if n_gate_pass_total == 0 {
        "**无信号通过门（本窗）**——无法判定触达深度。"
    } else if n_depth_ge1 == 0 {
        "**退化坐实（FullNest 未触达）**：全部通过门信号 depth=0 ⟹ N^δ 门在本窗**完全退化为 base-case confirm_side**（单 bit 方向确认），\
             **区间套跨级 [J_{ℓ-1}⊆J_ℓ] 从未被消费**。代码是真递归但有效域内 rungs 恒空——「区间套已接入」是声明膨胀（090/spec-execution-gap）。"
    } else if n_depth0 == 0 {
        "**FullNest 全触达**：全部通过门信号 depth≥1 ⟹ 每个信号都消费了跨级区间套（≥2 层证书）。"
    } else {
        "**FullNest 部分触达（混合）**：部分信号跨级（depth≥1），部分退化（depth=0）。区间套在有效域内**真触达但非全覆盖**——\
             如实标注：depth=0 那部分等价 base-case，depth≥1 那部分是真 N^δ。"
    };
    let _ = writeln!(rpt, "\n### P1 判定：{p1_verdict}");
    let _ = writeln!(rpt);
    // ── 小转大通道（task #47：**C2+C3(breakout) xzd**——level==1 硬门改为 C2∧新中枢突破，
    // level>=2 维持 #41 的 C2-only）：门通过数 = 新增可交易信号（区间套之外，输入域 Some/None 不相交）──
    let _ = writeln!(rpt, "## 小转大通道命中（**C2+C3(breakout) xzd**——codex #44 终局裁定(c)：level==1 硬门=C2∧C3新中枢突破，level>=2 维持 C2-only）");
    let _ = writeln!(rpt, "**小转大通过**：{n_xzd_pass} 条（占通过门总数 {n_gate_pass_total} 的 {:.2}%）。level==1 的通过数已隐含 C3(新中枢+突破) 硬门；level>=2 仍为 C2-only（旧 C3 same_side_same_center 字段降为诊断，不参门）。",
            if n_gate_pass_total > 0 { 100.0 * n_xzd_pass as f64 / n_gate_pass_total as f64 } else { 0.0 });
    let n_nest_pass: usize = nest_depth_hist_pass.iter().sum();
    let _ = writeln!(rpt, "- 通道分离：区间套（descend=Some，depth 直方图 {n_nest_pass} 条）与小转大（descend=None，{n_xzd_pass} 条）输入域 Some/None 互斥（codex §6-4 构造同义反复，非经验重叠）。");
    let _ = writeln!(rpt, "- **小转大域触达/C2/旧C3 分项（诊断，旧 C3=same_side_same_center 不参门）**：路由到 Xzd={n_xzd_routed}，其中 C2 成立={n_xzd_c2}，旧 C3 成立={n_xzd_c3}，门通过={n_xzd_pass}。");
    let _ = writeln!(rpt, "- **StructBreak 收紧测量（task #62，codex 终局裁决A）**：零 bit（bsp_class==0）候选中通过门={n_zerobit_gate_pass} 条（新代码下恒 0——`bsp_cand_type` 六 bit 全零恒 StructBreak ⟹ `build_gate_certificate` 恒 None，不再经旧 else=>Type3 分派误入 Nest/Xzd 通道）。");
    let _ = writeln!(rpt);

    // ── C3 死门诊断探针（codex 终局裁定 §5.4，task #41）：按 level 聚合 + lvl==1/lvl>=2 分裂断点 ──
    let _ = writeln!(rpt, "## C3 死门诊断探针（task #41，裁定 §5.4 精确规格）");
    let _ = writeln!(
        rpt,
        "| level | Xzd routed | C2 成立 | C3 成立(same_side_same_center) | C3 命中率 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|");
    for l in 0..LMAX {
        if xzd_routed_by_level[l] == 0 {
            continue;
        }
        let rate = 100.0 * xzd_c3_by_level[l] as f64 / xzd_routed_by_level[l] as f64;
        let _ = writeln!(
            rpt,
            "| {l} | {} | {} | {} | {rate:.2}% |",
            xzd_routed_by_level[l], xzd_c2_by_level[l], xzd_c3_by_level[l]
        );
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "### lvl==1 子集分裂断点（裁定 §5.4：last_zs_exists / same_side_l0_type3_any / same_center_any / same_side_causal_ok）");
    let n_l1 = xzd_routed_by_level.get(1).copied().unwrap_or(0);
    if n_l1 == 0 {
        let _ = writeln!(rpt, "- 本窗无 lvl==1 路由到 Xzd 的信号，无法裁断。");
    } else {
        let pct = |x: usize| 100.0 * x as f64 / n_l1 as f64;
        let _ = writeln!(rpt, "- lvl==1 routed={n_l1}");
        let _ = writeln!(
            rpt,
            "- last_zs_exists={} ({:.2}%)：s 跨度内存在次级中枢",
            xzd_l1_last_zs_exists,
            pct(xzd_l1_last_zs_exists)
        );
        let _ = writeln!(
            rpt,
            "- same_side_l0_type3_any={} ({:.2}%)：存在同向 L0 Type3（不问 center）",
            xzd_l1_same_side_l0_type3_any,
            pct(xzd_l1_same_side_l0_type3_any)
        );
        let _ = writeln!(
            rpt,
            "- same_center_any={} ({:.2}%)：存在任意侧 Type3 其 center==last_zs",
            xzd_l1_same_center_any,
            pct(xzd_l1_same_center_any)
        );
        let _ = writeln!(rpt, "- same_side_causal_ok={} ({:.2}%)：同向 Type3 候选中存在 source_index<=confirm_index 者（否则=时间确认问题）", xzd_l1_same_side_causal_ok, pct(xzd_l1_same_side_causal_ok));
        let n_l1_c3 = xzd_c3_by_level.get(1).copied().unwrap_or(0);
        let l1_verdict = if n_l1_c3 == 0 {
            "**level==1 也是死门（本窗实测）**：same_side_same_center=0/lvl==1 routed ⟹ C2-only 全域退化处置在本窗成立，无需分级处置。".to_string()
        } else {
            format!(
                    "**level==1 命中率显著 >0（same_side_same_center={n_l1_c3}/{n_l1}={:.2}%）**：按裁定 §边界条件，\
                     处置应翻转为分级——lvl>=2 走 C2-only、lvl==1 保留 C2∧C3 硬门，而非本次全域退化。\
                     本探针只报数，是否翻转由后续工位/编排者裁定。",
                    pct(n_l1_c3)
                )
        };
        let _ = writeln!(rpt, "- {l1_verdict}");
    }
    let _ = writeln!(rpt);

    // ── XZD C2-only 口径复审探针（task #170）：lvl>=2 子集 C3 新判据命中数 ──
    // 分母 = lvl>=2 routed（与下方死门重封同源 xzd_routed_by_level[2..]）。报数不裁断：
    // 「C2-only 保留 vs C3 硬门全 level 启用」由 codex 裁定，本探针供其量化输入。
    {
        let n_lge2_probe: usize = xzd_routed_by_level[2..].iter().sum();
        let _ = writeln!(
            rpt,
            "### XZD C2-only 复审探针（task #170）：lvl>=2 C3 新判据命中"
        );
        let _ = writeln!(
                rpt,
                "- lvl>=2 routed={n_lge2_probe}：c3_new_center_exists={xzd_lge2_c3_new_center_exists} / c3_new_center_breakout_ok={xzd_lge2_c3_new_center_breakout_ok}（不参门，codex 裁定输入）"
            );
        eprintln!("[c3-breakout-dx] lge2 routed={n_lge2_probe} new_center_exists={xzd_lge2_c3_new_center_exists} breakout_ok={xzd_lge2_c3_new_center_breakout_ok}");
    }
    let _ = writeln!(rpt);

    // ── C3 新判据命中率（task #47，codex #44(c) 终局裁定）：level==1 子集「新中枢+突破」命中率 ──
    let _ = writeln!(
        rpt,
        "### C3 新判据（新中枢+突破）level==1 命中率（task #47，codex #44 终局裁定(c)）"
    );
    if n_l1 == 0 {
        let _ = writeln!(rpt, "- 本窗无 lvl==1 路由到 Xzd 的信号，无法裁断。");
    } else {
        let pct = |x: usize| 100.0 * x as f64 / n_l1 as f64;
        let _ = writeln!(
            rpt,
            "- c3_new_center_exists={} ({:.2}%)：source_index~confirm_index 间存在新确认次级中枢",
            xzd_l1_c3_new_center_exists,
            pct(xzd_l1_c3_new_center_exists)
        );
        let _ = writeln!(rpt, "- c3_new_center_breakout_ok={} ({:.2}%)：新中枢被其后次级走势反向突破（level==1 硬门参门项）", xzd_l1_c3_new_center_breakout_ok, pct(xzd_l1_c3_new_center_breakout_ok));
        eprintln!("[c3-breakout-dx] lvl1 routed={n_l1} new_center_exists={xzd_l1_c3_new_center_exists} breakout_ok={xzd_l1_c3_new_center_breakout_ok}");

        // ── C3 L1 零命中根因判别探针报告落盘（codex #55 终局裁定(5)，task #56）──
        // 放在下方终局不变量 assert **之前**：assert 现为 `assert_eq!(breakout_ok, 0)`（#56 终局，
        // 见下），命中恒 0 时 assert **通过**不 panic；探针报告先落盘以在任何情形（含未来 rate>0
        // 触发 assert 失败）下都保留诊断证据（探针纯只读旁路，独立于终局不变量真封）。
        if overlap_probe_enabled {
            let overlap_new_center_signals =
                xzd_l1_overlap_rows.iter().filter(|r| r.2 >= 1).count();
            let overlap_hit_signals = xzd_l1_overlap_rows.iter().filter(|r| r.3 >= 1).count();
            let mut probe_rpt = String::new();
            let _ = writeln!(
                probe_rpt,
                "# C3 L1 零命中根因判别探针（codex #55 终局裁定(5)，task #56）"
            );
            let _ = writeln!(probe_rpt);
            let _ = writeln!(probe_rpt, "**认识论等级**：L2（真实 BTC 数据，逐 level==1 信号滑动重叠窗口扫描，可产否定性结果）。");
            let _ = writeln!(
                probe_rpt,
                "**窗口**：bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}。"
            );
            let _ = writeln!(probe_rpt);
            let _ = writeln!(probe_rpt, "## 结论");
            let _ = writeln!(
                probe_rpt,
                "- level==1 Xzd routed 样本数={}",
                xzd_l1_overlap_rows.len()
            );
            let _ = writeln!(
                probe_rpt,
                "- 存在 ≥1 个滑动重叠窗口 post-source 新中枢的信号数={overlap_new_center_signals}"
            );
            let _ = writeln!(probe_rpt, "- 存在 ≥1 个滑动重叠窗口新中枢被突破（overlapping_breakout_count>=1）的信号数={overlap_hit_signals}");
            let judgement = if overlap_hit_signals >= 1 {
                "**判别=候选(1)成立**：overlapping_breakout_count>=1 出现 ⟹ 推翻当前生产中枢扫描策略\
                     （非重叠三段窗口是命中率为0的算法性根因），需转向实装可表达延伸/滑动确认的新中枢，用\
                     golden digest 重验全部受影响路径（codex #55 边界条件，回 codex 复审，大动作）。"
            } else {
                "**判别=候选(2)坐实**：滑动重叠窗口下 overlapping_breakout_count 恒为 0（`overlapping_new_center_count`\
                     是否非零不改变本判别——边界条件二支均归候选(2)）⟹ 排除「非重叠窗口压掉新中枢」的算法限制假设，\
                     level==1 走势尚未确认背驰反转期间（source_index 之后）在真实数据窗口下几何上确无可反向突破的\
                     次级中枢——level==1 小转大通道在当前定义下实践关闭，不再为它改定义（codex #55 边界条件，终局）。"
            };
            let _ = writeln!(probe_rpt, "- {judgement}");
            let _ = writeln!(probe_rpt);
            let _ = writeln!(probe_rpt, "## 定义依据");
            let _ = writeln!(probe_rpt, "codex #55 终局裁定(5) 精确规格（`.chanlun/review-results/codex-decide-20260702-201450-8032.md`）：\
                    `xzd_c3_overlap_window_probe` 对 `sub_units.windows(3)` 做滑动一格扫描（非 `detect_centers_with` 的非重叠\
                    三段消费），复用同一中枢构造函数 `center_from_segments`（方向交替+全三段核心非空）+ 同一突破规则\
                    `xzd_c3_new_center_breakout`（`Side::Long⟹hi>zg` / `Side::Short⟹lo<zd`）；只统计\
                    `start_index>=source_index && end_index<=confirm_index` 的 post-source 新中枢。");
            let _ = writeln!(probe_rpt);
            let _ = writeln!(probe_rpt, "## 边界条件（codex 原文，决定本裁定是否被推翻）");
            let _ = writeln!(probe_rpt, "- 若 `overlapping_breakout_count>=1`（本窗任一信号）：推翻本判别，转候选(1)——先修 `detect_centers_with`/`center.rs` 支持延伸/重叠中枢，全受影响路径 golden digest 重验。");
            let _ = writeln!(probe_rpt, "- 若 `overlapping_new_center_count==0`，或有滑动新中枢但 `overlapping_breakout_count==0`：候选(2)坐实，终局。");
            let _ = writeln!(probe_rpt, "- 若未来权威规格把「旧中枢 source 后延伸并突破」定义为 C3：重开候选(3)（本探针不判别候选(3)，候选(3)另需形式化裁定）。");
            let _ = writeln!(probe_rpt);
            let _ = writeln!(probe_rpt, "## 下游推论");
            let _ = writeln!(probe_rpt, "#13（W-VERIFY alpha 全量重测）的最终签收阻塞到本探针结果。候选(2)坐实 ⟹ Xzd 有效通道收窄为 level>=2 的 C2-only（30 条）+ Nest 862，#13 可基于该口径解锁；候选(1)成立 ⟹ #13 继续阻塞，需先完成 center/tower 延伸中枢实装+golden digest 重验全部受影响路径。");
            let _ = writeln!(probe_rpt);
            let _ = writeln!(probe_rpt, "## 谱系引用");
            let _ = writeln!(probe_rpt, "#44（`codex-decide-20260702-193853-5bbe.md`，C3 判据从「center 精确匹配」重设计为「新中枢+突破」）、\
                    #47（`c3-breakout-impl-20260702.md`，判据实装）、678（center 对象身份分裂——本次判定不适用于新判据，见 codex #55 原文 §678 摘要）、\
                    codex #55（`codex-decide-20260702-201450-8032.md`，本探针精确规格来源+判别边界条件来源）。");
            let _ = writeln!(probe_rpt);
            let _ = writeln!(probe_rpt, "## 影响声明");
            let _ = writeln!(probe_rpt, "新增 `XzdC3OverlapProbeDiag`/`xzd_c3_overlap_window_probe`/`l0_units_from_tower`（`rust/src/theta_v0/backtest/econ_positive.rs`），\
                    纯只读旁路，默认不调用，`ECON_C3_OVERLAP_PROBE=1` 门控。不改 `gate_pass()`、不改 `Classification.levels[*].centers`、\
                    不改 `tower`、不改任何生产 `collect_signals`/正常输出 digest——仅本诊断测试内新增探针调用+独立报告落盘\
                    （`.chanlun/review-results/c3-overlap-probe-20260702.md`），不影响既有 `acc-classification-level-hole-20260701.md` 报告内容。");
            let _ = writeln!(probe_rpt);
            let _ = writeln!(
                probe_rpt,
                "## 逐信号统计表（level==1 routed={}）",
                xzd_l1_overlap_rows.len()
            );
            let _ = writeln!(probe_rpt, "| # | source_index | confirm_index | overlapping_new_center_count | overlapping_breakout_count | first_overlapping_center |");
            let _ = writeln!(probe_rpt, "|---|---|---|---|---|---|");
            for (idx, (src, confirm, new_cnt, brk_cnt, first)) in
                xzd_l1_overlap_rows.iter().enumerate()
            {
                let first_str = first
                    .map(|(s, e)| format!("({s},{e})"))
                    .unwrap_or_else(|| "—".to_string());
                let _ = writeln!(
                    probe_rpt,
                    "| {} | {src} | {confirm} | {new_cnt} | {brk_cnt} | {first_str} |",
                    idx + 1
                );
            }
            let probe_out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
                .parent()
                .expect("rust/ 父目录 = 项目根")
                .join(".chanlun/review-results/c3-overlap-probe-20260702.md");
            std::fs::write(&probe_out, &probe_rpt)
                .unwrap_or_else(|e| panic!("写探针报告失败：{e}"));
            eprintln!(
                    "\n[c3-overlap-probe] 探针报告已落盘：{probe_out:?}（routed={} new_center_signals={overlap_new_center_signals} breakout_hit_signals={overlap_hit_signals}）",
                    xzd_l1_overlap_rows.len()
                );
        }

        // ★#148 死门重封（#137 先例：锁默认窗确定性基线）。旧终局不变量 `breakout_ok == 0`
        // （codex #55 裁定(5) + #56 候选(2)：「恒 0 = 市场几何事实」）的翻转条件由其自身预设：
        // 「center/tower 延伸中枢实装」⟹ 转候选(1)。#142（§5 延伸吸收）+ #148（第33课升级重切，
        // codex-decide-20260704-001933 裁定 A1/B-II/C1/D1）正是该条件的合法触发：升级重切改变
        // canonical 中枢链（≥9 段窗口拆为每 3 段子中枢）⟹ source~confirm 间可存在新确认次级
        // 中枢（exists 0→13）且可被反向突破（breakout_ok 0→3，2026-07-04 默认窗实测）。#56
        // 候选(2) 的前提结构（无升级语义的中枢链）已合法作废——这是语义变更，非逻辑漂移。
        // 重封形式 = 锁默认窗确定性基线（同下 lvl>=2 先例：基线是窗口函数，仅默认窗断言；
        // 窗口/数据/定义变 ⟹ 重测重锁，不放宽为范围断言）。
        // ★下游口径已裁（codex #179 终裁 codex-xzd-grading-20260704）：Xzd level≥2 C2-only 口径
        // 因 C3 脱 0 曾上浮 codex 复审——终裁「条件翻转，当前维持现状」，level≥2 的 C3 硬门有效域
        // 未证（breakout_ok=1/217=0.46% 近退化单点，非结构性死门），翻转须满足终裁三条件（脱退化
        // n>=10+同量级命中率 / C3 对 lvl>=2 判别力 OOS 显著 / 排除观测口径伪影）。见 #148 下游推论。
        let _ = writeln!(rpt, "- **判据健康度（#148 重封）**：延伸+升级实装后 level==1 C3 可命中（默认窗基线 exists=13/breakout_ok=3）；基线漂移 ⟹ 硬失败重推导；Xzd C2-only 口径复审已上浮。");
        if max_bars == MAX_BARS_DEFAULT {
            assert_eq!(
                    (xzd_l1_c3_new_center_exists, xzd_l1_c3_new_center_breakout_ok),
                    (13, 3),
                    "C3 新判据 level==1 计数漂移（exists={xzd_l1_c3_new_center_exists} breakout_ok=\
                     {xzd_l1_c3_new_center_breakout_ok}，默认窗基线 13/3，#148 升级重切后 2026-07-04 实测）\
                     ——固定数据+默认窗下漂移只能来自 center/tower/C3 逻辑变更，须重推导重封（推导链见上注）。"
                );
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "### lvl>=2 死门重封（裁定A+#123：sub_bsp 可含 Type3，锁基线数值）"
    );
    let n_lge2_routed: usize = xzd_routed_by_level[2..].iter().sum();
    let _ = writeln!(
        rpt,
        "- lvl>=2 routed={n_lge2_routed}，sub_bsp Type3 点总数={xzd_lge2_sub_bsp_type3_total}"
    );
    eprintln!("[deadgate-reseal] lvl>=2 routed={n_lge2_routed} sub_bsp_type3_total={xzd_lge2_sub_bsp_type3_total}");
    // 死门重封（#137）：原前提「lvl>=2 sub_bsp 恒无 Type3（extract_second_for_level 只产 B2/S2）」
    // 已被 codex-t1 裁定A + #123（0a35f0167c，级别≥1 一/三类候选生成，三类净增 2364）合法作废。
    // 重封形式 = 锁默认窗确定性基线（BTC 冻结数据全量 4613599 bar，末 300K 窗 2025-11-04→2026-05-31，
    // 2026-07-03 实测）。基线是窗口函数 ⟹ 仅默认窗断言；窗口/数据变 ⟹ 重测重锁，不放宽为范围断言。
    if max_bars == MAX_BARS_DEFAULT {
        // Q7-#1 裁定C 重封（codex-q7-fallback-20260703，2026-07-03 实测）：fallback 单元非
        // 方向锚 ⟹ 上级一/三类收缩（一类 1057→614、type3 总数 3150→657），XZD 路由候选构成
        // 随中枢/信号结构变化 routed 75→160（codex 裁决预告「不保证单调」的实证）。
        // ★#148 重锁（2026-07-04 实测）：升级重切（第33课 ≥9 段拆子中枢，codex-decide-
        // 20260704-001933）改变 canonical 中枢链 ⟹ 全塔 BSP/路由级联变化，routed 160→217、
        // sub_bsp_type3_total 657→433——中枢变多（重切）且外缘变窄（子窗聚合）双向作用的净效应。
        assert_eq!(
                (n_lge2_routed, xzd_lge2_sub_bsp_type3_total), (217, 433),
                "lvl>=2 死门基线漂移（#148 升级重切后基线：routed=217/sub_bsp_type3_total=433）——\
                 上游 BSP 生产链（extract/hl13 级别-N 判定/Q7 锚门）或 Xzd 路由变化，需重测重锁并审计来源"
            );
        let _ = writeln!(rpt, "- **重封通过**：默认 300K 窗基线锁定 routed=217 / sub_bsp_type3_total=433（#148 升级重切后新真值，2026-07-04 测定）。");
    } else {
        let _ = writeln!(
            rpt,
            "- 非默认窗（max_bars={max_bars}），基线断言跳过（基线仅对默认 300K 窗定义）。"
        );
    }
    let _ = writeln!(rpt);

    // ── 配对后 decomps level 分布（关键：sig_post 是门后配对前，decomps 是配对后）──
    // 分水岭：若中间级 sig_post>0 但 decomps 该级=0 ⟹ 配对阶段丢失（非门滤空 H1，是右删失/跨级混合配对）。
    // ── C1（algo-opt-plan-20260702 泳道 C）：配对复用 signals_dx，省二次 O(bar²) 全量重收集。──
    // 原 decompose_capturable_spread(&ds,&config) = collect_signals(O bar²) + pair_signals(O 信号)；
    // 复用后 pair_signals 直接吃 dx 手写循环自建的 signals_dx（与生产 collect_signals 同序同门），
    // 全窗只跑一次 classify_at 收集 —— 本项 dx harness ~2x 提速来源。
    //
    // 真封退化诚实声明（no-patch）：agg_prod 改由 signals_dx 派生后，真封① sig_post_sum>=n_signals
    // 从「dx 循环 vs 独立 decompose」交叉验证退化为 dx 收集内自证。恢复交叉验证需再跑一次
    // collect_signals（O bar²）—— 与提速目标互斥。替代对拍（plan verdict 首选）：默认窗
    // （≤300K，correctness tier）跑全量 collect_signals 逐元组对拍 signals_dx，坐实 dx 手写门
    // （build_nest_certificate.n_delta）与生产门（build_multilevel_nest_cert）bit-exact 同收集；
    // 全历史基准窗（ECON_L2_MAX_BARS 放大，perf tier）跳过对拍换取 2x，收集正确性由默认窗对拍背书。
    let fee_rate =
        (config.exec.commission_bps + config.exec.slippage_bps + config.exec.tax_bps) / 10_000.0;
    if max_bars <= MAX_BARS_DEFAULT {
        let signals_prod = collect_signals(&ds, &config);
        assert_eq!(
                signals_dx, signals_prod,
                "dx 手写收集循环 ≠ 生产 collect_signals：门判定/字段漂移（n_delta vs build_multilevel_nest_cert，或 sigma_higher/bsp_class）"
            );
    }

    // ★force_state 生产热路由 fill-rate 断言（beta-route #115 step7；perm_test.rs:207-210 指明属 L2
    // 回测报告消费点，非 lib 单元层）。防「生产全 None 静默」：一类信号（i_class 含 buy1|sell1，
    // bit0|bit3）⟹ 必有 A/C 段配对（macd_c_lt_a 判据前提）⟹ z.force_state 须 Some（A4 支配序已填）。
    // 若路由断裂（增量 dif 空 / 透传丢失），一类信号 force_state 全 None ⟹ 此断言 fire。
    // δ-共线核对（memory「方向性维进桶键=检验自毁」）：force_state 由 A/C 段**绝对量**算，δ-free
    // （perm_test.rs:220 置于 base_of δ-free 键，置换 δ 时恒定）⟹ 非方向性 A4 支配序，不引入 δ-共线。
    let type1_sigs = signals_dx
        .iter()
        .filter(|s| s.z.i_class & 0b001_001 != 0)
        .count();
    let type1_forced = signals_dx
        .iter()
        .filter(|s| s.z.i_class & 0b001_001 != 0 && s.z.force_state.is_some())
        .count();
    eprintln!(
        "[force_state 生产路由] 信号总数={} 一类(buy1|sell1)={} force_state=Some={} 填充率={:.0}%",
        signals_dx.len(),
        type1_sigs,
        type1_forced,
        if type1_sigs > 0 {
            100.0 * type1_forced as f64 / type1_sigs as f64
        } else {
            0.0
        }
    );
    if type1_sigs > 0 {
        assert_eq!(
                type1_forced, type1_sigs,
                "force_state 生产热路由：每个一类信号（A/C 段可配对）z.force_state 须 Some（防增量 dif 空/透传丢失致全 None 静默）"
            );
    }
    let (decomps_prod, agg_prod) = pair_signals(&signals_dx, bars, tick, fee_rate);
    let mut decomp_by_level = [0usize; LMAX];
    for d in &decomps_prod {
        if (d.level as usize) < LMAX {
            decomp_by_level[d.level as usize] += 1;
        }
    }
    let _ = writeln!(
        rpt,
        "## 配对后 decomps level 分布（sig_post=门后配对前 vs decomps=配对后）"
    );
    let _ = writeln!(
        rpt,
        "| level | sig_post(门后Γ) | pan(承接) | decomps(配对后) | 配对丢失 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|");
    let mut any_pairing_loss_mid = false;
    for l in 0..LMAX {
        let gate_total = sig_post[l] + sig_post_pan[l]; // 门后全通道（Γ 二通道 + PanDiv 承接）
        if gate_total == 0 && decomp_by_level[l] == 0 {
            continue;
        }
        let lost = gate_total.saturating_sub(decomp_by_level[l]);
        if l >= 1 && decomp_by_level[l] == 0 && gate_total > 0 {
            any_pairing_loss_mid = true;
        }
        let _ = writeln!(
            rpt,
            "| {l} | {} | {} | {} | {} |",
            sig_post[l], sig_post_pan[l], decomp_by_level[l], lost
        );
    }
    let _ = writeln!(
        rpt,
        "\n- n_unpaired（无配对出场反转信号，右删失剔除）={}",
        agg_prod.n_unpaired
    );
    let _ = writeln!(
        rpt,
        "- **配对机制**：next_opp 表跨级别混合（所有 level 信号按 entry_bar 排序）——\
            中间级信号找「下一个反向信号」时不分级别，几乎总配 level0（信号 {}/{} 是 level0）。\
            decomp.level=入场信号 level（配对出场 level 不影响）。",
        decomp_by_level[0],
        decomps_prod.len()
    );
    if any_pairing_loss_mid {
        let _ = writeln!(rpt, "- **⚠ 配对丢失坐实**：中间级 sig_post>0 但 decomps=0 ⟹ 通过 N^δ 门的中间级信号\
                在退出配对阶段被 n_unpaired（右删失）剔除。**H1 门滤空判定被修正**——中间级空洞不仅是门滤，\
                还有配对丢失叠加（门后配对前 sig_post 已含中间级，配对后消失）。");
    }
    let _ = writeln!(rpt);

    // 落盘
    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/acc-classification-level-hole-20260701.md");
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n报告已落盘：{out:?}");

    // 真封①：分级别门后计数之和 >= n_signals（门后信号含未配对出场者）。门后全通道 =
    // sig_post（Γ 二通道）+ sig_post_pan（PanDiv 承接，#145 新入口，#147 补记账——此前漏计
    // 致 sig_post_sum < n_signals 假红）。C1 后 agg_prod 源自 signals_dx（同收集），此断言退化
    // 为收集内自证（n_signals = 其配对子集）；跨实现交叉验证由上方 max_bars≤300K 的
    // collect_signals 逐元组对拍承接（perf 窗跳过对拍，收集正确性由 correctness 窗背书）。
    let sig_post_sum: usize = sig_post.iter().sum();
    let pan_pass_sum: usize = sig_post_pan.iter().sum();
    // 收集闭合（#147 防再漂移）：每条 push 恰有一次门后计数 ⟹ 新增信号通道漏记账即红。
    assert_eq!(
        sig_post_sum + pan_pass_sum,
        signals_dx.len(),
        "门后计数和({sig_post_sum}+{pan_pass_sum}) 应 = signals_dx.len({})：信号通道记账漏计",
        signals_dx.len()
    );
    assert!(sig_post_sum + pan_pass_sum >= agg_prod.n_signals,
            "sig_post_sum({sig_post_sum})+pan({pan_pass_sum}) 应 >= n_signals({})：门后信号数含未配对出场者", agg_prod.n_signals);
    // 真封②：配对后 decomps 逐级和 = n_signals（聚合完整性）。
    let decomp_sum: usize = decomp_by_level.iter().sum();
    assert_eq!(
        decomp_sum, agg_prod.n_signals,
        "decomp 逐级和({decomp_sum}) 应 = n_signals({})",
        agg_prod.n_signals
    );
    eprintln!("真封：sig_post_sum={sig_post_sum}+pan={pan_pass_sum} >= n_signals={} = decomp_sum={decomp_sum}",
            agg_prod.n_signals);
    // 真封③（P1 FullNest + 小转大二通道）：区间套深度直方图和 + 小转大通过 = 通过门总数 = sig_post_sum
    // （build_gate_certificate 二通道 bit-exact 同源；小转大通道无区间套 depth，depth 直方图外计 n_xzd_pass）。
    let depth_hist_sum: usize = nest_depth_hist_pass.iter().sum();
    assert_eq!(depth_hist_sum + n_xzd_pass, n_gate_pass_total,
            "区间套深度直方图和({depth_hist_sum})+小转大通过({n_xzd_pass}) 应 = 通过门总数({n_gate_pass_total})");
    assert_eq!(n_gate_pass_total, sig_post_sum,
            "通过门总数({n_gate_pass_total}) 应 = sig_post_sum({sig_post_sum})（build_gate_certificate 二通道 bit-exact == 生产 collect_signals）");
    eprintln!("真封③（P1+小转大）：depth_hist_sum={depth_hist_sum}+n_xzd_pass={n_xzd_pass} = n_gate_pass_total={n_gate_pass_total} = sig_post_sum={sig_post_sum}");
    eprintln!("[structbreak-tighten] 零 bit（bsp_class==0）候选通过门={n_zerobit_gate_pass}（task #62 收紧测量）");
}

/// 阶段0 对拍（bottomup-nest task #101，PDF §二/§四/§十二问题①）：现行生产 descend（source_index
/// **点包含**）vs PDF bottom-up（`J_{k-1}⊆I(c)` **子区间包含** + Sel_Θ 作用于包含集）在真实 BTC
/// 逐信号对拍——Γ 成员（n_delta）差异计数 + 有效深度分布差异 + rung 结构差异。
///
/// **假设**（PDF §三.1）：recursive_tower Compose 是良式分解 refinement（tower[k] 边界 ⊆
/// tower[k-1] 边界），故含段唯一、Sel 平凡、点包含 ≡ 区间包含 ⟹ 二者逐信号 bit-exact，差异=0。
/// 差异=0 ⟹ 本测试即**等价固化**（NO-SHIP，生产 descend 无需改）；差异>0 ⟹ 塔非严格 refinement，
/// 须把生产改成 bottom-up（PDF §五裁决 b），届时本测试的 assert 会红，暴露分歧信号。
///
/// **认识论 L2**：真实 BTC 单标的全历史逐信号对拍，可产否定性结果（差异>0 = 现口径非最严格）。
/// `#[ignore]`：需 BTC 全量 + O(n²) 重分类，`--release`。
/// 命令：`ECON_L2_MAX_BARS=<N> cargo test --release acc_bottomup_nest_parity_probe -- --ignored --nocapture`
/// （默认 300K；全历史用 ECON_L2_MAX_BARS=5000000）。
#[test]
#[ignore]
fn acc_bottomup_nest_parity_probe() {
    use super::super::super::classifier::divergence::compute_macd;
    use super::super::super::strategy::interp::assemble_gamma_with_tower;
    use super::super::super::strategy::voice::VoiceSide;
    use super::super::super::types::Side;
    use super::super::data;
    use super::super::incremental::IncrementalClassifier;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    // #399：骨架收敛至共享 helper（mod tests 顶部），行为不变。
    let max_bars = econ_l2_max_bars();
    let ds = truncate_tail_bars(ds_full, max_bars);
    let bars = &ds.bars;
    let n = bars.len();
    let tick = config.tick.tick_size;
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[bottomup-parity] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    let closes: Vec<f64> = bars.iter().map(|b| b.close as f64 / tick as f64).collect();
    let macd_hist = compute_macd(&closes, &config.macd).hist;

    const LMAX: usize = 8;
    let mut n_cert_attempt = 0usize; // 到达 cert 构造点的候选总数（gamma 非 Flat）
    let mut n_prod_some = 0usize; // 生产 cert = Some
    let mut n_bu_some = 0usize; // bottom-up cert = Some
    let mut n_some_mismatch = 0usize; // Some/None 不一致
    let mut n_gamma_diff = 0usize; // n_delta（Γ 成员）不一致
    let mut n_depth_diff = 0usize; // effective_nest_depth 不一致（两者均 Some）
    let mut n_rungs_len_diff = 0usize; // rungs.len() 不一致
    let mut n_interval_diff = 0usize; // 任一 rung 区间/base 不一致（结构差，即便 n_delta 同）
    let mut gamma_prod = 0usize; // 生产 Γ 规模（n_delta=true）
    let mut gamma_bu = 0usize; // bottom-up Γ 规模
    let mut depth_prod = [0usize; LMAX + 1];
    let mut depth_bu = [0usize; LMAX + 1];
    // 分歧样本前 20 条（诊断用）：(bar_i, lvl, source_index, δ, prod_ndelta, bu_ndelta, prod_depth, bu_depth)
    let mut diff_samples: Vec<(usize, usize, usize, i8, bool, bool, usize, usize)> = Vec::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();
    let mut prev_bsp: Vec<Rc<Vec<BspPoint>>> = Vec::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __wl2 = classifier_incr.classify_at(i);
        let l0_i = classifier_incr
            .last_l0()
            .expect("classify_at 已推进 ParseLayer");
        let cls_i = __wl2.classification;
        let tower_i = __wl2.tower;
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if prev_bsp
                .get(lvl)
                .map_or(false, |prev| Rc::ptr_eq(prev, &ls.bsp))
            {
                continue;
            }
            if lvl < prev_bsp.len() {
                prev_bsp[lvl] = Rc::clone(&ls.bsp);
            } else {
                prev_bsp.push(Rc::clone(&ls.bsp));
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()), // Q4：dx 与生产 single 同形（无盘整背驰载荷）
                            first_class_grades: Rc::new(Vec::new()), // #885：同 pan_div 口径（single 屏蔽层无分级记录载荷）
                            level_projection: None,                  // #110 门关口径
                        })
                        .collect(),
                };
                for c in &assemble_gamma_with_tower(&single, &tower_i) {
                    let delta_side = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    n_cert_attempt += 1;
                    // 两口径 cert 构造（同一 tower/lvl/source_index/δ/bits/hist）——唯一变量是 rung 锚定口径。
                    let prod = build_nest_certificate(
                        &tower_i,
                        lvl,
                        p.source_index,
                        delta_side,
                        &p.bits,
                        &macd_hist,
                        &l0_i.strokes, // ★#883
                        config.divergence_gauge,
                    );
                    let bu = build_nest_certificate_bottomup(
                        &tower_i,
                        lvl,
                        p.source_index,
                        delta_side,
                        &p.bits,
                        &macd_hist,
                        &l0_i.strokes, // ★#883
                        config.divergence_gauge,
                    );
                    let (prod_nd, prod_depth) = match &prod {
                        Some(cert) => {
                            n_prod_some += 1;
                            (cert.n_delta(), effective_nest_depth(cert))
                        }
                        None => (false, 0),
                    };
                    let (bu_nd, bu_depth) = match &bu {
                        Some(cert) => {
                            n_bu_some += 1;
                            (cert.n_delta(), effective_nest_depth(cert))
                        }
                        None => (false, 0),
                    };
                    if prod.is_some() != bu.is_some() {
                        n_some_mismatch += 1;
                    }
                    if prod_nd {
                        gamma_prod += 1;
                    }
                    if bu_nd {
                        gamma_bu += 1;
                    }
                    if prod.is_some() {
                        depth_prod[prod_depth.min(LMAX)] += 1;
                    }
                    if bu.is_some() {
                        depth_bu[bu_depth.min(LMAX)] += 1;
                    }
                    if prod_nd != bu_nd {
                        n_gamma_diff += 1;
                    }
                    if prod.is_some() && bu.is_some() && prod_depth != bu_depth {
                        n_depth_diff += 1;
                    }
                    // 结构差：rungs.len 或任一 interval（含 base）不同。
                    if let (Some(pc), Some(bc)) = (&prod, &bu) {
                        if pc.rungs().len() != bc.rungs().len() {
                            n_rungs_len_diff += 1;
                        }
                        let struct_diff =
                            pc.base_interval() != bc.base_interval()
                                || pc.rungs().len() != bc.rungs().len()
                                || pc.rungs().iter().zip(bc.rungs().iter()).any(|(a, b)| {
                                    a.interval() != b.interval() || a.cand() != b.cand()
                                });
                        if struct_diff {
                            n_interval_diff += 1;
                        }
                    }
                    if prod_nd != bu_nd
                        || (prod.is_some() && bu.is_some() && prod_depth != bu_depth)
                    {
                        if diff_samples.len() < 20 {
                            let dl: i8 = if delta_side == Side::Long { 1 } else { -1 };
                            diff_samples.push((
                                i,
                                lvl,
                                p.source_index,
                                dl,
                                prod_nd,
                                bu_nd,
                                prod_depth,
                                bu_depth,
                            ));
                        }
                    }
                }
            }
        }
    }

    eprintln!(
        "\n════════ bottomup-nest 阶段0 对拍结果（BTC {n} bar，{win_start}→{win_end}）════════"
    );
    eprintln!("到达 cert 构造点候选数 n_cert_attempt = {n_cert_attempt}");
    eprintln!("cert=Some：生产 {n_prod_some} / bottom-up {n_bu_some}（Some/None 不一致 n_some_mismatch={n_some_mismatch}）");
    eprintln!(
        "Γ 规模（n_delta=true）：生产 gamma_prod={gamma_prod} / bottom-up gamma_bu={gamma_bu}"
    );
    eprintln!("── 差异计数（全 0 ⟹ 两口径 bit-exact 等价）──");
    eprintln!("Γ 成员差异 n_gamma_diff      = {n_gamma_diff}");
    eprintln!("有效深度差异 n_depth_diff    = {n_depth_diff}");
    eprintln!("rungs.len 差异 n_rungs_len_diff = {n_rungs_len_diff}");
    eprintln!("结构差异 n_interval_diff     = {n_interval_diff}");
    eprint!("有效深度分布（生产）：");
    for (d, c) in depth_prod.iter().enumerate() {
        if *c > 0 {
            eprint!("d{d}={c} ");
        }
    }
    eprintln!();
    eprint!("有效深度分布（bottom-up）：");
    for (d, c) in depth_bu.iter().enumerate() {
        if *c > 0 {
            eprint!("d{d}={c} ");
        }
    }
    eprintln!();
    if !diff_samples.is_empty() {
        eprintln!(
            "── 分歧样本（前 {}）(bar,lvl,src,δ,prod_nd,bu_nd,prod_depth,bu_depth) ──",
            diff_samples.len()
        );
        for s in &diff_samples {
            eprintln!("  {s:?}");
        }
    }
    eprintln!("════════════════════════════════════════════════════════════════════\n");

    // 等价固化（PDF §三.1 良式分解定位天然唯一）：差异全 0 ⟹ 生产点包含 descend ≡ PDF bottom-up
    // 区间包含 descend。此 assert 是等价的机器守卫——将来塔构造改动若破坏 refinement，本测试转红，
    // 逼出 bottom-up 实装（不静默把非严格 refinement 当等价，formalization-validity-domain L2）。
    assert_eq!(
        n_some_mismatch, 0,
        "Some/None 分歧：生产 descend 与 bottom-up 定位存在性不一致"
    );
    assert_eq!(
        n_gamma_diff, 0,
        "Γ 成员分歧：n_delta 不一致——现口径非 PDF bottom-up 等价，须实装 bottom-up"
    );
    assert_eq!(n_depth_diff, 0, "有效深度分歧：区间套跨级层数不一致");
    assert_eq!(
        n_interval_diff, 0,
        "rung 结构分歧：定位区间/cand 不一致（点包含选段 ≠ 区间包含 Sel 选段）"
    );
}

/// P0-1 验收（p01-nest-trigger task #108，codex-f2 #1/#2）：per-`NestTrigger` 桶的候选数 + μ̂
/// 质量对照——**证明「高级别背驰段前置门」只作用于 Type1，Xzd 不受一票否决**。
///
/// 「过滤前后」框架（codex #1）：若把 f1 提议的单一 bool「须有高级别背驰段」门套到**全通道**，只有
/// `Type1TrendDivergence` 存活，`Type23SublevelType1`+`XiaoZhuanDa` 被一票否决。本探针量化被否决桶的
/// 候选数与 μ̂——若这些桶 μ̂ 非负/可观，一票否决即误杀有质量信号（codex 裁决「Xzd 不受否决」的 L2 证据）。
/// **不绑 depth≥2**（codex #2：加门只减候选不制造深 rungs）。
///
/// **认识论 L2**：真实 BTC 单标的全历史，per-trigger μ̂ 含选择偏差（全窗，仅质量对照非 OOS alpha）。
/// `#[ignore]`：需 BTC 全量 + O(n²) 重分类。命令：
/// `ECON_L2_MAX_BARS=<N> cargo test --release acc_nest_trigger_quality_probe -- --ignored --nocapture`
#[test]
#[ignore]
fn acc_nest_trigger_quality_probe() {
    use super::super::data;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let _ = ds_full.bars.len(); // #399 收敛后 n_full 不再被本点消费（评审 #995 C-2 消警）
                                // #399：骨架收敛至共享 helper（mod tests 顶部），行为不变。
    let max_bars = econ_l2_max_bars();
    let ds = truncate_tail_bars(ds_full, max_bars);
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();

    let (decomps, _agg) = decompose_capturable_spread(&ds, &config);
    let total = decomps.len();

    // per-trigger 桶：(count, Σactual_pnl)。
    let mut bucket: std::collections::BTreeMap<u8, (usize, f64)> =
        std::collections::BTreeMap::new();
    let key = |t: NestTrigger| match t {
        NestTrigger::Type1TrendDivergence => 0u8,
        NestTrigger::Type23SublevelType1 => 1u8,
        NestTrigger::XiaoZhuanDa => 2u8,
        NestTrigger::PanDivConsolidation => 3u8, // Q4 #145：盘整背驰承接桶（独立归因，不并入他桶）
    };
    for d in &decomps {
        let e = bucket.entry(key(d.trigger)).or_insert((0, 0.0));
        e.0 += 1;
        e.1 += d.actual_pnl;
    }
    // 交叉校验（防 trigger 标注 bug）：直接数 decomp.bsp_class 的一类位（bit0=buy1 / bit3=sell1）。
    let first_class_n = decomps
        .iter()
        .filter(|d| d.bsp_class & (1 << 0) != 0 || d.bsp_class & (1 << 3) != 0)
        .count();
    let get = |k: u8| bucket.get(&k).copied().unwrap_or((0, 0.0));
    let (t1_n, t1_pnl) = get(0);
    let (t23_n, t23_pnl) = get(1);
    let (xzd_n, xzd_pnl) = get(2);
    let (pan_n, pan_pnl) = get(3); // Q4 #145：盘整背驰承接桶
    let mu = |n: usize, s: f64| if n > 0 { s / n as f64 } else { 0.0 };
    let vetoed_n = t23_n + xzd_n;
    let vetoed_pnl = t23_pnl + xzd_pnl;

    eprintln!("\n════════ P0-1 NestTrigger 质量对照（BTC {total} 配对信号，{win_start}→{win_end}）════════");
    eprintln!("| trigger | n | Σactual_pnl | μ̂ |");
    eprintln!(
        "| Type1TrendDivergence | {t1_n} | {t1_pnl:.4e} | {:.4e} |",
        mu(t1_n, t1_pnl)
    );
    eprintln!(
        "| Type23SublevelType1  | {t23_n} | {t23_pnl:.4e} | {:.4e} |",
        mu(t23_n, t23_pnl)
    );
    eprintln!(
        "| XiaoZhuanDa          | {xzd_n} | {xzd_pnl:.4e} | {:.4e} |",
        mu(xzd_n, xzd_pnl)
    );
    eprintln!(
        "| PanDivConsolidation  | {pan_n} | {pan_pnl:.4e} | {:.4e} |",
        mu(pan_n, pan_pnl)
    );
    eprintln!("── 过滤前后（codex #1：单一 bool 背驰门若套全通道）──");
    eprintln!("交叉校验：decomp.bsp_class 含一类位(buy1/sell1)的条数 = {first_class_n}（应≈Type1TrendDivergence 桶 n={t1_n}）");
    eprintln!("过滤前候选总数 = {total}");
    eprintln!(
        "过滤后（仅 Type1 存活）= {t1_n}；被一票否决 = {vetoed_n}（Type23 {t23_n} + Xzd {xzd_n}）"
    );
    eprintln!("被否决桶 μ̂ = {:.4e}（Σpnl={vetoed_pnl:.4e}）——非负/可观 ⟹ 一票否决误杀有质量信号（codex 裁决 Xzd 不受否决）", mu(vetoed_n, vetoed_pnl));
    eprintln!("════════════════════════════════════════════════════════════════════\n");

    // 自检（partition 不变量）：四桶计数和 = 配对信号总数（trigger 标注无遗漏无重复；Q4 #145 增 PanDiv 桶）。
    assert_eq!(
        t1_n + t23_n + xzd_n + pan_n,
        total,
        "NestTrigger 四桶未完全覆盖配对信号——trigger 标注有洞"
    );
}

/// H2 样本级验证（task #8）：level1-4 第二类信号的 N^δ 门拒绝阶段分解 + 互斥链实证。
///
/// **来源**：codex H2 裁决（`.chanlun/review-results/codex-h1-ndelta-gate-20260702.md`）的
/// L0 推导需 L2 样本级收口。codex 断言：`build_nest_certificate` 在 rung k=lvl+1 把 `Cand^δ`
/// 操作化为 `div_cand` 的 **Extreme**（Long: `s.lo<s_prev.lo`），与第二类分类前提
/// `retrace_no_break`（Long: `m2.lo>=m1.lo`）在 `s=m2 / s_prev=m1` 时结构性互斥。
/// **★#816 B-2②/#884 前提失效**：`retrace_no_break` 硬闸已拆（判据不得以「回拉不创新低/新高」
/// 为必要条件，`101:32`【正文】），该互斥链的「分类前提」一侧不再成立——本诊断的互斥链分解
/// 读数须重读：Extreme 与二类准入不再结构互斥，跌破者经 `retrace_breaks_type1` 重合标注
/// 承载（语义归 #817）。测试体保留作历史口径对照（`#[ignore]` 诊断，不进 CI 默认集）。
/// **边界条件缺口**（codex 自留）：若 B1/B2 间有多段同向子腿，`div_cand` 条件2的 `rfind` 命中
/// 比 m1 更近的 q≠m1，`m2.lo>=m1.lo`（旧分类前提）与 `m2.lo<q.lo`（Extreme）可同真，互斥链不
/// 必然成立。codex 给出**等价可测判据**：「s_prev 的低点仍高于/接近 m2 使 Extreme 必假」
/// ⟹ 直接测 rung k=lvl+1 的 Extreme 真假即等价于「s_prev 使互斥成立」。
///
/// **级别对齐（本测试的关键前提，非假设）**：level-lvl 第二类信号由 `extract_second_for_level`
/// 从 level-(lvl+1) 的 `parent`（`RMove::Compose`）产出——`m1`/`m2` 是 `descend(parent)` 的
/// **level-lvl** 次级别走势，`source_index = m2.end_index`。而 `build_nest_certificate` 的 rung
/// k=lvl+1 的 `knode` **正是**该 `parent`（`tower[lvl+1]` 中含 source_index 的段），
/// `knode.sub_moves = [m1, m2, …]`，`target_idx = i2`（m2 位置），`s = m2`。故 codex 的
/// 「s_prev vs m1」是同级别对象比较，无级别偏移。
///
/// **产出**（三 deliverable）：
/// - (a) rung k=lvl+1 到达 cond3 的信号中 **Extreme必假占比**（codex 等价 s_prev 使互斥成立）；
/// - (b) **Extreme可满足（gap）**样本（`s_prev=q≠m1` 且 m2 创新极值）的门通过/拒绝分布；
/// - (c) 结论：level1-4 100%归零是否**完全**由 cond3 互斥链解释（还是 cond1 方向/cond2 无前段/
///   base 等其他机制叠加）。
///
/// **bit-exact 铁律**：门判定用 `build_nest_certificate` + `n_delta`（与生产 `build_multilevel_nest_cert`
/// 共用构造），rung 分解的 `div_cand`/`rmove_dir` 与生产同源；cond4(Weak) 用「cond1∧2∧3 通过但
/// div_cand=false ⟹ cond4 失败」推断（不触碰私有 `segment_macd_area`）。macd_hist 与生产 econ 路径
/// 同口径（全 bar 域 close）。
///
/// **认识论 L2**：真实 BTC 全历史逐信号分解，可产否定性结果（互斥链不完全解释 ⟹ codex 裁决部分转向）。
/// `#[ignore]`：需 BTC 全量 + O(n²) 重分类，`--release`。
/// 命令：`ECON_L2_MAX_BARS=5000000 cargo test --release h2_sample_exclusion_dx -- --ignored --nocapture`
#[test]
#[ignore]
fn h2_sample_exclusion_dx() {
    use super::super::super::classifier::cand_predicate::{div_cand, rmove_dir, DivCandInput};
    use super::super::super::classifier::divergence::compute_macd;
    use super::super::super::strategy::interp::assemble_gamma_with_tower;
    use super::super::super::strategy::voice::VoiceSide;
    use super::super::super::types::{Direction, Side};
    use super::super::data;
    use super::super::incremental::IncrementalClassifier;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    // #399：骨架收敛至共享 helper（mod tests 顶部），行为不变。
    let max_bars = econ_l2_max_bars();
    let ds = truncate_tail_bars(ds_full, max_bars);
    let bars = &ds.bars;
    let n = bars.len();
    let tick = config.tick.tick_size;
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[h2-exclusion-dx] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    let closes: Vec<f64> = bars.iter().map(|b| b.close as f64 / tick as f64).collect();
    let macd_hist = compute_macd(&closes, &config.macd).hist;

    // ── 目标域：level ∈ 1..=4（acc 报告的 1473 中间级第二类信号）。 ──
    const LMIN: usize = 1;
    const LMAX: usize = 4;
    let in_scope = |lvl: usize| (LMIN..=LMAX).contains(&lvl);

    // ── 分解计数器（rung k=lvl+1 div_cand 拒绝阶段，互斥优先序 = div_cand 检查序）。 ──
    let mut n_total = 0usize; // 进入 Γ 的 level1-4 信号（每 (信号,dir) 一次，同 acc 口径）
    let mut n_by_level = [0usize; LMAX + 1]; // 各级 n_total
                                             // 拒绝阶段（当 gate=false 时归入首个失败检查）+ gate_pass。互斥穷举。
    let mut st_base_none = 0usize; // build_nest_certificate=None（tower[lvl] 无 end==src 候选段）
    let mut st_no_upper = 0usize; // rung lvl+1 无 knode（tower[lvl+1] 无含 src 段 ⟹ rungs 空，退化 base-case）
    let mut st_no_target = 0usize; // knode.sub_moves 无 end==src（target_idx 缺失）
    let mut st_cond1_dir = 0usize; // dir(s=m2) ≠ −δ（m2 方向不是背驰段要求方向）
    let mut st_cond2_noprev = 0usize; // 无同向跨界前段 s_prev（★#883 后 = D-3 取段结构失败）
    let mut st_cond3_extreme = 0usize; // ★Extreme 假（m2 未创新极值）= codex 互斥链
    let mut st_cond4_weak = 0usize; // cond1∧2∧3 通过但 div_cand=false ⟹ cond4(Weak) 失败
    let mut st_reject_elsewhere = 0usize; // rung lvl+1 div_cand=true 但 gate=false（更高 rung / is_sub / base）
    let mut st_gate_pass = 0usize; // n_delta=true（通过门）

    // ── 互斥链核心统计（cond3 到达域）。 ──
    let mut cond3_reached = 0usize; // rung lvl+1 到达 cond3（cond1∧cond2 通过）
    let mut extreme_true_pass = 0usize; // Extreme 真 ∧ gate 通过
    let mut extreme_true_reject = 0usize; // Extreme 真 ∧ gate 拒绝（cond4 或 elsewhere）= codex 缺口坐实
                                          // cond3 到达但 cert=None（落 base_none 短路，绕过 extreme 三桶）。673 号段2 landing 后新增：
                                          // Type2/3 信号下沉次级别无 Type1 锚点（小转大）⟹ build_nest_certificate 段2 门 return None（line 599），
                                          // 而 cond3_reach（tower[lvl+1] cond1∧cond2）独立成立 ⟹ 该信号在 cond3 到达域内但不入 extreme 分桶。
    let mut extreme_cert_none = 0usize;
    // cond3 到达 ∧ gate 通过 ∧ r_extreme 假：生产门 n_delta 经 base-case/其他 rung 通过，
    // 但 test 侧 lvl+1 rung 的 Extreme 假 ⟹ 落 gate_pass 但不入 extreme_true_pass（只计 cond3∧r_extreme）。
    // 与段2 正交的第二个潜在漏计（段2 前即存在，只是历史窗口未触发；段2 改门语义后暴露）。
    let mut extreme_gate_noext = 0usize;
    // 路径A 判别（塔一致性回归探针）：cond3_reach ⟹ knode.sub_moves 有 end==src ⟹ tower[lvl] 必有 end==src
    // （sub_moves 是 tower[lvl] 窗口的携坐标副本，recursive_tower 不变量）⟹ base 定位（line 580）必成功。
    // 若 base 定位失败 ⟹ 塔不一致（B4 换装/增量塔重标定引入的真回归），计入 cert_none_path_a。
    let mut cert_none_path_a = 0usize;
    let mut leg_gap_hist = [0usize; 16]; // cond3 到达域的 target_idx−j（s_prev 与 s 间距，=2 ⟹ 单条反向腿=codex 常见结构 s_prev==m1）
    let mut base_conf_false = 0usize; // confirm_side(δ) 假（δ 与 bits 侧不符 ⟹ base 拒，非互斥）

    // ── 阶段0 诊断探针（区间套问题①：端点相等 vs 区间包含 base 级定位）。 ──
    // 端点相等 find_move_by_end_index(tower[lvl],src) vs 区间包含 start≤src≤end（同一 exec_moves）。
    // false negative = 区间包含命中 ∧ 端点相等未命中（=区间套.pdf §一 3 反例的系统性表现）。
    // 若 base_false_neg=0 ⟹ 差异为零 ⟹ NO-SHIP（端点相等结论获区间包含加固，depth 归零非本口径伪影）。
    let mut base_ep_hit = 0usize; // 端点相等口径命中
    let mut base_ct_hit = 0usize; // 区间包含口径命中
    let mut base_false_neg = 0usize; // 包含命中 ∧ 端点未命中 = 问题① false negative
    let mut base_fn_by_level = [0usize; LMAX + 1];

    // 逐信号明细（前 60 条拒绝样本，spot-check）。
    let mut detail: Vec<String> = Vec::new();
    const DETAIL_CAP: usize = 60;

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __wl3 = classifier_incr.classify_at(i);
        let l0_i = classifier_incr
            .last_l0()
            .expect("classify_at 已推进 ParseLayer");
        let cls_i = __wl3.classification;
        let tower_i = __wl3.tower;
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if !in_scope(lvl) {
                continue;
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                // 只看第二类（buy2/sell2）——acc 报告 level1-4 全为第二类，防御性过滤。
                if !(p.bits.buy2 || p.bits.sell2) {
                    continue;
                }
                // Γ 组装（bit-exact 复制生产路径）。
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()), // Q4：dx 与生产 single 同形（无盘整背驰载荷）
                            first_class_grades: Rc::new(Vec::new()), // #885：同 pan_div 口径（single 屏蔽层无分级记录载荷）
                            level_projection: None,                  // #110 门关口径
                        })
                        .collect(),
                };
                for c in &assemble_gamma_with_tower(&single, &tower_i) {
                    let delta = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    let src = p.source_index;
                    n_total += 1;
                    n_by_level[lvl] += 1;
                    if !p.bits.confirm_side(delta) {
                        base_conf_false += 1;
                    }

                    // 阶段0 探针：base 级两口径对照（无条件，覆盖全信号）。
                    {
                        let exec_moves = tower_i[lvl].as_slice();
                        let ep = find_move_by_end_index(exec_moves, src).is_some();
                        let ct = exec_moves
                            .iter()
                            .any(|m| m.start_index <= src && src <= m.end_index);
                        if ep {
                            base_ep_hit += 1;
                        }
                        if ct {
                            base_ct_hit += 1;
                        }
                        if ct && !ep {
                            base_false_neg += 1;
                            base_fn_by_level[lvl] += 1;
                        }
                    }

                    // 门判定（生产同源）。
                    let cert_opt = build_nest_certificate(
                        &tower_i,
                        lvl,
                        src,
                        delta,
                        &p.bits,
                        &macd_hist,
                        &l0_i.strokes, // ★#883
                        config.divergence_gauge,
                    );
                    let gate = cert_opt.as_ref().map(|c| c.n_delta()).unwrap_or(false);

                    // rung k=lvl+1 div_cand 分解（独立于 gate，用于阶段归因 + 互斥统计）。
                    let mut r_knode = false;
                    let mut r_target = false;
                    let mut r_cond1 = false;
                    let mut r_cond2 = false;
                    let mut r_extreme = false; // cond3
                    let mut r_divcand = false; // rung lvl+1 完整 div_cand
                    let mut r_leggap = 0usize;
                    let mut s_ext = 0i64; // s 的极值（Long=lo / Short=hi），明细用
                    let mut sp_ext = 0i64; // s_prev 的极值，明细用
                    if let Some(upper) = tower_i.get(lvl + 1) {
                        if let Some(knode) = upper
                            .iter()
                            .find(|m| m.start_index <= src && src <= m.end_index)
                        {
                            r_knode = true;
                            // C3 后新形态：直读 LeveledMove（rmove_dir + rmove.lo()/hi() 惰性派生），与生产 div_cand 同源。
                            let subs = knode.sub_moves.as_slice();
                            if let Some(tidx) = subs.iter().position(|m| m.end_index == src) {
                                r_target = true;
                                let s = &subs[tidx];
                                let expected = match delta {
                                    Side::Long => Direction::Down,
                                    Side::Short => Direction::Up,
                                };
                                let s_dir = rmove_dir(&s.rmove);
                                r_cond1 = s_dir == Some(expected);
                                if r_cond1 {
                                    let s_dir = s_dir.expect("cond1 成立时方向必可判");
                                    if let Some((j, sp)) = subs[..tidx]
                                        .iter()
                                        .enumerate()
                                        .rev()
                                        .find(|(_, m)| rmove_dir(&m.rmove) == Some(s_dir))
                                    {
                                        r_cond2 = true;
                                        r_leggap = tidx - j;
                                        r_extreme = match delta {
                                            Side::Long => s.rmove.lo() < sp.rmove.lo(),
                                            Side::Short => s.rmove.hi() > sp.rmove.hi(),
                                        };
                                        s_ext = match delta {
                                            Side::Long => s.rmove.lo(),
                                            Side::Short => s.rmove.hi(),
                                        };
                                        sp_ext = match delta {
                                            Side::Long => sp.rmove.lo(),
                                            Side::Short => sp.rmove.hi(),
                                        };
                                    }
                                }
                                r_divcand = div_cand(&DivCandInput {
                                        context: subs,
                                        target_idx: tidx,
                                        hist: &macd_hist,
                                        delta,
                                        strokes: &l0_i.strokes, // ★#883
                                        parent_center: super::super::super::classifier::cand_predicate::parent_last_center(knode),
                                        gauge: config.divergence_gauge,
                                        close_src: None,
                                    });
                            }
                        }
                    }

                    let cond3_reach = r_knode && r_target && r_cond1 && r_cond2;
                    if cond3_reach {
                        cond3_reached += 1;
                        leg_gap_hist[r_leggap.min(15)] += 1;
                    }

                    // 阶段归因（互斥）。
                    let stage: &str;
                    if gate {
                        st_gate_pass += 1;
                        stage = "gate_pass";
                        if cond3_reach && r_extreme {
                            extreme_true_pass += 1;
                        } else if cond3_reach {
                            extreme_gate_noext += 1;
                        }
                    } else if cert_opt.is_none() {
                        st_base_none += 1;
                        stage = "base_none";
                        if cond3_reach {
                            extreme_cert_none += 1;
                            if find_move_by_end_index(tower_i[lvl].as_slice(), src).is_none() {
                                cert_none_path_a += 1; // base 定位失败 = 塔不一致回归
                            }
                        }
                    } else if !r_knode {
                        st_no_upper += 1;
                        stage = "no_upper";
                    } else if !r_target {
                        st_no_target += 1;
                        stage = "no_target";
                    } else if !r_cond1 {
                        st_cond1_dir += 1;
                        stage = "cond1_dir";
                    } else if !r_cond2 {
                        st_cond2_noprev += 1;
                        stage = "cond2_noprev";
                    } else if !r_extreme {
                        st_cond3_extreme += 1; // ★互斥链
                        stage = "cond3_extreme";
                    } else if !r_divcand {
                        st_cond4_weak += 1;
                        extreme_true_reject += 1; // cond3 通过（Extreme 真）但 cond4 拒
                        stage = "cond4_weak";
                    } else {
                        st_reject_elsewhere += 1;
                        extreme_true_reject += 1; // rung lvl+1 cand 真但 gate 拒（更高 rung/is_sub）
                        stage = "reject_elsewhere";
                    }

                    if stage != "gate_pass" && detail.len() < DETAIL_CAP {
                        let dbits = bsp_class;
                        detail.push(format!(
                                "| {lvl} | {src} | {} | {dbits:#04x} | {stage} | c1={} c2={} ext={} dc={} | gap={} | s={} sp={} |",
                                if delta == Side::Long { "+1" } else { "-1" },
                                r_cond1 as u8, r_cond2 as u8, r_extreme as u8, r_divcand as u8,
                                r_leggap, s_ext, sp_ext,
                            ));
                    }
                }
            }
        }
    }

    // ── 报告 ──
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# H2 样本级验证原始数据：level1-4 第二类信号 N^δ 门拒绝阶段分解"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "- task: #8（codex H2 边界条件 L2 收口）");
    let _ = writeln!(
        rpt,
        "- **认识论等级**：L2（真实 BTC 全历史逐信号分解，可产否定性结果）"
    );
    let _ = writeln!(
        rpt,
        "- **窗口**：bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );
    let _ = writeln!(
        rpt,
        "- **目标域**：level {LMIN}..={LMAX} 第二类(buy2/sell2)信号，进入 Γ 后逐信号分解"
    );
    let _ = writeln!(rpt);

    let _ = writeln!(rpt, "## 1. 信号计数（各级进入 Γ 的第二类信号数）");
    let _ = writeln!(rpt, "| level | 进入Γ信号数 |");
    let _ = writeln!(rpt, "|---|---|");
    for l in LMIN..=LMAX {
        let _ = writeln!(rpt, "| {l} | {} |", n_by_level[l]);
    }
    let _ = writeln!(rpt, "| **合计** | **{n_total}** |");
    let _ = writeln!(rpt);

    let _ = writeln!(
        rpt,
        "## 2. N^δ 门拒绝阶段分解（rung k=lvl+1 div_cand，互斥优先序）"
    );
    let _ = writeln!(rpt, "| 阶段 | 信号数 | 占比 | 含义 |");
    let _ = writeln!(rpt, "|---|---|---|---|");
    let pct = |x: usize| {
        if n_total > 0 {
            100.0 * x as f64 / n_total as f64
        } else {
            0.0
        }
    };
    let _ = writeln!(
        rpt,
        "| base_none | {} | {:.2}% | tower[lvl] 无 end==src 候选段（无定位） |",
        st_base_none,
        pct(st_base_none)
    );
    let _ = writeln!(
        rpt,
        "| no_upper | {} | {:.2}% | tower[lvl+1] 无含 src 段 ⟹ rungs 空退化 base-case |",
        st_no_upper,
        pct(st_no_upper)
    );
    let _ = writeln!(
        rpt,
        "| no_target | {} | {:.2}% | knode.sub_moves 无 end==src |",
        st_no_target,
        pct(st_no_target)
    );
    let _ = writeln!(
        rpt,
        "| cond1_dir | {} | {:.2}% | dir(m2)≠−δ（m2 非背驰段要求方向） |",
        st_cond1_dir,
        pct(st_cond1_dir)
    );
    let _ = writeln!(
        rpt,
        "| cond2_noprev | {} | {:.2}% | 无同向跨界前段 s_prev（#883 D-3 取段） |",
        st_cond2_noprev,
        pct(st_cond2_noprev)
    );
    let _ = writeln!(rpt, "| **cond3_extreme** | **{}** | **{:.2}%** | **Extreme 假（m2 未创新极值）= codex 互斥链** |", st_cond3_extreme, pct(st_cond3_extreme));
    let _ = writeln!(
        rpt,
        "| cond4_weak | {} | {:.2}% | cond1∧2∧3 过但 div_cand=false ⟹ MACD 力度未衰减 |",
        st_cond4_weak,
        pct(st_cond4_weak)
    );
    let _ = writeln!(rpt, "| reject_elsewhere | {} | {:.2}% | rung lvl+1 cand=true 但 gate=false（更高 rung/is_sub） |", st_reject_elsewhere, pct(st_reject_elsewhere));
    let _ = writeln!(
        rpt,
        "| gate_pass | {} | {:.2}% | 通过门 |",
        st_gate_pass,
        pct(st_gate_pass)
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- confirm_side(δ) 假（δ 与 bits 侧不符，base 层拒，与互斥正交）：{base_conf_false}"
    );
    let _ = writeln!(rpt);

    // ── 阶段0 诊断探针：区间套问题① base 级两口径对照 ──
    let _ = writeln!(
        rpt,
        "## 2b. 阶段0 诊断探针：区间套问题①（端点相等 vs 区间包含 base 级定位）"
    );
    let _ = writeln!(rpt, "| 口径 | 命中数 | 占比 |");
    let _ = writeln!(rpt, "|---|---|---|");
    let _ = writeln!(
        rpt,
        "| 端点相等 find_move_by_end_index(tower[lvl],src) | {base_ep_hit} | {:.2}% |",
        pct(base_ep_hit)
    );
    let _ = writeln!(
        rpt,
        "| 区间包含 start≤src≤end（同 exec_moves） | {base_ct_hit} | {:.2}% |",
        pct(base_ct_hit)
    );
    let _ = writeln!(
        rpt,
        "| **false negative（包含命中∧端点未命中）** | **{base_false_neg}** | **{:.2}%** |",
        pct(base_false_neg)
    );
    for l in LMIN..=LMAX {
        let _ = writeln!(rpt, "| ↳ level {l} FN | {} | |", base_fn_by_level[l]);
    }
    let _ = writeln!(rpt, "- **判据**：base_false_neg=0 ⟹ 两口径无差异 ⟹ **NO-SHIP**（端点相等结论获区间包含加固，depth 归零非本口径伪影，无须改生产）。");
    let _ = writeln!(rpt, "- base_false_neg>0 ⟹ 端点相等系统性漏检坐实 ⟹ 按区间套.pdf §一 4 改区间包含定位（bottom-up + Sel_Θ 唯一），重跑三件套。");
    let _ = writeln!(rpt);

    // ── deliverable (a)：Extreme必假占比（cond3 到达域）──
    let _ = writeln!(
        rpt,
        "## 3. deliverable (a)：Extreme 必假占比（codex 等价 s_prev 使互斥成立）"
    );
    let extreme_false = st_cond3_extreme; // cond3 到达且 Extreme 假 ⟹ 必然归入 cond3_extreme（全拒）
    let extreme_true = cond3_reached.saturating_sub(extreme_false);
    let ext_false_pct = if cond3_reached > 0 {
        100.0 * extreme_false as f64 / cond3_reached as f64
    } else {
        0.0
    };
    let _ = writeln!(
        rpt,
        "- 到达 cond3 的信号数（cond1∧cond2 通过）：{cond3_reached}"
    );
    let _ = writeln!(rpt, "- 其中 **Extreme 必假**（互斥成立，s_prev 使 m2 无法创新极值）：{extreme_false}（{ext_false_pct:.2}%）");
    let _ = writeln!(
        rpt,
        "- 其中 **Extreme 可满足**（m2 创新极值 vs 最近同向 s_prev=q）：{extreme_true}"
    );
    let _ = writeln!(rpt, "\n**s_prev 与 s 间距（leg_gap=target_idx−j）分布**（=2 ⟹ 单条反向腿=codex「常见结构 s_prev==m1」；>2 ⟹ 多同向腿=可能 q≠m1）：");
    let _ = writeln!(rpt, "| leg_gap | 信号数 |");
    let _ = writeln!(rpt, "|---|---|");
    for g in 0..16 {
        if leg_gap_hist[g] == 0 {
            continue;
        }
        let _ = writeln!(
            rpt,
            "| {}{} | {} |",
            if g == 15 { "≥" } else { "" },
            g,
            leg_gap_hist[g]
        );
    }
    let _ = writeln!(rpt);

    // ── deliverable (b)：Extreme 可满足（gap）样本的门分布 ──
    let _ = writeln!(
        rpt,
        "## 4. deliverable (b)：s_prev≠m1（Extreme 可满足 gap）样本的门通过/拒绝分布"
    );
    let _ = writeln!(rpt, "- Extreme 可满足样本总数：{extreme_true}");
    let _ = writeln!(rpt, "  - 门**通过**（gate_pass）：{extreme_true_pass}");
    let _ = writeln!(
        rpt,
        "  - 门**拒绝**（cond4_weak / reject_elsewhere）：{extreme_true_reject}"
    );
    let _ = writeln!(rpt, "\n**读解**：若 extreme_true=0 ⟹ 无 gap 样本，互斥链在 cond3 到达域内完全成立（Extreme 必假）。\
            若 extreme_true>0 且门拒 ⟹ 这些 gap 样本被 cond4/更高 rung/is_sub 拒（非 cond3 互斥）——\
            互斥链**不**是它们归零的原因。");
    let _ = writeln!(rpt);

    // ── deliverable (c)：100% 归零是否完全由互斥链解释 ──
    let _ = writeln!(
        rpt,
        "## 5. deliverable (c)：level1-4 100%归零是否完全由 cond3 互斥链解释"
    );
    let reject_total = n_total.saturating_sub(st_gate_pass);
    let excl_pct = if reject_total > 0 {
        100.0 * st_cond3_extreme as f64 / reject_total as f64
    } else {
        0.0
    };
    let _ = writeln!(
        rpt,
        "- 被门拒信号数：{reject_total} / {n_total}（gate_pass={st_gate_pass}）"
    );
    let _ = writeln!(
        rpt,
        "- 其中 cond3 互斥链（Extreme 必假）解释：{}（占拒绝 {excl_pct:.2}%）",
        st_cond3_extreme
    );
    let other = reject_total.saturating_sub(st_cond3_extreme);
    let _ = writeln!(
        rpt,
        "- 其他机制（base_none/no_upper/no_target/cond1/cond2/cond4/elsewhere）解释：{other}"
    );
    let verdict = if st_gate_pass > 0 {
        "**部分归零**：存在通过门的 level1-4 信号 ⟹ 与 acc「100%归零」不符（窗口差异，跨窗核对）。"
    } else if other == 0 {
        "**完全由互斥链解释**：所有拒绝都是 cond3 Extreme 必假（s_prev 使 m2 无法创新极值）——codex H2 互斥链 100% 坐实，边界缺口未实现（无 s_prev≠m1 使 Extreme 可满足的样本）。"
    } else if st_cond3_extreme == 0 {
        "**完全不由互斥链解释**：无信号止于 cond3——归零由其他机制（方向/无前段/base/更高级 rung）主导，codex 互斥链在本域不是主因。"
    } else {
        "**混合（互斥链非唯一机制）**：cond3 互斥链解释部分归零，其余由 cond1 方向/cond2 无前段/base/cond4/更高 rung 解释——codex H2 互斥链在 level1-4 **部分成立**，边界缺口（其他机制）实证存在，裁决需标注「互斥链是子集机制，非全部」。"
    };
    let _ = writeln!(rpt, "\n### 判定：{verdict}");
    let _ = writeln!(rpt);

    // ── 明细（前 {DETAIL_CAP} 条拒绝样本）──
    let _ = writeln!(
        rpt,
        "## 6. 拒绝样本明细（前 {} 条，spot-check）",
        detail.len()
    );
    let _ = writeln!(
        rpt,
        "| lvl | src | δ | bits | 阶段 | cond flags | leg_gap | s极值 s_prev极值 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|");
    for line in &detail {
        let _ = writeln!(rpt, "{line}");
    }
    let _ = writeln!(rpt);

    // 落盘（原始数据；六要素结果包由 owner 用 Write 工具单独落盘 h2-sample-verification）。
    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/h2-sample-raw-20260702.md");
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n原始数据已落盘：{out:?}");

    // ── 真封（计数不变量）──
    let stage_sum = st_base_none
        + st_no_upper
        + st_no_target
        + st_cond1_dir
        + st_cond2_noprev
        + st_cond3_extreme
        + st_cond4_weak
        + st_reject_elsewhere
        + st_gate_pass;
    assert_eq!(
        stage_sum, n_total,
        "阶段分解穷举：Σ阶段({stage_sum}) 应 = n_total({n_total})"
    );
    // 673 号段2 landing 后守恒扩展：cond3 到达域现分四桶（Extreme必假 / Extreme真通过 / Extreme真拒 /
    // cert=None 段2 小转大门拒）。旧三桶守恒（写于段2 前，隐含 cond3_reach⟹cert.is_some）已过时——
    // 段2 门（build_nest_certificate line 599）合法地对 Type2/3 小转大信号 return None，这些信号 cond3 到达
    // 但落 base_none 短路，绕过 extreme 三桶。补第四桶 extreme_cert_none 使分解重新穷举。
    assert_eq!(cert_none_path_a, 0,
            "塔一致性回归探针：cond3_reach 信号 base 定位失败 {cert_none_path_a} 例 ⟹ tower[lvl] 与 knode.sub_moves \
             不一致（B4 换装/增量塔重标定引入的真回归，非段2 小转大）。应为 0。");
    assert_eq!(
            extreme_false + extreme_true_pass + extreme_true_reject + extreme_cert_none + extreme_gate_noext,
            cond3_reached,
            "cond3 到达域守恒（五桶穷举）：Extreme必假({extreme_false})+Extreme真通过({extreme_true_pass})\
             +Extreme真拒({extreme_true_reject})+cert=None段2门拒({extreme_cert_none})\
             +gate通过∧Extreme假({extreme_gate_noext}) 应 = cond3_reached({cond3_reached})");
    eprintln!("真封：Σ阶段={stage_sum}=n_total={n_total}；cond3_reached={cond3_reached}=必假{extreme_false}+真通过{extreme_true_pass}+真拒{extreme_true_reject}+段2门拒{extreme_cert_none}+门通过Ext假{extreme_gate_noext}（path_a回归={cert_none_path_a}）");
}

/// **L2-dist（task #23）：段2 全历史 depth/小转大分布收集器**（临时 collector，非交付、不入生产路径）。
///
/// 复用 `h2_sample_exclusion_dx` 的 bit-exact classify 循环，对 level1-4 每条 Type2/3 信号
/// （per-delta `!is_type1 && (is_type2||is_type3)`）调私有 `descend_type1_anchor_depth`：
/// `DescendLocator{depth:0, ..}`（NoDivergence）=小转大（次级别无一类锚点，精确点无法下沉定位）
/// 计数；`depth≥1`=区间套下沉深度直方图。
/// 另抽样验证锚点正确性（`s.sub_moves` 中 `end_index==source_index` 段方向=−δ 回抽方向）。
///
/// 命令：`ECON_L2_MAX_BARS=100000000 cargo test --release l2_depth_distribution_dx -- --ignored --nocapture`
/// （默认 max_bars=usize::MAX ⟹ 全历史；段1 全历史先例 ≈39min）。
#[test]
#[ignore]
fn l2_depth_distribution_dx() {
    use super::super::super::classifier::cand_predicate::rmove_dir;
    use super::super::super::classifier::divergence::compute_macd;
    use super::super::super::strategy::interp::assemble_gamma_with_tower;
    use super::super::super::strategy::voice::VoiceSide;
    use super::super::super::types::{Direction, Side};
    use super::super::data;
    use super::super::incremental::IncrementalClassifier;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    let max_bars = std::env::var(crate::theta_v0::env_registry::ECON_L2_MAX_BARS)
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(usize::MAX);
    let ds = if n_full > max_bars {
        ds_full.slice_bar_range(n_full - max_bars, n_full)
    } else {
        ds_full
    };
    let bars = &ds.bars;
    let n = bars.len();
    let tick = config.tick.tick_size;
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[l2-depth-dx] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    let closes: Vec<f64> = bars.iter().map(|b| b.close as f64 / tick as f64).collect();
    let macd_hist = compute_macd(&closes, &config.macd).hist;

    const LMIN: usize = 1;
    const LMAX: usize = 4;
    const DCAP: usize = 8; // depth 直方图桶上限（level4 下沉理论 ≤4，8 留冗余）
    let in_scope = |lvl: usize| (LMIN..=LMAX).contains(&lvl);

    // Type2/3 主群（per-delta `!is_type1 && (is_type2||is_type3)`）——task 报告口径。
    let mut n_t23 = [0usize; LMAX + 1]; // 各级 Type2/3 信号总数
    let mut base_none_t23 = [0usize; LMAX + 1]; // tower[lvl] 无 end==src 候选段（descent 未触达）
    let mut xzd_t23 = [0usize; LMAX + 1]; // descend=None = 小转大（次级别无一类锚点）
    let mut depth_t23 = [[0usize; DCAP + 1]; LMAX + 1]; // descend=Some(d) 深度直方图
    let mut depth_overflow = 0usize; // d>DCAP 溢出（clamp 记录）
    let mut max_depth = 0usize;

    // 残差群（`!is_type1` 但既非 type2 也非 type3）——诚实标注：门的 descent 域比 Type2/3 略宽。
    let mut n_other = 0usize;
    let mut none_other = 0usize; // base_none + descend=None 合并
    let mut some_other = 0usize;

    // 锚点正确性抽样（Some(d) 结果的 end==src ∧ 方向=−δ）。
    const SAMPLE_CAP: usize = 200;
    let mut sample_n = 0usize;
    let mut sample_pass = 0usize;
    let mut sample_fail_detail: Vec<String> = Vec::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __wl4 = classifier_incr.classify_at(i);
        let l0_i = classifier_incr
            .last_l0()
            .expect("classify_at 已推进 ParseLayer");
        let cls_i = __wl4.classification;
        let tower_i = __wl4.tower;
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if !in_scope(lvl) {
                continue;
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                // 预过滤：至少带一个 type2/3 bit（type1-only 与无 bsp bit 信号非本群，省 Γ 组装）。
                if !(p.bits.buy2 || p.bits.sell2 || p.bits.buy3 || p.bits.sell3) {
                    continue;
                }
                // Γ 组装（bit-exact 复制生产路径）取交易方向 δ。
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()), // Q4：dx 与生产 single 同形（无盘整背驰载荷）
                            first_class_grades: Rc::new(Vec::new()), // #885：同 pan_div 口径（single 屏蔽层无分级记录载荷）
                            level_projection: None,                  // #110 门关口径
                        })
                        .collect(),
                };
                for c in &assemble_gamma_with_tower(&single, &tower_i) {
                    let delta = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    let src = p.source_index;
                    // per-delta 类型（与 build_nest_certificate 的 is_type1 同源）。
                    let is_type1 = match delta {
                        Side::Long => p.bits.buy1,
                        Side::Short => p.bits.sell1,
                    };
                    if is_type1 {
                        continue; // Type1 走本级 div_cand，不下沉——非本群
                    }
                    let is_type2 = match delta {
                        Side::Long => p.bits.buy2,
                        Side::Short => p.bits.sell2,
                    };
                    let is_type3 = match delta {
                        Side::Long => p.bits.buy3,
                        Side::Short => p.bits.sell3,
                    };
                    let is_t23 = is_type2 || is_type3;

                    // 执行级候选段 s（build_nest_certificate line 542 同逻辑）。
                    let s_opt = tower_i
                        .get(lvl)
                        .and_then(|mv| mv.iter().find(|m| m.end_index == src));
                    // descent 结果（s 缺失 ⟹ 生产门早退 None，视作 base_none）。
                    let descend = s_opt.map(|s| {
                        descend_type1_anchor_depth(
                            s,
                            src,
                            delta,
                            &macd_hist,
                            &l0_i.strokes, // ★#883
                            config.divergence_gauge,
                        )
                    });

                    if is_t23 {
                        n_t23[lvl] += 1;
                        match descend {
                            None => base_none_t23[lvl] += 1, // 无候选段
                            Some(locator) if !locator.anchored() => xzd_t23[lvl] += 1, // 小转大
                            Some(locator) => {
                                let d = locator.depth();
                                max_depth = max_depth.max(d);
                                if d > DCAP {
                                    depth_overflow += 1;
                                }
                                depth_t23[lvl][d.min(DCAP)] += 1;
                                // 抽样锚点正确性
                                if sample_n < SAMPLE_CAP {
                                    sample_n += 1;
                                    let s = s_opt.unwrap();
                                    let subs = s.sub_moves.as_slice();
                                    let tidx = subs
                                        .iter()
                                        .position(|m| m.end_index == src)
                                        .expect("anchored ⟹ 存在 end==src 锚段");
                                    let cm_dir = rmove_dir(&subs[tidx].rmove);
                                    let expected = match delta {
                                        Side::Long => Direction::Down,
                                        Side::Short => Direction::Up,
                                    };
                                    let end_ok = subs[tidx].end_index == src;
                                    let dir_ok = cm_dir == Some(expected);
                                    if end_ok && dir_ok {
                                        sample_pass += 1;
                                    } else if sample_fail_detail.len() < 20 {
                                        sample_fail_detail.push(format!(
                                                "| {lvl} | {src} | {} | end_ok={end_ok} dir_ok={dir_ok}（got {:?} exp {:?}）|",
                                                if delta == Side::Long { "+1" } else { "-1" }, cm_dir, expected));
                                    }
                                }
                            }
                        }
                    } else {
                        n_other += 1;
                        match descend {
                            Some(locator) if locator.anchored() => some_other += 1,
                            _ => none_other += 1,
                        }
                    }
                }
            }
        }
    }

    // ── 报告 ──
    let pct = |x: usize, tot: usize| {
        if tot == 0 {
            0.0
        } else {
            100.0 * x as f64 / tot as f64
        }
    };
    let tot_t23: usize = n_t23.iter().sum();
    let tot_base_none: usize = base_none_t23.iter().sum();
    let tot_xzd: usize = xzd_t23.iter().sum();
    let tot_some: usize = tot_t23 - tot_base_none - tot_xzd;

    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# L2-dist 原始数据：段2 全历史 depth/小转大分布（level1-4 Type2/3）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "- task: #23（acc-optB-l2dist）");
    let _ = writeln!(
        rpt,
        "- **认识论等级**：L2（真实 BTC 全历史逐信号结构下钻，确定性 div_cand，可产否定性计数）"
    );
    let _ = writeln!(
        rpt,
        "- 窗口：{win_start}→{win_end}，bars={n}（全量={n_full}），max_bars={max_bars}"
    );
    let _ = writeln!(rpt, "- 群定义：per-delta `!is_type1 && (is_type2||is_type3)`（Type2/3 主群，域=生产门 descent 触发域子集）");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 1. Type2/3 主群：各 level 分布");
    let _ = writeln!(
        rpt,
        "| lvl | 信号总数 | base_none(无候选段) | 小转大(descend None) | 有锚(Some d) | 小转大% |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for lvl in LMIN..=LMAX {
        let some_l = n_t23[lvl] - base_none_t23[lvl] - xzd_t23[lvl];
        let _ = writeln!(
            rpt,
            "| {lvl} | {} | {} | {} | {} | {:.2}% |",
            n_t23[lvl],
            base_none_t23[lvl],
            xzd_t23[lvl],
            some_l,
            pct(xzd_t23[lvl], n_t23[lvl])
        );
    }
    let _ = writeln!(rpt, "| **合计** | **{tot_t23}** | **{tot_base_none}** | **{tot_xzd}** | **{tot_some}** | **{:.2}%** |",
            pct(tot_xzd, tot_t23));
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## 2. depth 直方图（descend=Some(d)，逐 level × 深度）"
    );
    let _ = write!(rpt, "| lvl \\ d ");
    for d in 1..=DCAP {
        let _ = write!(rpt, "| d={d} ");
    }
    let _ = writeln!(rpt, "|");
    let _ = write!(rpt, "|---");
    for _ in 1..=DCAP {
        let _ = write!(rpt, "|---");
    }
    let _ = writeln!(rpt, "|");
    for lvl in LMIN..=LMAX {
        let _ = write!(rpt, "| {lvl} ");
        for d in 1..=DCAP {
            let _ = write!(rpt, "| {} ", depth_t23[lvl][d]);
        }
        let _ = writeln!(rpt, "|");
    }
    let _ = writeln!(
        rpt,
        "\n- max_depth 观测 = {max_depth}；depth>DCAP({DCAP}) 溢出 = {depth_overflow}"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## 3. 锚点正确性抽样（Some(d) 结果 end_index==src ∧ 方向=−δ）"
    );
    let _ = writeln!(
        rpt,
        "- 抽样数：{sample_n}（cap={SAMPLE_CAP}）；通过：{sample_pass}；失败：{}",
        sample_n - sample_pass
    );
    if !sample_fail_detail.is_empty() {
        let _ = writeln!(rpt, "\n失败明细（前 {} 条）：", sample_fail_detail.len());
        let _ = writeln!(rpt, "| lvl | src | δ | 校验 |");
        let _ = writeln!(rpt, "|---|---|---|---|");
        for line in &sample_fail_detail {
            let _ = writeln!(rpt, "{line}");
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "## 4. 残差群（`!is_type1` 但非 type2/3，门 descent 域内、本报告群外）"
    );
    let _ = writeln!(
        rpt,
        "- 总数：{n_other}；有锚(Some d)：{some_other}；无锚(None/base_none)：{none_other}"
    );
    let _ = writeln!(
        rpt,
        "- 诚实标注：生产门 descent 触发域=`!is_type1 && lvl>=1`，比 Type2/3 主群宽 {n_other} 条；"
    );
    let _ = writeln!(rpt, "  这些是 Γ 定向为非 Flat、带 δ 但该方向无 type2/3 bit 的信号（多为对侧 bit 或纯结构 voice）。");
    let _ = writeln!(rpt);

    // 落盘原始数据（六要素结果包由 owner 用 Write 单独落盘 l2-depth-distribution）。
    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/l2-depth-raw-20260702.md");
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n原始数据已落盘：{out:?}");

    // ── 真封（计数不变量）：主群逐 level 三桶穷举 = 信号总数。 ──
    for lvl in LMIN..=LMAX {
        let sum = base_none_t23[lvl]
            + xzd_t23[lvl]
            + (0..=DCAP).map(|d| depth_t23[lvl][d]).sum::<usize>();
        assert_eq!(
            sum, n_t23[lvl],
            "level{lvl} 三桶穷举：base_none+小转大+Σdepth({sum}) 应 = 信号总数({})",
            n_t23[lvl]
        );
    }
    assert_eq!(tot_base_none + tot_xzd + tot_some, tot_t23, "合计三桶穷举");
    eprintln!(
        "真封：Type2/3 主群={tot_t23}=base_none{tot_base_none}+小转大{tot_xzd}+有锚{tot_some}；\
            抽样 {sample_pass}/{sample_n} 锚点正确；残差群={n_other}"
    );
}

/// **P1 FullNest L1：effective_nest_depth 前缀语义（build_nest_certificate 与门共用构造的读数）**。
///
/// depth = 从 rungs[0]（最高级）起连续 cand=true 的层数。混合 cand 时在首个 false 处截断。
/// **认识论 L1**（合成证书结构验证，非 alpha）：验证深度读数与 n_delta 短路语义一致。
#[test]
fn effective_nest_depth_prefix_semantics() {
    use super::super::super::classifier::nest::{NestCertificate, NestInterval, NestRung};
    let mut bits = BspBits::default();
    bits.buy1 = true;
    let iv = |et: u64| NestInterval {
        end_index: et,
        start_index: 0,
        idx: 0,
    };
    // 全 cand=true 的 3 级证书 ⟹ depth=3（100⊇80⊇60，均 cand=true，且 base⊆最低 rung）。
    let cert_full = NestCertificate::from_parts(
        Side::Long,
        bits,
        iv(50),
        vec![
            NestRung::new(iv(100), true),
            NestRung::new(iv(80), true),
            NestRung::new(iv(60), true),
        ],
    );
    assert_eq!(
        effective_nest_depth(&cert_full),
        3,
        "全 cand=true ⟹ depth=rungs.len()=3"
    );
    // 空 rungs ⟹ depth=0（纯 base-case，退化）。
    let cert_base = NestCertificate::from_parts(Side::Long, bits, iv(50), vec![]);
    assert_eq!(
        effective_nest_depth(&cert_base),
        0,
        "空 rungs ⟹ depth=0（base-case 退化）"
    );
    // 中间 cand=false ⟹ 前缀在首个 false 处截断（depth=1，只数 rungs[0]）。
    let cert_mid = NestCertificate::from_parts(
        Side::Long,
        bits,
        iv(50),
        vec![
            NestRung::new(iv(100), true),
            NestRung::new(iv(80), false), // 截断处
            NestRung::new(iv(60), true),
        ],
    );
    assert_eq!(
        effective_nest_depth(&cert_mid),
        1,
        "中间 cand=false ⟹ 前缀截断 depth=1"
    );
    // 首级 cand=false ⟹ depth=0（即便有 rungs，n_delta 立即在最高级短路）。
    let cert_top_false = NestCertificate::from_parts(
        Side::Long,
        bits,
        iv(50),
        vec![NestRung::new(iv(100), false)],
    );
    assert_eq!(
        effective_nest_depth(&cert_top_false),
        0,
        "首级 cand=false ⟹ depth=0"
    );
}

// ═══════════════════════════════════════════════════════════════════════
// #846 探针：Type1 下钻逐级连续性（ADR 0013 裁定七实测）
// ═══════════════════════════════════════════════════════════════════════

/// [`descend_type1_anchor_depth`] 单步失败成因（#846 三分）。
///
/// - `EmptySubs`（A）：`sub_moves` 空 = 递归底（塔以线段为底，笔不在塔的级别阶梯内，#520
///   订正 / commit 4a8105c0ea）——**基底选择，不算断链**。
/// - `NoAlign`（B）：`sub_moves` 中既无 `end_index == source_index` 的对齐段、也无包含段——命题直接反例候选。
/// - `DivFalse(c)`（C）：对齐/包含段存在但 `div_cand` 判假，`c` = 四条件中首个不满足者（1..=4）。
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum StepFail {
    EmptySubs,
    NoAlign,
    DivFalse(u8),
}

impl StepFail {
    /// 三分桶序（0=A / 1=B / 2=C），用于计数数组下标。
    fn bucket(self) -> usize {
        match self {
            StepFail::EmptySubs => 0,
            StepFail::NoAlign => 1,
            StepFail::DivFalse(_) => 2,
        }
    }
}

/// ★#883：生产 [`div_cand_fail`] 的薄包装（探针条件归因入口）。
///
/// **parity 由构造保证**——#883 起失败分支外化进生产本体（`cand_predicate::div_cand_fail`），
/// 探针不再维护镜像体 + 对拍锁（旧 `div_cand_why` 镜像已删，`parity_violation` 计数退役）。
fn prod_div_cand_why(
    context: &[LeveledMove],
    target_idx: usize,
    hist: &[f64],
    delta: Side,
    strokes: &[crate::theta_v0::types::Stroke],
    parent_center: Option<&crate::theta_v0::types::Center>,
    gauge: super::super::super::classifier::divergence::DivergenceGauge,
) -> Option<u8> {
    super::super::super::classifier::cand_predicate::div_cand_fail(
        &super::super::super::classifier::cand_predicate::DivCandInput {
            context,
            target_idx,
            hist,
            delta,
            strokes,
            parent_center,
            gauge,
            close_src: None,
        },
    )
}

/// ★#883 验收对照臂（**诊断专用，禁入生产**）：#846 口径的旧 `div_cand` 逐字镜像——
/// 「同父前序最近同向段」取段（趋势形状，无中枢概念）+ MACD 同色面积 Weak。
///
/// 用途唯一：量化「C 桶里有多少本该算类一类点」——`legacy_fail ∧ prod_pass` 即被盘整
/// 背驰入口（#814 D-3 取段）+ ForceL 换档联合救回的量（spec #847 S4-b 验收原话「补入口
/// 前测不出来」的事后可读数）。按 ADR-0005 对照臂纪律：不产生任何交易决策，不参与准入。
fn legacy_div_cand_why(
    context: &[LeveledMove],
    target_idx: usize,
    hist: &[f64],
    delta: Side,
) -> Option<u8> {
    use super::super::super::classifier::cand_predicate::rmove_dir;
    use super::super::super::classifier::divergence::{is_divergence, segment_macd_area};
    use super::super::super::types::Direction;

    if target_idx >= context.len() {
        return Some(0);
    }
    let s = &context[target_idx];
    let Some(s_dir) = rmove_dir(&s.rmove) else {
        return Some(1);
    };
    let expected_dir = match delta {
        Side::Long => Direction::Down,
        Side::Short => Direction::Up,
    };
    if s_dir != expected_dir {
        return Some(1);
    }
    let Some(s_prev) = context[..target_idx]
        .iter()
        .rfind(|m| rmove_dir(&m.rmove) == Some(s_dir))
    else {
        return Some(2);
    };
    let extreme_ok = match delta {
        Side::Long => s.rmove.lo() < s_prev.rmove.lo(),
        Side::Short => s.rmove.hi() > s_prev.rmove.hi(),
    };
    if !extreme_ok {
        return Some(3);
    }
    // #988 同色口径：delta Side ⟹ 走势方向（cand_predicate 同款映射）。
    let dir4 = match delta {
        Side::Long => Direction::Down,
        Side::Short => Direction::Up,
    };
    let prev_area = segment_macd_area(hist, s_prev.start_index, s_prev.end_index, dir4);
    let curr_area = segment_macd_area(hist, s.start_index, s.end_index, dir4);
    if !is_divergence(prev_area, curr_area) {
        return Some(4);
    }
    None
}

/// **#846 探针：Type1 一类点区间套下钻的逐级连续性**（只读诊断，不改生产，`#[ignore]`）。
///
/// ## 验什么
///
/// ADR 0013（#839）裁定七：「某级别一类点 = 该级别走势的**结束** ⟹ 构成它的最后一个次级别
/// 走势也结束 ⟹ 那必然是次级别的一类点（趋势背驰）或类一类点（盘整背驰）。**逐级无空档。**」
///
/// 本仓从未测过。旧两组实测（`9bd0a518c9:.chanlun/review-results/l2-depth-distribution-20260702.md`
/// / `b06e5cf10d:.chanlun/review-results/l2-depth-raw-20260702.md`）只测 Type2/3（走势**中途**
/// 的位置），且只报「小转大 89.79%–91.85%」这个**合计数**——`None` 的三种成因未分。
///
/// ## 怎么测
///
/// 复用 `l2_depth_distribution_dx` 的 bit-exact classify 循环（同一批 bar / 同一 Γ 定向 / 同一
/// 塔），把它 `:7299-7301` 的 `if is_type1 { continue }` **反过来**选出 Type1 群，同时保留
/// Type2/3 群作对照。对每条信号把 [`descend_type1_anchor_depth`] 的递归**展开成可观测的循环**，
/// 逐级记录 成功 / A / B / C（见 [`StepFail`]）。
///
/// **忠实性**（真封处断言）：
/// 1. 展开循环的返回值与真 `descend_type1_anchor_depth` 逐信号对拍（`trace_mismatch==0`）。
/// 2. ~~`div_cand_why` 镜像对拍~~ ★#883 起退役：失败分支外化收编进生产本体
///    （`cand_predicate::div_cand_fail`），探针直调生产函数，parity 由构造保证。
///
/// ## 口径声明（★#883 落地后口径）
///
/// 判据 = 当前 `cand_predicate::div_cand` 四条件合取：(1) `dir(s)=−δ`；(2) **#814 D-3 统一
/// 取段**（以父走势最近中枢为界，s 自身跨界，s′=往回最近同向跨界段——首次离开=进入段／
/// 反复震荡=上次离开段，中枢内震荡段不参与）；(3) Extreme（δ=Long→`lo(s)<lo(s′)`）；
/// (4) Weak = #990 收编后统一判据原语（默认 ForceL `L(C)<L(B)` 经 #989 段→笔反查；
/// MacdArea 同色面积为对照档）。**「类一类点（盘整背驰）」的入口已由 #883 补上**——
/// 本探针（#846 系）的 C 桶读数自此反映补入口后的判据；为量化「C 桶里有多少本该算
/// 类一类点」（spec #847 S4-b 验收原话），探针并行跑 #846 旧口径对照臂
/// （`legacy_div_cand_why`，诊断专用 ADR-0005 臂），报 2×2 交叉计数
/// （`legacy假∧生产真` = 盘整入口救回量）。
///
/// ## 与生产的关系（诚实标注）
///
/// ★S4 接线后：生产 `build_nest_certificate` 的 base gate（`cand_delta_base_gate`）对
/// Type2/3 调 `descend_type1_anchor_depth`（存在性锚准入），**Type1 也走一次下钻**（定位工具，
/// 非准入——探针 #852/#870 实测 Type1 首步 DivFalse ≈92.7%，下钻结果不作门）。故本探针对
/// Type1 群测的是**命题**（下钻逐级连续性），不改变任何信号集。
///
/// **认识论 L2**（真实 BTC 逐信号结构下钻 + 确定性判据，可产否定性计数）。
///
/// 命令：`ECON_L2_MAX_BARS=100000000 cargo test --release type1_descend_continuity_dx -- --ignored --nocapture`
#[test]
#[ignore]
fn type1_descend_continuity_dx() {
    use super::super::super::classifier::cand_predicate::rmove_dir;
    use super::super::super::classifier::divergence::{compute_macd, segment_macd_area};
    use super::super::super::types::Direction;
    use super::super::data;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    let max_bars = std::env::var(crate::theta_v0::env_registry::ECON_L2_MAX_BARS)
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(usize::MAX);
    let ds = if n_full > max_bars {
        ds_full.slice_bar_range(n_full - max_bars, n_full)
    } else {
        ds_full
    };
    let bars = &ds.bars;
    let n = bars.len();
    let tick = config.tick.tick_size;
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[t1-descend-dx] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    let closes: Vec<f64> = bars.iter().map(|b| b.close as f64 / tick as f64).collect();
    let macd_hist = compute_macd(&closes, &config.macd).hist;

    // ★LMIN=0（与 l2_depth_distribution_dx 的 LMIN=1 差异）：一类点在塔里落哪一级是**待测量**，
    //   不是已知——把 level0 也收进来，否则「Type1=0 条」分不清是「没有」还是「没收」。
    //   lvl≥1 各行仍与旧两组数据同口径可比。
    const LMIN: usize = 0;
    const LMAX: usize = 4;
    const DCAP: usize = 8;
    const NG: usize = 2; // 0 = Type1 群；1 = Type2/3 群（对照）
    const NR: usize = 3; // 终止成因三桶：0=A(EmptySubs) 1=B(NoAlign) 2=C(DivFalse)
    let gname = |g: usize| if g == 0 { "Type1" } else { "Type2/3" };
    let in_scope = |lvl: usize| (LMIN..=LMAX).contains(&lvl);

    // ── BSP bit 清单（Γ 定向**之前**的原始读数，逐级）：用于分辨「群为空」的成因 ──
    let mut raw_pts = [0usize; LMAX + 1]; // 去重后的 BSP 点数
    let mut raw_bit = [[0usize; 6]; LMAX + 1]; // buy1,buy2,buy3,sell1,sell2,sell3 各自置位点数
    let mut raw_t1_pts = [0usize; LMAX + 1]; // 带 buy1|sell1 的点数
    let mut gamma_none = [0usize; LMAX + 1]; // Γ 未产出任何非 Flat 候选的点数
    let mut t1_gamma_none = [0usize; LMAX + 1]; // 带 type1 bit 但 Γ 无方向
    let mut t1_dir_mismatch = [0usize; LMAX + 1]; // 带 type1 bit、Γ 有方向但该方向无 type1 bit

    // ── 计数器 ──
    let mut n_sig = [[0usize; LMAX + 1]; NG]; // [群][信号级] 信号总数（per-delta 去重后）
    let mut base_none = [[0usize; LMAX + 1]; NG]; // tower[lvl] 无 end==src 段 ⟹ descend 未启动

    // ★#1076：锚定位「区间包含」回退计数（end== 精确匹配 MISS、包含定位 HIT——departure 终点
    // 落次级别走势内部的对齐回退例，与生产 descend_type1_anchor_depth 同源）。
    let mut align_fallback = [[0usize; LMAX + 1]; NG]; // [群][信号级] 对齐回退例数
    let mut depth_hist = [[[0usize; DCAP + 1]; LMAX + 1]; NG]; // [群][信号级][depth]
    let mut top_none = [[[0usize; NR]; LMAX + 1]; NG]; // depth==0（顶层 None）的 A/B/C
    let mut term_by_lvl = [[[0usize; NR]; LMAX + 1]; NG]; // 链**终止**成因 × 信号级
    let mut term_by_abs = [[[0usize; LMAX + 1]; NR]; NG]; // 链终止成因 × 终止绝对级别 L
    let mut step_ok = [[[0usize; LMAX + 1]; LMAX + 1]; NG]; // [群][信号级][L] L→L−1 成功步数
    let mut step_fail = [[[[0usize; NR]; LMAX + 1]; LMAX + 1]; NG]; // [群][信号级][L][成因]
    let mut cond_fail = [[0usize; 5]; NG]; // C 的条件号分布（下标 0..=4）
    let mut cond_fail_abs = [[[0usize; 5]; LMAX + 1]; NG]; // C 条件号 × 绝对级别
    let mut max_depth = [0usize; NG];
    let mut depth_overflow = 0usize;

    // 忠实性校验计数（真封断言为 0）。★#883：`parity_violation` 退役——失败分支外化已
    // 收编进生产本体（`cand_predicate::div_cand_fail`），探针直调生产函数，parity 由构造保证。
    let mut trace_mismatch = 0usize;
    let mut level_underflow = 0usize;

    // ★#883 验收计数（spec #847 S4-b：「C 桶里有多少本该算类一类点」事后可读数）。
    // 对照臂 = `legacy_div_cand_why`（#846 旧口径镜像：趋势形状取段 + MACD 面积 Weak，
    // 诊断专用 ADR-0005 对照臂）；主读数 = 生产 `div_cand_fail`（D-3 取段 + gauge 档力度）。
    let mut pan_rescue = [[0usize; LMAX + 1]; NG]; // [群][信号级] legacy 假 ∧ 生产真（盘整入口救回）
    let mut reverse_diff = [[0usize; LMAX + 1]; NG]; // legacy 真 ∧ 生产假（取段收紧/换档反向差）
    let mut both_pass = [[0usize; LMAX + 1]; NG]; // 两臂同真
    let mut both_fail = [[0usize; LMAX + 1]; NG]; // 两臂同假
    let mut n_eval = [[0usize; LMAX + 1]; NG]; // 两臂同评的下钻步数（2×2 穷举校验分母）

    // 残差群（既非 Type1 也非 Type2/3 的带 δ 信号）——诚实标注域差。
    let mut n_other = 0usize;

    // ── 断链现场取样 ──
    const PER_CELL_CAP: usize = 3; // 每 (群,成因,绝对级别) 最多留 3 例
    const TOTAL_CAP: usize = 40;
    let mut cell_used = [[[0usize; LMAX + 1]; NR]; NG];
    let mut sample_b: Vec<String> = Vec::new();
    let mut sample_c: Vec<String> = Vec::new();
    let mut sample_f: Vec<String> = Vec::new(); // ★#1076：对齐回退例逐例 dump（结构形态归类）

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __wl5 = classifier_incr.classify_at(i);
        let l0_i = classifier_incr
            .last_l0()
            .expect("classify_at 已推进 ParseLayer");
        let cls_i = __wl5.classification;
        let tower_i = __wl5.tower;
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if !in_scope(lvl) {
                continue;
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                // 预过滤：至少带一个 bsp bit（无 bit 信号两群皆非，省 Γ 组装）。
                // ★与 l2_depth_distribution_dx:7264 的差异：那里只收 type2/3 bit，这里放宽到
                //   含 type1 bit ⟹ Type1 群进入采集域；Type2/3 群的采集条件**未变**。
                if !(p.bits.buy1
                    || p.bits.sell1
                    || p.bits.buy2
                    || p.bits.sell2
                    || p.bits.buy3
                    || p.bits.sell3)
                {
                    continue;
                }
                // 原始 bit 清单（Γ 之前）。
                raw_pts[lvl] += 1;
                for (bi, on) in [
                    p.bits.buy1,
                    p.bits.buy2,
                    p.bits.buy3,
                    p.bits.sell1,
                    p.bits.sell2,
                    p.bits.sell3,
                ]
                .into_iter()
                .enumerate()
                {
                    if on {
                        raw_bit[lvl][bi] += 1;
                    }
                }
                let has_t1_bit = p.bits.buy1 || p.bits.sell1;
                if has_t1_bit {
                    raw_t1_pts[lvl] += 1;
                }
                // Γ 组装（bit-exact 复制生产路径）取交易方向 δ。
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()),
                            first_class_grades: Rc::new(Vec::new()), // #885：同 pan_div 口径（single 屏蔽层无分级记录载荷）
                            level_projection: None,
                        })
                        .collect(),
                };
                let cands = assemble_gamma_with_tower(&single, &tower_i);
                let n_dir = cands
                    .iter()
                    .filter(|c| !matches!(c.dir, VoiceSide::Flat))
                    .count();
                if n_dir == 0 {
                    gamma_none[lvl] += 1;
                    if has_t1_bit {
                        t1_gamma_none[lvl] += 1;
                    }
                } else if has_t1_bit
                    && !cands.iter().any(|c| match c.dir {
                        VoiceSide::Long => p.bits.buy1,
                        VoiceSide::Short => p.bits.sell1,
                        VoiceSide::Flat => false,
                    })
                {
                    t1_dir_mismatch[lvl] += 1;
                }
                for c in &cands {
                    let delta = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    let src = p.source_index;
                    // per-delta 类型（与 build_nest_certificate 的 is_type1 同源）。
                    let is_type1 = match delta {
                        Side::Long => p.bits.buy1,
                        Side::Short => p.bits.sell1,
                    };
                    let is_type2 = match delta {
                        Side::Long => p.bits.buy2,
                        Side::Short => p.bits.sell2,
                    };
                    let is_type3 = match delta {
                        Side::Long => p.bits.buy3,
                        Side::Short => p.bits.sell3,
                    };
                    // ★群定义：Type1 优先（与 bsp_cand_type 的 Type1>Type2>Type3 坍缩同序）。
                    let g = if is_type1 {
                        0
                    } else if is_type2 || is_type3 {
                        1
                    } else {
                        n_other += 1;
                        continue;
                    };
                    n_sig[g][lvl] += 1;

                    // 执行级候选段 s（build_nest_certificate 同逻辑，同一 production helper：
                    // ★#1052 后用「区间包含」定位——点锚迁移后 src 可能落 C 段内部）。
                    let exec_moves = match tower_i.get(lvl) {
                        Some(mv) => mv.as_slice(),
                        None => {
                            base_none[g][lvl] += 1;
                            continue;
                        }
                    };
                    let Some(si) = find_move_containing_index(exec_moves, src) else {
                        base_none[g][lvl] += 1;
                        continue;
                    };
                    let s = &exec_moves[si];

                    // ── 展开 descend_type1_anchor_depth 的递归为可观测循环 ──
                    let mut cur: &LeveledMove = s;
                    let mut cur_level = lvl;
                    let mut depth = 0usize;
                    let terminal: StepFail;
                    loop {
                        let subs = cur.sub_moves.as_slice();
                        if subs.is_empty() {
                            terminal = StepFail::EmptySubs;
                            break;
                        }
                        // ★#1076：锚定位与生产 descend 同源——end == 精确匹配 MISS 时回退「区间包含」。
                        let tidx = match find_move_by_end_index(subs, src) {
                            Some(tidx) => tidx,
                            None => match find_move_containing_index(subs, src) {
                                Some(tidx) => {
                                    align_fallback[g][lvl] += 1;
                                    // 逐例 dump（结构形态归类）：包含段方向/类型/锚偏移。
                                    if sample_f.len() < 54 {
                                        let sub = &subs[tidx];
                                        let dir_txt = match rmove_dir(&sub.rmove) {
                                            Some(Direction::Up) => "Up",
                                            Some(Direction::Down) => "Down",
                                            None => "None",
                                        };
                                        let kind_txt = if matches!(&sub.rmove, RM2::Segment { .. })
                                        {
                                            "Segment"
                                        } else {
                                            "Compose"
                                        };
                                        sample_f.push(format!(
                                                "| {lvl} | {cur_level} | {src} | {} | {} | {} | {} | [{}..{}] | {} | {} |",
                                                gname(g),
                                                dir_txt,
                                                kind_txt,
                                                subs.len(),
                                                sub.start_index,
                                                sub.end_index,
                                                src - sub.start_index,
                                                sub.end_index - src
                                            ));
                                    }
                                    tidx
                                }
                                None => {
                                    terminal = StepFail::NoAlign;
                                    break;
                                }
                            },
                        };
                        // ★#883：生产判据直调（D-3 取段的「界」= 当前父走势 cur 的最近中枢；
                        // 力度档 = config.divergence_gauge，与生产 collect_signals 同口径）。
                        let parent_center =
                            super::super::super::classifier::cand_predicate::parent_last_center(
                                cur,
                            );
                        let why = prod_div_cand_why(
                            subs,
                            tidx,
                            &macd_hist,
                            delta,
                            &l0_i.strokes,
                            parent_center,
                            config.divergence_gauge,
                        );
                        // ★#883 验收对照臂（诊断专用）：#846 旧口径同步评一次，交叉计数。
                        let legacy_why = legacy_div_cand_why(subs, tidx, &macd_hist, delta);
                        n_eval[g][lvl] += 1;
                        match (legacy_why.is_none(), why.is_none()) {
                            (true, true) => both_pass[g][lvl] += 1,
                            (true, false) => reverse_diff[g][lvl] += 1,
                            (false, true) => pan_rescue[g][lvl] += 1, // C 桶里本该算类一类点
                            (false, false) => both_fail[g][lvl] += 1,
                        }
                        if let Some(cond) = why {
                            terminal = StepFail::DivFalse(cond);
                            break;
                        }
                        // 本步成功（L → L−1）
                        step_ok[g][lvl][cur_level] += 1;
                        depth += 1;
                        cur = &subs[tidx];
                        if cur_level == 0 {
                            level_underflow += 1;
                        }
                        cur_level = cur_level.saturating_sub(1);
                    }

                    // 忠实性对拍①：展开循环 ≡ 真 descend_type1_anchor_depth。
                    let real_locator = descend_type1_anchor_depth(
                        s,
                        src,
                        delta,
                        &macd_hist,
                        &l0_i.strokes,
                        config.divergence_gauge,
                    );
                    if real_locator.depth() != depth {
                        trace_mismatch += 1;
                    }

                    let rb = terminal.bucket();
                    term_by_lvl[g][lvl][rb] += 1;
                    term_by_abs[g][rb][cur_level.min(LMAX)] += 1;
                    step_fail[g][lvl][cur_level.min(LMAX)][rb] += 1;
                    if depth == 0 {
                        top_none[g][lvl][rb] += 1;
                    }
                    max_depth[g] = max_depth[g].max(depth);
                    if depth > DCAP {
                        depth_overflow += 1;
                    }
                    depth_hist[g][lvl][depth.min(DCAP)] += 1;
                    if let StepFail::DivFalse(cond) = terminal {
                        cond_fail[g][cond as usize] += 1;
                        cond_fail_abs[g][cur_level.min(LMAX)][cond as usize] += 1;
                    }

                    // ── 断链现场取样（B / C）──
                    let want_sample = matches!(terminal, StepFail::NoAlign | StepFail::DivFalse(_))
                        && cell_used[g][rb][cur_level.min(LMAX)] < PER_CELL_CAP
                        && (sample_b.len() + sample_c.len()) < TOTAL_CAP;
                    if want_sample {
                        cell_used[g][rb][cur_level.min(LMAX)] += 1;
                        let subs = cur.sub_moves.as_slice();
                        let dsym = if delta == Side::Long { "+1" } else { "-1" };
                        match terminal {
                            StepFail::NoAlign => {
                                // 该级实际结构：段数、各段 end_index、目标 src、最近端点差。
                                let ends: Vec<String> =
                                    subs.iter().map(|m| m.end_index.to_string()).collect();
                                let nearest = subs
                                    .iter()
                                    .map(|m| ((m.end_index as i64 - src as i64).abs(), m.end_index))
                                    .min();
                                let (dist, near_end) = nearest.unwrap_or((-1, usize::MAX));
                                sample_b.push(format!(
                                        "| {} | {lvl} | {src} | {dsym} | {}→{} | {} | `[{}]` | {} | {} | parent[{}..{}] |",
                                        gname(g),
                                        cur_level,
                                        cur_level.saturating_sub(1),
                                        subs.len(),
                                        ends.join(", "),
                                        near_end,
                                        dist,
                                        cur.start_index,
                                        cur.end_index
                                    ));
                            }
                            StepFail::DivFalse(cond) => {
                                // ★#1076：与生产同源——精确匹配 MISS 时回退「区间包含」（C 类
                                // 可能经对齐回退定位，不能只按 end== 精确匹配反查）。
                                let tidx = find_move_by_end_index(subs, src)
                                    .or_else(|| find_move_containing_index(subs, src))
                                    .expect("C 类 ⟹ 对齐段/包含段存在");
                                let t = &subs[tidx];
                                let t_dir = rmove_dir(&t.rmove);
                                let expected = match delta {
                                    Side::Long => Direction::Down,
                                    Side::Short => Direction::Up,
                                };
                                let prev = t_dir.and_then(|dir| {
                                    subs[..tidx]
                                        .iter()
                                        .rfind(|m| rmove_dir(&m.rmove) == Some(dir))
                                });
                                let prev_txt = match prev {
                                    Some(pv) => format!(
                                        "idx?<{tidx} lo={} hi={} area={:.4} [{}..{}]",
                                        pv.rmove.lo(),
                                        pv.rmove.hi(),
                                        segment_macd_area(
                                            &macd_hist,
                                            pv.start_index,
                                            pv.end_index,
                                            t_dir.unwrap_or(Direction::Up)
                                        ),
                                        pv.start_index,
                                        pv.end_index
                                    ),
                                    None => "（无同向跨界前段）".to_string(),
                                };
                                sample_c.push(format!(
                                        "| {} | {lvl} | {src} | {dsym} | {}→{} | cond{cond} | segs={} tidx={tidx} | dir={:?}(exp {:?}) | lo={} hi={} area={:.4} | prev: {} |",
                                        gname(g),
                                        cur_level,
                                        cur_level.saturating_sub(1),
                                        subs.len(),
                                        t_dir,
                                        expected,
                                        t.rmove.lo(),
                                        t.rmove.hi(),
                                        segment_macd_area(
                                            &macd_hist,
                                            t.start_index,
                                            t.end_index,
                                            t_dir.unwrap_or(Direction::Up)
                                        ),
                                        prev_txt
                                    ));
                            }
                            StepFail::EmptySubs => unreachable!("已由 want_sample 排除"),
                        }
                    }
                }
            }
        }
    }

    // ══ 报告 ══
    let pct = |x: usize, tot: usize| {
        if tot == 0 {
            0.0
        } else {
            100.0 * x as f64 / tot as f64
        }
    };
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# #846 原始数据：Type1 一类点区间套下钻的逐级连续性（A/B/C 三分）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "- issue: #846（ADR 0013 裁定七实测；#839 裁定）");
    let _ = writeln!(
        rpt,
        "- **认识论 L2**（真实 BTC 逐信号结构下钻，确定性 div_cand，可产否定性计数）"
    );
    let _ = writeln!(
        rpt,
        "- 窗口：{win_start}→{win_end}，bars={n}（全量={n_full}），max_bars={max_bars}"
    );
    let _ = writeln!(rpt, "- 群定义（per-delta，Type1 优先坍缩）：Type1 = `buy1|sell1` 置位；Type2/3 = 非 Type1 且 `buy2|sell2|buy3|sell3` 置位");
    let _ = writeln!(rpt, "- 判据口径：`cand_predicate::div_cand` 四条件（1 方向 / 2 前序同向段 / 3 Extreme / 4 Weak=MACD 段面积严格减）");
    let _ = writeln!(rpt, "- 三分：**A**=`sub_moves` 空（递归底=L0，基底选择，**不算断链**，#520）；**B**=无 `end_index==src` 对齐段；**C**=对齐但 `div_cand` 假");
    let _ = writeln!(
        rpt,
        "- 级别记号 `L→L−1`：在**级 L 走势的 `sub_moves`（=级 L−1 序列）**上做的那一步；失败记在 L"
    );
    let _ = writeln!(rpt);

    // 0. BSP bit 清单（Γ 之前）——分辨「群为空」的成因
    let _ = writeln!(rpt, "## 0. BSP bit 清单（Γ 定向**之前**的原始读数）");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| lvl | 去重BSP点数 | buy1 | buy2 | buy3 | sell1 | sell2 | sell3 | 带type1 bit | 其中Γ无方向 | 其中Γ方向对不上 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|---|");
    for lvl in LMIN..=LMAX {
        let _ = writeln!(
            rpt,
            "| {lvl} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} |",
            raw_pts[lvl],
            raw_bit[lvl][0],
            raw_bit[lvl][1],
            raw_bit[lvl][2],
            raw_bit[lvl][3],
            raw_bit[lvl][4],
            raw_bit[lvl][5],
            raw_t1_pts[lvl],
            t1_gamma_none[lvl],
            t1_dir_mismatch[lvl]
        );
    }
    let _ = writeln!(
        rpt,
        "\n- Γ 完全无方向（全 Flat）的点数逐级：{:?}",
        &gamma_none[LMIN..=LMAX]
    );
    let _ = writeln!(rpt, "- 判读：`带type1 bit` = 0 ⟹ 该级根本不产一类点（塔/识别层事实）；\
            `其中Γ无方向`/`方向对不上` > 0 ⟹ 一类点存在但被 Γ 定向环节滤掉（探针域问题，非命题否证）。");
    let _ = writeln!(rpt);

    // 1. 逐级命中率
    let _ = writeln!(rpt, "## 1. 逐级命中率（每步 成功/A/B/C）");
    let _ = writeln!(rpt);
    for g in 0..NG {
        let _ = writeln!(rpt, "### 1.{} {} 群", g + 1, gname(g));
        let _ = writeln!(rpt, "| 信号级 lvl | 步 L→L−1 | 到达该步 | 成功 | A(空subs) | B(无对齐) | C(div假) | 成功% |");
        let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|");
        for lvl in LMIN..=LMAX {
            for l in (0..=lvl).rev() {
                let ok = step_ok[g][lvl][l];
                let fa = step_fail[g][lvl][l][0];
                let fb = step_fail[g][lvl][l][1];
                let fc = step_fail[g][lvl][l][2];
                let reach = ok + fa + fb + fc;
                if reach == 0 {
                    continue;
                }
                let _ = writeln!(
                    rpt,
                    "| {lvl} | {l}→{} | {reach} | {ok} | {fa} | {fb} | {fc} | {:.2}% |",
                    l.saturating_sub(1),
                    pct(ok, reach)
                );
            }
        }
        let _ = writeln!(rpt);
    }

    // 2. 顶层 A/B/C（= 旧报告「小转大」合计数的三分拆）
    let _ = writeln!(
        rpt,
        "## 2. 顶层 `None`（depth==0）的 A/B/C 三分——旧「小转大」合计数的拆分"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 群 | lvl | 信号总数 | base_none(塔无 end==src 段) | 顶层None合计 | A | B | C | 有锚 Some(d) | 顶层None% |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        let mut t_n = 0usize;
        let mut t_bn = 0usize;
        let mut t_a = 0usize;
        let mut t_b = 0usize;
        let mut t_c = 0usize;
        for lvl in LMIN..=LMAX {
            let (a, b, cc) = (
                top_none[g][lvl][0],
                top_none[g][lvl][1],
                top_none[g][lvl][2],
            );
            let none_tot = a + b + cc;
            let some_l = n_sig[g][lvl] - base_none[g][lvl] - none_tot;
            let _ = writeln!(
                rpt,
                "| {} | {lvl} | {} | {} | {none_tot} | {a} | {b} | {cc} | {some_l} | {:.2}% |",
                gname(g),
                n_sig[g][lvl],
                base_none[g][lvl],
                pct(none_tot, n_sig[g][lvl])
            );
            t_n += n_sig[g][lvl];
            t_bn += base_none[g][lvl];
            t_a += a;
            t_b += b;
            t_c += cc;
        }
        let t_none = t_a + t_b + t_c;
        let _ = writeln!(
                rpt,
                "| **{}合计** | — | **{t_n}** | **{t_bn}** | **{t_none}** | **{t_a}** | **{t_b}** | **{t_c}** | **{}** | **{:.2}%** |",
                gname(g),
                t_n - t_bn - t_none,
                pct(t_none, t_n)
            );
    }
    let _ = writeln!(rpt);

    // 3. 断链级别分布
    let _ = writeln!(
        rpt,
        "## 3. 断链级别分布（链**终止**成因，含 depth>0 的链尾）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "### 3.1 按信号级切");
    let _ = writeln!(
        rpt,
        "| 群 | 信号级 lvl | 终止=A | 终止=B | 终止=C | 合计链数 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            let (a, b, cc) = (
                term_by_lvl[g][lvl][0],
                term_by_lvl[g][lvl][1],
                term_by_lvl[g][lvl][2],
            );
            if a + b + cc == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {} | {lvl} | {a} | {b} | {cc} | {} |",
                gname(g),
                a + b + cc
            );
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "### 3.2 按绝对级别切（链在级 L 上终止）");
    let _ = writeln!(rpt, "| 群 | 绝对级 L | 终止=A | 终止=B | 终止=C |");
    let _ = writeln!(rpt, "|---|---|---|---|---|");
    for g in 0..NG {
        for l in 0..=LMAX {
            let (a, b, cc) = (
                term_by_abs[g][0][l],
                term_by_abs[g][1][l],
                term_by_abs[g][2][l],
            );
            if a + b + cc == 0 {
                continue;
            }
            let _ = writeln!(rpt, "| {} | {l} | {a} | {b} | {cc} |", gname(g));
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "### 3.3 C 类的失败条件号分布（div_cand 四条件中首个不满足者）"
    );
    let _ = writeln!(rpt, "| 群 | cond0(越界) | cond1(方向≠−δ) | cond2(D-3 取段失败) | cond3(Extreme 假) | cond4(Weak 假) |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for g in 0..NG {
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {} | {} | {} |",
            gname(g),
            cond_fail[g][0],
            cond_fail[g][1],
            cond_fail[g][2],
            cond_fail[g][3],
            cond_fail[g][4]
        );
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "### 3.4 C 类条件号 × 绝对级别");
    let _ = writeln!(
        rpt,
        "| 群 | 绝对级 L | cond0 | cond1 | cond2 | cond3 | cond4 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
    for g in 0..NG {
        for l in 0..=LMAX {
            let row = cond_fail_abs[g][l];
            if row.iter().sum::<usize>() == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {} | {l} | {} | {} | {} | {} | {} |",
                gname(g),
                row[0],
                row[1],
                row[2],
                row[3],
                row[4]
            );
        }
    }
    let _ = writeln!(rpt);

    // 4. 深度分布
    let _ = writeln!(rpt, "## 4. 深度分布（成功钻了几层；depth==0 即顶层 None）");
    let _ = writeln!(rpt);
    let _ = write!(rpt, "| 群 | lvl ");
    for d in 0..=DCAP {
        let _ = write!(rpt, "| d={d} ");
    }
    let _ = writeln!(rpt, "|");
    let _ = write!(rpt, "|---|---");
    for _ in 0..=DCAP {
        let _ = write!(rpt, "|---");
    }
    let _ = writeln!(rpt, "|");
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            let _ = write!(rpt, "| {} | {lvl} ", gname(g));
            for d in 0..=DCAP {
                let _ = write!(rpt, "| {} ", depth_hist[g][lvl][d]);
            }
            let _ = writeln!(rpt, "|");
        }
    }
    let _ = writeln!(
        rpt,
        "\n- max_depth：Type1={}，Type2/3={}；depth>DCAP({DCAP}) 溢出={depth_overflow}",
        max_depth[0], max_depth[1]
    );
    let _ = writeln!(rpt);

    // 5. 断链现场取样
    let _ = writeln!(
        rpt,
        "## 5. 断链现场取样（每 (群,成因,级别) ≤{PER_CELL_CAP} 例，总 ≤{TOTAL_CAP}）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "### 5.1 B 类（无 `end_index==src` 对齐段）：{} 例",
        sample_b.len()
    );
    if sample_b.is_empty() {
        let _ = writeln!(rpt, "\n**（空——B 类未出现或未取到样）**");
    } else {
        let _ = writeln!(
            rpt,
            "| 群 | 信号级 | src | δ | 步 | 该级段数 | 各段 end_index | 最近 end | 差 | 父段区间 |"
        );
        let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|");
        for l in &sample_b {
            let _ = writeln!(rpt, "{l}");
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "### 5.2 C 类（对齐/包含段存在，`div_cand` 判假）：{} 例",
        sample_c.len()
    );
    if sample_c.is_empty() {
        let _ = writeln!(rpt, "\n**（空——C 类未出现或未取到样）**");
    } else {
        let _ = writeln!(rpt, "| 群 | 信号级 | src | δ | 步 | 失败条件 | 该级结构 | 目标段方向 | 目标段 lo/hi/area | 前序同向段 |");
        let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|");
        for l in &sample_c {
            let _ = writeln!(rpt, "{l}");
        }
    }
    let _ = writeln!(rpt);
    // ★#1076：对齐回退例（departure 终点落次级别走势内部，end== 精确匹配 MISS ⟹ 区间包含定位）。
    let _ = writeln!(
        rpt,
        "### 5.3 对齐回退例（#1076，锚不落边界 ⟹ 区间包含定位）：{} 例",
        sample_f.len()
    );
    if sample_f.is_empty() {
        let _ = writeln!(rpt, "\n**（空——无对齐回退例）**");
    } else {
        let _ = writeln!(rpt, "| 信号级 | 当前级 | src | 群 | 包含段方向 | 包含段类型 | 该级段数 | 包含段区间 | 离起点 | 离终点 |");
        let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|");
        for l in &sample_f {
            let _ = writeln!(rpt, "{l}");
        }
    }
    let _ = writeln!(rpt);

    // 6. 忠实性 + 域外声明
    let _ = writeln!(rpt, "## 6. 忠实性校验与域外声明");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- 展开循环 ≡ `descend_type1_anchor_depth` 对拍不一致：**{trace_mismatch}**（须 0）"
    );
    let _ = writeln!(
            rpt,
            "- ★#883：`div_cand_why` 镜像已退役（失败分支收编进生产 `div_cand_fail`，parity 由构造保证）"
        );
    // ★#883 验收读数（spec #847 S4-b：「C 桶里有多少本该算类一类点」）。
    let _ = writeln!(
        rpt,
        "
## ★#883 验收：盘整入口救回量（#846 旧口径对照臂 × 生产新判据）
"
    );
    let _ = writeln!(
            rpt,
            "| 群 | 信号级 | 评估步数 | 同真 | **legacy假∧生产真（本该算类一类点）** | legacy真∧生产假 | 同假 |"
        );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            if n_eval[g][lvl] == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {} | {lvl} | {} | {} | **{}** | {} | {} |",
                gname(g),
                n_eval[g][lvl],
                both_pass[g][lvl],
                pan_rescue[g][lvl],
                reverse_diff[g][lvl],
                both_fail[g][lvl]
            );
        }
    }
    let _ = writeln!(
            rpt,
            "
口径：legacy = #846 旧判据镜像（趋势形状取段 + MACD 面积 Weak，诊断对照臂）；生产 = #883 后判据（#814 D-3 统一取段 + config.divergence_gauge 力度档，默认 ForceL）。「legacy假∧生产真」即 C 桶里本该算类一类点的下钻步数（盘整入口救回）；「legacy真∧生产假」是取段收紧（震荡段除名/无中枢不判）与 ForceL 换档的反向差，照实并列。"
        );
    let _ = writeln!(
        rpt,
        "- 级别下溢（cur_level==0 仍成功下钻一步）：**{level_underflow}**"
    );
    let _ = writeln!(
        rpt,
        "- 残差群（带 δ 但无任何 bsp bit 命中该方向）：{n_other} 条，两群皆不计"
    );
    let _ = writeln!(rpt, "- 生产关系：`build_nest_certificate:1019` 的 base gate 只对 Type2/3 调下钻；Type1 群的读数是**命题测量**，非生产现行行为");
    let _ = writeln!(rpt);

    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/issue846-type1-descend-continuity-raw.md");
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n原始数据已落盘：{out:?}");

    // ── 真封（穷举 + 忠实性）──
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            let sum = base_none[g][lvl] + (0..=DCAP).map(|d| depth_hist[g][lvl][d]).sum::<usize>();
            assert_eq!(
                sum,
                n_sig[g][lvl],
                "{} lvl{lvl} 穷举：base_none+Σdepth({sum}) 应 = 信号总数({})",
                gname(g),
                n_sig[g][lvl]
            );
            let term_sum: usize = term_by_lvl[g][lvl].iter().sum();
            assert_eq!(
                term_sum,
                n_sig[g][lvl] - base_none[g][lvl],
                "{} lvl{lvl} 终止成因穷举：ΣA/B/C({term_sum}) 应 = 启动下钻的链数",
                gname(g)
            );
        }
    }
    // ★#883：验收 2×2 穷举（每评估步必落且仅落一格）。
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            assert_eq!(
                both_pass[g][lvl] + both_fail[g][lvl] + pan_rescue[g][lvl] + reverse_diff[g][lvl],
                n_eval[g][lvl],
                "#883 验收 2×2 穷举：{} lvl{lvl} 四格合计应 = 评估步数",
                gname(g)
            );
        }
    }
    assert_eq!(
        trace_mismatch, 0,
        "展开循环与 descend_type1_anchor_depth 返回不一致 {trace_mismatch} 次 ⟹ 探针失真，读数作废"
    );
    eprintln!(
            "真封：Type1 群={} 条（base_none={}，对齐回退={}），Type2/3 群={} 条（base_none={}，对齐回退={}）；trace={trace_mismatch}；#883 验收：pan_rescue={} reverse_diff={}",
            n_sig[0].iter().sum::<usize>(),
            base_none[0].iter().sum::<usize>(),
            align_fallback[0].iter().sum::<usize>(),
            n_sig[1].iter().sum::<usize>(),
            base_none[1].iter().sum::<usize>(),
            align_fallback[1].iter().sum::<usize>(),
            pan_rescue.iter().map(|r| r.iter().sum::<usize>()).sum::<usize>(),
            reverse_diff.iter().map(|r| r.iter().sum::<usize>()).sum::<usize>()
        );
}

// ═══════════════════════════════════════════════════════════════════════
// #1034 反事实探针：下钻对齐键改窗口极值 bar / departure 终点，重测方向桶
// ═══════════════════════════════════════════════════════════════════════

/// 按「包含 bar」定位子走势（替代 `end_index` 精确匹配）——`moves` 按 `end_index` 升序
/// （塔不变量，同 [`find_move_by_end_index`] 前提）⟹ `partition_point` 二分。
fn find_move_by_span(moves: &[LeveledMove], bar: usize) -> Option<usize> {
    let i = moves.partition_point(|m| m.end_index < bar);
    (i < moves.len() && moves[i].start_index <= bar).then_some(i)
}

/// #1034 反事实对齐键①：窗口极值 bar（背驰极值）。
///
/// 在 `cur` 的 K 序跨度 `[start_index, end_index]` 内取极值 bar：δ=Long → 最低 `low`；
/// δ=Short → 最高 `high`。平局取最早（`tail.rs:177` 同口径）。`bars` 下标 == `source_index`
/// （L0 原始 K 序；`Dataset::slice_bar_range` 截窗后重编号为 `0..bars.len()`，塔坐标同系）。
fn window_extreme_bar(bars: &[Bar], cur: &LeveledMove, delta: Side) -> Option<usize> {
    let (lo, hi) = (cur.start_index, cur.end_index);
    if lo > hi || hi >= bars.len() {
        return None;
    }
    let mut best: Option<(usize, i64)> = None;
    for i in lo..=hi {
        let v = match delta {
            Side::Long => bars[i].low,
            Side::Short => bars[i].high,
        };
        let better = match best {
            None => true,
            Some((_, bv)) => match delta {
                Side::Long => v < bv,
                Side::Short => v > bv,
            },
        };
        if better {
            best = Some((i, v));
        }
    }
    best.map(|(i, _)| i)
}

/// #1034 反事实对齐键②：departure 单元终点。
///
/// departure 单元 = `cur.sub_moves` 中 δ 同侧趋势方向的子走势（δ=Long → Down；δ=Short →
/// Up），即「离开中枢」的走势方向；取**最后一个**（最近一次同趋势离开）的 `end_index`。
/// 无趋势方向子走势 ⟹ None（诚实无键，不伪造）。
fn departure_unit_end(cur: &LeveledMove, delta: Side) -> Option<usize> {
    use super::super::super::classifier::cand_predicate::rmove_dir;
    use super::super::super::types::Direction;
    let trend = match delta {
        Side::Long => Direction::Down,
        Side::Short => Direction::Up,
    };
    cur.sub_moves
        .iter()
        .rev()
        .find_map(|m| (rmove_dir(&m.rmove) == Some(trend)).then_some(m.end_index))
}

/// **#1034 反事实探针：Type1 下钻首步 cond1（方向）桶的对齐键对照**（只读诊断，`#[ignore]`）。
///
/// ## 验什么
///
/// #870 cond1-research H1：一类点 `source_index` = 中枢窗口 `end_index`（回抽段终点，
/// `recursive_tower.rs` compose `end_index = subs.last().end_index` + Step3 non-extension
/// `c.end_index = units[j].end_index`）⟹ 下钻对齐（`find_move_by_end_index(subs, src)`）
/// 恒取窗口末段（反趋势回抽段）⟹ cond1 方向失败（#870 二轮 62%）是**锚点错位**。
///
/// ## 怎么测
///
/// 在 `type1_descend_continuity_dx` 旁新增**对照臂**（不删原臂）：对齐键替换为
/// ① 窗口极值 bar（背驰极值，δ 侧价格极值）② departure 单元终点（δ 侧趋势方向子走势终点），
/// 重跑 Type1 `lvl≥1` 首步 cond1 桶，报三臂方向失败率 + 成功 20 例对照。纯测量：
/// 只比 `rmove_dir(target) == −δ`（= `div_cand` 条件1），**不触碰生产判据、不跑 cond2/3/4**。
///
/// **范围**：只测**首步**（L→L−1 第一步）——H1 的锚点错位在首步即发生，且 #870 二轮
/// 92.7% 链在首步终止；更深步对齐是后续事。
///
/// **认识论 L2**（真实 BTC 逐信号结构 + 确定性判据，可产否定性计数）。
///
/// 命令：`ECON_L2_MAX_BARS=100000000 cargo test --release type1_cond1_alignment_counterfactual_dx -- --ignored --nocapture`
#[test]
#[ignore]
fn type1_cond1_alignment_counterfactual_dx() {
    use super::super::super::classifier::cand_predicate::rmove_dir;
    use super::super::super::types::Direction;
    use super::super::data;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    let max_bars = econ_l2_max_bars();
    let ds = truncate_tail_bars(ds_full, max_bars);
    let bars = &ds.bars;
    let n = bars.len();
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[t1-cond1-align-dx] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    // Type1 归类测量的有效域：lvl≥1（L0 是递归底，不进归类测量——同 #846/#870 口径）。
    const LMIN: usize = 1;
    const LMAX: usize = 4;
    // 三臂：0=原臂(source_index) 1=窗口极值 bar 2=departure 终点。
    const NARM: usize = 3;
    let arm_name = |a: usize| match a {
        0 => "原臂(source_index)",
        1 => "窗口极值bar",
        2 => "departure终点",
        _ => unreachable!(),
    };

    let mut n_sig = 0usize; // Type1 lvl≥1 信号数（per-delta，去重后；含 base_none）
    let mut base_none = 0usize; // tower[lvl] 无 end==src 段 ⟹ 下钻未启动
    let mut key_none = [0usize; NARM]; // 键算不出（extreme/departure 臂；原臂恒 0）
    let mut noalign = [0usize; NARM]; // 键有但取不到目标子走势（B 类；防御计数）
    let mut dir_pass = [0usize; NARM];
    let mut dir_fail = [0usize; NARM];
    // 原臂 cond1 失败桶 → 两反事实臂的翻转计数。
    let mut flip = [[0usize; 2]; 2]; // [臂 1|2][pass|fail]（只对 orig 失败信号计）

    // 成功 20 例对照：原臂方向失败 ∧ 任一反事实臂方向通过。
    const SAMPLE_CAP: usize = 20;
    let mut sample: Vec<String> = Vec::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __wl6 = classifier_incr.classify_at(i);
        let cls_i = __wl6.classification;
        let tower_i = __wl6.tower;
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if !(LMIN..=LMAX).contains(&lvl) {
                continue;
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                if !(p.bits.buy1 || p.bits.sell1) {
                    continue;
                }
                // Γ 组装（bit-exact 复制生产路径，同 type1_descend_continuity_dx）取交易方向 δ。
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl { vec![*p] } else { Vec::new() }),
                            pan_div: Rc::new(Vec::new()),
                            first_class_grades: Rc::new(Vec::new()),
                            level_projection: None,
                        })
                        .collect(),
                };
                let cands = assemble_gamma_with_tower(&single, &tower_i);
                for c in &cands {
                    let delta = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    let is_type1 = match delta {
                        Side::Long => p.bits.buy1,
                        Side::Short => p.bits.sell1,
                    };
                    if !is_type1 {
                        continue;
                    }
                    let src = p.source_index;
                    n_sig += 1;

                    let exec_moves = match tower_i.get(lvl) {
                        Some(mv) => mv.as_slice(),
                        None => {
                            base_none += 1;
                            continue;
                        }
                    };
                    let Some(si) = find_move_containing_index(exec_moves, src) else {
                        base_none += 1;
                        continue;
                    };
                    let s = &exec_moves[si];
                    let subs = s.sub_moves.as_slice();
                    let expected = match delta {
                        Side::Long => Direction::Down,
                        Side::Short => Direction::Up,
                    };

                    // 三臂的键 + 目标子走势。
                    let keys = [
                        Some(src),                          // 原臂：source_index
                        window_extreme_bar(bars, s, delta), // ① 窗口极值 bar
                        departure_unit_end(s, delta),       // ② departure 单元终点
                    ];
                    // 原臂与生产 descend 同源：end == 精确匹配，MISS 回退「区间包含」（#1076 对齐回退）；
                    // 反事实臂用「包含」匹配。
                    let targets: [Option<usize>; NARM] = [
                        find_move_by_end_index(subs, src)
                            .or_else(|| find_move_containing_index(subs, src)),
                        keys[1].and_then(|k| find_move_by_span(subs, k)),
                        keys[2].and_then(|k| find_move_by_span(subs, k)),
                    ];

                    let mut verdict = [0u8; NARM]; // 0=未评估（无键/无对齐） 2=方向通过 3=方向失败
                    for a in 0..NARM {
                        if keys[a].is_none() {
                            key_none[a] += 1;
                            continue;
                        }
                        let Some(tidx) = targets[a] else {
                            noalign[a] += 1;
                            continue;
                        };
                        let dir_ok = rmove_dir(&subs[tidx].rmove) == Some(expected);
                        if dir_ok {
                            dir_pass[a] += 1;
                            verdict[a] = 2;
                        } else {
                            dir_fail[a] += 1;
                            verdict[a] = 3;
                        }
                    }

                    // 原臂 cond1 失败桶 → 两反事实臂翻转计数。
                    if verdict[0] == 3 {
                        for a in 1..NARM {
                            match verdict[a] {
                                2 => flip[a - 1][0] += 1,
                                3 => flip[a - 1][1] += 1,
                                _ => {}
                            }
                        }
                    }

                    // 成功 20 例对照：原臂失败 ∧ 至少一反事实臂通过。
                    if verdict[0] == 3
                        && (verdict[1] == 2 || verdict[2] == 2)
                        && sample.len() < SAMPLE_CAP
                    {
                        let dsym = if delta == Side::Long { "+1" } else { "-1" };
                        let fmt_dir = |d: Option<Direction>| match d {
                            Some(Direction::Up) => "Up",
                            Some(Direction::Down) => "Down",
                            None => "None",
                        };
                        let fmt_arm = |a: usize| match targets[a] {
                            Some(tidx) => {
                                format!("idx={tidx} dir={}", fmt_dir(rmove_dir(&subs[tidx].rmove)))
                            }
                            None => "（无对齐）".to_string(),
                        };
                        sample.push(format!(
                            "| {lvl} | {src} | {dsym} | {} | {} → {} | {} → {} | {} |",
                            subs.len(),
                            keys[1].map_or("None".to_string(), |k| k.to_string()),
                            fmt_arm(1),
                            keys[2].map_or("None".to_string(), |k| k.to_string()),
                            fmt_arm(2),
                            fmt_arm(0)
                        ));
                    }
                }
            }
        }
    }

    let pct = |x: usize, tot: usize| {
        if tot == 0 {
            0.0
        } else {
            100.0 * x as f64 / tot as f64
        }
    };
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# #1034 原始数据：Type1 下钻首步 cond1（方向）桶的对齐键反事实对照"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- issue: #1034（#870 cond1-research H1 反事实探针；纯测量，不改生产判据）"
    );
    let _ = writeln!(
        rpt,
        "- **认识论 L2**（真实 BTC 逐信号结构下钻，确定性方向判据）"
    );
    let _ = writeln!(
        rpt,
        "- 窗口：{win_start}→{win_end}，bars={n}（全量={n_full}），max_bars={max_bars}"
    );
    let _ = writeln!(rpt, "- 范围：Type1 `lvl≥1` **首步**（L→L−1）；方向判据 = `rmove_dir(target) == −δ`（= `div_cand` 条件1）");
    let _ = writeln!(rpt, "- 三臂：0 原臂(source_index) / 1 窗口极值 bar（δ 侧价格极值） / 2 departure 单元终点（δ 侧趋势方向子走势末段）");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "## 1. 三臂方向读数（首步）");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| 臂 | 键缺失 | 无对齐 | 方向通过 | 方向失败 | 评估数 | 方向失败率 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
    for a in 0..NARM {
        let eval = dir_pass[a] + dir_fail[a];
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {} | {} | {eval} | {:.2}% |",
            arm_name(a),
            key_none[a],
            noalign[a],
            dir_pass[a],
            dir_fail[a],
            pct(dir_fail[a], eval)
        );
    }
    let _ = writeln!(
            rpt,
            "\n- Type1 lvl≥1 信号数（per-delta 去重后）：{n_sig}；base_none（塔无 end==src 段）：{base_none}。"
        );
    let _ = writeln!(rpt);

    let _ = writeln!(rpt, "## 2. 原臂 cond1 失败桶 → 两反事实臂翻转");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| 反事实臂 | 原失败中方向通过 | 原失败中仍失败 | 通过率 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|");
    for (a, row) in flip.iter().enumerate() {
        let tot = row[0] + row[1];
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {:.2}% |",
            arm_name(a + 1),
            row[0],
            row[1],
            pct(row[0], tot)
        );
    }
    let _ = writeln!(rpt);

    let _ = writeln!(
        rpt,
        "## 3. 成功 20 例对照（原臂方向失败 ∧ 至少一反事实臂方向通过）：{} 例",
        sample.len()
    );
    let _ = writeln!(rpt);
    if sample.is_empty() {
        let _ = writeln!(rpt, "\n**（空——无翻转例）**");
    } else {
        let _ = writeln!(rpt, "| 信号级 | src | δ | 段数 | ①极值bar→目标(idx,dir) | ②departure终点→目标(idx,dir) | 原臂目标(idx,dir) |");
        let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
        for l in &sample {
            let _ = writeln!(rpt, "{l}");
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
            rpt,
            "口径：① 窗口极值 bar = δ 侧价格极值所在 bar（δ=Long 最低 low / δ=Short 最高 high，平局取最早）；\
             ② departure 单元终点 = 最后一个 δ 侧趋势方向子走势的 end_index；\
             目标子走势按「包含键 bar」定位（原臂按 end_index 精确匹配，与生产同口径）。\
             方向失败 = `rmove_dir(target)` 非 Some(−δ)（含 None，与 `div_cand` 条件1 同口径）。"
        );
    let _ = writeln!(rpt);

    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/issue1034-cond1-alignment-counterfactual-raw.md");
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n原始数据已落盘：{out:?}");

    // ── 真封（穷举 + 键/对齐/方向三格穷举）──
    let measured = n_sig - base_none;
    for a in 0..NARM {
        assert_eq!(
            key_none[a] + noalign[a] + dir_pass[a] + dir_fail[a],
            measured,
            "臂 {} 穷举：键缺失+无对齐+通过+失败 应 = 启动下钻的信号数 {measured}",
            arm_name(a)
        );
    }
    assert_eq!(
        key_none[0] + noalign[0],
        0,
        "原臂 source_index 键恒有且塔不变量保证首步对齐（base_none 已另计）——B 类应恒 0"
    );
    eprintln!(
            "真封：Type1 lvl≥1={n_sig} 条（base_none={base_none}）；原臂方向失败={}；①极值臂方向失败={}；②departure臂方向失败={}",
            dir_fail[0], dir_fail[1], dir_fail[2]
        );
}

// ── #1034 反事实对齐键 helper 的合成单测（不依赖真实数据，锁定义）──

/// `find_move_by_span`：按「包含 bar」定位子走势（含端点归属与越界）。
#[test]
fn find_move_by_span_locates_containing_move() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::ElementId;
    use super::super::super::types::Direction;
    use std::rc::Rc;
    let seg = |s: usize, e: usize, ord: u64| LeveledMove {
        rmove: RMove::Segment {
            direction: Direction::Up,
            lo: 0,
            hi: 10,
        },
        start_index: s,
        end_index: e,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 0,
            ordinal: ord,
        },
    };
    let moves = vec![seg(0, 3, 0), seg(4, 7, 1), seg(8, 11, 2)];
    assert_eq!(find_move_by_span(&moves, 2), Some(0));
    assert_eq!(find_move_by_span(&moves, 5), Some(1));
    assert_eq!(find_move_by_span(&moves, 11), Some(2));
    assert_eq!(find_move_by_span(&moves, 3), Some(0), "端点归包含段");
    assert_eq!(find_move_by_span(&moves, 12), None, "越界无段");
    assert_eq!(find_move_by_span(&[], 0), None, "空序列无段");
}

/// `window_extreme_bar`：δ 侧极值 + 平局取最早 + 越界 None。
#[test]
fn window_extreme_bar_tracks_delta_side_and_ties() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::ElementId;
    use super::super::super::types::Direction;
    use std::rc::Rc;
    let mk = |i: usize, low: i64, high: i64| Bar {
        source_index: i,
        timestamp: i as i64,
        open: low,
        high,
        low,
        close: low,
        volume: 0.0,
        untradable: false,
    };
    let bars = vec![mk(0, 10, 20), mk(1, 5, 25), mk(2, 8, 30), mk(3, 7, 15)];
    let cur = LeveledMove {
        rmove: RMove::Segment {
            direction: Direction::Down,
            lo: 5,
            hi: 30,
        },
        start_index: 0,
        end_index: 3,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 0,
            ordinal: 0,
        },
    };
    assert_eq!(
        window_extreme_bar(&bars, &cur, Side::Long),
        Some(1),
        "Long 取最低 low"
    );
    assert_eq!(
        window_extreme_bar(&bars, &cur, Side::Short),
        Some(2),
        "Short 取最高 high"
    );
    // 平局取最早：两 bar low 相等 ⟹ 更早者。
    let tie = vec![mk(0, 5, 30), mk(1, 5, 20)];
    let cur_tie = LeveledMove {
        rmove: RMove::Segment {
            direction: Direction::Down,
            lo: 5,
            hi: 30,
        },
        start_index: 0,
        end_index: 1,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 0,
            ordinal: 1,
        },
    };
    assert_eq!(window_extreme_bar(&tie, &cur_tie, Side::Long), Some(0));
    // 越界（end_index 超出 bars）⟹ None。
    let cur_bad = LeveledMove {
        rmove: RMove::Segment {
            direction: Direction::Down,
            lo: 5,
            hi: 30,
        },
        start_index: 0,
        end_index: 4,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 0,
            ordinal: 2,
        },
    };
    assert_eq!(window_extreme_bar(&bars, &cur_bad, Side::Long), None);
}

/// `departure_unit_end`：取最后一个 δ 侧趋势方向子走势终点；无趋势子走势 ⟹ None。
#[test]
fn departure_unit_end_picks_last_trend_direction_submove() {
    use super::super::super::classifier::descend::RMove;
    use super::super::super::classifier::recursive_tower::ElementId;
    use super::super::super::types::Direction;
    use std::rc::Rc;
    let seg = |dir: Direction, s: usize, e: usize, ord: u64| LeveledMove {
        rmove: RMove::Segment {
            direction: dir,
            lo: 100,
            hi: 200,
        },
        start_index: s,
        end_index: e,
        sub_moves: Rc::new(vec![]),
        id: ElementId {
            level: 0,
            ordinal: ord,
        },
    };
    let center = Center {
        zd: 150,
        zg: 180,
        dd: 100,
        gg: 200,
        start_index: 0,
        end_index: 8,
    };
    let subs = vec![
        seg(Direction::Down, 0, 2, 0),
        seg(Direction::Up, 2, 4, 1),
        seg(Direction::Down, 4, 6, 2),
        seg(Direction::Up, 6, 8, 3),
    ];
    let sub_rmoves: Vec<RMove> = subs.iter().map(|m| m.rmove.clone()).collect();
    let cur = LeveledMove {
        rmove: RMove::Compose {
            subs: Rc::new(sub_rmoves),
            centers: vec![center],
            level: 1,
        },
        start_index: 0,
        end_index: 8,
        sub_moves: Rc::new(subs),
        id: ElementId {
            level: 1,
            ordinal: 0,
        },
    };
    assert_eq!(
        departure_unit_end(&cur, Side::Long),
        Some(6),
        "Long 取最后一个 Down 段终点"
    );
    assert_eq!(
        departure_unit_end(&cur, Side::Short),
        Some(8),
        "Short 取最后一个 Up 段终点"
    );
    // 无趋势方向子走势 ⟹ None。
    let only_up = vec![seg(Direction::Up, 0, 2, 0), seg(Direction::Up, 2, 4, 1)];
    let up_rmoves: Vec<RMove> = only_up.iter().map(|m| m.rmove.clone()).collect();
    let cur_up = LeveledMove {
        rmove: RMove::Compose {
            subs: Rc::new(up_rmoves),
            centers: vec![center],
            level: 1,
        },
        start_index: 0,
        end_index: 4,
        sub_moves: Rc::new(only_up),
        id: ElementId {
            level: 1,
            ordinal: 1,
        },
    };
    assert_eq!(departure_unit_end(&cur_up, Side::Long), None);
}

// ═══════════════════════════════════════════════════════════════════════
// #1091 探针：三轮下钻残余桶（cond1 残 / cond2 D-3 取段 / cond3 Extreme /
// cond4 Weak）反事实拆解（#1028 终局）
// ═══════════════════════════════════════════════════════════════════════

/// **#1091 探针：Type1 下钻残余桶（cond1/2/3/4）的逐例 dump + 三键反事实**（只读诊断，`#[ignore]`）。
///
/// ## 验什么
///
/// #1028 终验（裁定 A 后三轮重测）：首步 C 27.5%（109/396）、方向桶 159→13（已证 =
/// 锚错位，#1034 反事实 + 裁定 A 修后）。**对表口径订正**：cond1 方向残 13 是三轮终验
/// （锚迁 #1052 后）读数；cond2 D-3 取段 59 / cond3 Extreme 36 / cond4 Weak 15 是
/// #870 二轮（迁前）读数——迁后三桶正是本探针要首次测出的量（ADR 0013 三轮订正只给
/// 定性「残余 27.5% = D-3/Extreme/Weak + base_none 54」，未给迁后三桶计数）。
/// 本票对**剩余桶**做 cond1-research
/// （#1034）同款拆解：逐例 dump + 三键反事实（source_index / 窗口极值 bar / departure
/// 终点）翻转率 + 归因排序（归因判读口径见设计文档
/// `.chanlun/review-results/issue1091-residual-counterfactual-design-20260818.md`）。
///
/// ## 怎么测
///
/// 复制 `type1_descend_continuity_dx` 的 bit-exact classify 循环与下钻展开，对每条 Type1
/// `lvl≥1` 信号在**链终止 C 步**上：
/// 1. 逐例 dump：父走势结构（Segment/Compose·中枢数·subs 数·父中枢）/ D-3 取段键（s 跨界·
///    prev 进入段 vs 上次离开段）/ 目标段 lo-hi-area / 前序同向段 lo-hi-area / 期望与实判
///    （方向·Extreme·Weak 三子判定 + 首个失败条件）。
/// 2. 三键反事实：目标子走势对齐键换成 ①source_index（生产现锚 = departure 终点）②窗口
///    极值 bar（δ 侧价格极值）③departure 终点，重跑生产 `div_cand_fail`，记新结局
///    （pass / cond1..4）与翻转率。**纯测量，不改生产判据、不改生产锚。**
///
/// ## 三键关系（诚实声明）
///
/// ① 与 ③ 在**首步**同值（裁定 A 后 `source_index` == departure 终点）——两臂只在下钻**更深步**
/// （cur 已非顶层 C，src 仍是顶层锚而 ③ 是当前父走势自己的 departure 终点）分叉。真正的
/// 对照差异由 ②（窗口极值 bar，即 #1035 判定的「背驰极值」候选锚）贡献。
///
/// **认识论 L2**（真实 BTC 逐信号结构下钻 + 确定性 div_cand，可产否定性计数）。
///
/// 命令：`ECON_L2_MAX_BARS=100000000 cargo test --release type1_residual_counterfactual_dx -- --ignored --nocapture`
#[test]
#[ignore]
fn type1_residual_counterfactual_dx() {
    use super::super::super::classifier::cand_predicate::{parent_last_center, rmove_dir};
    use super::super::super::classifier::divergence::{compute_macd, segment_macd_area};
    use super::super::super::parser::segment::segment_force_l;
    use super::super::super::types::Direction;
    use super::super::data;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    let max_bars = econ_l2_max_bars();
    let ds = truncate_tail_bars(ds_full, max_bars);
    let bars = &ds.bars;
    let n = bars.len();
    let tick = config.tick.tick_size;
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[t1-residual-cf-dx] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    let closes: Vec<f64> = bars.iter().map(|b| b.close as f64 / tick as f64).collect();
    let macd_hist = compute_macd(&closes, &config.macd).hist;

    const LMIN: usize = 1;
    const LMAX: usize = 4;
    const NARM: usize = 3;
    let arm_name = |a: usize| match a {
        0 => "原臂(source_index)",
        1 => "窗口极值bar",
        2 => "departure终点",
        _ => unreachable!(),
    };
    let cond_name = |cd: u8| match cd {
        0 => "pass",
        1 => "cond1方向",
        2 => "cond2取段",
        3 => "cond3Extreme",
        4 => "cond4Weak",
        _ => "?",
    };
    let fmt_dir = |d: Option<Direction>| match d {
        Some(Direction::Up) => "Up",
        Some(Direction::Down) => "Down",
        None => "None",
    };

    // ── 计数器 ──
    let mut n_sig = 0usize; // Type1 lvl≥1 信号数（per-delta 去重后，含 base_none）
    let mut base_none = 0usize; // tower[lvl] 无 end==src 段 ⟹ 下钻未启动
    let mut first_step = [0usize; 4]; // 首步 0=成功 1=A(空subs) 2=B(无对齐) 3=C(div假)
    let mut bucket_count = [0usize; 5]; // 链终止 C 条件号分布（下标 1..=4）

    // 三键反事实：arm_key_none[bucket][arm] / arm_no_align[bucket][arm] /
    // arm_out[bucket][arm][new]（new：0=pass 1..=4=cond）。
    let mut arm_key_none = [[0usize; NARM]; 5];
    let mut arm_no_align = [[0usize; NARM]; 5];
    let mut arm_out = [[[0usize; 5]; NARM]; 5];

    // ── 逐例 dump（md 取样 + jsonl 全量）──
    const PER_BUCKET_CAP: usize = 8;
    const TOTAL_CAP: usize = 40;
    let mut bucket_used = [0usize; 5];
    let mut sample_md: Vec<String> = Vec::new();
    let mut cases_jsonl: Vec<String> = Vec::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __w = classifier_incr.classify_at(i);
        let l0_i = classifier_incr
            .last_l0()
            .expect("classify_at 已推进 ParseLayer");
        let cls_i = __w.classification;
        let tower_i = __w.tower;
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if !(LMIN..=LMAX).contains(&lvl) {
                continue;
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                if !(p.bits.buy1 || p.bits.sell1) {
                    continue;
                }
                // Γ 组装（bit-exact 复制生产路径，同 type1_descend_continuity_dx）。
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()),
                            first_class_grades: Rc::new(Vec::new()),
                            level_projection: None,
                        })
                        .collect(),
                };
                let cands = assemble_gamma_with_tower(&single, &tower_i);
                for c in &cands {
                    let delta = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    let is_type1 = match delta {
                        Side::Long => p.bits.buy1,
                        Side::Short => p.bits.sell1,
                    };
                    if !is_type1 {
                        continue;
                    }
                    let src = p.source_index;
                    n_sig += 1;

                    let exec_moves = match tower_i.get(lvl) {
                        Some(mv) => mv.as_slice(),
                        None => {
                            base_none += 1;
                            continue;
                        }
                    };
                    let Some(si) = find_move_by_end_index(exec_moves, src) else {
                        base_none += 1;
                        continue;
                    };
                    let s = &exec_moves[si];

                    // ── 展开 descend_type1_anchor_depth 的递归为可观测循环（同 #846 探针）──
                    let mut cur: &LeveledMove = s;
                    let mut cur_level = lvl;
                    let mut depth = 0usize;
                    let terminal: StepFail;
                    let mut term_tidx: Option<usize> = None;
                    loop {
                        let subs = cur.sub_moves.as_slice();
                        if subs.is_empty() {
                            terminal = StepFail::EmptySubs;
                            break;
                        }
                        let Some(tidx) = find_move_by_end_index(subs, src) else {
                            terminal = StepFail::NoAlign;
                            break;
                        };
                        let parent_center = parent_last_center(cur);
                        let why = prod_div_cand_why(
                            subs,
                            tidx,
                            &macd_hist,
                            delta,
                            &l0_i.strokes,
                            parent_center,
                            config.divergence_gauge,
                        );
                        if let Some(cond) = why {
                            terminal = StepFail::DivFalse(cond);
                            term_tidx = Some(tidx);
                            break;
                        }
                        depth += 1;
                        cur = &subs[tidx];
                        cur_level = cur_level.saturating_sub(1);
                    }

                    // 首步四分类（0=成功 1=A 2=B 3=C）。
                    if depth == 0 {
                        let fs = match terminal {
                            StepFail::EmptySubs => 1,
                            StepFail::NoAlign => 2,
                            StepFail::DivFalse(_) => 3,
                        };
                        first_step[fs] += 1;
                    } else {
                        first_step[0] += 1;
                    }

                    // 只对链终止 C 做反事实 + dump。
                    let StepFail::DivFalse(cond) = terminal else {
                        continue;
                    };
                    bucket_count[cond as usize] += 1;
                    let subs = cur.sub_moves.as_slice();
                    let tidx = term_tidx.expect("C 类 ⟹ 对齐段存在");
                    let parent_center = parent_last_center(cur);
                    let dsym = if delta == Side::Long { "+1" } else { "-1" };
                    let expected = match delta {
                        Side::Long => Direction::Down,
                        Side::Short => Direction::Up,
                    };

                    // ── 三键反事实 ──
                    let keys = [
                        Some(src),
                        window_extreme_bar(bars, cur, delta),
                        departure_unit_end(cur, delta),
                    ];
                    let targets: [Option<usize>; NARM] = [
                        find_move_by_end_index(subs, src),
                        keys[1].and_then(|k| find_move_by_span(subs, k)),
                        keys[2].and_then(|k| find_move_by_span(subs, k)),
                    ];
                    let mut outcomes = [0u8; NARM]; // 0=pass 1..=4=cond
                    for a in 0..NARM {
                        if keys[a].is_none() {
                            arm_key_none[cond as usize][a] += 1;
                            continue;
                        }
                        let Some(nt) = targets[a] else {
                            arm_no_align[cond as usize][a] += 1;
                            continue;
                        };
                        let new_why = prod_div_cand_why(
                            subs,
                            nt,
                            &macd_hist,
                            delta,
                            &l0_i.strokes,
                            parent_center,
                            config.divergence_gauge,
                        );
                        let out = match new_why {
                            None => 0,
                            Some(c2) => c2,
                        };
                        arm_out[cond as usize][a][out as usize] += 1;
                        outcomes[a] = out;
                    }

                    // ── 逐例 dump 字段 ──
                    let s_t = &subs[tidx];
                    let s_dir = rmove_dir(&s_t.rmove);
                    // MacdArea 同色口径 = δ 侧反向走势（与 div_cand_fail 的 dir 同款）。
                    let dir4 = expected;
                    let s_area =
                        segment_macd_area(&macd_hist, s_t.start_index, s_t.end_index, dir4);
                    // D-3 取段键（与 div_cand_fail 同谓词：s 跨界 + prev 选择；cond1 失败时
                    // 生产已短路，此处照镜像给出「若方向通过会选谁」的诊断读数）。
                    let crosses = |m: &LeveledMove, dir: Direction, c: &Center| -> bool {
                        match dir {
                            Direction::Down => m.rmove.lo() < c.zd,
                            Direction::Up => m.rmove.hi() > c.zg,
                        }
                    };
                    let (s_crosses, prev_info, prev_idx, prev_lo, prev_hi, prev_area) =
                        match (s_dir, parent_center) {
                            (Some(dir), Some(c)) => {
                                let s_cross = crosses(s_t, dir, c);
                                let prev = subs[..tidx].iter().enumerate().rev().find(|(_, m)| {
                                    rmove_dir(&m.rmove) == Some(dir)
                                        && (crosses(m, dir, c) || m.end_index <= c.start_index)
                                });
                                match prev {
                                    Some((idx, m)) => {
                                        let role = if crosses(m, dir, c) {
                                            "上次离开段(跨界)"
                                        } else {
                                            "进入段"
                                        };
                                        (
                                            s_cross,
                                            format!(
                                                "idx={idx} {role} lo={} hi={} [{}..{}]",
                                                m.rmove.lo(),
                                                m.rmove.hi(),
                                                m.start_index,
                                                m.end_index
                                            ),
                                            Some(idx),
                                            Some(m.rmove.lo()),
                                            Some(m.rmove.hi()),
                                            Some(segment_macd_area(
                                                &macd_hist,
                                                m.start_index,
                                                m.end_index,
                                                dir4,
                                            )),
                                        )
                                    }
                                    None => (
                                        s_cross,
                                        "（无同向可比较前段）".to_string(),
                                        None,
                                        None,
                                        None,
                                        None,
                                    ),
                                }
                            }
                            _ => (
                                false,
                                "（无父中枢语境）".to_string(),
                                None,
                                None,
                                None,
                                None,
                            ),
                        };
                    let extreme_ok = match (delta, prev_lo, prev_hi) {
                        (Side::Long, Some(pl), _) => s_t.rmove.lo() < pl,
                        (Side::Short, _, Some(ph)) => s_t.rmove.hi() > ph,
                        _ => false,
                    };
                    // Weak 两档读数（ForceL 教义档 + MacdArea 对照档）。
                    let lc = segment_force_l(&l0_i.strokes, s_t.start_index, s_t.end_index);
                    let lb = prev_idx.and_then(|idx| {
                        segment_force_l(&l0_i.strokes, subs[idx].start_index, subs[idx].end_index)
                    });
                    let l_ok = match (lb, lc) {
                        (Some(b), Some(cc)) => Some(cc < b),
                        _ => None,
                    };
                    let macd_ok = prev_area.map(|pa| s_area < pa);

                    // 父走势结构。
                    let parent_txt = match &cur.rmove {
                        RMove::Segment { direction, .. } => {
                            format!("Segment(dir={:?})", direction)
                        }
                        RMove::Compose { centers, level, .. } => {
                            format!("Compose(lvl={level} centers={})", centers.len())
                        }
                    };
                    let center_txt = match parent_center {
                        Some(c) => format!(
                            "Some(zd={} zg={} [{}..{}])",
                            c.zd, c.zg, c.start_index, c.end_index
                        ),
                        None => "None".to_string(),
                    };

                    let arm_txt = (0..NARM)
                        .map(|a| {
                            if keys[a].is_none() {
                                format!("{}=键缺失", arm_name(a))
                            } else if targets[a].is_none() {
                                format!("{}=无对齐", arm_name(a))
                            } else {
                                format!("{}={}", arm_name(a), cond_name(outcomes[a]))
                            }
                        })
                        .collect::<Vec<_>>()
                        .join(" · ");

                    // JSONL 全量（值先算成变量，json! 只收变量/字面量）。
                    let target_dir_txt = fmt_dir(s_dir).to_string();
                    let dir_ok = s_dir == Some(expected);
                    let center_json = match parent_center {
                        Some(c) => serde_json::json!({
                            "zd": c.zd,
                            "zg": c.zg,
                            "start": c.start_index,
                            "end": c.end_index
                        }),
                        None => serde_json::Value::Null,
                    };
                    let rec = serde_json::json!({
                        "lvl": lvl,
                        "term_level": cur_level,
                        "depth": depth,
                        "src": src,
                        "delta": dsym,
                        "bucket": cond,
                        "parent_kind": parent_txt,
                        "parent_span": [cur.start_index, cur.end_index],
                        "parent_subs": subs.len(),
                        "center": center_json,
                        "target_idx": tidx,
                        "target_dir": target_dir_txt,
                        "target_lo": s_t.rmove.lo(),
                        "target_hi": s_t.rmove.hi(),
                        "target_span": [s_t.start_index, s_t.end_index],
                        "target_area": s_area,
                        "prev_idx": prev_idx,
                        "prev_lo": prev_lo,
                        "prev_hi": prev_hi,
                        "prev_area": prev_area,
                        "d3_s_crosses": s_crosses,
                        "d3_prev": prev_info,
                        "dir_ok": dir_ok,
                        "extreme_ok": extreme_ok,
                        "weak_l_ok": l_ok,
                        "weak_macd_ok": macd_ok,
                        "arm0": cond_name(outcomes[0]),
                        "arm1": cond_name(outcomes[1]),
                        "arm2": cond_name(outcomes[2])
                    });
                    cases_jsonl.push(serde_json::to_string(&rec).unwrap_or_default());

                    // md 取样。
                    if bucket_used[cond as usize] < PER_BUCKET_CAP && sample_md.len() < TOTAL_CAP {
                        bucket_used[cond as usize] += 1;
                        let term = cur_level.saturating_sub(1);
                        sample_md.push(format!(
                                "#### [cond{cond} · 例{}] lvl={lvl}→{term}（步深{depth}）src={src} δ={dsym}\n\
                                 - 父：{parent_txt} span=[{}..{}] subs={}；parent_center={center_txt}\n\
                                 - 取段键：s跨界={s_crosses}；prev={prev_info}\n\
                                 - 目标段：idx={tidx} dir={} lo={} hi={} span=[{}..{}] area={:.4}\n\
                                 - 前序同向段：{}\n\
                                 - 期望→实判：dir={}(期望{}) Extreme={} Weak(L={},MacdArea={}) → {}\n\
                                 - 三键：{arm_txt}",
                                bucket_used[cond as usize],
                                cur.start_index,
                                cur.end_index,
                                subs.len(),
                                fmt_dir(s_dir),
                                s_t.rmove.lo(),
                                s_t.rmove.hi(),
                                s_t.start_index,
                                s_t.end_index,
                                s_area,
                                prev_idx
                                    .map(|idx| format!(
                                        "idx={idx} lo={} hi={} span=[{}..{}] area={:.4}",
                                        prev_lo.unwrap_or(0),
                                        prev_hi.unwrap_or(0),
                                        subs[idx].start_index,
                                        subs[idx].end_index,
                                        prev_area.unwrap_or(0.0)
                                    ))
                                    .unwrap_or_else(|| prev_info.clone()),
                                fmt_dir(s_dir),
                                fmt_dir(Some(expected)),
                                extreme_ok,
                                l_ok.map(|b| b.to_string())
                                    .unwrap_or_else(|| "None".to_string()),
                                macd_ok.map(|b| b.to_string())
                                    .unwrap_or_else(|| "None".to_string()),
                                cond_name(cond),
                            ));
                    }
                }
            }
        }
    }

    // ══ 报告 ══
    let pct = |x: usize, tot: usize| {
        if tot == 0 {
            0.0
        } else {
            100.0 * x as f64 / tot as f64
        }
    };
    let mut rpt = String::new();
    let _ = writeln!(
            rpt,
            "# #1091 原始数据：三轮下钻残余桶（cond1 残 / cond2 D-3 取段 / cond3 Extreme / cond4 Weak）反事实拆解"
        );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- issue: #1091（#1028 终局残余桶拆解；纯测量，不改生产判据）"
    );
    let _ = writeln!(
        rpt,
        "- **认识论 L2**（真实 BTC 逐信号结构下钻 + 确定性 div_cand，可产否定性计数）"
    );
    let _ = writeln!(
        rpt,
        "- 窗口：{win_start}→{win_end}，bars={n}（全量={n_full}），max_bars={max_bars}"
    );
    let _ = writeln!(
        rpt,
        "- 范围：Type1 `lvl≥1` 全链下钻（同 #846/#870 口径）；失败桶 = 链**终止** C 条件号"
    );
    let _ = writeln!(rpt, "- 判据口径：`cand_predicate::div_cand` 四条件（`prod_div_cand_why` 直调生产 `div_cand_fail`）");
    let _ = writeln!(rpt, "- 三键：0 原臂(source_index，生产现锚=departure 终点) / 1 窗口极值 bar（δ 侧价格极值） / 2 departure 终点（当前父走势末趋势子段终点）；①③ 首步同值，更深步分叉");
    let _ = writeln!(rpt);

    let _ = writeln!(rpt, "## 1. 总读数（与 #1028 三轮对表）");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 指标 | 值 |");
    let _ = writeln!(rpt, "|---|---|");
    let _ = writeln!(rpt, "| Type1 lvl≥1 信号数 | {n_sig} |");
    let _ = writeln!(rpt, "| base_none（塔无 end==src 段） | {base_none} |");
    let _ = writeln!(rpt, "| 首步成功 | {} |", first_step[0]);
    let _ = writeln!(rpt, "| 首步 A(空subs) | {} |", first_step[1]);
    let _ = writeln!(rpt, "| 首步 B(无对齐) | {} |", first_step[2]);
    let _ = writeln!(rpt, "| 首步 C(div假) | {} |", first_step[3]);
    let _ = writeln!(
        rpt,
        "| 首步 C 率 | {:.2}% |",
        pct(
            first_step[3],
            first_step[0] + first_step[1] + first_step[2] + first_step[3]
        )
    );
    let _ = writeln!(
        rpt,
        "| 链终止 C 条件号 | cond1={} cond2={} cond3={} cond4={} |",
        bucket_count[1], bucket_count[2], bucket_count[3], bucket_count[4]
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
            rpt,
            "- 对表口径：`cond1` 方向残 13 = #1028 三轮终验（锚迁 #1052 后）读数；`cond2/3/4`（D-3 取段 59 / Extreme 36 / Weak 15）= #870 二轮（迁前）读数——迁后三桶正是本探针要首次测出的量（ADR 0013 三轮订正只给定性「残余 27.5% = D-3/Extreme/Weak + base_none 54」，未给迁后三桶计数）。"
        );
    let _ = writeln!(rpt);

    let _ = writeln!(rpt, "## 2. 三键反事实翻转矩阵（每桶 × 三臂的新结局分布）");
    let _ = writeln!(rpt);
    for b in 1..=4 {
        let _ = writeln!(rpt, "### 2.{b} cond{b}（{}）", cond_name(b as u8));
        let _ = writeln!(
                rpt,
                "| 臂 | 键缺失 | 无对齐 | 通过 | 仍同桶 | →cond1 | →cond2 | →cond3 | →cond4 | 翻转率(任一变) | 翻转为通过率 |"
            );
        let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|---|");
        for a in 0..NARM {
            let tot = bucket_count[b];
            let evaluated = tot - arm_key_none[b][a] - arm_no_align[b][a];
            let pass = arm_out[b][a][0];
            let same = arm_out[b][a][b];
            let flip_any = evaluated - same;
            let _ = writeln!(
                rpt,
                "| {} | {} | {} | {} | {} | {} | {} | {} | {} | {:.2}% | {:.2}% |",
                arm_name(a),
                arm_key_none[b][a],
                arm_no_align[b][a],
                pass,
                same,
                arm_out[b][a][1],
                arm_out[b][a][2],
                arm_out[b][a][3],
                arm_out[b][a][4],
                pct(flip_any, evaluated),
                pct(pass, evaluated)
            );
        }
        let _ = writeln!(rpt);
    }
    let _ = writeln!(
            rpt,
            "> 判读：翻转率/翻转为通过率的分母 = 可评估数（= 桶计数 − 键缺失 − 无对齐）；某臂「翻转为通过」高 ⟹ 该桶失败是对齐键敏感（锚/取段边界错位投影）；三臂「仍同桶」恒高 ⟹ 判据真失败（Extreme 真否 / Weak 力度真否 / 市场事实）。详见设计文档。"
        );
    let _ = writeln!(rpt);

    let _ = writeln!(
        rpt,
        "## 3. 逐例 dump（md 取样，每桶 ≤{PER_BUCKET_CAP} 例，总 ≤{TOTAL_CAP}；全量见 jsonl）"
    );
    let _ = writeln!(rpt);
    if sample_md.is_empty() {
        let _ = writeln!(rpt, "\n**（空——无 C 失败例）**");
    } else {
        for l in &sample_md {
            let _ = writeln!(rpt, "{l}");
        }
    }
    let _ = writeln!(rpt);

    let _ = writeln!(rpt, "## 4. 真封与域外声明");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- 穷举：n_sig == base_none + Σ首步四类：{}",
        n_sig == base_none + first_step.iter().sum::<usize>()
    );
    let _ = writeln!(
        rpt,
        "- 原臂恒复现原桶（arm_out[b][0][b] == bucket_count[b]）：{}",
        (1..=4).all(|b| arm_out[b][0][b] == bucket_count[b])
    );
    let _ = writeln!(
        rpt,
        "- 三键反事实穷举（每桶每臂键缺失+无对齐+Σ新结局 == 桶计数）：{}",
        (1..=4).all(|b| (0..NARM).all(|a| {
            arm_key_none[b][a] + arm_no_align[b][a] + arm_out[b][a].iter().sum::<usize>()
                == bucket_count[b]
        }))
    );
    let _ = writeln!(rpt, "- 全量逐例 jsonl：{} 条", cases_jsonl.len());
    let _ = writeln!(rpt);

    eprint!("{rpt}");
    let out_md = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/issue1091-residual-counterfactual-raw.md");
    std::fs::write(&out_md, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n原始数据已落盘：{out_md:?}");
    let out_jsonl = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(".chanlun/review-results/issue1091-residual-counterfactual-cases.jsonl");
    std::fs::write(&out_jsonl, cases_jsonl.join("\n"))
        .unwrap_or_else(|e| panic!("写 jsonl 失败：{e}"));
    eprintln!("逐例 jsonl 已落盘：{out_jsonl:?}");

    // ── 真封（assert）──
    assert_eq!(
        base_none + first_step.iter().sum::<usize>(),
        n_sig,
        "穷举：base_none + Σ首步四类 应 = 信号总数"
    );
    for b in 1..=4 {
        assert_eq!(
            arm_out[b][0][b], bucket_count[b],
            "原臂恒复现原桶：cond{b} 原臂新结局应恒为 cond{b}"
        );
        for a in 0..NARM {
            assert_eq!(
                arm_key_none[b][a] + arm_no_align[b][a] + arm_out[b][a].iter().sum::<usize>(),
                bucket_count[b],
                "cond{b} 臂{a} 穷举：键缺失+无对齐+Σ新结局 应 = 桶计数"
            );
        }
    }
    eprintln!(
            "真封：Type1 lvl≥1={n_sig} 条（base_none={base_none}）；首步 C={}；链终止 C：cond1={} cond2={} cond3={} cond4={}；逐例={}",
            first_step[3],
            bucket_count[1],
            bucket_count[2],
            bucket_count[3],
            bucket_count[4],
            cases_jsonl.len()
        );
}

// ═══════════════════════════════════════════════════════════════════════
// #848 探针：归类半句的第二把尺子——BSP 识别层 / pan_div 通道认不认同一个点
// ═══════════════════════════════════════════════════════════════════════

/// 某级别 BSP 层在**同一坐标** `src` 上的合并读数（同坐标可有多条 [`BspPoint`]，六 bit 取并）。
#[derive(Clone, Copy, Default, PartialEq, Eq, Debug)]
struct BspAtCoord {
    /// 该级 `bsp` 列表里存在 `source_index == src` 的条目（**含零 bit 结构候选**）。
    present: bool,
    /// 六 bit 并（[`bsp_disc`] 口径：0=buy1 1=buy2 2=buy3 3=sell1 4=sell2 5=sell3）。
    mask: u8,
}

impl BspAtCoord {
    /// δ 同侧一类 bit（Long→buy1 / Short→sell1）＝「BSP 层认这是次级别一类点」。
    fn t1_side(self, delta: Side) -> bool {
        match delta {
            Side::Long => self.mask & 0b00_0001 != 0,
            Side::Short => self.mask & 0b00_1000 != 0,
        }
    }
    /// 任意侧一类 bit（方向不计——用于分辨「点不在」与「点在但方向标反」）。
    fn t1_any(self) -> bool {
        self.mask & 0b00_1001 != 0
    }
    /// δ 同侧二/三类 bit。
    fn t23_side(self, delta: Side) -> bool {
        match delta {
            Side::Long => self.mask & 0b00_0110 != 0,
            Side::Short => self.mask & 0b11_0000 != 0,
        }
    }
    /// 任意 bit 置位（区分「坐标只是零 bit 结构候选」与「坐标带 bit」）。
    fn any_bit(self) -> bool {
        self.mask != 0
    }
}

/// 扫某级 `bsp` 列表，合并 `source_index == src` 的全部条目。
fn bsp_at_coord(pts: &[BspPoint], src: usize) -> BspAtCoord {
    let mut r = BspAtCoord::default();
    for p in pts {
        if p.source_index == src {
            r.present = true;
            r.mask |= bsp_disc(&p.bits);
        }
    }
    r
}

/// 扫某级 `pan_div` 证书列表：返回 `(任意侧命中, δ 同侧命中)`。
fn pan_div_at_coord(certs: &[PanDivCert], src: usize, delta: Side) -> (bool, bool) {
    let mut any = false;
    let mut same = false;
    for c in certs {
        if c.source_index == src {
            any = true;
            if c.side == delta {
                same = true;
            }
        }
    }
    (any, same)
}

/// **#848 探针：换一把不同源的尺子再量归类半句**（只读诊断，不改生产，`#[ignore]`）。
///
/// ## 为什么要第二把尺子
///
/// #846 用 `descend_type1_anchor_depth` 里的 `div_cand` 测 ADR 0013 裁定七的**归类半句**
/// （「一类点的最后一个次级别走势**必然被判为**次级别一类点／类一类点」），得 C 类 92.03%。
/// 该读数**不算否证**：`div_cand` 的比较基准写死「同父前序最近同向段」＝**趋势背驰**形状，
/// 「类一类点（盘整背驰）」在该判据下**没有入口**（`cand_predicate.rs` 四条件里没有对应分支）。
///
/// ★#883 订正：盘整背驰入口已落地（#814 D-3 统一取段 + #990 统一力度原语）——上两句描述
/// 的是 #883 之前的判据形状，保留作历史动机；本探针两臂（BSP 识别层 / pan_div 通道）与
/// `div_cand` 新口径**仍不同源**，对照价值不变。
///
/// 本探针**不改判据**，改问两条**与 `div_cand` 不同源**的现成管线：
/// 1. **BSP 识别层**：`cls.levels[L−1].bsp` 里有没有坐标 `== source_index` 的 `buy1`/`sell1`
///    （判据是 `signal.rs:516` 的 `below_last_center = diverged && t3_in_c_present`，与
///    `div_cand` 四条件**不是同一套**）；
/// 2. **pan_div 通道**：`cls.levels[L−1].pan_div`（`PanDivCert`，同一中枢两次同向离开 + 面积
///    C<A）——这正是 `div_cand` 缺的那个「盘整背驰」入口的**替代观测**。
///
/// ## 口径（与 #846 严格同批，否则两次读数不可比）
///
/// 同一份 BTC 数据、同一 `IncrementalClassifier` 逐 bar 循环、同一 `seen` 去重键
/// `(lvl, source_index, bsp_disc)`、同一 `LMIN=0` / `LMAX=4`、同一 Γ 定向、同一群定义
/// （Type1 优先坍缩）。§0 的 BSP bit 清单与 §5 的 `n_sig` 逐格与 #846 报告对照即可自检。
///
/// ## 两个时点都读（防「查不到」被写成「不存在」）
///
/// - **同期**：信号首次出现的那个 bar 上的 `cls_i`（point-in-time，含因果）；
/// - **终局**：全窗最后一个可交易 bar 的 `cls` 快照（`bsp`/`pan_div` 为累积列表）。
///   两者差值 = 「信号出现时次级别还没标上，后来标上了」的量。
///
/// ## 不裁教义
///
/// 「类一类点」的准入判据（盘整背驰算不算、几段起算）归 #817，**本探针不裁**，只测现有
/// 两套判据各自认什么。
///
/// **认识论 L2**（真实 BTC 逐信号 + 确定性判据，可产否定性计数）。
///
/// 命令：`ECON_L2_MAX_BARS=100000000 cargo test --release type1_bsp_layer_crosscheck_dx -- --ignored --nocapture`
#[test]
#[ignore]
fn type1_bsp_layer_crosscheck_dx() {
    use super::super::super::classifier::divergence::compute_macd;
    use super::super::data;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    let max_bars = std::env::var(crate::theta_v0::env_registry::ECON_L2_MAX_BARS)
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(usize::MAX);
    let ds = if n_full > max_bars {
        ds_full.slice_bar_range(n_full - max_bars, n_full)
    } else {
        ds_full
    };
    let bars = &ds.bars;
    let n = bars.len();
    let tick = config.tick.tick_size;
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[t1-bsp-xcheck] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    let closes: Vec<f64> = bars.iter().map(|b| b.close as f64 / tick as f64).collect();
    let macd_hist = compute_macd(&closes, &config.macd).hist;

    const LMIN: usize = 0;
    const LMAX: usize = 4;
    const NG: usize = 2;
    let gname = |g: usize| if g == 0 { "Type1" } else { "Type2/3" };
    let in_scope = |lvl: usize| (LMIN..=LMAX).contains(&lvl);

    // ── 与 #846 同口径的信号基数（跨报告可比性自检面）──
    let mut raw_pts = [0usize; LMAX + 1];
    let mut raw_bit = [[0usize; 6]; LMAX + 1];
    let mut raw_t1_pts = [0usize; LMAX + 1];
    let mut n_sig = [[0usize; LMAX + 1]; NG];
    let mut base_none = [[0usize; LMAX + 1]; NG];
    let mut n_other = 0usize;

    // ── 读数①②：逐级向下问 BSP 层 / pan_div（[群][信号级 lvl][目标级 tl]）──
    let mut q_n = [[[0usize; LMAX + 1]; LMAX + 1]; NG]; // 发起查询数
    let mut q_absent = [[[0usize; LMAX + 1]; LMAX + 1]; NG]; // cls.levels 无该级
    let mut q_present = [[[0usize; LMAX + 1]; LMAX + 1]; NG]; // 坐标存在 BSP 条目（含零 bit）
    let mut q_anybit = [[[0usize; LMAX + 1]; LMAX + 1]; NG];
    let mut q_t1_side = [[[0usize; LMAX + 1]; LMAX + 1]; NG]; // ★同侧一类 bit
    let mut q_t1_any = [[[0usize; LMAX + 1]; LMAX + 1]; NG];
    let mut q_t23_side = [[[0usize; LMAX + 1]; LMAX + 1]; NG];
    let mut q_pd_any = [[[0usize; LMAX + 1]; LMAX + 1]; NG];
    let mut q_pd_side = [[[0usize; LMAX + 1]; LMAX + 1]; NG]; // ★同侧 pan_div
                                                              // 终局快照同一套
    let mut f_present = [[[0usize; LMAX + 1]; LMAX + 1]; NG];
    let mut f_t1_side = [[[0usize; LMAX + 1]; LMAX + 1]; NG];
    let mut f_t1_any = [[[0usize; LMAX + 1]; LMAX + 1]; NG];
    let mut f_pd_side = [[[0usize; LMAX + 1]; LMAX + 1]; NG];
    let mut f_pd_any = [[[0usize; LMAX + 1]; LMAX + 1]; NG];

    // ── 读数③：差集交叉表（只对首步 L→L−1）[群][lvl][div_ok][bsp_ok] ──
    let mut cross_t1 = [[[[0usize; 2]; 2]; LMAX + 1]; NG]; // bsp_ok = 同侧一类 bit
    let mut cross_wide = [[[[0usize; 2]; 2]; LMAX + 1]; NG]; // bsp_ok = 同侧一类 bit ∨ 同侧 pan_div
                                                             // ── 读数④：div_cand 失败条件号 × BSP 层认不认 [群][cond][bsp_ok] ──
    let mut cond_x_t1 = [[[0usize; 2]; 5]; NG];
    let mut cond_x_wide = [[[0usize; 2]; 5]; NG];

    // 首步三分（与 #846 同义，用于自检两报告口径一致）
    let mut first_ok = [[0usize; LMAX + 1]; NG];
    let mut first_a = [[0usize; LMAX + 1]; NG];
    let mut first_b = [[0usize; LMAX + 1]; NG];
    let mut first_c = [[0usize; LMAX + 1]; NG];

    // ★#883：`parity_violation` 退役（直调生产 `div_cand_fail`，parity 由构造保证）。

    // 终局快照（`bsp`/`pan_div` 是累积列表 ⟹ 末 bar 即全窗全集）
    let last_bar = (0..n)
        .rev()
        .find(|&i| !bars[i].untradable && bars[i].close > 0);
    let mut final_bsp: Vec<Rc<Vec<BspPoint>>> = Vec::new();
    let mut final_pd: Vec<Rc<Vec<PanDivCert>>> = Vec::new();
    // 延后到终局再查的信号台账：(g, lvl, src, delta, div_ok, cond)
    let mut sigs: Vec<(usize, usize, usize, Side, bool, u8)> = Vec::new();

    // ── 取样 ──
    const CELL_CAP: usize = 6;
    let mut xcell = [[0usize; 2]; 2];
    let mut sample_x: Vec<String> = Vec::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __wl7 = classifier_incr.classify_at(i);
        let l0_i = classifier_incr
            .last_l0()
            .expect("classify_at 已推进 ParseLayer");
        let cls_i = __wl7.classification;
        let tower_i = __wl7.tower;
        if Some(i) == last_bar {
            final_bsp = cls_i.levels.iter().map(|l| Rc::clone(&l.bsp)).collect();
            final_pd = cls_i.levels.iter().map(|l| Rc::clone(&l.pan_div)).collect();
        }
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if !in_scope(lvl) {
                continue;
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                if !(p.bits.buy1
                    || p.bits.sell1
                    || p.bits.buy2
                    || p.bits.sell2
                    || p.bits.buy3
                    || p.bits.sell3)
                {
                    continue;
                }
                raw_pts[lvl] += 1;
                for (bi, on) in [
                    p.bits.buy1,
                    p.bits.buy2,
                    p.bits.buy3,
                    p.bits.sell1,
                    p.bits.sell2,
                    p.bits.sell3,
                ]
                .into_iter()
                .enumerate()
                {
                    if on {
                        raw_bit[lvl][bi] += 1;
                    }
                }
                if p.bits.buy1 || p.bits.sell1 {
                    raw_t1_pts[lvl] += 1;
                }
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()),
                            first_class_grades: Rc::new(Vec::new()), // #885：同 pan_div 口径（single 屏蔽层无分级记录载荷）
                            level_projection: None,
                        })
                        .collect(),
                };
                let cands = assemble_gamma_with_tower(&single, &tower_i);
                for c in &cands {
                    let delta = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    let src = p.source_index;
                    let is_type1 = match delta {
                        Side::Long => p.bits.buy1,
                        Side::Short => p.bits.sell1,
                    };
                    let is_type2 = match delta {
                        Side::Long => p.bits.buy2,
                        Side::Short => p.bits.sell2,
                    };
                    let is_type3 = match delta {
                        Side::Long => p.bits.buy3,
                        Side::Short => p.bits.sell3,
                    };
                    let g = if is_type1 {
                        0
                    } else if is_type2 || is_type3 {
                        1
                    } else {
                        n_other += 1;
                        continue;
                    };
                    n_sig[g][lvl] += 1;

                    // ── 首步 div_cand 判读（★#883：直调生产 `div_cand_fail`，parity 由构造保证）──
                    let exec_moves = match tower_i.get(lvl) {
                        Some(mv) => mv.as_slice(),
                        None => {
                            base_none[g][lvl] += 1;
                            continue;
                        }
                    };
                    let Some(si) = find_move_containing_index(exec_moves, src) else {
                        base_none[g][lvl] += 1;
                        continue;
                    };
                    let s = &exec_moves[si];
                    let subs = s.sub_moves.as_slice();
                    let (div_ok, cond) = if subs.is_empty() {
                        first_a[g][lvl] += 1;
                        (false, 0u8)
                    } else if let Some(tidx) = find_move_by_end_index(subs, src)
                        .or_else(|| find_move_containing_index(subs, src))
                    {
                        let why = prod_div_cand_why(
                            subs,
                            tidx,
                            &macd_hist,
                            delta,
                            &l0_i.strokes,
                            super::super::super::classifier::cand_predicate::parent_last_center(s),
                            config.divergence_gauge,
                        );
                        match why {
                            None => {
                                first_ok[g][lvl] += 1;
                                (true, 0u8)
                            }
                            Some(c0) => {
                                first_c[g][lvl] += 1;
                                (false, c0)
                            }
                        }
                    } else {
                        first_b[g][lvl] += 1;
                        (false, 0u8)
                    };

                    // ── 逐级向下问 BSP 层 / pan_div（同期读数）──
                    let mut sub_t1 = false; // 次级别（L−1）同侧一类 bit
                    let mut sub_pd = false; // 次级别（L−1）同侧 pan_div
                    for tl in (0..lvl).rev() {
                        q_n[g][lvl][tl] += 1;
                        let Some(tls) = cls_i.levels.get(tl) else {
                            q_absent[g][lvl][tl] += 1;
                            continue;
                        };
                        let at = bsp_at_coord(&tls.bsp, src);
                        let (pd_any, pd_same) = pan_div_at_coord(&tls.pan_div, src, delta);
                        if at.present {
                            q_present[g][lvl][tl] += 1;
                        }
                        if at.any_bit() {
                            q_anybit[g][lvl][tl] += 1;
                        }
                        if at.t1_side(delta) {
                            q_t1_side[g][lvl][tl] += 1;
                        }
                        if at.t1_any() {
                            q_t1_any[g][lvl][tl] += 1;
                        }
                        if at.t23_side(delta) {
                            q_t23_side[g][lvl][tl] += 1;
                        }
                        if pd_any {
                            q_pd_any[g][lvl][tl] += 1;
                        }
                        if pd_same {
                            q_pd_side[g][lvl][tl] += 1;
                        }
                        if tl + 1 == lvl {
                            sub_t1 = at.t1_side(delta);
                            sub_pd = pd_same;
                        }
                    }

                    // ── 差集交叉表（首步；lvl==0 无次级别，不进表）──
                    if lvl >= 1 {
                        cross_t1[g][lvl][div_ok as usize][sub_t1 as usize] += 1;
                        let wide = sub_t1 || sub_pd;
                        cross_wide[g][lvl][div_ok as usize][wide as usize] += 1;
                        if !div_ok && cond > 0 {
                            cond_x_t1[g][cond as usize][sub_t1 as usize] += 1;
                            cond_x_wide[g][cond as usize][wide as usize] += 1;
                        }
                        if g == 0 {
                            let cell = &mut xcell[div_ok as usize][sub_t1 as usize];
                            if *cell < CELL_CAP {
                                *cell += 1;
                                let at1 = cls_i
                                    .levels
                                    .get(lvl - 1)
                                    .map(|t| bsp_at_coord(&t.bsp, src))
                                    .unwrap_or_default();
                                sample_x.push(format!(
                                        "| {lvl} | {src} | {} | {} | cond{cond} | {} | mask=0b{:06b} | pd_same={} | t1_any={} | t23_same={} |",
                                        if delta == Side::Long { "+1" } else { "-1" },
                                        if div_ok { "div_cand=真" } else { "div_cand=假" },
                                        if sub_t1 { "**BSP层认**" } else { "BSP层不认" },
                                        at1.mask,
                                        sub_pd,
                                        at1.t1_any(),
                                        at1.t23_side(delta),
                                    ));
                            }
                        }
                    }
                    sigs.push((g, lvl, src, delta, div_ok, cond));
                }
            }
        }
    }

    // ── 终局快照复查（防「同期查不到」被写成「不存在」）──
    for &(g, lvl, src, delta, _, _) in &sigs {
        for tl in (0..lvl).rev() {
            let Some(bl) = final_bsp.get(tl) else {
                continue;
            };
            let at = bsp_at_coord(bl, src);
            if at.present {
                f_present[g][lvl][tl] += 1;
            }
            if at.t1_side(delta) {
                f_t1_side[g][lvl][tl] += 1;
            }
            if at.t1_any() {
                f_t1_any[g][lvl][tl] += 1;
            }
            if let Some(pl) = final_pd.get(tl) {
                let (pa, ps) = pan_div_at_coord(pl, src, delta);
                if pa {
                    f_pd_any[g][lvl][tl] += 1;
                }
                if ps {
                    f_pd_side[g][lvl][tl] += 1;
                }
            }
        }
    }

    // ══════════════════════════ 报告 ══════════════════════════
    let pct = |x: usize, tot: usize| {
        if tot == 0 {
            0.0
        } else {
            100.0 * x as f64 / tot as f64
        }
    };
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# #848 原始数据：归类半句的第二把尺子——BSP 识别层 / pan_div 通道 vs `div_cand`"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "- issue: #848（承 #846；ADR 0013 裁定七归类半句）");
    let _ = writeln!(
        rpt,
        "- **认识论 L2**（真实 BTC 逐信号，两套确定性判据对照，可产否定性计数）"
    );
    let _ = writeln!(
        rpt,
        "- 窗口：{win_start}→{win_end}，bars={n}（全量={n_full}），max_bars={max_bars}"
    );
    let _ = writeln!(
        rpt,
        "- 信号集与 #846 **严格同批**（同去重键 / 同 Γ 定向 / 同群定义 / LMIN=0 LMAX=4）"
    );
    let _ = writeln!(rpt, "- 「BSP 层认」= `cls.levels[tl].bsp` 中存在 `source_index==src` 且带 **δ 同侧** `buy1`/`sell1` 的条目");
    let _ = writeln!(rpt, "- 「pan_div 认」= `cls.levels[tl].pan_div` 中存在 `source_index==src` 且 `side==δ` 的 `PanDivCert`");
    let _ = writeln!(
        rpt,
        "- 「宽口径认」= BSP 层认 ∨ pan_div 认（= 趋势背驰入口 ∪ 盘整背驰入口）"
    );
    let _ = writeln!(rpt);

    // 0. 基数自检（应与 #846 报告 §3 表逐格相等）
    let _ = writeln!(rpt, "## 0. 信号基数自检（与 #846 同批的可比性证据）");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| lvl | 去重BSP点数 | buy1 | buy2 | buy3 | sell1 | sell2 | sell3 | 带type1 bit | n_sig(Type1) | n_sig(Type2/3) | base_none 合计 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|---|---|");
    for lvl in LMIN..=LMAX {
        let _ = writeln!(
            rpt,
            "| {lvl} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} |",
            raw_pts[lvl],
            raw_bit[lvl][0],
            raw_bit[lvl][1],
            raw_bit[lvl][2],
            raw_bit[lvl][3],
            raw_bit[lvl][4],
            raw_bit[lvl][5],
            raw_t1_pts[lvl],
            n_sig[0][lvl],
            n_sig[1][lvl],
            base_none[0][lvl] + base_none[1][lvl]
        );
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "首步三分（与 #846 §4 的 `L→L−1` 首行同义）：");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| 群 | lvl | 信号数 | 首步成功 | A(空subs) | B(无对齐) | C(div假) | 成功% |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            if n_sig[g][lvl] == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {} | {lvl} | {} | {} | {} | {} | {} | {:.2}% |",
                gname(g),
                n_sig[g][lvl],
                first_ok[g][lvl],
                first_a[g][lvl],
                first_b[g][lvl],
                first_c[g][lvl],
                pct(first_ok[g][lvl], n_sig[g][lvl])
            );
        }
    }
    let _ = writeln!(rpt);

    // 1. BSP 层逐级命中率
    let _ = writeln!(rpt, "## 1. 读数一：BSP 识别层认不认（逐级向下，同期读数）");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 群 | 信号级 lvl | 目标级 tl | 查询数 | 该级缺失 | 坐标存在BSP条目 | 其中带任意bit | **同侧buy1/sell1** | 任意侧一类bit | 同侧2/3类bit | **同侧一类命中%** |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            for tl in (0..lvl).rev() {
                if q_n[g][lvl][tl] == 0 {
                    continue;
                }
                let _ = writeln!(
                    rpt,
                    "| {} | {lvl} | {tl} | {} | {} | {} | {} | **{}** | {} | {} | **{:.2}%** |",
                    gname(g),
                    q_n[g][lvl][tl],
                    q_absent[g][lvl][tl],
                    q_present[g][lvl][tl],
                    q_anybit[g][lvl][tl],
                    q_t1_side[g][lvl][tl],
                    q_t1_any[g][lvl][tl],
                    q_t23_side[g][lvl][tl],
                    pct(q_t1_side[g][lvl][tl], q_n[g][lvl][tl])
                );
            }
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "### 1.1 终局快照复查（末 bar 的累积 `bsp`；差值 = 同期没标、后来标上的量）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 群 | lvl | tl | 查询数 | 同期同侧一类 | **终局同侧一类** | 同期存在坐标 | 终局存在坐标 | 终局任意侧一类 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            for tl in (0..lvl).rev() {
                if q_n[g][lvl][tl] == 0 {
                    continue;
                }
                let _ = writeln!(
                    rpt,
                    "| {} | {lvl} | {tl} | {} | {} | **{}** | {} | {} | {} |",
                    gname(g),
                    q_n[g][lvl][tl],
                    q_t1_side[g][lvl][tl],
                    f_t1_side[g][lvl][tl],
                    q_present[g][lvl][tl],
                    f_present[g][lvl][tl],
                    f_t1_any[g][lvl][tl]
                );
            }
        }
    }
    let _ = writeln!(rpt);

    // 2. pan_div
    let _ = writeln!(
        rpt,
        "## 2. 读数二：pan_div 通道认不认（`div_cand` 缺的盘整背驰入口的替代观测）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 群 | 信号级 lvl | 目标级 tl | 查询数 | 同期任意侧 | **同期同侧** | 终局任意侧 | **终局同侧** | 同期同侧% |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            for tl in (0..lvl).rev() {
                if q_n[g][lvl][tl] == 0 {
                    continue;
                }
                let _ = writeln!(
                    rpt,
                    "| {} | {lvl} | {tl} | {} | {} | **{}** | {} | **{}** | {:.2}% |",
                    gname(g),
                    q_n[g][lvl][tl],
                    q_pd_any[g][lvl][tl],
                    q_pd_side[g][lvl][tl],
                    f_pd_any[g][lvl][tl],
                    f_pd_side[g][lvl][tl],
                    pct(q_pd_side[g][lvl][tl], q_n[g][lvl][tl])
                );
            }
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "全窗 pan_div 证书总量（末 bar 累积列表长度，用于分辨「通道空转」与「通道有货但不在这些坐标上」）：");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| lvl | `pan_div` 证书条数 | `bsp` 条目数（含零 bit） |"
    );
    let _ = writeln!(rpt, "|---|---|---|");
    for tl in LMIN..=LMAX {
        let _ = writeln!(
            rpt,
            "| {tl} | {} | {} |",
            final_pd.get(tl).map(|v| v.len()).unwrap_or(0),
            final_bsp.get(tl).map(|v| v.len()).unwrap_or(0)
        );
    }
    let _ = writeln!(rpt);

    // 3. 差集交叉表
    let _ = writeln!(rpt, "## 3. 读数三：★两套判据的差集（首步 L→L−1，lvl≥1）");
    let _ = writeln!(rpt);
    for (tag, tab) in [
        ("窄口径（BSP 层同侧一类 bit）", &cross_t1),
        ("宽口径（BSP 层 ∨ pan_div，同侧）", &cross_wide),
    ] {
        let _ = writeln!(
            rpt,
            "### 3.{} {tag}",
            if tag.starts_with('窄') { 1 } else { 2 }
        );
        let _ = writeln!(rpt);
        let _ = writeln!(rpt, "| 群 | lvl | div真∧层认 | div真∧层不认 | **div假∧层认** | **两边都不认** | 合计 | 层认合计 | 层认% | div真% |");
        let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|");
        for g in 0..NG {
            let mut acc = [[0usize; 2]; 2];
            for lvl in 1..=LMAX {
                let c = tab[g][lvl];
                let tot = c[0][0] + c[0][1] + c[1][0] + c[1][1];
                if tot == 0 {
                    continue;
                }
                for a in 0..2 {
                    for b in 0..2 {
                        acc[a][b] += c[a][b];
                    }
                }
                let _ = writeln!(
                    rpt,
                    "| {} | {lvl} | {} | {} | **{}** | **{}** | {tot} | {} | {:.2}% | {:.2}% |",
                    gname(g),
                    c[1][1],
                    c[1][0],
                    c[0][1],
                    c[0][0],
                    c[1][1] + c[0][1],
                    pct(c[1][1] + c[0][1], tot),
                    pct(c[1][0] + c[1][1], tot)
                );
            }
            let tot = acc[0][0] + acc[0][1] + acc[1][0] + acc[1][1];
            if tot > 0 {
                let _ = writeln!(
                        rpt,
                        "| **{} lvl≥1 小计** | — | {} | {} | **{}** | **{}** | **{tot}** | **{}** | **{:.2}%** | **{:.2}%** |",
                        gname(g),
                        acc[1][1],
                        acc[1][0],
                        acc[0][1],
                        acc[0][0],
                        acc[1][1] + acc[0][1],
                        pct(acc[1][1] + acc[0][1], tot),
                        pct(acc[1][0] + acc[1][1], tot)
                    );
            }
        }
        let _ = writeln!(rpt);
    }

    // 4. cond × BSP 层
    let _ = writeln!(
        rpt,
        "## 4. 读数四：`div_cand` 失败条件号 × BSP 层认不认（分歧定位）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| 群 | 失败条件 | C 类计数 | 窄口径层认 | 层认% | 宽口径层认 | 宽口径% |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
    let cond_name = |c: usize| match c {
        1 => "cond1 方向≠−δ",
        2 => "cond2 D-3 取段失败",
        3 => "cond3 Extreme 假",
        4 => "cond4 Weak 假",
        _ => "cond0 越界",
    };
    for g in 0..NG {
        for c in 0..5 {
            let tot = cond_x_t1[g][c][0] + cond_x_t1[g][c][1];
            if tot == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {} | {} | {tot} | {} | {:.2}% | {} | {:.2}% |",
                gname(g),
                cond_name(c),
                cond_x_t1[g][c][1],
                pct(cond_x_t1[g][c][1], tot),
                cond_x_wide[g][c][1],
                pct(cond_x_wide[g][c][1], tot)
            );
        }
    }
    let _ = writeln!(rpt);

    // 5. 取样
    let _ = writeln!(rpt, "## 5. Type1 四格取样（每格 ≤{CELL_CAP} 例）");
    let _ = writeln!(rpt);
    if sample_x.is_empty() {
        let _ = writeln!(rpt, "**（空——无 Type1 lvl≥1 信号）**");
    } else {
        let _ = writeln!(rpt, "| 信号级 | src | δ | div_cand | 首个失败条件 | BSP层 | 次级别 mask | pan_div同侧 | 任意侧一类 | 同侧2/3类 |");
        let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|");
        for l in &sample_x {
            let _ = writeln!(rpt, "{l}");
        }
    }
    let _ = writeln!(rpt);

    // 6. 忠实性与域外
    let _ = writeln!(rpt, "## 6. 忠实性校验与域外声明");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- ★#883：`div_cand_why` 镜像退役——直调生产 `div_cand_fail`，parity 由构造保证"
    );
    let _ = writeln!(
        rpt,
        "- 残差群（带 δ 但无任何 bsp bit 命中该方向）：{n_other} 条，两群皆不计"
    );
    let _ = writeln!(
        rpt,
        "- 台账信号条数：{}（= Σn_sig − Σbase_none）",
        sigs.len()
    );
    let _ = writeln!(
        rpt,
        "- 终局快照取自末可交易 bar：{last_bar:?}；`final_bsp` 级数={}，`final_pd` 级数={}",
        final_bsp.len(),
        final_pd.len()
    );
    let _ = writeln!(
        rpt,
        "- **本探针不改任何判据**，只测现有两套判据各自认什么；「类一类点」准入判据归 #817 未裁"
    );
    let _ = writeln!(rpt);

    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(format!(
            ".chanlun/review-results/issue848-bsp-crosscheck-raw-b{n}.md"
        ));
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n原始数据已落盘：{out:?}");

    // ── 真封 ──
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            let sum = base_none[g][lvl]
                + first_ok[g][lvl]
                + first_a[g][lvl]
                + first_b[g][lvl]
                + first_c[g][lvl];
            assert_eq!(
                sum,
                n_sig[g][lvl],
                "{} lvl{lvl} 穷举：base_none+首步四分({sum}) 应 = 信号总数({})",
                gname(g),
                n_sig[g][lvl]
            );
        }
    }
    eprintln!(
        "真封：Type1={} 条 / Type2-3={} 条",
        n_sig[0].iter().sum::<usize>(),
        n_sig[1].iter().sum::<usize>()
    );
}

/// **#848 后半程：BSP 层「同侧一类 bit 恒零」的四假说判定探针**（只读诊断，不改生产，`#[ignore]`）。
///
/// ## 待判定的观测
///
/// `issue848-bsp-crosscheck-raw-b1200000.md` §1：「BSP 层同侧一类 bit 命中」在**所有格子、
/// 两个群、所有级别对**上恒为 `0`（0.00%）。同一批坐标上同侧 2/3 类 bit 有命中、`pan_div`
/// 同侧命中 13–16%，§0 又能数出 L0 有 27 个 `buy1` / 34 个 `sell1` ⟹ 「坐标系」与「读 bit」
/// 并非全坏。本探针判定该绝对零值是**真发现**还是**查询 bug**。
///
/// 前序数据已自排除两条：「同期没标后来标上」（§1.1 终局复查同为 0）、「方向判反」
/// （§1 任意侧一类 bit 同为 0）。本探针只测剩下四条，一次只变一个变量：
///
/// - **H3 坐标匹配 bug**：正控——用探针查询用的**同一个** [`bsp_at_coord`] 去查信号点
///   **自己所在级**（`tl == lvl`）。带 δ 同侧一类 bit 的 Type1 信号按构造必须 100% 自命中；
///   不足 100% ⟹ 匹配那一环坏，其余假说作废。
/// - **H4 级别错位**：(a) 目标级从 `lvl−1` 扩到 `tl ∈ {lvl−2, lvl−1, lvl, lvl+1}` 逐偏移算
///   同侧一类命中率；(b) **坐标空间归属矩阵**——各级 `bsp` 的 `source_index` 集落在哪一层
///   `tower[j]` 的 `end_index` 集里。(b) 是错位假说的判定式版本，比偏移扫描更直接。
/// - **H1 一类点稀疏 ⟹ 物理上撞不上**：反查——各级一类点坐标集 ∩ 上一级 Type1 信号坐标集；
///   再加「信号坐标 → 最近次级别一类点」的距离直方图（0 / 1–5 / 6–50 / 51–500 / >500），
///   把「根本不在附近」与「差几个 bar 的端点约定错配」分开。
/// - **H2 命题不成立**：对「坐标存在次级别 BSP 条目」的 Type1 案例逐条 dump 六 bit 分布，
///   答「次级别实际标成了什么」。
///
/// ## 口径
///
/// 与 [`type1_bsp_layer_crosscheck_dx`] 严格同批（同数据、同 `IncrementalClassifier` 逐 bar
/// 循环、同 `seen` 去重键 `(lvl, source_index, bsp_disc)`、同 `LMIN=0`/`LMAX=4`、同 Γ 定向、
/// 同群定义）。§0 的 `n_sig` 逐格与前序报告对照即自检。
///
/// 「union（同期并集）」= 逐 bar 见过的全部去重条目之并（比终局快照宽——终局列表会因结构
/// 改写丢点，前序 §2 已见 L0 终局 3972 < 去重 4891）；反查与距离直方图一律取 union，取的是
/// **对命题最有利**的口径，避免把「快照丢了」写成「命题不成立」。
///
/// **认识论 L2**（真实 BTC 逐信号，确定性判据，可产否定性计数）。**本探针不改任何判据**。
///
/// 命令：`ECON_L2_MAX_BARS=1200000 cargo test --release type1_bsp_layer_zero_hypotheses_dx -- --ignored --nocapture`
#[test]
#[ignore]
fn type1_bsp_layer_zero_hypotheses_dx() {
    use super::super::data;
    use std::collections::HashSet;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    let max_bars = std::env::var(crate::theta_v0::env_registry::ECON_L2_MAX_BARS)
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(usize::MAX);
    let ds = if n_full > max_bars {
        ds_full.slice_bar_range(n_full - max_bars, n_full)
    } else {
        ds_full
    };
    let bars = &ds.bars;
    let n = bars.len();
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[t1-zero-hyp] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    const LMIN: usize = 0;
    const LMAX: usize = 4;
    const NG: usize = 2;
    const NOFF: usize = 4;
    /// H4 偏移扫描的目标级偏移（`tl = lvl + OFFS[o]`）。
    const OFFS: [i64; NOFF] = [-2, -1, 0, 1];
    let gname = |g: usize| if g == 0 { "Type1" } else { "Type2/3" };
    let in_scope = |lvl: usize| (LMIN..=LMAX).contains(&lvl);

    let mut n_sig = [[0usize; LMAX + 1]; NG];
    let mut n_other = 0usize;

    // ── H3 正控：自查同级（同期 + 终局）──
    let mut h3_present = [[0usize; LMAX + 1]; NG];
    let mut h3_t1_side = [[0usize; LMAX + 1]; NG];
    let mut h3_f_present = [[0usize; LMAX + 1]; NG];
    let mut h3_f_t1_side = [[0usize; LMAX + 1]; NG];

    // ── H4(a) 偏移扫描 [群][信号级][偏移] ──
    let mut h4_n = [[[0usize; NOFF]; LMAX + 1]; NG];
    let mut h4_absent = [[[0usize; NOFF]; LMAX + 1]; NG];
    let mut h4_present = [[[0usize; NOFF]; LMAX + 1]; NG];
    let mut h4_t1side = [[[0usize; NOFF]; LMAX + 1]; NG];
    let mut h4_t1any = [[[0usize; NOFF]; LMAX + 1]; NG];

    // ── H2 次级别六 bit 直方图（Type1，`tl = lvl−1`，仅坐标存在条目的案例）──
    let mut h2_bit = [[0usize; 6]; LMAX + 1];
    let mut h2_present_cnt = [0usize; LMAX + 1];
    let mut h2_zero_mask = [0usize; LMAX + 1];
    const H2_CAP: usize = 40;
    let mut h2_dump: Vec<String> = Vec::new();

    // ── union（同期并集）：坐标集，用于 H1 反查与距离直方图 ──
    let mut u_all: Vec<HashSet<usize>> = (0..=LMAX).map(|_| HashSet::new()).collect();
    let mut u_t1_long: Vec<HashSet<usize>> = (0..=LMAX).map(|_| HashSet::new()).collect();
    let mut u_t1_short: Vec<HashSet<usize>> = (0..=LMAX).map(|_| HashSet::new()).collect();
    // 信号坐标（按群/级/侧），用于反查方向
    let mut u_sig_t1_long: Vec<HashSet<usize>> = (0..=LMAX).map(|_| HashSet::new()).collect();
    let mut u_sig_t1_short: Vec<HashSet<usize>> = (0..=LMAX).map(|_| HashSet::new()).collect();
    let mut u_sig_all: Vec<HashSet<usize>> = (0..=LMAX).map(|_| HashSet::new()).collect();

    // 终局快照
    let last_bar = (0..n)
        .rev()
        .find(|&i| !bars[i].untradable && bars[i].close > 0);
    let mut final_bsp: Vec<Rc<Vec<BspPoint>>> = Vec::new();
    let mut final_tower: Vec<Rc<Vec<LeveledMove>>> = Vec::new();
    // 台账：(g, lvl, src, delta)
    let mut sigs: Vec<(usize, usize, usize, Side)> = Vec::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __wl8 = classifier_incr.classify_at(i);
        let cls_i = __wl8.classification;
        let tower_i = __wl8.tower;
        if Some(i) == last_bar {
            final_bsp = cls_i.levels.iter().map(|l| Rc::clone(&l.bsp)).collect();
            final_tower = tower_i.clone();
        }
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if !in_scope(lvl) {
                continue;
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                // union 收集在零 bit 过滤**之前**（`u_all` 含零 bit 结构候选，与
                // `bsp_at_coord().present` 同口径）。
                u_all[lvl].insert(p.source_index);
                if p.bits.buy1 {
                    u_t1_long[lvl].insert(p.source_index);
                }
                if p.bits.sell1 {
                    u_t1_short[lvl].insert(p.source_index);
                }
                if !(p.bits.buy1
                    || p.bits.sell1
                    || p.bits.buy2
                    || p.bits.sell2
                    || p.bits.buy3
                    || p.bits.sell3)
                {
                    continue;
                }
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()),
                            first_class_grades: Rc::new(Vec::new()), // #885：同 pan_div 口径（single 屏蔽层无分级记录载荷）
                            level_projection: None,
                        })
                        .collect(),
                };
                let cands = assemble_gamma_with_tower(&single, &tower_i);
                for c in &cands {
                    let delta = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    let src = p.source_index;
                    let is_type1 = match delta {
                        Side::Long => p.bits.buy1,
                        Side::Short => p.bits.sell1,
                    };
                    let is_type2 = match delta {
                        Side::Long => p.bits.buy2,
                        Side::Short => p.bits.sell2,
                    };
                    let is_type3 = match delta {
                        Side::Long => p.bits.buy3,
                        Side::Short => p.bits.sell3,
                    };
                    let g = if is_type1 {
                        0
                    } else if is_type2 || is_type3 {
                        1
                    } else {
                        n_other += 1;
                        continue;
                    };
                    n_sig[g][lvl] += 1;
                    u_sig_all[lvl].insert(src);
                    if g == 0 {
                        match delta {
                            Side::Long => u_sig_t1_long[lvl].insert(src),
                            Side::Short => u_sig_t1_short[lvl].insert(src),
                        };
                    }

                    // ── H3 正控：用同一个 `bsp_at_coord` 查信号点自己所在级 ──
                    let self_at = bsp_at_coord(&cls_i.levels[lvl].bsp, src);
                    if self_at.present {
                        h3_present[g][lvl] += 1;
                    }
                    if self_at.t1_side(delta) {
                        h3_t1_side[g][lvl] += 1;
                    }

                    // ── H4(a) 偏移扫描 ──
                    for (o, &d) in OFFS.iter().enumerate() {
                        let t = lvl as i64 + d;
                        if t < 0 {
                            continue;
                        }
                        let tl = t as usize;
                        h4_n[g][lvl][o] += 1;
                        let Some(tls) = cls_i.levels.get(tl) else {
                            h4_absent[g][lvl][o] += 1;
                            continue;
                        };
                        let at = bsp_at_coord(&tls.bsp, src);
                        if at.present {
                            h4_present[g][lvl][o] += 1;
                        }
                        if at.t1_side(delta) {
                            h4_t1side[g][lvl][o] += 1;
                        }
                        if at.t1_any() {
                            h4_t1any[g][lvl][o] += 1;
                        }
                    }

                    // ── H2：次级别（`lvl−1`）六 bit 分布 ──
                    if g == 0 && lvl >= 1 {
                        if let Some(tls) = cls_i.levels.get(lvl - 1) {
                            let at = bsp_at_coord(&tls.bsp, src);
                            if at.present {
                                h2_present_cnt[lvl] += 1;
                                if at.mask == 0 {
                                    h2_zero_mask[lvl] += 1;
                                }
                                for b in 0..6 {
                                    if at.mask & (1u8 << b) != 0 {
                                        h2_bit[lvl][b] += 1;
                                    }
                                }
                                if h2_dump.len() < H2_CAP {
                                    h2_dump.push(format!(
                                        "| {lvl} | {src} | {} | 0b{:06b} | {} |",
                                        if delta == Side::Long { "+1" } else { "-1" },
                                        at.mask,
                                        bit_names(at.mask),
                                    ));
                                }
                            }
                        }
                    }
                    sigs.push((g, lvl, src, delta));
                }
            }
        }
    }

    // ── H3 终局自查（同坐标 → 终局累积 `bsp` 列表）──
    for &(g, lvl, src, delta) in &sigs {
        let Some(bl) = final_bsp.get(lvl) else {
            continue;
        };
        let at = bsp_at_coord(bl, src);
        if at.present {
            h3_f_present[g][lvl] += 1;
        }
        if at.t1_side(delta) {
            h3_f_t1_side[g][lvl] += 1;
        }
    }

    // ── H4(b) 坐标空间归属矩阵（终局快照）──
    let tower_ends: Vec<HashSet<usize>> = final_tower
        .iter()
        .map(|lv| lv.iter().map(|m| m.end_index).collect())
        .collect();
    let f_bsp_coord: Vec<HashSet<usize>> = final_bsp
        .iter()
        .map(|l| l.iter().map(|p| p.source_index).collect())
        .collect();
    let f_bsp_t1_coord: Vec<HashSet<usize>> = final_bsp
        .iter()
        .map(|l| {
            l.iter()
                .filter(|p| p.bits.buy1 || p.bits.sell1)
                .map(|p| p.source_index)
                .collect()
        })
        .collect();

    // ── H1 距离直方图：信号坐标 → 最近的次级别一类点 / 任意 BSP 条目 ──
    let sorted = |s: &HashSet<usize>| {
        let mut v: Vec<usize> = s.iter().copied().collect();
        v.sort_unstable();
        v
    };
    let u_t1_any: Vec<Vec<usize>> = (0..=LMAX)
        .map(|k| {
            let mut v: Vec<usize> = u_t1_long[k].union(&u_t1_short[k]).copied().collect();
            v.sort_unstable();
            v
        })
        .collect();
    let u_t1_long_s: Vec<Vec<usize>> = (0..=LMAX).map(|k| sorted(&u_t1_long[k])).collect();
    let u_t1_short_s: Vec<Vec<usize>> = (0..=LMAX).map(|k| sorted(&u_t1_short[k])).collect();
    let u_all_s: Vec<Vec<usize>> = (0..=LMAX).map(|k| sorted(&u_all[k])).collect();

    // 桶：0=命中(0) 1=1–5 2=6–50 3=51–500 4=>500 5=该级空集
    let mut d_t1_side = [[0usize; 6]; LMAX + 1];
    let mut d_t1_any = [[0usize; 6]; LMAX + 1];
    let mut d_anybsp = [[0usize; 6]; LMAX + 1];
    for &(g, lvl, src, delta) in &sigs {
        if g != 0 || lvl == 0 {
            continue;
        }
        let k = lvl - 1;
        let side_set = match delta {
            Side::Long => &u_t1_long_s[k],
            Side::Short => &u_t1_short_s[k],
        };
        d_t1_side[lvl][dist_bucket(nearest_dist(side_set, src))] += 1;
        d_t1_any[lvl][dist_bucket(nearest_dist(&u_t1_any[k], src))] += 1;
        d_anybsp[lvl][dist_bucket(nearest_dist(&u_all_s[k], src))] += 1;
    }

    // ══════════════════════════ 报告 ══════════════════════════
    let pct = |x: usize, tot: usize| {
        if tot == 0 {
            0.0
        } else {
            100.0 * x as f64 / tot as f64
        }
    };
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# #848 后半程原始数据：BSP 层同侧一类 bit 恒零的四假说判定"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- issue: #848（承 #846 / 前序 `issue848-bsp-crosscheck-raw-b*.md`）"
    );
    let _ = writeln!(
        rpt,
        "- **认识论 L2**（真实 BTC 逐信号，确定性判据，可产否定性计数）"
    );
    let _ = writeln!(
        rpt,
        "- 窗口：{win_start}→{win_end}，bars={n}（全量={n_full}），max_bars={max_bars}"
    );
    let _ = writeln!(rpt, "- 与前序探针 `type1_bsp_layer_crosscheck_dx` **严格同批**（同去重键 / 同 Γ 定向 / 同群定义 / LMIN=0 LMAX=4）");
    let _ = writeln!(
        rpt,
        "- 「union」= 逐 bar 去重条目之并（比终局快照宽，取对命题最有利口径）"
    );
    let _ = writeln!(rpt);

    // §0 基数
    let _ = writeln!(rpt, "## 0. 信号基数（与前序 §0 对照即自检）");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| lvl | n_sig(Type1) | n_sig(Type2/3) | union 全 BSP 坐标 | union buy1 坐标 | union sell1 坐标 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for lvl in LMIN..=LMAX {
        let _ = writeln!(
            rpt,
            "| {lvl} | {} | {} | {} | {} | {} |",
            n_sig[0][lvl],
            n_sig[1][lvl],
            u_all[lvl].len(),
            u_t1_long[lvl].len(),
            u_t1_short[lvl].len()
        );
    }
    let _ = writeln!(rpt);

    // §1 H3
    let _ = writeln!(
        rpt,
        "## 1. H3（坐标匹配 bug）：正控——同一个 `bsp_at_coord` 查信号点**自己所在级**"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "按构造，Type1 信号的 δ 同侧一类 bit 必在本级自命中 ⟹ **同期同侧一类 = 信号数** 是硬预测。"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 群 | lvl | 信号数 | 同期坐标存在 | **同期同侧一类** | 自命中% | 终局坐标存在 | 终局同侧一类 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            if n_sig[g][lvl] == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {} | {lvl} | {} | {} | **{}** | **{:.2}%** | {} | {} |",
                gname(g),
                n_sig[g][lvl],
                h3_present[g][lvl],
                h3_t1_side[g][lvl],
                pct(h3_t1_side[g][lvl], n_sig[g][lvl]),
                h3_f_present[g][lvl],
                h3_f_t1_side[g][lvl]
            );
        }
    }
    let _ = writeln!(rpt);

    // §2 H4(a)
    let _ = writeln!(
        rpt,
        "## 2. H4(a)（级别错位）：目标级偏移扫描 `tl ∈ {{lvl−2, lvl−1, lvl, lvl+1}}`"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 群 | 信号级 lvl | 偏移 | 目标级 tl | 查询数 | 该级缺失 | 坐标存在 | **同侧一类** | 任意侧一类 | **同侧一类%** |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        for lvl in LMIN..=LMAX {
            for (o, &d) in OFFS.iter().enumerate() {
                if h4_n[g][lvl][o] == 0 {
                    continue;
                }
                let tl = lvl as i64 + d;
                let _ = writeln!(
                    rpt,
                    "| {} | {lvl} | {d:+} | {tl} | {} | {} | {} | **{}** | {} | **{:.2}%** |",
                    gname(g),
                    h4_n[g][lvl][o],
                    h4_absent[g][lvl][o],
                    h4_present[g][lvl][o],
                    h4_t1side[g][lvl][o],
                    h4_t1any[g][lvl][o],
                    pct(h4_t1side[g][lvl][o], h4_n[g][lvl][o])
                );
            }
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "偏移小计（两群合并，跨信号级汇总）：");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| 群 | 偏移 | 查询数 | 坐标存在 | **同侧一类** | **同侧一类%** |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for g in 0..NG {
        for (o, &d) in OFFS.iter().enumerate() {
            let tot: usize = (LMIN..=LMAX).map(|l| h4_n[g][l][o]).sum();
            if tot == 0 {
                continue;
            }
            let pr: usize = (LMIN..=LMAX).map(|l| h4_present[g][l][o]).sum();
            let hit: usize = (LMIN..=LMAX).map(|l| h4_t1side[g][l][o]).sum();
            let _ = writeln!(
                rpt,
                "| {} | {d:+} | {tot} | {pr} | **{hit}** | **{:.2}%** |",
                gname(g),
                pct(hit, tot)
            );
        }
    }
    let _ = writeln!(rpt);

    // §3 H4(b)
    let _ = writeln!(
        rpt,
        "## 3. H4(b)（级别错位·判定式）：BSP 坐标空间归属矩阵（终局快照）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "各级 `bsp` 的 `source_index` 集 ∩ 各层 `tower[j]` 的 `end_index` 集。若 `levels[k]` 与 `tower[k]`");
    let _ = writeln!(
        rpt,
        "同套编号，则 `j == k` 那一格应 100%；命中峰落在 `j ≠ k` ⟹ 错位坐实。"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "`tower[j]` 端点集基数：");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| j | tower[j] 元素数 | 去重 end_index 数 |");
    let _ = writeln!(rpt, "|---|---|---|");
    for (j, t) in final_tower.iter().enumerate() {
        let _ = writeln!(rpt, "| {j} | {} | {} |", t.len(), tower_ends[j].len());
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| bsp 级 k | 坐标数(全部) | {} |",
        (0..final_tower.len())
            .map(|j| format!("∈tower[{j}]"))
            .collect::<Vec<_>>()
            .join(" | ")
    );
    let _ = writeln!(rpt, "|---|---|{}", "---|".repeat(final_tower.len()));
    for (k, s) in f_bsp_coord.iter().enumerate() {
        let cells: Vec<String> = (0..final_tower.len())
            .map(|j| {
                let c = s.intersection(&tower_ends[j]).count();
                format!("{c} ({:.1}%)", pct(c, s.len()))
            })
            .collect();
        let _ = writeln!(rpt, "| {k} | {} | {} |", s.len(), cells.join(" | "));
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "仅**带一类 bit** 的坐标：");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| bsp 级 k | 一类坐标数 | {} |",
        (0..final_tower.len())
            .map(|j| format!("∈tower[{j}]"))
            .collect::<Vec<_>>()
            .join(" | ")
    );
    let _ = writeln!(rpt, "|---|---|{}", "---|".repeat(final_tower.len()));
    for (k, s) in f_bsp_t1_coord.iter().enumerate() {
        let cells: Vec<String> = (0..final_tower.len())
            .map(|j| {
                let c = s.intersection(&tower_ends[j]).count();
                format!("{c} ({:.1}%)", pct(c, s.len()))
            })
            .collect();
        let _ = writeln!(rpt, "| {k} | {} | {} |", s.len(), cells.join(" | "));
    }
    let _ = writeln!(rpt);

    // §4 H1 反查
    let _ = writeln!(
        rpt,
        "## 4. H1（稀疏 ⟹ 撞不上）：反查 + 距离直方图（union 口径）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "### 4.1 反查：次级别一类点坐标集 ∩ 本级 Type1 信号坐标集"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "命题若成立，`lvl` 的每个 Type1 信号应「用掉」`lvl−1` 的一个一类点 ⟹ 交集 ≈ 信号数。"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 信号级 lvl | Type1 信号坐标数 | lvl−1 一类点坐标数 | **同侧交集** | 任意侧交集 | 与 lvl−1 全 BSP 坐标交集 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for lvl in 1..=LMAX {
        let k = lvl - 1;
        let sig_cnt = u_sig_t1_long[lvl].len() + u_sig_t1_short[lvl].len();
        if sig_cnt == 0 {
            continue;
        }
        let same = u_sig_t1_long[lvl].intersection(&u_t1_long[k]).count()
            + u_sig_t1_short[lvl].intersection(&u_t1_short[k]).count();
        let anys = u_sig_t1_long[lvl]
            .iter()
            .chain(u_sig_t1_short[lvl].iter())
            .filter(|s| u_t1_long[k].contains(s) || u_t1_short[k].contains(s))
            .count();
        let inall = u_sig_t1_long[lvl]
            .iter()
            .chain(u_sig_t1_short[lvl].iter())
            .filter(|s| u_all[k].contains(s))
            .count();
        let _ = writeln!(
            rpt,
            "| {lvl} | {sig_cnt} | {} | **{same}** | {anys} | {inall} |",
            u_t1_long[k].len() + u_t1_short[k].len()
        );
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "反方向（次级别一类点里有多少被本级 Type1 信号「用掉」）："
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 次级别 k | k 级一类点坐标数 | 其中 = 某个 k+1 级 Type1 信号坐标 | 占比 | 其中 = 某个 k+1 级**任意群**信号坐标 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|");
    for k in 0..LMAX {
        let pts: Vec<usize> = u_t1_long[k].union(&u_t1_short[k]).copied().collect();
        if pts.is_empty() {
            continue;
        }
        let used = pts
            .iter()
            .filter(|c| u_sig_t1_long[k + 1].contains(c) || u_sig_t1_short[k + 1].contains(c))
            .count();
        let used_any = pts.iter().filter(|c| u_sig_all[k + 1].contains(c)).count();
        let _ = writeln!(
            rpt,
            "| {k} | {} | {used} | {:.2}% | {used_any} |",
            pts.len(),
            pct(used, pts.len())
        );
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "### 4.2 距离直方图：Type1 信号坐标 → 最近的次级别标的（bar 数）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "「0」= 坐标重合；「空集」= 该次级别根本没有此类标的。");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| 目标 | 信号级 lvl | 0 | 1–5 | 6–50 | 51–500 | >500 | 空集 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|");
    for (nm, tab) in [
        ("次级别同侧一类点", &d_t1_side),
        ("次级别任意侧一类点", &d_t1_any),
        ("次级别任意 BSP 条目", &d_anybsp),
    ] {
        for lvl in 1..=LMAX {
            if tab[lvl].iter().sum::<usize>() == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {nm} | {lvl} | {} | {} | {} | {} | {} | {} |",
                tab[lvl][0], tab[lvl][1], tab[lvl][2], tab[lvl][3], tab[lvl][4], tab[lvl][5]
            );
        }
    }
    let _ = writeln!(rpt);

    // §5 H2
    let _ = writeln!(
        rpt,
        "## 5. H2（命题不成立）：次级别实际标成了什么（Type1，`tl = lvl−1`，仅坐标存在条目）"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 信号级 lvl | Type1 信号数 | 坐标存在条目 | mask=0（纯结构候选） | buy1 | buy2 | buy3 | sell1 | sell2 | sell3 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|");
    for lvl in 1..=LMAX {
        if n_sig[0][lvl] == 0 {
            continue;
        }
        let _ = writeln!(
            rpt,
            "| {lvl} | {} | {} | {} | {} | {} | {} | {} | {} | {} |",
            n_sig[0][lvl],
            h2_present_cnt[lvl],
            h2_zero_mask[lvl],
            h2_bit[lvl][0],
            h2_bit[lvl][1],
            h2_bit[lvl][2],
            h2_bit[lvl][3],
            h2_bit[lvl][4],
            h2_bit[lvl][5]
        );
    }
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "逐条 dump（≤{H2_CAP} 例）：");
    let _ = writeln!(rpt);
    if h2_dump.is_empty() {
        let _ = writeln!(
            rpt,
            "**（空——无「坐标存在次级别 BSP 条目」的 Type1 案例）**"
        );
    } else {
        let _ = writeln!(rpt, "| 信号级 | src | δ | 次级别 mask | 置位 bit |");
        let _ = writeln!(rpt, "|---|---|---|---|---|");
        for l in &h2_dump {
            let _ = writeln!(rpt, "{l}");
        }
    }
    let _ = writeln!(rpt);

    // §6 忠实性
    let _ = writeln!(rpt, "## 6. 忠实性校验与域外声明");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- 残差群（带 δ 但无任何 bsp bit 命中该方向）：{n_other} 条，两群皆不计"
    );
    let _ = writeln!(rpt, "- 台账信号条数：{}", sigs.len());
    let _ = writeln!(
        rpt,
        "- 终局快照取自末可交易 bar：{last_bar:?}；`final_bsp` 级数={}，`final_tower` 层数={}",
        final_bsp.len(),
        final_tower.len()
    );
    let _ = writeln!(
        rpt,
        "- **本探针不改任何判据**，只判定前序全零读数的归属；「类一类点」准入判据归 #817 未裁"
    );
    let _ = writeln!(rpt);

    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(format!(
            ".chanlun/review-results/issue848-zero-hypotheses-raw-b{n}.md"
        ));
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n原始数据已落盘：{out:?}");

    // ── 真封：H3 正控是硬预测（自命中必须 100%），破了即查询路径坏 ──
    for lvl in LMIN..=LMAX {
        assert_eq!(
            h3_t1_side[0][lvl], n_sig[0][lvl],
            "H3 正控破：Type1 lvl{lvl} 自查同级同侧一类命中 {} ≠ 信号数 {} \
                 ⟹ `bsp_at_coord` 坐标匹配那一环有 bug",
            h3_t1_side[0][lvl], n_sig[0][lvl]
        );
    }
    eprintln!(
        "真封：H3 正控通过（Type1 自命中 {}/{}）；Type1={} 条 / Type2-3={} 条",
        h3_t1_side[0].iter().sum::<usize>(),
        n_sig[0].iter().sum::<usize>(),
        n_sig[0].iter().sum::<usize>(),
        n_sig[1].iter().sum::<usize>()
    );
}

/// 六 bit mask → 人读名（[`bsp_disc`] 口径：0=buy1 1=buy2 2=buy3 3=sell1 4=sell2 5=sell3）。
fn bit_names(mask: u8) -> String {
    const NAMES: [&str; 6] = ["buy1", "buy2", "buy3", "sell1", "sell2", "sell3"];
    let v: Vec<&str> = (0..6)
        .filter(|b| mask & (1u8 << b) != 0)
        .map(|b| NAMES[b])
        .collect();
    if v.is_empty() {
        "（无）".to_string()
    } else {
        v.join("+")
    }
}

/// 升序坐标表里离 `x` 最近的元素距离（空集 ⟹ `None`）。
fn nearest_dist(sorted_coords: &[usize], x: usize) -> Option<usize> {
    if sorted_coords.is_empty() {
        return None;
    }
    let i = sorted_coords.partition_point(|&c| c < x);
    let mut best = usize::MAX;
    if i < sorted_coords.len() {
        best = best.min(sorted_coords[i] - x);
    }
    if i > 0 {
        best = best.min(x - sorted_coords[i - 1]);
    }
    Some(best)
}

/// 距离分桶：0=重合 1=1–5 2=6–50 3=51–500 4=>500 5=空集。
fn dist_bucket(d: Option<usize>) -> usize {
    match d {
        None => 5,
        Some(0) => 0,
        Some(x) if x <= 5 => 1,
        Some(x) if x <= 50 => 2,
        Some(x) if x <= 500 => 3,
        Some(_) => 4,
    }
}

// ═══════════════════════════════════════════════════════════════════════
// #851 探针：#848 漏数的那一层——「次级别二/三类 bit」∧「同坐标盘整背驰」的**交集**
// ═══════════════════════════════════════════════════════════════════════

/// 某级 `pan_div` 在坐标 `src` 上的**分侧**命中：`(Long 命中, Short 命中)`。
///
/// 与 [`pan_div_at_coord`] 的区别：那个把结果折成「任意侧 / δ 同侧」两个 bool，本函数保留
/// 原始两侧——#851 明确要求分清「大 buy1 ↔ 小**同侧**盘背」与「大 buy1 ↔ 小**反侧**盘背」，
/// 折叠口径会把这两件事混数。
fn pan_div_sides_at_coord(certs: &[PanDivCert], src: usize) -> (bool, bool) {
    let mut long_hit = false;
    let mut short_hit = false;
    for c in certs {
        if c.source_index == src {
            match c.side {
                Side::Long => long_hit = true,
                Side::Short => short_hit = true,
            }
        }
    }
    (long_hit, short_hit)
}

/// **#851 探针：交集口径重数 #848 的 34 例**（只读诊断，不改生产，不改判据，`#[ignore]`）。
///
/// ## 为什么要重数
///
/// #848 §4 统计「大级别 Type1 信号坐标上，次级别标了什么」，得 34 例中一类 bit **0 个**，
/// 实际 buy2×16 / buy3×6 / sell2×10 / sell3×4，据此判「归类半句不成立」。但 #848 把
/// **BSP 层一类 bit**（§1，窄口径恒 0）与 **`pan_div` 通道**（§2，宽口径 9.09%/13.57%）
/// **分开数**，从未数过二者的**交集**。
///
/// ADR 0013 裁定七的命题写的是「次级别一类点**或类一类点（盘整背驰）**」，原文承重：
/// - `101-第101课.md:32`「第二类买点跌破第一类买点……这里**一般都构成盘整背驰**」
/// - `060-第60课.md:50`「严格来说，**盘整背驰无所谓第一类买点，只是这样来类比**」
/// - `027-第27课.md:66`「这因为盘整背驰而形成的**类第一类买点**」
///
/// ⟹ 命题要的口径是「次级别二类 bit **∧** 同坐标盘整背驰」这个**交集**，不是两个分离计数。
///
/// ## 本探针测什么（四件）
///
/// 1. **交集交叉表**：34 例逐例给出次级别 BSP bit × 同坐标 `pan_div` 命中/同侧，至少四格
///    （标二类∧有盘背 / 标二类∧无 / 标三类∧有 / 标三类∧无）。
/// 2. **同侧反侧分开数**：逐例标明大级别 δ、次级别哪个 bit、同侧还是反侧。
///    「大 buy1 ↔ 小 sell2」与「大 buy1 ↔ 小 buy2」是两件事。
/// 3. 二类点的 `Type1Anchor` 归属锚（`make_second_point` 载 `OwnerRef::Type1Anchor`）——
///    答「大级别一类点坐标落在次级别二类点上时，那个二类点自己的一类锚在哪」。
/// 4. 全 66 例（含 32 例坐标无次级别条目）的 `pan_div` 覆盖，防「只看 34 例」的选择偏差。
///
/// ## 口径（与 #848 严格同批，否则两次读数不可比）
///
/// 同一份 BTC 数据、同一 `IncrementalClassifier` 逐 bar 循环、同一 `seen` 去重键
/// `(lvl, source_index, bsp_disc)`、同一 `LMIN=0`/`LMAX=4`、同一 Γ 定向、同一群定义。
/// §0 的 `n_sig` 逐格与 `issue848-bsp-crosscheck-raw-b1200000.md` §0 对照即自检。
///
/// ## 不裁教义
///
/// 「盘整背驰算不算类一类点、几段起算」归 #817，**本探针不裁**；只测现有两个载体在同一
/// 坐标上的共现。**不改判据、不碰生产代码。**
///
/// **认识论 L2**（真实 BTC 逐信号 + 确定性判据，可产否定性计数）。
///
/// 命令：`ECON_L2_MAX_BARS=1200000 cargo test --release type1_quasi_first_intersection_dx -- --ignored --nocapture`
#[test]
#[ignore]
fn type1_quasi_first_intersection_dx() {
    use super::super::super::classifier::bsp::OwnerRef;
    use super::super::data;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    let max_bars = std::env::var(crate::theta_v0::env_registry::ECON_L2_MAX_BARS)
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(usize::MAX);
    let ds = if n_full > max_bars {
        ds_full.slice_bar_range(n_full - max_bars, n_full)
    } else {
        ds_full
    };
    let bars = &ds.bars;
    let n = bars.len();
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!(
        "[t1-quasi-inter] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}"
    );

    const LMIN: usize = 0;
    const LMAX: usize = 4;
    const NG: usize = 2;
    let gname = |g: usize| if g == 0 { "Type1" } else { "Type2/3" };
    let in_scope = |lvl: usize| (LMIN..=LMAX).contains(&lvl);

    let mut n_sig = [[0usize; LMAX + 1]; NG];
    let mut raw_t1_pts = [0usize; LMAX + 1];
    let mut n_other = 0usize;

    // ── 坐标级 4×3 交叉表：[群][类别][pd 列] ──
    // 类别 0=带二类bit（任意侧） 1=不带二类但带三类bit 2=带一类bit 3=mask==0（纯结构候选）
    // pd 列 0=同侧 pan_div  1=仅反侧 pan_div  2=无 pan_div
    let mut cross_cat = [[[0usize; 3]; 4]; NG];
    // ── 同侧/反侧细分（指示计数，同坐标可多格并计）：[群][4 种][pd 列] ──
    // 0=同侧二类 1=反侧二类 2=同侧三类 3=反侧三类
    let mut cross_side = [[[0usize; 3]; 4]; NG];
    // ── 六 bit × pd 列（bit 级，与 #848 §4 的 bit 计数同口径）──
    let mut bit_x_pd = [[[0usize; 3]; 6]; NG];
    // 分母：坐标存在次级别条目的例数 / 全部 lvl≥1 例数
    let mut n_lvlge1 = [0usize; NG];
    let mut n_present = [0usize; NG];
    // 全 66 例口径：坐标**无**次级别条目时的 pan_div 覆盖
    let mut absent_pd = [[0usize; 3]; NG];
    // 终局快照复查（防「同期查不到」被写成「不存在」）
    let mut f_present = [0usize; NG];
    let mut f_pd_same = [0usize; NG];
    let mut f_pd_any = [0usize; NG];

    // 逐例台账（只 Type1 dump）
    struct Row {
        lvl: usize,
        src: usize,
        delta: Side,
        mask: u8,
        pd_long: bool,
        pd_short: bool,
        anchors: Vec<usize>,
    }
    let mut rows: Vec<Row> = Vec::new();
    // 终局复查用：(g, lvl, src, delta)
    let mut sigs: Vec<(usize, usize, usize, Side)> = Vec::new();

    let last_bar = (0..n)
        .rev()
        .find(|&i| !bars[i].untradable && bars[i].close > 0);
    let mut final_bsp: Vec<Rc<Vec<BspPoint>>> = Vec::new();
    let mut final_pd: Vec<Rc<Vec<PanDivCert>>> = Vec::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __wl9 = classifier_incr.classify_at(i);
        let cls_i = __wl9.classification;
        let tower_i = __wl9.tower;
        if Some(i) == last_bar {
            final_bsp = cls_i.levels.iter().map(|l| Rc::clone(&l.bsp)).collect();
            final_pd = cls_i.levels.iter().map(|l| Rc::clone(&l.pan_div)).collect();
        }
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if !in_scope(lvl) {
                continue;
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                if !(p.bits.buy1
                    || p.bits.sell1
                    || p.bits.buy2
                    || p.bits.sell2
                    || p.bits.buy3
                    || p.bits.sell3)
                {
                    continue;
                }
                if p.bits.buy1 || p.bits.sell1 {
                    raw_t1_pts[lvl] += 1;
                }
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()),
                            first_class_grades: Rc::new(Vec::new()), // #885：同 pan_div 口径（single 屏蔽层无分级记录载荷）
                            level_projection: None,
                        })
                        .collect(),
                };
                let cands = assemble_gamma_with_tower(&single, &tower_i);
                for c in &cands {
                    let delta = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    let src = p.source_index;
                    let is_type1 = match delta {
                        Side::Long => p.bits.buy1,
                        Side::Short => p.bits.sell1,
                    };
                    let is_type2 = match delta {
                        Side::Long => p.bits.buy2,
                        Side::Short => p.bits.sell2,
                    };
                    let is_type3 = match delta {
                        Side::Long => p.bits.buy3,
                        Side::Short => p.bits.sell3,
                    };
                    let g = if is_type1 {
                        0
                    } else if is_type2 || is_type3 {
                        1
                    } else {
                        n_other += 1;
                        continue;
                    };
                    n_sig[g][lvl] += 1;
                    if lvl == 0 {
                        continue; // 无次级别，不进表
                    }
                    let tl = lvl - 1;
                    n_lvlge1[g] += 1;
                    sigs.push((g, lvl, src, delta));

                    let Some(tls) = cls_i.levels.get(tl) else {
                        continue;
                    };
                    let at = bsp_at_coord(&tls.bsp, src);
                    let (pd_long, pd_short) = pan_div_sides_at_coord(&tls.pan_div, src);
                    let (pd_same, pd_opp) = match delta {
                        Side::Long => (pd_long, pd_short),
                        Side::Short => (pd_short, pd_long),
                    };
                    // pd 列：0=同侧 1=仅反侧 2=无
                    let pdc = if pd_same {
                        0
                    } else if pd_opp {
                        1
                    } else {
                        2
                    };

                    if !at.present {
                        absent_pd[g][pdc] += 1;
                        continue;
                    }
                    n_present[g] += 1;

                    // 坐标级类别
                    let has_t2_any = at.mask & 0b01_0010 != 0; // buy2 | sell2
                    let has_t3_any = at.mask & 0b10_0100 != 0; // buy3 | sell3
                    let has_t1_any = at.t1_any();
                    let cat = if has_t2_any {
                        0
                    } else if has_t3_any {
                        1
                    } else if has_t1_any {
                        2
                    } else {
                        3
                    };
                    cross_cat[g][cat][pdc] += 1;

                    // 同侧/反侧细分（指示计数）
                    let (b2_same, b2_opp, b3_same, b3_opp) = match delta {
                        Side::Long => (
                            at.mask & 0b00_0010 != 0, // buy2
                            at.mask & 0b01_0000 != 0, // sell2
                            at.mask & 0b00_0100 != 0, // buy3
                            at.mask & 0b10_0000 != 0, // sell3
                        ),
                        Side::Short => (
                            at.mask & 0b01_0000 != 0, // sell2
                            at.mask & 0b00_0010 != 0, // buy2
                            at.mask & 0b10_0000 != 0, // sell3
                            at.mask & 0b00_0100 != 0, // buy3
                        ),
                    };
                    for (k, on) in [b2_same, b2_opp, b3_same, b3_opp].into_iter().enumerate() {
                        if on {
                            cross_side[g][k][pdc] += 1;
                        }
                    }
                    for b in 0..6 {
                        if at.mask & (1 << b) != 0 {
                            bit_x_pd[g][b][pdc] += 1;
                        }
                    }

                    if g == 0 {
                        // 二类 bit 的归属锚（`make_second_point` 载 OwnerRef::Type1Anchor）
                        let mut anchors = Vec::new();
                        for q in tls.bsp.iter() {
                            if q.source_index != src || !(q.bits.buy2 || q.bits.sell2) {
                                continue;
                            }
                            if let Some(OwnerRef::Type1Anchor(a)) = q.center {
                                if !anchors.contains(&a) {
                                    anchors.push(a);
                                }
                            }
                        }
                        rows.push(Row {
                            lvl,
                            src,
                            delta,
                            mask: at.mask,
                            pd_long,
                            pd_short,
                            anchors,
                        });
                    }
                }
            }
        }
    }

    // ── 终局快照复查 ──
    for &(g, lvl, src, delta) in &sigs {
        let tl = lvl - 1;
        if let Some(bl) = final_bsp.get(tl) {
            if bsp_at_coord(bl, src).present {
                f_present[g] += 1;
            }
        }
        if let Some(pl) = final_pd.get(tl) {
            let (pl_long, pl_short) = pan_div_sides_at_coord(pl, src);
            let same = match delta {
                Side::Long => pl_long,
                Side::Short => pl_short,
            };
            if same {
                f_pd_same[g] += 1;
            }
            if pl_long || pl_short {
                f_pd_any[g] += 1;
            }
        }
    }

    // ══════════════════════════ 报告 ══════════════════════════
    let pct = |x: usize, tot: usize| {
        if tot == 0 {
            0.0
        } else {
            100.0 * x as f64 / tot as f64
        }
    };
    let bit_name = |b: usize| ["buy1", "buy2", "buy3", "sell1", "sell2", "sell3"][b];
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# #851 原始数据：交集口径——次级别二/三类 bit **∧** 同坐标盘整背驰"
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- issue: #851（承 #848 / #846；ADR 0013 裁定七归类半句）"
    );
    let _ = writeln!(
        rpt,
        "- **认识论 L2**（真实 BTC 逐信号，两个现成载体的同坐标共现计数）"
    );
    let _ = writeln!(
        rpt,
        "- 窗口：{win_start}→{win_end}，bars={n}（全量={n_full}），max_bars={max_bars}"
    );
    let _ = writeln!(
        rpt,
        "- 信号集与 #848/#846 **严格同批**（同去重键 / 同 Γ 定向 / 同群定义 / LMIN=0 LMAX=4）"
    );
    let _ = writeln!(rpt, "- 「次级别」= `tl = lvl−1`；坐标匹配 = `source_index == src`（与 #848 同一 `bsp_at_coord`）");
    let _ = writeln!(rpt, "- 「盘背同侧」= `cls.levels[tl].pan_div` 中存在 `source_index==src` 且 `side==δ` 的 `PanDivCert`");
    let _ = writeln!(
        rpt,
        "- **本探针不改判据、不碰生产代码**；「盘整背驰算不算类一类点」归 #817 未裁"
    );
    let _ = writeln!(rpt);

    // §0 基数自检
    let _ = writeln!(rpt, "## 0. 基数自检（与 #848 §0 逐格可比）");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| lvl | 带type1 bit 点数 | n_sig(Type1) | n_sig(Type2/3) |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|");
    for lvl in LMIN..=LMAX {
        let _ = writeln!(
            rpt,
            "| {lvl} | {} | {} | {} |",
            raw_t1_pts[lvl], n_sig[0][lvl], n_sig[1][lvl]
        );
    }
    let _ = writeln!(rpt);
    for g in 0..NG {
        let _ = writeln!(
            rpt,
            "- {}：lvl≥1 共 **{}** 例，其中坐标存在次级别 BSP 条目 **{}** 例（#848 §4 的分母）",
            gname(g),
            n_lvlge1[g],
            n_present[g]
        );
    }
    let _ = writeln!(rpt);

    // §1 ★核心交叉表
    let _ = writeln!(
        rpt,
        "## 1. ★核心交叉表（坐标级；分母 = 坐标存在次级别条目的例数）"
    );
    let _ = writeln!(rpt);
    let cat_name = |c: usize| {
        [
            "带二类 bit（任意侧）",
            "不带二类、带三类 bit",
            "带一类 bit",
            "mask=0（纯结构候选）",
        ][c]
    };
    for g in 0..NG {
        let _ = writeln!(rpt, "### 1.{} {}", g + 1, gname(g));
        let _ = writeln!(rpt);
        let _ = writeln!(rpt, "| 次级别标了什么 | **∧ 同侧盘背** | ∧ 仅反侧盘背 | ∧ 无盘背 | 合计 | 同侧盘背% | 任意侧盘背% |");
        let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
        for cat in 0..4 {
            let r = &cross_cat[g][cat];
            let tot = r[0] + r[1] + r[2];
            if tot == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {} | **{}** | {} | {} | {tot} | {:.2}% | {:.2}% |",
                cat_name(cat),
                r[0],
                r[1],
                r[2],
                pct(r[0], tot),
                pct(r[0] + r[1], tot)
            );
        }
        let mut s = [0usize; 3];
        for cat in 0..4 {
            for k in 0..3 {
                s[k] += cross_cat[g][cat][k];
            }
        }
        let stot = s[0] + s[1] + s[2];
        let _ = writeln!(
            rpt,
            "| **合计** | **{}** | {} | {} | {stot} | {:.2}% | {:.2}% |",
            s[0],
            s[1],
            s[2],
            pct(s[0], stot),
            pct(s[0] + s[1], stot)
        );
        let _ = writeln!(rpt);
        let _ = writeln!(rpt, "**票面点名的四格**（合并盘背侧向）：");
        let _ = writeln!(rpt);
        let _ = writeln!(rpt, "| | 有盘整背驰 | 无盘整背驰 |");
        let _ = writeln!(rpt, "|---|---|---|");
        let _ = writeln!(
            rpt,
            "| 标二类 | {} | {} |",
            cross_cat[g][0][0] + cross_cat[g][0][1],
            cross_cat[g][0][2]
        );
        let _ = writeln!(
            rpt,
            "| 标三类 | {} | {} |",
            cross_cat[g][1][0] + cross_cat[g][1][1],
            cross_cat[g][1][2]
        );
        let _ = writeln!(rpt);
    }

    // §2 同侧/反侧细分
    let _ = writeln!(rpt, "## 2. 同侧 / 反侧细分（指示计数，同坐标可多格并计）");
    let _ = writeln!(rpt);
    let side_name = |k: usize| ["同侧二类", "**反**侧二类", "同侧三类", "**反**侧三类"][k];
    let _ = writeln!(
        rpt,
        "| 群 | 次级别 bit 相对大级别 δ | ∧ 同侧盘背 | ∧ 仅反侧盘背 | ∧ 无盘背 | 合计 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for g in 0..NG {
        for k in 0..4 {
            let r = &cross_side[g][k];
            let tot = r[0] + r[1] + r[2];
            if tot == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {} | {} | {} | {} | {} | {tot} |",
                gname(g),
                side_name(k),
                r[0],
                r[1],
                r[2]
            );
        }
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "六 bit × 盘背列（bit 级，与 #848 §4 的 bit 计数同口径）："
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| 群 | 次级别 bit | ∧ 同侧盘背 | ∧ 仅反侧盘背 | ∧ 无盘背 | 合计 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for g in 0..NG {
        for b in 0..6 {
            let r = &bit_x_pd[g][b];
            let tot = r[0] + r[1] + r[2];
            if tot == 0 {
                continue;
            }
            let _ = writeln!(
                rpt,
                "| {} | {} | {} | {} | {} | {tot} |",
                gname(g),
                bit_name(b),
                r[0],
                r[1],
                r[2]
            );
        }
    }
    let _ = writeln!(rpt);

    // §3 全 lvl≥1 口径（含坐标无次级别条目的例）
    let _ = writeln!(rpt, "## 3. 全 lvl≥1 口径（防「只看有条目那批」的选择偏差）");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| 群 | lvl≥1 例数 | 有次级别条目 | 无条目 | 无条目∧同侧盘背 | 无条目∧仅反侧 | 无条目∧无盘背 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
    for g in 0..NG {
        let a = &absent_pd[g];
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {} | {} | {} | {} |",
            gname(g),
            n_lvlge1[g],
            n_present[g],
            a[0] + a[1] + a[2],
            a[0],
            a[1],
            a[2]
        );
    }
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "终局快照复查（末 bar 累积列表；差值 = 同期没标、后来标上的量）："
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "| 群 | lvl≥1 例数 | 终局有条目 | 终局同侧盘背 | 终局任意侧盘背 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|");
    for g in 0..NG {
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {} | {} |",
            gname(g),
            n_lvlge1[g],
            f_present[g],
            f_pd_same[g],
            f_pd_any[g]
        );
    }
    let _ = writeln!(rpt);

    // §4 逐例 dump
    let _ = writeln!(
        rpt,
        "## 4. ★Type1 逐例 dump（坐标存在次级别条目的全部 {} 例）",
        rows.len()
    );
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "`δ` = 大级别方向（+1=buy1 / −1=sell1）；`次级别 bit` 后括注同侧/反侧；"
    );
    let _ = writeln!(rpt, "`盘背` 列给 `pan_div` 在**同一坐标**的分侧命中；`二类锚` = 该二类点自己的 `OwnerRef::Type1Anchor` 坐标。");
    let _ = writeln!(rpt);
    let _ = writeln!(rpt, "| # | 信号级 | src | δ | 次级别 bit（同侧?） | 盘背同侧 | 盘背反侧 | 二类锚 type1_src | 锚距 src |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|");
    for (k, r) in rows.iter().enumerate() {
        let mut bits_s = Vec::new();
        for b in 0..6 {
            if r.mask & (1 << b) == 0 {
                continue;
            }
            let bit_is_long = b < 3; // buy* = 买侧 = Long
            let same = (r.delta == Side::Long) == bit_is_long;
            bits_s.push(format!(
                "{}({})",
                bit_name(b),
                if same { "同" } else { "**反**" }
            ));
        }
        let (pd_same, pd_opp) = match r.delta {
            Side::Long => (r.pd_long, r.pd_short),
            Side::Short => (r.pd_short, r.pd_long),
        };
        let anchors_s = if r.anchors.is_empty() {
            "—".to_string()
        } else {
            r.anchors
                .iter()
                .map(|a| a.to_string())
                .collect::<Vec<_>>()
                .join(",")
        };
        let dist_s = if r.anchors.is_empty() {
            "—".to_string()
        } else {
            r.anchors
                .iter()
                .map(|a| {
                    if *a <= r.src {
                        format!("−{}", r.src - a)
                    } else {
                        format!("+{}", a - r.src)
                    }
                })
                .collect::<Vec<_>>()
                .join(",")
        };
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {} | {} | {} | {} | {} | {} |",
            k + 1,
            r.lvl,
            r.src,
            if r.delta == Side::Long { "+1" } else { "−1" },
            if bits_s.is_empty() {
                "mask=0".to_string()
            } else {
                bits_s.join(" ")
            },
            if pd_same { "**是**" } else { "否" },
            if pd_opp { "是" } else { "否" },
            anchors_s,
            dist_s
        );
    }
    let _ = writeln!(rpt);

    // §5 忠实性与域外
    let _ = writeln!(rpt, "## 5. 忠实性校验与域外声明");
    let _ = writeln!(rpt);
    let _ = writeln!(
        rpt,
        "- 残差群（带 δ 但无任何 bsp bit 命中该方向）：{n_other} 条，两群皆不计"
    );
    let _ = writeln!(
        rpt,
        "- 台账信号条数：{}（= Σn_sig）",
        n_sig.iter().flatten().sum::<usize>()
    );
    let _ = writeln!(
        rpt,
        "- 终局快照取自末可交易 bar：{last_bar:?}；`final_bsp` 级数={}，`final_pd` 级数={}",
        final_bsp.len(),
        final_pd.len()
    );
    let _ = writeln!(
        rpt,
        "- **窗口 = {n} bar（全量 {n_full} 的 {:.0}%），未跑全史**——百分比不得外推",
        pct(n, n_full)
    );
    let _ = writeln!(
        rpt,
        "- **本探针不改任何判据、不碰生产代码**；新增诊断挂 `#[ignore]`，不进 CI 默认集"
    );
    let _ = writeln!(rpt);

    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(format!(
            ".chanlun/review-results/issue851-quasi-first-intersection-raw-b{n}.md"
        ));
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n原始数据已落盘：{out:?}");

    // ── 真封（与 #848 同批的可比性硬断言）──
    for g in 0..NG {
        let cat_sum: usize = cross_cat[g].iter().flatten().sum();
        assert_eq!(
            cat_sum,
            n_present[g],
            "{} 坐标级交叉表穷举：四类别合计({cat_sum}) 应 = 有条目例数({})",
            gname(g),
            n_present[g]
        );
        let absent_sum: usize = absent_pd[g].iter().sum();
        assert_eq!(
            absent_sum + n_present[g],
            n_lvlge1[g],
            "{} 分母穷举：无条目({absent_sum})+有条目({}) 应 = lvl≥1 例数({})",
            gname(g),
            n_present[g],
            n_lvlge1[g]
        );
    }
    assert_eq!(
        rows.len(),
        n_present[0],
        "Type1 逐例 dump 行数({}) 应 = 有条目例数({})",
        rows.len(),
        n_present[0]
    );
    eprintln!(
        "真封：Type1 lvl≥1={} 有条目={}；Type2/3 lvl≥1={} 有条目={}",
        n_lvlge1[0], n_present[0], n_lvlge1[1], n_present[1]
    );
}

/// **#852 探针：区间套逐级收缩（命题①）+ 逐级累积找一类点（命题②）+ 同步共振（命题③）**
/// （只读诊断，`#[ignore]`，**不改任何判据、不碰生产代码**）。
///
/// ## 为什么要开（#846/#848/#851 测的都不是这个）
///
/// 前三张探针问的都是「**下一级被标成了哪一类买卖点**」（只钻一级、看类型标签），
/// 而 `017-第17课.md:72` 明写「这某级别**不一定是次级别**，因为次级别里可以是第二类买卖点」
/// ——那一条缠师自己就否了。本探针测的是另外三条：
///
/// - **命题①** `027-第27课.md:44`「某大级别的转折点，可以通过不同级别背驰段的**逐级收缩范围**而确定」
///   ＋`:46`「在次级别图里找出相应背驰段在次级别里的背驰段，**反复进行下去，直到最低级别**」
///   ＋`:50`「把高数里的**区间套定理**复习一下」。**与买卖点类型无关**，只问背驰段本身。
/// - **命题②** `017-第17课.md:70` 缠中说禅趋势转折定律：「任何级别的上涨转折都是由**某级别**的
///   第一类卖点构成的」。关键词是**某级别**——从信号级向下**逐级累积**地找，遇二类点继续往下。
/// - **命题③** `017:72`「不同级别同时出现第一类买卖点，也就是出现**不同级别的同步共振**」（只说可能）。
///
/// ## 测什么（三段）
///
/// **§A 命题①**：展开 [`descend_type1_anchor_depth`] 的递归为可观测循环（与 #846
/// `type1_descend_continuity_dx` 同一 loop 形状），逐步记录——
/// (a) 每级取不取得到（三分成因：`EmptySubs` 递归底 / `NoAlign` 无端点对齐段 / `DivFalse` 非背驰段）；
/// (b) **区间是否真的逐级收缩**（`sub.start_index ≥ cur.start_index` 且 `sub.end_index ≤ cur.end_index`
///     是否成立；左端点是否**严格**右移）——#846 **没测过这一格**，是本探针相对 #846 的新增量；
/// (c) 一路能到哪一级、到不到 L0；(d) 断在哪一级。
/// 忠实性对拍：展开循环 ≡ 真 `descend_type1_anchor_depth`（`trace_mismatch` 硬断言 = 0）。
///
/// **§B 命题②**：从信号级 `lvl` 向下**逐级累积**扫 BSP 层坐标 `src`，`tl = lvl-1, lvl-2, …, 0`，
/// 遇二类/三类 bit **不算失败、继续往下**，直到命中或触底 level0。两个口径：
/// - **窄**＝同侧一类 bit（`BspAtCoord::t1_side`）；
/// - **宽**＝同侧一类 bit ∨ 同坐标同侧 `pan_div`（「类一类点」，`060:50`/`027:66`）。
///
/// **§C 命题③**：同坐标上相邻两级同时挂同侧一类 bit 的例数（窄/宽两口径）。
///
/// ## 已知载体缺口——读数是**下界**，不是「不受影响」
///
/// - 「类一类点」载体残缺（#851 查实）：`PanDivCert` 只覆盖「C 段破核心」一支，
///   否则域记录只在 thread_local sidecar、**按坐标查不到**；`027:68` 的「类第二类」全仓零载体。
///   ⟹ §B 宽口径 / §C 宽口径的命中率**是下界**。
/// - 二类点整类受 `no_new_low` 硬闸（`rmove_compose.rs:80-82/:160`，#851 查实，SPEC #847）：
///   跌破前低就不产二类点 ⟹ §B 沿途的二类点被**系统性漏掉**，「沿途遇二类」计数也是下界。
///
/// ## 口径（与 #846/#848/#851 严格同批，否则不可比）
///
/// 同一份 BTC 数据、同一 `IncrementalClassifier` 逐 bar 循环、同一 `seen` 去重键
/// `(lvl, source_index, bsp_disc)`、同一 Γ 定向（`assemble_gamma_with_tower`）、LMIN=0 LMAX=4。
/// §0 的 `n_sig` 逐格与 `issue848-*` / `issue851-*` 同窗读数对照即自检。
///
/// **不裁教义**（「盘整背驰算不算类一类点」归 #817）；**不改判据、不碰生产代码**。
///
/// **认识论 L2**（真实 BTC 逐信号 + 确定性判据，可产否定性计数）。
///
/// 命令：`ECON_L2_MAX_BARS=1200000 cargo test --release nesting_descent_and_type1_reach_dx -- --ignored --nocapture`
#[test]
#[ignore]
fn nesting_descent_and_type1_reach_dx() {
    use super::super::super::classifier::cand_predicate::{div_cand, DivCandInput};
    use super::super::super::classifier::divergence::compute_macd;
    use super::super::super::classifier::recursive_tower::{find_move_by_end_index, LeveledMove};
    use super::super::data;
    use std::fmt::Write as _;

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let n_full = ds_full.bars.len();
    let max_bars = std::env::var(crate::theta_v0::env_registry::ECON_L2_MAX_BARS)
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(usize::MAX);
    let ds = if n_full > max_bars {
        ds_full.slice_bar_range(n_full - max_bars, n_full)
    } else {
        ds_full
    };
    let bars = &ds.bars;
    let n = bars.len();
    let tick = config.tick.tick_size;
    let win_start = ds
        .dates
        .first()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    let win_end = ds
        .dates
        .last()
        .map(|d| d.get(..10).unwrap_or("").to_string())
        .unwrap_or_default();
    eprintln!("[nest-852] bars={n}（{win_start}→{win_end}，全量={n_full}），max_bars={max_bars}");

    let closes: Vec<f64> = bars.iter().map(|b| b.close as f64 / tick as f64).collect();
    let macd_hist = compute_macd(&closes, &config.macd).hist;

    const LMIN: usize = 0;
    const LMAX: usize = 4;
    const NG: usize = 2;
    let gname = |g: usize| if g == 0 { "Type1" } else { "Type2/3" };
    let in_scope = |lvl: usize| (LMIN..=LMAX).contains(&lvl);

    // ── §0 自检 ──
    let mut n_sig = [[0usize; LMAX + 1]; NG];

    // ── §A 命题①：逐级收缩 ──
    // 断链成因桶：0=EmptySubs(递归底) 1=NoAlign(无端点对齐段) 2=DivFalse(非背驰段)
    let mut seg_absent = [[0usize; LMAX + 1]; NG]; // 执行级连候选段都没有
    let mut depth_hist = [[0usize; LMAX + 2]; NG]; // 下钻深度 d
    let mut term_reason = [[0usize; 3]; NG]; // 终止成因
    let mut term_level = [[0usize; LMAX + 1]; NG]; // 终止时所在绝对级
    let mut reach_l0 = [0usize; NG]; // 链一路到 level0（cur_level==0 时终止）
    let mut reach_l0_bottom = [0usize; NG]; // 且终止成因 = EmptySubs（真「到最低级别」）
                                            // 区间包含实测（每个成功对齐的步都记一次，含最后失败在 DivFalse 的那步）
    let mut ct_ok = [0usize; NG]; // sub ⊆ cur
    let mut ct_bad = [0usize; NG]; // 违反包含
    let mut ct_left_strict = [0usize; NG]; // 左端点严格右移（真收缩）
    let mut ct_left_eq = [0usize; NG]; // 左端点相等（退化，不收缩）
    let mut ct_right_eq = [0usize; NG]; // 右端点相等（必然：两端都由 end_index==src 定位）
    let mut ct_steps = [0usize; NG];
    let mut trace_mismatch = 0usize;

    // ── §B 命题②：逐级累积找一类点 ──
    let mut b_pop = [0usize; NG]; // 参与 §B 的信号数（lvl≥1）
    let mut b_hit_n = [0usize; NG]; // 窄口径命中
    let mut b_hit_w = [0usize; NG]; // 宽口径命中
    let mut b_hit_any = [0usize; NG]; // 任意侧一类 bit（诊断「方向标反」）
    let mut b_steps_n = [0usize; NG]; // 窄口径命中时下钻级数之和
    let mut b_steps_w = [0usize; NG];
    let mut b_lvl_n = [[0usize; LMAX + 1]; NG]; // 窄口径命中在哪一绝对级
    let mut b_lvl_w = [[0usize; LMAX + 1]; NG];
    let mut b_miss_bottom_n = [0usize; NG]; // 触底 level0 仍未命中
    let mut b_miss_bottom_w = [0usize; NG];
    let mut b_saw_t23 = [0usize; NG]; // 沿途至少遇到一次同侧二/三类 bit（本该被记失败、本探针继续往下）
    let mut b_saw_t23_then_hit_n = [0usize; NG]; // 遇二三类后仍窄口径命中（票面点名的那一格）

    // ── §C 命题③：相邻两级同侧一类共振 ──
    let mut c_pop = [0usize; NG];
    let mut c_res_n = [0usize; NG];
    let mut c_res_w = [0usize; NG];

    // 逐例台账（只 Type1）
    struct Row {
        lvl: usize,
        src: usize,
        delta: Side,
        depth: usize,
        term: usize,
        term_lvl: usize,
        left_strict: usize,
        hit_n: Option<usize>,
        hit_w: Option<usize>,
        saw_t23: bool,
    }
    let mut rows: Vec<Row> = Vec::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    let mut seen: std::collections::HashSet<(usize, usize, u8)> = std::collections::HashSet::new();

    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let __wl10 = classifier_incr.classify_at(i);
        let l0_i = classifier_incr
            .last_l0()
            .expect("classify_at 已推进 ParseLayer");
        let cls_i = __wl10.classification;
        let tower_i = __wl10.tower;
        for (lvl, ls) in cls_i.levels.iter().enumerate() {
            if !in_scope(lvl) {
                continue;
            }
            for p in ls.bsp.iter() {
                let bsp_class = bsp_disc(&p.bits);
                if !seen.insert((lvl, p.source_index, bsp_class)) {
                    continue;
                }
                if !(p.bits.buy1
                    || p.bits.sell1
                    || p.bits.buy2
                    || p.bits.sell2
                    || p.bits.buy3
                    || p.bits.sell3)
                {
                    continue;
                }
                let single = super::super::super::classifier::Classification {
                    levels: cls_i
                        .levels
                        .iter()
                        .enumerate()
                        .map(|(l2, _)| super::super::super::classifier::LevelState {
                            moves: Vec::new(),
                            centers: Rc::new(Vec::new()),
                            cp_ownership: Rc::new(Vec::new()),
                            bsp: Rc::new(if l2 == lvl {
                                vec![p.clone()]
                            } else {
                                Vec::new()
                            }),
                            pan_div: Rc::new(Vec::new()),
                            first_class_grades: Rc::new(Vec::new()), // #885：同 pan_div 口径（single 屏蔽层无分级记录载荷）
                            level_projection: None,
                        })
                        .collect(),
                };
                let cands = assemble_gamma_with_tower(&single, &tower_i);
                for c in &cands {
                    let delta = match c.dir {
                        VoiceSide::Long => Side::Long,
                        VoiceSide::Short => Side::Short,
                        VoiceSide::Flat => continue,
                    };
                    let src = p.source_index;
                    let is_type1 = match delta {
                        Side::Long => p.bits.buy1,
                        Side::Short => p.bits.sell1,
                    };
                    let is_type2 = match delta {
                        Side::Long => p.bits.buy2,
                        Side::Short => p.bits.sell2,
                    };
                    let is_type3 = match delta {
                        Side::Long => p.bits.buy3,
                        Side::Short => p.bits.sell3,
                    };
                    let g = if is_type1 {
                        0
                    } else if is_type2 || is_type3 {
                        1
                    } else {
                        continue;
                    };
                    n_sig[g][lvl] += 1;

                    // ═══ §A 命题①：背驰段逐级收缩 ═══
                    let exec_moves: &[LeveledMove] = match tower_i.get(lvl) {
                        Some(mv) => mv.as_slice(),
                        None => {
                            seg_absent[g][lvl] += 1;
                            continue;
                        }
                    };
                    let Some(si) = find_move_containing_index(exec_moves, src) else {
                        seg_absent[g][lvl] += 1;
                        continue;
                    };
                    let s = &exec_moves[si];

                    let mut cur: &LeveledMove = s;
                    let mut cur_level = lvl;
                    let mut depth = 0usize;
                    let mut left_strict_here = 0usize;
                    let terminal: usize;
                    loop {
                        let subs = cur.sub_moves.as_slice();
                        if subs.is_empty() {
                            terminal = 0; // EmptySubs：递归底
                            break;
                        }
                        // ★#1076：与生产 descend 同源——end == 精确匹配 MISS 回退「区间包含」。
                        let tidx = match find_move_by_end_index(subs, src) {
                            Some(tidx) => tidx,
                            None => match find_move_containing_index(subs, src) {
                                Some(tidx) => tidx,
                                None => {
                                    terminal = 1; // NoAlign
                                    break;
                                }
                            },
                        };
                        // ★ 区间包含实测（本探针相对 #846 的新增量）
                        let sub = &subs[tidx];
                        ct_steps[g] += 1;
                        if sub.start_index >= cur.start_index && sub.end_index <= cur.end_index {
                            ct_ok[g] += 1;
                        } else {
                            ct_bad[g] += 1;
                        }
                        if sub.start_index > cur.start_index {
                            ct_left_strict[g] += 1;
                            left_strict_here += 1;
                        } else if sub.start_index == cur.start_index {
                            ct_left_eq[g] += 1;
                        }
                        if sub.end_index == cur.end_index {
                            ct_right_eq[g] += 1;
                        }

                        let ok = div_cand(&DivCandInput {
                            context: subs,
                            target_idx: tidx,
                            hist: &macd_hist,
                            delta,
                            strokes: &l0_i.strokes, // ★#883
                            parent_center:
                                super::super::super::classifier::cand_predicate::parent_last_center(
                                    cur,
                                ),
                            gauge: config.divergence_gauge,
                            close_src: None,
                        });
                        if !ok {
                            terminal = 2; // DivFalse
                            break;
                        }
                        depth += 1;
                        cur = sub;
                        cur_level = cur_level.saturating_sub(1);
                    }
                    // 忠实性对拍：展开循环 ≡ 真 descend_type1_anchor_depth
                    let real_locator = descend_type1_anchor_depth(
                        s,
                        src,
                        delta,
                        &macd_hist,
                        &l0_i.strokes,
                        config.divergence_gauge,
                    );
                    if real_locator.depth() != depth {
                        trace_mismatch += 1;
                    }
                    depth_hist[g][depth.min(LMAX + 1)] += 1;
                    term_reason[g][terminal] += 1;
                    term_level[g][cur_level.min(LMAX)] += 1;
                    if cur_level == 0 {
                        reach_l0[g] += 1;
                        if terminal == 0 {
                            reach_l0_bottom[g] += 1;
                        }
                    }

                    // ═══ §B 命题②：逐级累积找一类点（遇二三类继续往下）═══
                    if lvl >= 1 {
                        b_pop[g] += 1;
                        let mut hit_n: Option<usize> = None;
                        let mut hit_w: Option<usize> = None;
                        let mut hit_any = false;
                        let mut saw_t23 = false;
                        // 逐级累积：tl = lvl-1, lvl-2, …, 0（不在第一级停）
                        for tl in (0..lvl).rev() {
                            let Some(tls) = cls_i.levels.get(tl) else {
                                continue;
                            };
                            let at = bsp_at_coord(&tls.bsp, src);
                            let (_pd_any, pd_same) = pan_div_at_coord(&tls.pan_div, src, delta);
                            if at.t1_any() {
                                hit_any = true;
                            }
                            if at.t23_side(delta) {
                                saw_t23 = true;
                            }
                            if hit_n.is_none() && at.t1_side(delta) {
                                hit_n = Some(tl);
                            }
                            if hit_w.is_none() && (at.t1_side(delta) || pd_same) {
                                hit_w = Some(tl);
                            }
                        }
                        if hit_any {
                            b_hit_any[g] += 1;
                        }
                        if saw_t23 {
                            b_saw_t23[g] += 1;
                        }
                        match hit_n {
                            Some(tl) => {
                                b_hit_n[g] += 1;
                                b_steps_n[g] += lvl - tl;
                                b_lvl_n[g][tl] += 1;
                                if saw_t23 {
                                    b_saw_t23_then_hit_n[g] += 1;
                                }
                            }
                            None => b_miss_bottom_n[g] += 1,
                        }
                        match hit_w {
                            Some(tl) => {
                                b_hit_w[g] += 1;
                                b_steps_w[g] += lvl - tl;
                                b_lvl_w[g][tl] += 1;
                            }
                            None => b_miss_bottom_w[g] += 1,
                        }

                        // ═══ §C 命题③：相邻两级同侧一类共振 ═══
                        c_pop[g] += 1;
                        let mut t1n = vec![false; lvl + 1];
                        let mut t1w = vec![false; lvl + 1];
                        t1n[lvl] = is_type1;
                        t1w[lvl] = is_type1;
                        for (tl, (slot_n, slot_w)) in
                            t1n.iter_mut().zip(t1w.iter_mut()).enumerate().take(lvl)
                        {
                            let Some(tls) = cls_i.levels.get(tl) else {
                                continue;
                            };
                            let at = bsp_at_coord(&tls.bsp, src);
                            let (_pd_any, pd_same) = pan_div_at_coord(&tls.pan_div, src, delta);
                            *slot_n = at.t1_side(delta);
                            *slot_w = at.t1_side(delta) || pd_same;
                        }
                        if t1n.windows(2).any(|w| w[0] && w[1]) {
                            c_res_n[g] += 1;
                        }
                        if t1w.windows(2).any(|w| w[0] && w[1]) {
                            c_res_w[g] += 1;
                        }

                        if g == 0 {
                            rows.push(Row {
                                lvl,
                                src,
                                delta,
                                depth,
                                term: terminal,
                                term_lvl: cur_level,
                                left_strict: left_strict_here,
                                hit_n,
                                hit_w,
                                saw_t23,
                            });
                        }
                    }
                }
            }
        }
    }

    // ══════════════ 报告 ══════════════
    let pct = |a: usize, b: usize| {
        if b == 0 {
            f64::NAN
        } else {
            a as f64 * 100.0 / b as f64
        }
    };
    let tname = |t: usize| match t {
        0 => "EmptySubs(递归底)",
        1 => "NoAlign(无对齐段)",
        _ => "DivFalse(非背驰段)",
    };
    let mut rpt = String::new();
    let _ = writeln!(
        rpt,
        "# #852 原始读数：区间套逐级收缩 + 逐级累积找一类点（BTC，窗口 {n} bar）\n"
    );
    let _ = writeln!(rpt, "- 探针：`nesting_descent_and_type1_reach_dx`（`#[ignore]`，只读诊断，不改判据、不碰生产代码）");
    let _ = writeln!(rpt, "- 窗口：**{n} bar**（{win_start}→{win_end}，全量 {n_full} 的 {:.1}%）——**未跑全史，百分比不得外推**", pct(n, n_full));
    let _ = writeln!(
        rpt,
        "- 口径与 #846/#848/#851 同批：同 `seen` 去重键、同 Γ 定向、LMIN={LMIN} LMAX={LMAX}\n"
    );

    let _ = writeln!(rpt, "## 0. 同批性自检：信号基数逐级\n");
    let _ = writeln!(rpt, "| 群 | lvl0 | lvl1 | lvl2 | lvl3 | lvl4 | 合计 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
    for g in 0..NG {
        let tot: usize = n_sig[g].iter().sum();
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {} | {} | {} | **{}** |",
            gname(g),
            n_sig[g][0],
            n_sig[g][1],
            n_sig[g][2],
            n_sig[g][3],
            n_sig[g][4],
            tot
        );
    }
    let _ = writeln!(
        rpt,
        "\n- 展开循环 ≡ `descend_type1_anchor_depth` 对拍不一致：**{trace_mismatch}**（须 0）\n"
    );

    let _ = writeln!(rpt, "## A. 命题①：背驰段逐级收缩（`027:44/:46`）\n");
    let _ = writeln!(rpt, "### A.1 下钻深度分布（d = 成功下钻的级数）\n");
    let _ = writeln!(
        rpt,
        "| 群 | 无执行级候选段 | d=0 | d=1 | d=2 | d=3 | d≥4 | 合计 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        let tot: usize = depth_hist[g].iter().sum();
        let sa: usize = seg_absent[g].iter().sum();
        let _ = writeln!(
            rpt,
            "| {} | {} | **{}** | {} | {} | {} | {} | {} |",
            gname(g),
            sa,
            depth_hist[g][0],
            depth_hist[g][1],
            depth_hist[g][2],
            depth_hist[g][3],
            depth_hist[g][4] + depth_hist[g][5],
            tot
        );
    }
    let _ = writeln!(rpt, "\n### A.2 断在哪 / 到不到 L0\n");
    let _ = writeln!(rpt, "| 群 | 终止=EmptySubs | 终止=NoAlign | 终止=DivFalse | 终止时到 L0 | 其中真触底(EmptySubs) | 链能到 L0 % |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|");
    for g in 0..NG {
        let tot: usize = term_reason[g].iter().sum();
        let _ = writeln!(
            rpt,
            "| {} | {} | **{}** | **{}** | {} | {} | {:.2}% |",
            gname(g),
            term_reason[g][0],
            term_reason[g][1],
            term_reason[g][2],
            reach_l0[g],
            reach_l0_bottom[g],
            pct(reach_l0[g], tot)
        );
    }
    let _ = writeln!(rpt, "\n### A.3 终止时所在绝对级\n");
    let _ = writeln!(rpt, "| 群 | L0 | L1 | L2 | L3 | L4 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for g in 0..NG {
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {} | {} | {} |",
            gname(g),
            term_level[g][0],
            term_level[g][1],
            term_level[g][2],
            term_level[g][3],
            term_level[g][4]
        );
    }
    let _ = writeln!(
        rpt,
        "\n### A.4 ★ 区间是否真的逐级收缩（#846 没测过这一格）\n"
    );
    let _ = writeln!(
        rpt,
        "> 每一个「找到端点对齐子段」的步记一次（含最后失败在 DivFalse 的那步）。\n"
    );
    let _ = writeln!(rpt, "| 群 | 对齐步数 | sub ⊆ cur | **违反包含** | 左端点严格右移 | 左端点相等(不收缩) | 右端点相等 | 真收缩% |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | **{}** | {} | {} | {} | {:.2}% |",
            gname(g),
            ct_steps[g],
            ct_ok[g],
            ct_bad[g],
            ct_left_strict[g],
            ct_left_eq[g],
            ct_right_eq[g],
            pct(ct_left_strict[g], ct_steps[g])
        );
    }

    let _ = writeln!(
        rpt,
        "\n## B. 命题②：从信号级向下**逐级累积**找一类点（`017:70`）\n"
    );
    let _ = writeln!(
        rpt,
        "> 分母 = lvl≥1 的信号（lvl0 无下级，不进表）。**遇二类/三类点继续往下，不记失败。**\n"
    );
    let _ = writeln!(rpt, "| 群 | 分母(lvl≥1) | 窄口径命中 | 命中% | 平均下钻级数 | 触底未命中 | 宽口径命中 | 宽% | 宽平均级数 | 宽触底未命中 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|");
    for g in 0..NG {
        let _ = writeln!(
            rpt,
            "| {} | {} | **{}** | **{:.2}%** | {:.2} | {} | **{}** | **{:.2}%** | {:.2} | {} |",
            gname(g),
            b_pop[g],
            b_hit_n[g],
            pct(b_hit_n[g], b_pop[g]),
            if b_hit_n[g] == 0 {
                f64::NAN
            } else {
                b_steps_n[g] as f64 / b_hit_n[g] as f64
            },
            b_miss_bottom_n[g],
            b_hit_w[g],
            pct(b_hit_w[g], b_pop[g]),
            if b_hit_w[g] == 0 {
                f64::NAN
            } else {
                b_steps_w[g] as f64 / b_hit_w[g] as f64
            },
            b_miss_bottom_w[g]
        );
    }
    let _ = writeln!(rpt, "\n### B.2 命中在哪一绝对级\n");
    let _ = writeln!(rpt, "| 群 | 口径 | L0 | L1 | L2 | L3 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for g in 0..NG {
        let _ = writeln!(
            rpt,
            "| {} | 窄 | {} | {} | {} | {} |",
            gname(g),
            b_lvl_n[g][0],
            b_lvl_n[g][1],
            b_lvl_n[g][2],
            b_lvl_n[g][3]
        );
        let _ = writeln!(
            rpt,
            "| {} | 宽 | {} | {} | {} | {} |",
            gname(g),
            b_lvl_w[g][0],
            b_lvl_w[g][1],
            b_lvl_w[g][2],
            b_lvl_w[g][3]
        );
    }
    let _ = writeln!(rpt, "\n### B.3 「遇二类点继续往下」这条到底救回了几个\n");
    let _ = writeln!(
        rpt,
        "| 群 | 沿途至少遇一次同侧二/三类 | 其中最终窄口径命中 | 任意侧一类 bit 出现过 |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|");
    for g in 0..NG {
        let _ = writeln!(
            rpt,
            "| {} | {} | **{}** | {} |",
            gname(g),
            b_saw_t23[g],
            b_saw_t23_then_hit_n[g],
            b_hit_any[g]
        );
    }

    let _ = writeln!(rpt, "\n## C. 命题③：相邻两级同侧一类共振（`017:72`）\n");
    let _ = writeln!(
        rpt,
        "| 群 | 分母(lvl≥1) | 窄口径共振 | % | 宽口径共振 | % |"
    );
    let _ = writeln!(rpt, "|---|---|---|---|---|---|");
    for g in 0..NG {
        let _ = writeln!(
            rpt,
            "| {} | {} | **{}** | {:.2}% | **{}** | {:.2}% |",
            gname(g),
            c_pop[g],
            c_res_n[g],
            pct(c_res_n[g], c_pop[g]),
            c_res_w[g],
            pct(c_res_w[g], c_pop[g])
        );
    }

    let _ = writeln!(
        rpt,
        "\n## D. Type1 逐例台账（lvl≥1，共 {} 例）\n",
        rows.len()
    );
    let _ = writeln!(rpt, "| # | lvl | src | δ | 下钻深度 | 终止成因 | 终止级 | 左端严格右移步数 | 窄命中级 | 宽命中级 | 沿途遇二三类 |");
    let _ = writeln!(rpt, "|---|---|---|---|---|---|---|---|---|---|---|");
    for (k, r) in rows.iter().enumerate() {
        let _ = writeln!(
            rpt,
            "| {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} |",
            k + 1,
            r.lvl,
            r.src,
            if r.delta == Side::Long { "+1" } else { "−1" },
            r.depth,
            tname(r.term),
            r.term_lvl,
            r.left_strict,
            r.hit_n
                .map(|t| format!("L{t}"))
                .unwrap_or_else(|| "—".into()),
            r.hit_w
                .map(|t| format!("L{t}"))
                .unwrap_or_else(|| "—".into()),
            if r.saw_t23 { "是" } else { "否" }
        );
    }

    let _ = writeln!(rpt, "\n## E. 已知载体缺口（读数是下界）\n");
    let _ = writeln!(rpt, "- 「类一类点」载体残缺（#851）：`PanDivCert` 只覆盖 C 段破核心一支 ⟹ **B/C 宽口径命中率是下界**");
    let _ = writeln!(
            rpt,
            "- 二类点 `no_new_low` 硬闸已拆（#884/#816 B-2②）——B.3「沿途遇二三类」不再因该闸是下界；跌破一类的二类点经 `retrace_breaks_type1` 重合标注承载（语义归 #817）"
        );
    let _ = writeln!(
        rpt,
        "- **窗口 = {n} bar（全量 {n_full} 的 {:.1}%），未跑全史**——百分比不得外推",
        pct(n, n_full)
    );
    let _ = writeln!(
        rpt,
        "- **本探针不改任何判据、不碰生产代码**；诊断挂 `#[ignore]`，不进 CI 默认集\n"
    );

    eprint!("{rpt}");
    let out = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("rust/ 父目录 = 项目根")
        .join(format!(
            ".chanlun/review-results/issue852-nesting-descent-raw-b{n}.md"
        ));
    std::fs::write(&out, &rpt).unwrap_or_else(|e| panic!("写报告失败：{e}"));
    eprintln!("\n原始数据已落盘：{out:?}");

    // ── 真封 ──
    assert_eq!(
        trace_mismatch, 0,
        "展开循环与 descend_type1_anchor_depth 返回不一致 {trace_mismatch} 次 ⟹ 探针失真，读数作废"
    );
    for g in 0..NG {
        assert_eq!(
            b_hit_n[g] + b_miss_bottom_n[g],
            b_pop[g],
            "{} §B 窄口径穷举：命中+触底未命中 应 = 分母",
            gname(g)
        );
        assert_eq!(
            ct_ok[g] + ct_bad[g],
            ct_steps[g],
            "{} §A.4 包含检查穷举",
            gname(g)
        );
    }
    eprintln!(
        "真封通过：trace_mismatch=0；Type1 lvl≥1={}，Type2/3 lvl≥1={}",
        b_pop[0], b_pop[1]
    );
}

// ── #1223 探针（#[test] #[ignore]，env 驱动）：出场 cond1 拒 × 后续走势类型发展交叉（结构判据版）──
// 对 #1221/#1147 链的 308 出场 cond1 拒候选，逐候选落「结构口径」坐实证据——用生产结构函数
// （xzd_c3_new_center_breakout 新中枢+反向突破、xzd_force_exception 强力不背驰创新高、xzd_type2_confirmed
// 二类点诊断），替换 #1221 的「价格新高/新低」代理。判据引用生产已有结构函数，不另造。
//
// 双窗口径（判据同一，只换 confirm_index）：
// - 终点窗：confirm_index = 候选评估 bar（生产可达，无前瞻）；
// - 前瞻窗：confirm_index = min(候选 bar + H, 窗末)（上限，用未来数据），H ∈ {360,720,1440,2880}。
//
// 纯 #[cfg(test)]，零生产码改动。候选清单直接读 #1147 原始 dump（与 #1221 同源同口径）。
//
// 跑法：
// `P1223_STRUCT_DUMP_PATH=/tmp/p1223_struct.jsonl \
//   P1147_WINDOW_START=2024-01-01 P1147_WINDOW_END=2025-01-01 \
//   cargo test --release --lib cond1_structural_trend_dx -- --ignored --nocapture`
#[derive(Clone, Copy, Default)]
struct P1223Ev {
    new_center_exists: bool,
    breakout_ok: bool,
    force_exception: bool,
    type2_confirmed: bool,
    n_new_centers: usize,
    n_sub_moves: usize,
}

/// #1223 结构证据（终点窗/前瞻窗同一函数，只换 `confirm_index`）。
/// 判据 = 生产结构函数（不另造）：
/// - [`xzd_c3_new_center_breakout`]：新中枢 + 反向突破（三卖/三买坐实 = 中枢死亡）；
/// - [`xzd_force_exception`]：三买卖坐实后强力不背驰创新高/新低（#985 ForceL，例外臂）；
/// - [`xzd_type2_confirmed`]：二类点（诊断字段，不参与三臂分派）。
fn p1223_evidence(
    cls: &super::super::super::classifier::Classification,
    tower: &[std::rc::Rc<Vec<LeveledMove>>],
    strokes: &[crate::theta_v0::types::Stroke],
    level: u32,
    source_index: usize,
    confirm_index: usize,
    side: Side,
) -> P1223Ev {
    let lvl = level as usize;
    let sub_centers: &[Center] = if lvl > 0 {
        cls.levels
            .get(lvl - 1)
            .map(|ls| ls.centers.as_slice())
            .unwrap_or(&[])
    } else {
        &[]
    };
    let sub_moves: &[LeveledMove] = if lvl > 0 {
        tower.get(lvl - 1).map(|m| m.as_slice()).unwrap_or(&[])
    } else {
        &[]
    };
    let sub_bsp: &[BspPoint] = if lvl > 0 {
        cls.levels
            .get(lvl - 1)
            .map(|ls| ls.bsp.as_slice())
            .unwrap_or(&[])
    } else {
        &[]
    };
    let bsp_of_level: &[BspPoint] = cls
        .levels
        .get(lvl)
        .map(|ls| ls.bsp.as_slice())
        .unwrap_or(&[]);
    let diag = super::xzd_c3_new_center_breakout(
        source_index,
        confirm_index,
        side,
        sub_centers,
        sub_moves,
    );
    let force = super::xzd_force_exception(
        source_index,
        confirm_index,
        side,
        sub_centers,
        sub_bsp,
        sub_moves,
        strokes,
    );
    let type2 = super::xzd_type2_confirmed(bsp_of_level, source_index, side);
    let n_new_centers = sub_centers
        .iter()
        .filter(|c| c.start_index >= source_index && c.end_index <= confirm_index)
        .count();
    P1223Ev {
        new_center_exists: diag.new_center_exists,
        breakout_ok: diag.new_center_breakout_ok,
        force_exception: force,
        type2_confirmed: type2,
        n_new_centers,
        n_sub_moves: sub_moves.len(),
    }
}

/// #1223 价格代理复现输入（与 #1152 sample_structure 同口径，供 Python 侧复现 #1221 价格三分类）：
/// exec_move（执行段）、sub_moves（执行段次级别走势）、anchor_idx（锚定子段下标，Type1 为 None）。
fn p1223_dir_str(d: Option<crate::theta_v0::types::Direction>) -> Option<&'static str> {
    match d {
        Some(crate::theta_v0::types::Direction::Up) => Some("Up"),
        Some(crate::theta_v0::types::Direction::Down) => Some("Down"),
        None => None,
    }
}

fn p1223_price_input(
    tower: &[std::rc::Rc<Vec<LeveledMove>>],
    level: u32,
    source_index: usize,
    is_type23: bool,
) -> (serde_json::Value, serde_json::Value, Option<usize>) {
    use super::super::super::classifier::cand_predicate::rmove_dir;
    use super::super::super::classifier::recursive_tower::{
        find_move_by_end_index, find_move_containing_index,
    };
    let lvl = level as usize;
    let mut exec_move = serde_json::Value::Null;
    let mut sub_moves = serde_json::Value::Null;
    let mut anchor_idx: Option<usize> = None;
    if let Some(exec_moves) = tower.get(lvl).map(|m| m.as_slice()) {
        if let Some(si) = find_move_containing_index(exec_moves, source_index) {
            let s = &exec_moves[si];
            exec_move = serde_json::json!({
                "start": s.start_index,
                "end": s.end_index,
                "dir": p1223_dir_str(rmove_dir(&s.rmove)),
            });
            let subs = s.sub_moves.as_slice();
            sub_moves = serde_json::json!(subs
                .iter()
                .map(|m| {
                    serde_json::json!({
                        "start": m.start_index,
                        "end": m.end_index,
                        "dir": p1223_dir_str(rmove_dir(&m.rmove)),
                    })
                })
                .collect::<Vec<_>>());
            if is_type23 {
                anchor_idx = find_move_by_end_index(subs, source_index)
                    .or_else(|| find_move_containing_index(subs, source_index));
            }
        }
    }
    (exec_move, sub_moves, anchor_idx)
}

#[test]
#[ignore]
fn cond1_structural_trend_dx() {
    use super::super::data;
    use super::super::incremental::IncrementalClassifier;
    use std::collections::HashMap;
    use std::io::Write as _;

    let Some(out_path) = std::env::var(crate::theta_v0::env_registry::P1223_STRUCT_DUMP_PATH)
        .ok()
        .filter(|s| !s.is_empty())
    else {
        eprintln!("[p1223] P1223_STRUCT_DUMP_PATH 未设 ⟹ no-op");
        return;
    };
    let cand_path =
        std::env::var(crate::theta_v0::env_registry::P1223_CAND_PATH).unwrap_or_else(|_| {
            std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
                .parent()
                .expect("rust/ 父目录 = 项目根")
                .join(".chanlun/review-results/issue1147-stepfail-raw-2024.jsonl")
                .to_string_lossy()
                .to_string()
        });
    const HORIZONS: [usize; 4] = [360, 720, 1440, 2880];

    let config = ThetaConfig::default();
    let ds_full = match data::load_by_symbol("BTC", &config) {
        Ok(d) => d,
        Err(e) => panic!("BTC 加载失败：{e}（DATA BLOCKER，不伪造合成）"),
    };
    let start = std::env::var(crate::theta_v0::env_registry::P1147_WINDOW_START)
        .unwrap_or_else(|_| "2024-01-01".to_string());
    let end = std::env::var(crate::theta_v0::env_registry::P1147_WINDOW_END)
        .unwrap_or_else(|_| "2024-01-07".to_string());
    let ds = ds_full.slice_date_window(&start, &end);
    assert!(!ds.bars.is_empty(), "窗口 {start}..{end} 非空");
    let bars = &ds.bars;
    let n = bars.len();

    // 载入 308 cond1 拒候选（would_close ∧ !admit ∧ stepfail∈cond1），按 (bar, level, source_index, side) 去重。
    #[derive(Clone)]
    struct Cand {
        bar: usize,
        level: u32,
        source_index: usize,
        side: Side,
        stepfail: String,
    }
    let mut cands: Vec<Cand> = Vec::new();
    {
        let text = std::fs::read_to_string(&cand_path)
            .unwrap_or_else(|e| panic!("候选 dump 读取失败 {cand_path}：{e}"));
        let mut seen = std::collections::HashSet::new();
        for line in text.lines() {
            let line = line.trim();
            if line.is_empty() {
                continue;
            }
            let Ok(v) = serde_json::from_str::<serde_json::Value>(line) else {
                continue;
            };
            let (Some(bar), Some(level), Some(si)) = (
                v.get("bar").and_then(|x| x.as_u64()),
                v.get("level").and_then(|x| x.as_u64()),
                v.get("source_index").and_then(|x| x.as_u64()),
            ) else {
                continue;
            };
            let would_close = v
                .get("would_close")
                .and_then(|x| x.as_bool())
                .unwrap_or(false);
            let admit = v.get("admit").and_then(|x| x.as_bool()).unwrap_or(true);
            let stepfail = v.get("stepfail").and_then(|x| x.as_str()).unwrap_or("");
            let is_cond1 = matches!(
                stepfail,
                "type23_descend_nodiv_condSome(1)" | "type1_div_fail_Some(1)"
            );
            if !(would_close && !admit && is_cond1) {
                continue;
            }
            let side = match v.get("dir").and_then(|x| x.as_str()) {
                Some("Long") => Side::Long,
                Some("Short") => Side::Short,
                _ => continue,
            };
            if seen.insert((bar as usize, level as u32, si as usize, side)) {
                cands.push(Cand {
                    bar: bar as usize,
                    level: level as u32,
                    source_index: si as usize,
                    side,
                    stepfail: stepfail.to_string(),
                });
            }
        }
    }
    // 候选 bar 索引相对本窗口（#1147 同窗 2024-01-01..2025-01-01 时逐位对齐）；超出本窗口的
    // 候选（缩窗烟测时出现）不属于本窗口数据，直接排除，不落 garbage 证据。
    cands.retain(|c| c.bar < n);
    eprintln!(
        "[p1223] cond1 候选 = {}（窗口 {start}..{end}，bars={n}，H={:?}）",
        cands.len(),
        HORIZONS
    );

    // 检查点分桶：终点窗在 bar；前瞻窗在 min(bar+H, n-1)。
    let mut end_at: HashMap<usize, Vec<usize>> = HashMap::new();
    let mut fwd_at: HashMap<usize, Vec<(usize, usize)>> = HashMap::new();
    // 前瞻窗第二锚：confirm_index = source_index + H（与 #1206 前瞻价格窗 (source_index, +H] 同锚）。
    let mut fwd_si_at: HashMap<usize, Vec<(usize, usize)>> = HashMap::new();
    for (idx, c) in cands.iter().enumerate() {
        end_at.entry(c.bar).or_default().push(idx);
        for h in HORIZONS {
            let due = (c.bar + h).min(n - 1);
            fwd_at.entry(due).or_default().push((idx, h));
            let due_si = (c.source_index + h).min(n - 1);
            fwd_si_at.entry(due_si).or_default().push((idx, h));
        }
    }

    let mut end_ev: HashMap<usize, P1223Ev> = HashMap::new();
    let mut end_price: HashMap<usize, (serde_json::Value, serde_json::Value, Option<usize>)> =
        HashMap::new();
    let mut fwd_ev: HashMap<(usize, usize), P1223Ev> = HashMap::new();
    let mut fwd_confirm: HashMap<(usize, usize), usize> = HashMap::new();
    let mut fwd_si_ev: HashMap<(usize, usize), P1223Ev> = HashMap::new();
    let mut fwd_si_confirm: HashMap<(usize, usize), usize> = HashMap::new();

    let mut classifier_incr = IncrementalClassifier::new(bars, &config);
    for i in 0..n {
        let bar = &bars[i];
        if bar.untradable || bar.close <= 0 {
            continue;
        }
        let out = classifier_incr.classify_at(i);
        let l0 = classifier_incr
            .last_l0()
            .expect("classify_at 已推进 ParseLayer");
        let strokes: &[crate::theta_v0::types::Stroke] = &l0.strokes;
        if let Some(idxs) = end_at.get(&i) {
            for &idx in idxs {
                let c = &cands[idx];
                end_ev.insert(
                    idx,
                    p1223_evidence(
                        &out.classification,
                        &out.tower,
                        strokes,
                        c.level,
                        c.source_index,
                        i,
                        c.side,
                    ),
                );
                end_price.insert(
                    idx,
                    p1223_price_input(
                        &out.tower,
                        c.level,
                        c.source_index,
                        c.stepfail == "type23_descend_nodiv_condSome(1)",
                    ),
                );
            }
        }
        if let Some(pairs) = fwd_at.get(&i) {
            for &(idx, h) in pairs {
                let c = &cands[idx];
                let ev = p1223_evidence(
                    &out.classification,
                    &out.tower,
                    strokes,
                    c.level,
                    c.source_index,
                    i,
                    c.side,
                );
                fwd_ev.insert((idx, h), ev);
                fwd_confirm.insert((idx, h), i);
            }
        }
        if let Some(pairs) = fwd_si_at.get(&i) {
            for &(idx, h) in pairs {
                let c = &cands[idx];
                let ev = p1223_evidence(
                    &out.classification,
                    &out.tower,
                    strokes,
                    c.level,
                    c.source_index,
                    i,
                    c.side,
                );
                fwd_si_ev.insert((idx, h), ev);
                fwd_si_confirm.insert((idx, h), i);
            }
        }
    }

    // 落盘：每候选一行，含终点窗 + 各 H 前瞻窗。
    let file = std::fs::File::create(&out_path)
        .unwrap_or_else(|e| panic!("结构 dump 创建失败 {out_path}：{e}"));
    let mut w = std::io::BufWriter::new(file);
    let mut missing_end = 0usize;
    let mut missing_fwd = 0usize;
    for (idx, c) in cands.iter().enumerate() {
        let end = match end_ev.get(&idx) {
            Some(e) => *e,
            None => {
                missing_end += 1;
                P1223Ev::default()
            }
        };
        let mut fwd = serde_json::Map::new();
        let mut confirm = serde_json::Map::new();
        let mut trunc = serde_json::Map::new();
        for h in HORIZONS {
            let key = h.to_string();
            match fwd_ev.get(&(idx, h)) {
                Some(e) => {
                    fwd.insert(
                        key.clone(),
                        serde_json::json!({
                            "new_center_exists": e.new_center_exists,
                            "breakout_ok": e.breakout_ok,
                            "force_exception": e.force_exception,
                            "type2_confirmed": e.type2_confirmed,
                            "n_new_centers": e.n_new_centers,
                            "n_sub_moves": e.n_sub_moves,
                        }),
                    );
                    let ci = fwd_confirm.get(&(idx, h)).copied().unwrap_or(0);
                    confirm.insert(key.clone(), serde_json::json!(ci));
                    trunc.insert(key, serde_json::json!(c.bar + h >= n));
                }
                None => {
                    missing_fwd += 1;
                    fwd.insert(key.clone(), serde_json::Value::Null);
                    confirm.insert(key, serde_json::Value::Null);
                }
            }
        }
        let mut fwd_si = serde_json::Map::new();
        let mut confirm_si = serde_json::Map::new();
        let mut trunc_si = serde_json::Map::new();
        for h in HORIZONS {
            let key = h.to_string();
            match fwd_si_ev.get(&(idx, h)) {
                Some(e) => {
                    fwd_si.insert(
                        key.clone(),
                        serde_json::json!({
                            "new_center_exists": e.new_center_exists,
                            "breakout_ok": e.breakout_ok,
                            "force_exception": e.force_exception,
                            "type2_confirmed": e.type2_confirmed,
                            "n_new_centers": e.n_new_centers,
                            "n_sub_moves": e.n_sub_moves,
                        }),
                    );
                    let ci = fwd_si_confirm.get(&(idx, h)).copied().unwrap_or(0);
                    confirm_si.insert(key.clone(), serde_json::json!(ci));
                    trunc_si.insert(key, serde_json::json!(c.source_index + h >= n));
                }
                None => {
                    fwd_si.insert(key.clone(), serde_json::Value::Null);
                    confirm_si.insert(key, serde_json::Value::Null);
                }
            }
        }
        let (exec_move, sub_moves, anchor_idx) = end_price.get(&idx).cloned().unwrap_or((
            serde_json::Value::Null,
            serde_json::Value::Null,
            None,
        ));
        let line = serde_json::json!({
            "bar": c.bar,
            "level": c.level,
            "source_index": c.source_index,
            "dir": if c.side == Side::Long { "Long" } else { "Short" },
            "stepfail": c.stepfail,
            "exec_move": exec_move,
            "sub_moves": sub_moves,
            "anchor_idx": anchor_idx,
            "end": {
                "confirm_index": c.bar,
                "new_center_exists": end.new_center_exists,
                "breakout_ok": end.breakout_ok,
                "force_exception": end.force_exception,
                "type2_confirmed": end.type2_confirmed,
                "n_new_centers": end.n_new_centers,
                "n_sub_moves": end.n_sub_moves,
            },
            "fwd": fwd,
            "fwd_confirm_index": confirm,
            "fwd_truncated": trunc,
            "fwd_si": fwd_si,
            "fwd_si_confirm_index": confirm_si,
            "fwd_si_truncated": trunc_si,
        });
        let _ = writeln!(w, "{line}");
    }
    let _ = w.flush();
    eprintln!(
        "[p1223] 落盘 {out_path}：候选={} missing_end={missing_end} missing_fwd={missing_fwd}",
        cands.len()
    );
}
