//! B-M3a（#87）：净额执行原语 seam——自 `runner.rs` **纯移动**（设计文档
//! `chanlun/plans/runner-rs-seam-designs-20260721.md` §M3 节拍 3）：
//! `simulate_fills` / `apply_order` / `apply_fill` / `FillOutcome` / `bar_returns`。
//! 零语义改动；`dual_ledger.rs:472` D8 对拍经 `runner::apply_order` 门面 `pub(crate) use` 继续命中。

use super::super::config::ThetaConfig;
use super::super::types::{Bar, Order, StrictAction};

/// fill 模拟（Θ_exec 基础形态，reference-theta-v0.md:49-54）。
///
/// **可独立于 classify/plan_orders 内部逻辑实装**——只消费 `Vec<Order>`（携带 `exec_index`/
/// `action`/`qty`）。返回 `(权益曲线, 日 returns, 每笔平仓盈亏)`。
///
/// ## 当前实装范围（诚实声明）
///
/// - 开仓（Buy/Sell）/ 平仓（Close）/ 加减仓（Add/Reduce）按 `exec_index` bar 的 close
///   成交，扣 commission+slippage 费用（`ExecConfig`，bp/side）。
/// - **待补全**（与 strategy 订单语义对齐后，标注非 workaround 而是增量）：
///   - 止损成交（reference:52，long open<止损按 open 出否则 low 触及按 stop）——需 Order
///     携带止损价，当前 [`Order`] 无该字段（待 strategy 定订单是否含止损腿）。
///   - 冲突顺序（reference:54，止损先于开仓 / 高 level 先 / 1/2/3 类序）——需多 level
///     订单流，当前 classify 返回空无 level 信息。
///   - 延迟语义：`Order.exec_index` 已是"执行延迟后的成交 bar"（types.rs:218），fill 直接
///     用之，延迟在 strategy 层计算（此处不重复延迟）。
///
/// ## 资金口径（绝对 NAV，对齐 strategy `AccountState.nav`）
///
/// `Order.qty` 是 strategy sizing 算出的**整数 lot**（绝对手数，reference:47），lot×price =
/// 绝对名义额。fill 用**绝对 NAV**（`initial_nav`）记账——现金/市值都是绝对额，权益曲线
/// 归一化（÷initial_nav）后返回（收益率口径，metrics 用率不用绝对额）。这保留 lot sizing
/// 的绝对名义语义（区别于"归一化 cash=1 + units=qty"的错误口径——后者在 price≫NAV 时永远
/// 买不起 1 lot）。
///
/// **边界条件**：`orders` 为空（当前阻塞态）⇒ 现金不动，权益曲线 = 持平（全 1.0），
/// trade_pnls 为空。这正确反映"无 Θ 决策"，**不是** bug。
pub(super) fn simulate_fills(
    bars: &[Bar],
    orders: &[Order],
    initial_nav: f64,
    config: &ThetaConfig,
) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
    let n = bars.len();
    let mut equity_curve = Vec::with_capacity(n);
    let mut trade_pnls = Vec::new();

    // 费用率（bp/side → 比率）。commission + slippage（tax=0 默认）。
    let fee_rate =
        (config.exec.commission_bps + config.exec.slippage_bps + config.exec.tax_bps) / 10_000.0;

    // 按 exec_index 建索引（同 bar 多订单按出现顺序）。
    // 简单线性扫描：订单按 exec_index 排序后与 bar 主循环对齐。
    let mut sorted_orders: Vec<&Order> = orders.iter().collect();
    sorted_orders.sort_by_key(|o| o.exec_index);

    let nav = if initial_nav > 0.0 { initial_nav } else { 1.0 };
    let mut cash: f64 = nav; // 绝对现金（初始 = NAV）
    let mut units: f64 = 0.0; // 持仓 lot 数（正=多；做空腿待 strategy 订单语义定）
    let mut entry_cost: f64 = 0.0; // 含买入费的每单位成本基（成本对称）
    let mut ord_idx = 0usize;

    for i in 0..n {
        let bar = &bars[i];
        // 成交价 = 该 bar 的 close（f64 域；tick→f64 用 tick_size 还原，比率口径无关）。
        let px = bar.close as f64 * config.tick.tick_size;

        // 处理 exec_index == i 的订单（不可交易 bar 上不成交，reference:53）。
        while ord_idx < sorted_orders.len() && sorted_orders[ord_idx].exec_index == i {
            let o = sorted_orders[ord_idx];
            ord_idx += 1;
            if bar.untradable || px <= 0.0 || o.qty <= 0 {
                continue; // 不可交易 / 非法 qty ⇒ 跳过（reference:47 qty<=0 不交易）。
            }
            apply_order(
                o,
                px,
                fee_rate,
                &mut cash,
                &mut units,
                &mut entry_cost,
                &mut trade_pnls,
            );
        }

        // MtM 权益 = 现金 + 持仓市值，归一化（÷NAV → 收益率口径，初始=1.0）。
        let equity = (cash + units * px) / nav;
        equity_curve.push(equity);
    }

    // 日 returns：1min bar 权益曲线聚合到日。当前骨架用 bar-级 returns 作占位
    // （runner 调用方按 dates 聚合到日时替换为日聚合——见 §3.1"按 1min→日聚合"）。
    // 诚实标注：bar-级 returns 的年化基数 ≠ 日 returns，Sharpe 数值在日聚合接通前不是
    // 协议口径。日聚合需要 dates（Dataset.dates），属指标精确化（非阻塞引擎，待接）。
    let daily_returns = bar_returns(&equity_curve);

    (equity_curve, daily_returns, trade_pnls)
}

/// 应用单个订单到仓位（**方向中性账本**，开/平/加/减仓 + 费用，多空对称）。
///
/// ★v1 做空腿（操作语义补全，对齐 canonical FULL §10「根声部双向全定义状态机」+ §13「有符号
/// 名义头寸 n_v=σ_v·M·P·q」+ Origin.TotalWealth `TW=cash+units×price`）：`units` **有符号**
/// （正=多头，负=空头，0=空仓，对齐 canonical σ_r∈{-1,0,+1}×绝对手数）。订单方向（Buy/Add 增
/// units，Sell/Reduce/Close 减 units）统一映射到有符号 units 增减，**多空完全对称**（删 v0 退化
/// 的 long-only `close_long`，no-patch 重写）。
///
/// ★先平后开（canonical FULL §20「撤单→先平后开」执行序的 fill 层兑现）：任一订单先**平掉反向
/// 持仓部分**（实现 PnL 入 trade_pnls），再用剩余 qty **开新方向仓**（更新成本基）。这使翻转
/// （平多→开空 / 平空→开多）成本基语义无歧义——不存在"多空混合成本基"。
///
/// ★成本对称（缺陷③修复保留，多空两侧统一）：`entry_cost` 是当前持仓**每单位含费成本基**——
/// 多头 = 买入均价含买入费（开仓 cash−含费 cost）；空头 = 卖出均价**扣卖出费后**净收（开空
/// cash+净 proceeds）。平仓 PnL 两侧对称：平多 PnL=平仓proceeds(扣卖出费)−成本基(含买入费)；
/// 平空 PnL=开空成本基(扣卖出费净收)−平空支出(含买入费)。
///
/// ★现金约束（多空对称）：开多需 `cash ≥ 含费 cost`（现金买入）；开空收到卖出 proceeds（cash+），
/// 无需预付现金（保证金约束属 canonical §11/§14 K_Θ 风险可行集，v0 未建模——诚实有效域 L0：
/// 做空保证金/借券成本未建模，标注非全 canonical §11，是 σ 双向 + TW 账本的最小兑现）。
pub(crate) fn apply_order(
    o: &Order,
    px: f64,
    fee_rate: f64,
    cash: &mut f64,
    units: &mut f64,
    entry_cost: &mut f64,
    trade_pnls: &mut Vec<f64>,
) -> FillOutcome {
    let qty = o.qty as f64;
    // 订单 → (有符号成交方向 δ, 是否纯平仓 close_only)。
    // ★信号成交（Buy/Add/Sell）：可「先平后开」翻转（开多 δ+1 / 开空 δ−1）。
    // ★纯平仓（Close/Reduce，v1 做空腿方向感知）：平掉当前持仓——平多=卖（δ−1），平空=买（δ+1），
    //   **只平不反向开**（close_only=true，剩余 qty 超持仓时不借机开反向仓）。build_exit_order 对
    //   多空两腿都产 `StrictAction::Close`（不带方向），故成交方向由**当前持仓符号**决定；空仓 ⟹ 无操作。
    // ★A'（codex GAP3 裁定清单③）：返回本次 fill 的费后已实现 PnL（透传 [`apply_fill`]，
    //   无平仓分量 = 0.0）——TW 账本 Realize 的唯一合法资金源。
    let (delta, close_only): (f64, bool) = match o.action {
        StrictAction::Buy | StrictAction::Add => (1.0, false),
        StrictAction::Sell => (-1.0, false),
        StrictAction::Reduce | StrictAction::Close => {
            if *units > 0.0 {
                (-1.0, true) // 持多 ⟹ 卖出平多
            } else if *units < 0.0 {
                (1.0, true) // 持空 ⟹ 买回平空
            } else {
                return FillOutcome::noop(); // 空仓无仓可平
            }
        }
        StrictAction::Hold | StrictAction::Wait => return FillOutcome::noop(), // 不动
    };
    apply_fill(
        delta, qty, close_only, px, fee_rate, cash, units, entry_cost, trade_pnls,
    )
}

/// **方向中性成交**（v1 做空腿核心，先平后开）：有符号方向 `delta`（+1 买/−1 卖）× 绝对手数 `qty`。
///
/// 分两段（canonical §20 先平后开）：
/// 1. **平反向**：若新成交方向与当前持仓反向（`units·delta < 0`），先平掉 `min(qty, |units|)` 手，
///    实现 PnL 入 trade_pnls（多空 PnL 公式对称，见下），cash 反向于 units 变化。
/// 2. **开新仓**：剩余 `qty − 已平` 手按 `delta` 方向开仓，加权平均更新含费成本基。
///
/// PnL 口径（成本对称，多空统一）：
/// - 平多（delta=−1，units>0）：proceeds=平仓 qty×px×(1−fee)，cost_basis=qty×entry_cost（开仓含买入费）⟹ PnL=proceeds−cost_basis。
/// - 平空（delta=+1，units<0）：开空成本基=qty×entry_cost（开空扣卖出费净收），平空支出=qty×px×(1+fee)（买回含买入费）⟹ PnL=成本基−支出。
///   两式统一为 `PnL = sign·(entry_cost − px·(1+sign·fee_factor))`，由下方有符号代数自动覆盖。
pub(crate) fn apply_fill(
    delta: f64,
    qty: f64,
    close_only: bool,
    px: f64,
    fee_rate: f64,
    cash: &mut f64,
    units: &mut f64,
    entry_cost: &mut f64,
    trade_pnls: &mut Vec<f64>,
) -> FillOutcome {
    // ★A'（codex GAP3 裁定清单③）：返回 `(费后已实现 PnL, 成交费用)`。
    // - realized：本次 fill 的费后已实现 PnL（仅段 1 平仓分量产生；无平仓 = 0.0）。结算时点硬
    //   边界（推导链第 9 条）：只锚实际平仓 fill 的 close 分支——partial close 按平掉数量结算；
    //   flip（先平后开）只对先平的反向段结算（段 2 开新仓不产 PnL）。
    // - fee_paid（M6 R 分解 Commission+Slippage 独立累计）：本次成交实付费用 = 成交名义 ×
    //   fee_rate（平仓段 close_qty·px + 开仓段 remaining·px）。已内蕴在 cash 现金流的 (1±fee)
    //   因子里，此处**独立**测得供 RDecomposition 守恒断言（校验和 = 账本净变动，非从 net_r 反推）。
    let mut realized = 0.0;
    let mut fee_paid = 0.0;
    let mut closed_qty = 0.0;
    let mut opened_qty = 0.0;
    if qty <= 0.0 || px <= 0.0 {
        return FillOutcome {
            requested_qty: qty.max(0.0),
            executed_qty: 0.0,
            closed_qty,
            opened_qty,
            rejected_qty: qty.max(0.0),
            realized,
            fee: fee_paid,
        };
    }
    let mut remaining = qty;

    // ── 段 1：平反向持仓（units 与 delta 反向 ⟹ 本次成交先减仓）。 ──
    if *units * delta < 0.0 {
        let close_qty = remaining.min(units.abs());
        if close_qty > 0.0 {
            // 平仓现金流：delta=+1（买回平空）cash 减 qty×px×(1+fee)；delta=−1（卖出平多）cash 加 qty×px×(1−fee)。
            // 统一：cash += −delta × qty × px × (1 + delta×fee_rate)。
            let cash_flow = -delta * close_qty * px * (1.0 + delta * fee_rate);
            fee_paid += close_qty * px * fee_rate; // 平仓成交费（commission+slippage+tax）
                                                   // PnL = 持仓方向收益。持仓方向 sign = units.signum()（多=+1，空=−1）。
                                                   // 平多（持多，sign+1）：PnL = proceeds − cost = (qty×px×(1−fee)) − (qty×entry_cost)。
                                                   // 平空（持空，sign−1）：PnL = 开空净收 − 平空支出 = (qty×entry_cost) − (qty×px×(1+fee))。
                                                   // 统一：PnL = sign × (px_exit_net − entry_cost) × qty，其中 px_exit_net 对多=px(1−fee)，对空=px(1+fee)。
            let pos_sign = units.signum();
            let px_exit_net = px * (1.0 - pos_sign * fee_rate);
            let pnl = pos_sign * (px_exit_net - *entry_cost) * close_qty;
            *cash += cash_flow;
            // 平反向：delta 与持仓异号，units += delta×close_qty 使 |units| 减小（向 0 收敛）。
            // 平多（units=+N, delta=−1）⟹ N+(−1)·N=0；平空（units=−N, delta=+1）⟹ −N+1·N=0。
            *units += delta * close_qty;
            trade_pnls.push(pnl);
            realized = pnl; // A'：平仓结算事实（与 trade_pnls 同一值，返回给 TW Realize 生产者）
            closed_qty += close_qty;
            remaining -= close_qty;
            // 全平 ⟹ 成本基归零（无持仓）；未全平 ⟹ 同方向剩余成本基不变（同价同费基）。
            if *units == 0.0 {
                *entry_cost = 0.0;
            }
        }
    }

    // ── 段 2：开新方向仓 / 同向加仓（剩余 qty 按 delta 开仓）。纯平仓 ⟹ 不开新仓。 ──
    if remaining > 0.0 && !close_only {
        // 开仓现金流：开多（delta+1）cash 减 qty×px×(1+fee)（含买入费）；
        // 开空（delta−1）cash 加 qty×px×(1−fee)（卖出净收，扣卖出费）。
        // 统一：cash += −delta × qty × px × (1 + delta×fee_rate)。
        let cash_flow = -delta * remaining * px * (1.0 + delta * fee_rate);
        // 现金约束：开多需现金充足（cash ≥ 买入含费成本）；开空收现金（无预付，保证金 v0 未建模）。
        let need_cash = delta > 0.0; // 仅开多需现金
        let cost = remaining * px * (1.0 + fee_rate);
        if need_cash && *cash < cost {
            return FillOutcome {
                requested_qty: qty,
                executed_qty: closed_qty,
                closed_qty,
                opened_qty,
                rejected_qty: remaining,
                realized,
                fee: fee_paid,
            };
        }
        fee_paid += remaining * px * fee_rate; // 开仓成交费（commission+slippage+tax）
                                               // 每单位含费成本基（多=买入均价含买入费；空=卖出均价扣卖出费净收）。
                                               // 单笔成交成本基 = px × (1 + delta×fee_rate)：多 px(1+fee)，空 px(1−fee)。
        let unit_cost = px * (1.0 + delta * fee_rate);
        let old_units_abs = units.abs();
        let new_units = *units + delta * remaining;
        let new_units_abs = new_units.abs();
        if new_units_abs > 0.0 {
            // 加权平均含费成本基（同方向加仓：旧成本基×旧手数 + 本次成本基×本次手数 ÷ 新手数）。
            *entry_cost = (*entry_cost * old_units_abs + unit_cost * remaining) / new_units_abs;
        }
        *units = new_units;
        *cash += cash_flow;
        opened_qty += remaining;
        remaining = 0.0;
    }
    FillOutcome {
        requested_qty: qty,
        executed_qty: closed_qty + opened_qty,
        closed_qty,
        opened_qty,
        rejected_qty: remaining,
        realized,
        fee: fee_paid,
    }
}

/// 单次订单的真实成交分解。`closed_qty + opened_qty = executed_qty`；未成交余量只进入
/// `rejected_qty`，不得进入执行计数、交易轨迹或声部持仓账。
/// （pub(crate)：关⑤ D8 嵌入恒等对拍（dual_ledger.rs）只读复用，行为零改。）
#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) struct FillOutcome {
    pub(crate) requested_qty: f64,
    pub(crate) executed_qty: f64,
    pub(crate) closed_qty: f64,
    pub(crate) opened_qty: f64,
    pub(crate) rejected_qty: f64,
    pub(crate) realized: f64,
    pub(crate) fee: f64,
}

impl FillOutcome {
    pub(crate) fn noop() -> Self {
        Self {
            requested_qty: 0.0,
            executed_qty: 0.0,
            closed_qty: 0.0,
            opened_qty: 0.0,
            rejected_qty: 0.0,
            realized: 0.0,
            fee: 0.0,
        }
    }
}

/// bar-级 returns（占位；日聚合接通前的 L1 口径）。
pub(super) fn bar_returns(equity: &[f64]) -> Vec<f64> {
    if equity.len() < 2 {
        return Vec::new();
    }
    equity
        .windows(2)
        .map(|w| if w[0] > 0.0 { w[1] / w[0] - 1.0 } else { 0.0 })
        .collect()
}

// ══════════════════════════════════════════════════════════════════════════════
// B-M3b-contract（#91）：fill loop 本体 + FillOutput(Family)
// 自 runner.rs 纯移动（设计文档 §M3 节拍 6 contract 步）。零语义改动；外部消费方经
// `runner::` 门面 `pub use` 不受影响。
// ══════════════════════════════════════════════════════════════════════════════
// ★三方合并（kimi-nest-mainline-20260717）：本文件 = theirs seam 骨架 ∧ ours 教义线语义
// 并集——overlay/FillOutput 经符号级 3-way 合并（#145 出场
// 裁决三元化 ∧ #76/#82/#93/T5b 出场门、#183 T4 归一、#195-#201 账户镜像+shadow+裁决轨、
// #200 先平后开、#209/#237 断言硬门、#90 TwLedgerThread、#75 nest 真链门、W1 声部臂、
// L2-P5/P6 opsem 富化）；ours 独有探针/镜像/shadow 辅助区随 loop 同迁（见下方合并节）。

use super::super::classifier;
use super::super::closed_loop::state::AssemblyState;
use super::super::closed_loop::transition::{hybrid_step, AssemblyEvent};
use super::super::parser;
use super::super::strategy;
use super::super::strategy::ledger::{TwEvent, TwState};
use super::admission::ChiFilterCtx;
use super::admission::{
    exit_candidate_would_close, k_theta_risk_gate, kappa_policy_resolved, nest_cert_gate_enabled,
    voice_exec_gate, NestChainGate, NestGateStats,
};
#[cfg(test)]
use super::admission::{NEST_CERT_GATE_OVERRIDE, VOICE_EXEC_OVERRIDE};
use super::data::Dataset;
use super::ledger::{
    track_position_transition, LedgerOpen, OpsemEntrySnapshot, TwLedgerThread, TypedTrade,
    VoiceVerdictRec, TYPED_TRADE_SCHEMA_VERSION,
};
use super::metrics::{self, Metrics};
use super::opsem_dump::{
    eta_bucket_str, force_state_str, operation_role_str, risk_mode_str,
    strict_nest_sidecar_enabled, summarize_strict_nest_certificates, t_stage_str, voice_side_str,
    OpsemDump, RebaseObservationInput, StrictNestSidecarCollector,
};
use super::signal::{entry_structural_stop, newly_confirmed_step};
use std::rc::Rc;

// ══════════════════════════════════════════════════════════════════════════════
// 三方合并 ours 独有面（教义线 #196-#200/#209/#237）：断言探针三件套、账户镜像、
// silent_drop 判据、shadow 分歧报告路径——随 fill loop seam 同迁（原 runner.rs 私件，
// reset/count 与 silent_drop_exit_type 升格 pub(super) 经 runner 门面供既有测试消费）。
// ══════════════════════════════════════════════════════════════════════════════

// ── ★#198 断言4「首开反向隔离」探针（coverage.rs ancok_probe 同款 thread_local 模式）──
// （原「短差隔离」/shortdiff_isolation 系列，#281 更名 #283 实装。）
thread_local! {
    static REVERSE_OPEN_ISOLATION_PROBE: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
}

fn reverse_open_isolation_probe_bump() {
    REVERSE_OPEN_ISOLATION_PROBE.with(|c| c.set(c.get() + 1));
}

/// 归零首开反向隔离探针（见证测试 run 前调用；仅本模块测试消费，比照 coverage.rs
/// ancok_probe 三件套但无跨模块消费者 ⟹ 不 pub）。
pub(super) fn reverse_open_isolation_probe_reset() {
    REVERSE_OPEN_ISOLATION_PROBE.with(|c| c.set(0));
}

/// 读取首开反向隔离探针快照（ReverseOpen fill 隔离断言在生产路径的触发笔数）。
pub(super) fn reverse_open_isolation_probe_count() -> u64 {
    REVERSE_OPEN_ISOLATION_PROBE.with(std::cell::Cell::get)
}

/// ★#198 断言4 前置快照：全部非 ReverseOpen（Core{*}/Short{*}）分实例的 (key, qty)。
#[cfg(debug_assertions)]
fn non_reverse_open_qty_snapshot(
    view: &strategy::account::ParallelAccountLedger,
) -> std::collections::HashMap<strategy::account::AccountKey, f64> {
    view.instances()
        .iter()
        .filter(|(k, _)| {
            !matches!(
                k.account,
                strategy::account::AccountIdentity::ReverseOpen { .. }
            )
        })
        .map(|(k, i)| (*k, i.qty))
        .collect()
}

/// ★#198 断言4（#185「建议断言」4 的生产执行层同款）：`fill.account == ReverseOpen ⟹
/// Δqty(Core{*})==0 且 Δqty(Short{*})==0`——首开反向过账不得碰本仓/空仓任何分实例
/// （模型层「父仓不动」曾有 SplitLegLedger 等价保证——该机已随 #282 删除，本断言
/// 守生产执行层同款）。
///
/// 度量方式 = 账本状态**差分**（post 前快照 vs post 后逐实例比对，独立度量，非重算
/// `post` 的过账逻辑）；定位 = **回归锁**（与 #145 T1 同款纪律）：`post` 当前按单 key
/// 过账本满足隔离，本断言看守的是未来改动（执行延迟净额队列的逐账户投影属
/// #199/#200 接线面）把跨账户写引入过账路径时先炸而非静默漂移。挂载点说明：实仓
/// 净额 `units` 无账户键，并行记账视图（#197 expand）是当前唯一账户投影层——断言
/// 只能落此；净额出口行为不受本断言影响（debug 构建逐笔核对，release 编译消除）。
#[cfg(debug_assertions)]
fn debug_assert_reverse_open_isolation(
    view: &strategy::account::ParallelAccountLedger,
    pre: &std::collections::HashMap<strategy::account::AccountKey, f64>,
) {
    for (k, inst) in view.instances().iter().filter(|(k, _)| {
        !matches!(
            k.account,
            strategy::account::AccountIdentity::ReverseOpen { .. }
        )
    }) {
        let before = pre.get(k).copied().unwrap_or(0.0);
        debug_assert_eq!(
            inst.qty, before,
            "#198 断言4 首开反向隔离违例：ReverseOpen fill 改动 {:?} 分实例 qty（{} → {}）",
            k.account, before, inst.qty
        );
    }
    debug_assert_eq!(
        view.instances()
            .keys()
            .filter(|k| !matches!(
                k.account,
                strategy::account::AccountIdentity::ReverseOpen { .. }
            ))
            .count(),
        pre.len(),
        "#198 断言4 首开反向隔离违例：ReverseOpen fill 新增 Core/Short 分实例"
    );
}

// ── ★#199 断言②③探针（#198 断言4 同款 thread_local 模式；恒在计数，
//    「断言在生产路径真实触发」以探针 >0 为凭；断言本体 = debug 构建逐笔核对）──
thread_local! {
    static T1_CORE_ZERO_PROBE: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
    static T1_CORE_RESIDUAL_PROBE: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
    static TYPE2_SELL_GUARD_PROBE: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
    static TYPE2_WITH_CORE_RESIDUAL_PROBE: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
    static RESIDUAL_CORRECTION_PROBE: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
}

/// 断言②评估探针计数（一类 Core 平仓笔数）。
fn t1_core_zero_probe_bump() {
    T1_CORE_ZERO_PROBE.with(|c| c.set(c.get() + 1));
}

/// 归零断言②两枚探针（评估 zero + 违例 residual；见证测试 run 前调用；
/// 仅本模块测试消费 ⟹ 不 pub）。
pub(super) fn t1_core_zero_probe_reset() {
    T1_CORE_ZERO_PROBE.with(|c| c.set(0));
    T1_CORE_RESIDUAL_PROBE.with(|c| c.set(0));
}

/// 读取断言②探针快照（一类 Core 平仓评估笔数）。
pub(super) fn t1_core_zero_probe_count() -> u64 {
    T1_CORE_ZERO_PROBE.with(std::cell::Cell::get)
}

/// ★#209 终态违例探针：一类全平批末**级余额非零**笔数（release 构建可观测面；debug
/// 构建由批次边界 debug_assert 先行拦截）。★#237 起口径 = **批次方向侧**分量余额
/// （一类卖批查多侧/一类买批查空侧，`balance_side` 按方向拆查）。历史对照：#199 测量态
/// BTC 实测违例=1。
fn t1_core_residual_probe_bump() {
    T1_CORE_RESIDUAL_PROBE.with(|c| c.set(c.get() + 1));
}

/// 读取级余额违例探针快照（#209 终态见证材料：一类批末批次方向侧 balance(Core{L})≠0
/// 笔数——#237 拆查口径，验收口径 = 全窗 0）。
pub(super) fn t1_core_residual_probe_count() -> u64 {
    T1_CORE_RESIDUAL_PROBE.with(std::cell::Cell::get)
}

/// 断言③前半探针计数（ReverseType2 过账笔数——每笔经「不落 Core 账」约束核对）。
fn type2_sell_guard_probe_bump() {
    TYPE2_SELL_GUARD_PROBE.with(|c| c.set(c.get() + 1));
}

/// 归零断言③前半两枚探针（身份 guard + 歧义测量 with_core_residual；
/// 见证测试 run 前调用；仅本模块测试消费 ⟹ 不 pub）。
pub(super) fn type2_sell_guard_probe_reset() {
    TYPE2_SELL_GUARD_PROBE.with(|c| c.set(0));
    TYPE2_WITH_CORE_RESIDUAL_PROBE.with(|c| c.set(0));
}

/// 读取断言③前半探针快照（ReverseType2 账户约束断言在生产路径的触发笔数）。
pub(super) fn type2_sell_guard_probe_count() -> u64 {
    TYPE2_SELL_GUARD_PROBE.with(std::cell::Cell::get)
}

/// ★#199 断言③后半宽读法歧义测量（Spec 轴评审发现，待裁决）：二类卖
/// （ReverseType2，ReverseOpen/Short 身份）过账时**同级 Core{level} 残余非零**笔数。
/// 票面「qty(Core{L})>0 时必须另发 CoreResidualCorrection{L}」若按宽读法（二类卖
/// 发生时 Core 有残余即须另发纠错单），本探针即该场景的实测发生率：0 笔 = 该场景
/// 生产不存在（歧义消解）；>0 笔 = 待裁决是否另发（#185 存疑区 1：B/C 撞车裁决
/// 规则蓝图有「父仓 active」读法但 #184 未给优先级/双动作规则）。
fn type2_with_core_residual_probe_bump() {
    TYPE2_WITH_CORE_RESIDUAL_PROBE.with(|c| c.set(c.get() + 1));
}

/// 读取歧义测量探针快照（二类卖时同级 Core 残余非零笔数）。
pub(super) fn type2_with_core_residual_probe_count() -> u64 {
    TYPE2_WITH_CORE_RESIDUAL_PROBE.with(std::cell::Cell::get)
}

/// 残余纠错硬门探针计数（CoreResidualCorrection 过账笔数——每笔经残余实测非零核对）。
fn residual_correction_probe_bump() {
    RESIDUAL_CORRECTION_PROBE.with(|c| c.set(c.get() + 1));
}

/// 归零残余纠错硬门探针（见证测试 run 前调用；仅本模块测试消费 ⟹ 不 pub）。
pub(super) fn residual_correction_probe_reset() {
    RESIDUAL_CORRECTION_PROBE.with(|c| c.set(0));
}

/// 读取残余纠错硬门探针快照（CoreResidualCorrection 残余实测断言在生产路径的触发笔数）。
pub(super) fn residual_correction_probe_count() -> u64 {
    RESIDUAL_CORRECTION_PROBE.with(std::cell::Cell::get)
}

/// ★#197 并行记账视图镜像辅助（expand 只读旁路）：共享过账形状——身份解析 + 建单 + 提交成交。
///
/// 账户身份由入场冻结的 `entry_v` × 声部方向映射（[`strategy::account::identity_of`]，与
/// `reverse_exit_type` 同取入场冻结值）；数量 = 腿级 sizing 目标（与 `TypedTrade::units`
/// 同源 `SepLeg.q_units`），符号由调用侧（开/关）给出。腿级账本以决策 bar 为成交时点（与
/// `TypedTrade` 价格口径一致）；执行延迟净额队列的逐账户投影属 #198–#200。
///
/// `identity_of` 返回 `None`（Ambient×Flat）不写账：Flat 方向候选归 𝒦 记录不开腿
/// （interp.rs `assemble_gamma` 文档），不伪造归属。开/关两侧同判据 ⟹ 不会悬挂实例。
#[allow(clippy::too_many_arguments)]
fn account_mirror_post(
    view: &mut strategy::account::ParallelAccountLedger,
    entry_v: strategy::coverage::Vertical,
    side: strategy::voice::VoiceSide,
    level: u32,
    position_node_id: strategy::interp::PositionNodeId,
    signed_delta: f64,
    reason: strategy::account::ActionReason,
    px: f64,
    bar: usize,
) {
    use strategy::account::{AccountKey, AccountOrder};
    let Some(account_id) = strategy::account::identity_of(entry_v, side, level) else {
        return;
    };
    // ★#198 断言4 探针（恒在计数）：ReverseOpen fill 笔数（生产路径见证——
    // 「首开反向隔离断言真实触发」以探针 >0 为凭，断言本体见下方 debug 构建逐笔核对）。
    if matches!(
        account_id,
        strategy::account::AccountIdentity::ReverseOpen { .. }
    ) {
        reverse_open_isolation_probe_bump();
    }
    // 断言4 前置快照（仅 ReverseOpen 过账时；debug 构建，release 编译消除）。
    #[cfg(debug_assertions)]
    let pre_non_reverse_open = matches!(
        account_id,
        strategy::account::AccountIdentity::ReverseOpen { .. }
    )
    .then(|| non_reverse_open_qty_snapshot(view));
    // ★#199 断言③探针（恒在计数）+ 硬门（debug 逐笔核对，release 编译消除）：
    // - 前半「二类卖身份」：ReverseType2 仅落 ReverseOpen/Short 两身份，永不落 Core 账；
    // - 后半「仅残余才纠错」：CoreResidualCorrection 仅在核心残余实测非零时触发
    //   （post 前余额含被关腿在册量；与 runner 分流点 `has_residual` 同口径）。
    if reason == strategy::account::ActionReason::ReverseType2 {
        type2_sell_guard_probe_bump();
        debug_assert!(
            !matches!(account_id, strategy::account::AccountIdentity::Core { .. }),
            "#199 断言③违例：二类卖（ReverseType2）落 {:?}——合法二类卖出仅 ReverseOpen/Short 两身份",
            account_id
        );
        // ★#199 断言③后半宽读法歧义测量（不置断言，待裁决）：二类卖过账时同级
        // Core{level} 残余非零则计数（post 前余额含在飞腿；宽读法场景实测发生率）。
        if view.has_residual(strategy::account::AccountIdentity::Core { level }) {
            type2_with_core_residual_probe_bump();
        }
    }
    if reason == strategy::account::ActionReason::CoreResidualCorrection {
        residual_correction_probe_bump();
        debug_assert_ne!(
            view.balance(account_id),
            0.0,
            "#199 断言③违例：CoreResidualCorrection 在核心残余为零时触发（{:?}）——仅残余才纠错",
            account_id
        );
    }
    view.post(
        AccountOrder {
            key: AccountKey::new(account_id, level, position_node_id),
            reason,
            qty_delta: signed_delta,
            decision_bar: bar,
        },
        px,
        bar,
    );
    // ★#198 断言4 逐笔核对：ReverseOpen fill 后 Core{*}/Short{*} 分实例数量零变动。
    #[cfg(debug_assertions)]
    if let Some(pre) = pre_non_reverse_open {
        debug_assert_reverse_open_isolation(view, &pre);
    }
    // ★#199 断言②评估探针（恒在计数）：一类 Core 平仓评估笔数（#185 断言2：
    // filled(T1CoreClose{L}) ⟹ execution_ledger.qty(Core{L})==0）。
    //
    // ★#209 终态硬门**挂在批次边界**（π fill loop 反向关闭循环结束点，见该处注释）：
    // 多核心腿场景一类全平产生多条 AccountOrder（每腿恰一），逐笔 post 后账户余额
    // 仍含未平同级腿——单笔粒度误报，教义口径是「一类批末该级清仓」。本点只保留
    // 评估探针（按腿计数，与 fills 分类笔数对账口径不变）。历史对照（勿删）：#199
    // 测量态 BTC train 窗实测违例=1（一类只关首条，L=1 残留 277.9 单位）。
    if reason == strategy::account::ActionReason::ReverseType1
        && matches!(account_id, strategy::account::AccountIdentity::Core { .. })
    {
        t1_core_zero_probe_bump();
    }
}

/// ★#197：开腿镜像（reason=Open，符号 = 多正空负）。开腿方向恒非 Flat（见 `account_mirror_post`）。
///
/// ★#200 理由轴（账户正交，OpenShort 通道）：二类反向候选开**空仓账**（`identity_of` 解析
/// = `Short`）⟹ 理由 `OpenShort`（spec WP-2 修复 c）；其余开仓保留 `Open`（一类首开/加仓、
/// 短差开、级联开）。判据单源 = [`strategy::account::reason_of_open`]，账户身份经
/// [`strategy::account::identity_of`]（与关闭侧 `reason_of_reverse_close` 同判据，不镜像）。
fn account_mirror_open(
    view: &mut strategy::account::ParallelAccountLedger,
    c: &strategy::interp::Candidate,
    level: u32,
    position_node_id: strategy::interp::PositionNodeId,
    units: f64,
    px: f64,
    bar: usize,
) {
    use strategy::voice::VoiceSide;
    let signed = match c.dir {
        VoiceSide::Long => units,
        VoiceSide::Short => -units,
        // 结构不可达（opened 腿恒有方向，𝒦 记录不进 opened）；即便到达，
        // identity_of(*, Flat)=None ⟹ post 跳过，0.0 永不写账。
        VoiceSide::Flat => 0.0,
    };
    // #200：开仓理由 = 通道归属（二类 × Short 账户 ⟹ OpenShort）；identity None（Flat）时
    // 理由不被消费（post 跳过），给 Open 与全域口径一致（不伪造通道标注）。
    let reason = strategy::account::identity_of(c.role.v, c.dir, level)
        .map_or(strategy::account::ActionReason::Open, |a| {
            strategy::account::reason_of_open(a, c.bsp_class)
        });
    account_mirror_post(
        view,
        c.role.v,
        c.dir,
        level,
        position_node_id,
        signed,
        reason,
        px,
        bar,
    );
}

/// ★#197：关腿镜像（账户身份与退出理由正交——理由由调用通道给出，符号 = 开侧反向）。
fn account_mirror_close(
    view: &mut strategy::account::ParallelAccountLedger,
    open: &LedgerOpen,
    level: u32,
    reason: strategy::account::ActionReason,
    px: f64,
    bar: usize,
) {
    use strategy::voice::VoiceSide;
    let signed = match open.position_node_id.side {
        VoiceSide::Long => -open.units,
        VoiceSide::Short => open.units,
        // 结构不可达（同开侧）；identity_of(*, Flat)=None ⟹ 0.0 永不写账。
        VoiceSide::Flat => 0.0,
    };
    account_mirror_post(
        view,
        open.entry_v,
        open.position_node_id.side,
        level,
        open.position_node_id,
        signed,
        reason,
        px,
        bar,
    );
}

/// ★#198：silent drop（§13 AncOK 连带剪/Stale prune，无触发信号）的 typed 归属判据。
///
/// 账户身份与退出理由正交（#185 修复 a）：账户由 #197 [`strategy::account::identity_of`]
/// （entry_v × 方向）映射（FollowParent 级联核心仓 ⟹ `Core{level}`），剪枝理由由
/// `TypedTrade::via_structural_prune` / `ActionReason::StructuralPrune` 表达——不再用
/// `ExitType` 同时表达两者（同类错桶的根源）。
///
/// 判据：仅 `entry_v == ReverseOpen` 的首开反向腿记 `CloseReverseOpen`；其余（Ambient 根 /
/// FollowParent 级联核心仓）归 `CloseRoot`（core structural exit，account=`Core{level}`、
/// reason=`StructuralPrune`，经 #197 account 层映射）。
///
/// μ 分桶统计口径（随本判据更新，2026-07-23）：`ExitType` 诊断切片维持 #180 冻结铁律
/// （不进 `MuClass` 桶键、不进 χ_t 门控、不进 δ-free 主裁决聚合基），代码零改动；变化的是
/// 桶的**生产语义**——`CloseReverseOpen` 桶自此只含真首开反向腿（FollowParent 级联核心仓的
/// 结构剪枝归 `CloseRoot`），W-VERIFY 5 变体拆解与 `typed_ledger_btc_smoke` 分桶计数按
/// 新口径阅读（BTC train 窗实证翻动：CloseRoot 6→8、CloseReverseOpen 10→8，五枚举总数
/// 25 不变，见 `btc_prune_leg_exit_type_matches_account_identity` 见证注释）。
pub(super) fn silent_drop_exit_type(
    entry_v: strategy::coverage::Vertical,
) -> strategy::interp::ExitType {
    // ★#198 新口径（#185 修复 a）：仅首开反向腿记 CloseReverseOpen；Ambient/FollowParent 归
    // CloseRoot（core structural exit——账户侧 Core{level}+StructuralPrune，经 #197 映射）。
    if entry_v == strategy::coverage::Vertical::ReverseOpen {
        strategy::interp::ExitType::CloseReverseOpen
    } else {
        strategy::interp::ExitType::CloseRoot
    }
}

#[cfg(test)]
thread_local! {
    /// 测试注入点：Some(path) ⟹ **本线程**的 fill loop 在 run 结束落 shadow 分歧报告。
    /// 进程级 env 会被并行测试同时读到并覆写同一路径（opsem 2026-07-13 竞态同款教训）；
    /// 线程局部对并行测试不可见。
    pub(super) static SHADOW_DIVERGENCE_PATH_OVERRIDE: std::cell::RefCell<Option<std::path::PathBuf>> =
        std::cell::RefCell::new(None);
}

/// #196 shadow 分歧报告落盘路径：线程局部 override（测试）优先于进程 env
/// `THETA_V0_SHADOW_DIVERGENCE_PATH`；未设/空串 ⟹ None（零 IO，bit-exact 原路径）。
pub(super) fn shadow_divergence_path() -> Option<std::path::PathBuf> {
    #[cfg(test)]
    {
        if let Some(p) = SHADOW_DIVERGENCE_PATH_OVERRIDE.with(|c| c.borrow().clone()) {
            return Some(p);
        }
    }
    std::env::var_os(crate::theta_v0::env_registry::THETA_V0_SHADOW_DIVERGENCE_PATH)
        .filter(|s| !s.is_empty())
        .map(std::path::PathBuf::from)
}
pub(super) fn pi_theta_fill_loop<F>(
    classify_at: F,
    bars: &[Bar],
    initial_nav: f64,
    config: &ThetaConfig,
    chi: Option<ChiFilterCtx>,
) -> FillOutput
where
    F: FnMut(
        usize,
    ) -> (
        classifier::Classification,
        Vec<std::rc::Rc<Vec<classifier::recursive_tower::LeveledMove>>>,
        Vec<usize>,
        u64,
        u64,
        // ★#883：本 bar 因果前缀的 L0 笔序列（Rc 共享只读，source_index 域）——
        // nest 门 L2 旧臂 div_cand 的 ForceL 力度数据源（#873/#989/#990）。
        std::rc::Rc<Vec<super::super::types::Stroke>>,
    ),
{
    // ★M5 wrapper：overlay=None ⟹ 现有净额路径逐字节不变（bit-exact）。overlay 簿接线走
    // [`pi_theta_fill_loop_overlay`]（run_theta_v0_pi_overlay arm 传 Some）。
    // ★LEE M1：level_ledger=None ⟹ 级别账本镜像整段跳过（bit-exact 回归锁，#644）。
    pi_theta_fill_loop_overlay(
        classify_at,
        bars,
        initial_nav,
        config,
        chi,
        None,
        None,
        None,
    )
}

/// ★W1 声部独立执行臂（churn 修复，netting-vs-voice-execution-audit-20260719 §7）：与
/// [`pi_theta_fill_loop`] **同一决策路径**——净额影子账本（cash/units/entry_cost 全部原有
/// 逻辑原样跑）驱动决策层 ⟹ typed_ledger/TW/sep_legs 与净额臂逐字节一致；执行投影换为
/// [`VoiceExecBook`](super::super::strategy::overlay_state::VoiceExecBook)——
/// ① 声部独立持仓（hedge-mode (Q⁺,Q⁻)，PDF §10.2）；② 事件驱动 fill（消费同一
/// `pi_theta_step_traced` 的 step_trace 五类生命周期事件，禁第二裁决源；无事件 bar 零订单）；
/// ③ sizing 冻结（q_v 取开仓 bar 决策层 `SepLeg.q_units` 取整落簿，存续期不随 NAV/价重定）。
/// 生产接入 = `run_theta_v0_pi_overlay` 的 env `VOICE_EXEC=1` gate（默认关闭 = 净额臂 bit-exact）。
#[cfg(test)]
pub(super) fn pi_theta_fill_loop_voice<F>(
    classify_at: F,
    bars: &[Bar],
    initial_nav: f64,
    config: &ThetaConfig,
    chi: Option<ChiFilterCtx>,
    voice: &mut super::super::strategy::overlay_state::VoiceExecBook,
) -> FillOutput
where
    F: FnMut(
        usize,
    ) -> (
        classifier::Classification,
        Vec<std::rc::Rc<Vec<classifier::recursive_tower::LeveledMove>>>,
        Vec<usize>,
        u64,
        u64,
        // ★#883：本 bar 因果前缀的 L0 笔序列（Rc 共享只读，source_index 域）——
        // nest 门 L2 旧臂 div_cand 的 ForceL 力度数据源（#873/#989/#990）。
        std::rc::Rc<Vec<super::super::types::Stroke>>,
    ),
{
    pi_theta_fill_loop_overlay(
        classify_at,
        bars,
        initial_nav,
        config,
        chi,
        None,
        None,
        Some(voice),
    )
}

/// #292（T2 落点门控接线；★★触发源改码，用户裁定 2026-07-26）：单 bar 内驱动中枢生命周期
/// 事件（born/broken/reset/superseded，与 `opsem_dump::feed_center_lifecycle` 同款
/// `consume_chain`/`push_point` 驱动方式，状态独立不交叉——同一张塔链表的两个只读消费者）
/// + **次级别买卖点** → `CenterOscillationTrigger` 构造与 `on_trigger` 消费（A 裁定：中枢身份取
/// 本级 `alive_center()`；B 裁定：触发主信号源 = 次级别已确认买卖点，盘背非必要条件——
/// `PanDivTrigger` 降格为可选辅助，本函数不再消费它，见 `oscillation` 模块头）。纯函数化——
/// 不依赖 `tower_i`/pan_div 门内部，可脱离完整 fill 循环直接单测。顺序：先喂本 bar 生命周期
/// 事件（使 `alive_center()` 反映本 bar 内已发生的死亡），再消费本 bar 次级别买卖点触发。
///
/// ★#292 续修（二轮评审浮出的挂起悬空泄漏）：`ChainConsumed::Rebased` 分支接入
/// `osc_books[lvl].on_chain_rebase`——重基后挂起按身份核对新链，迁移/终结二分，禁悬空。
///
/// ★issue #357：新增 `witness` 观测参数（[`oscillation_campaign::CampaignWiringWitness`]）——
/// 逐挂起终结来源（挂起归宿）+ 逐触发构造结果（`CenterNotAlive` 丢弃率分母/分子）落账，
/// 纯观测不改变本函数既有决策（动作产出逻辑逐字节不变，同 `CenterOscillationActionRecord`
/// 既有先例）。
fn step_center_oscillation(
    bar: usize,
    classification_i: &classifier::Classification,
    classification_step: &classifier::Classification,
    cl_machines: &mut Vec<classifier::center_lifecycle::CenterEventMachine>,
    osc_books: &mut Vec<super::super::strategy::center_oscillation_trade::CenterOscillationBook>,
    witness: &mut super::super::strategy::oscillation_campaign::CampaignWiringWitness,
) -> CenterOscillationStepOutput {
    step_center_oscillation_impl(
        bar,
        classification_i,
        classification_step,
        cl_machines,
        osc_books,
        witness,
        None,
        None,
        false,
    )
}

/// ★#466 D0：仅供 `OPSEM_DUMP_DIR` 已启用的生产循环与事务落盘测试使用。状态推进与
/// [`step_center_oscillation`] 共用同一实现；增量只有 Rebased 时复制旧/新身份链和核销前挂起表。
fn step_center_oscillation_observed(
    bar: usize,
    classification_i: &classifier::Classification,
    classification_step: &classifier::Classification,
    cl_machines: &mut Vec<classifier::center_lifecycle::CenterEventMachine>,
    osc_books: &mut Vec<super::super::strategy::center_oscillation_trade::CenterOscillationBook>,
    witness: &mut super::super::strategy::oscillation_campaign::CampaignWiringWitness,
) -> CenterOscillationStepOutput {
    step_center_oscillation_impl(
        bar,
        classification_i,
        classification_step,
        cl_machines,
        osc_books,
        witness,
        None,
        None,
        true,
    )
}

/// ★#487 历史绑定三类证书的部署去重键：级别 + 精确 Owner + 事件坐标 + 买卖点类型。
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
struct HistoricalSeenKey {
    level: usize,
    owner: classifier::center_lifecycle::CenterId,
    source_index: usize,
    bits_disc: u8,
}

impl HistoricalSeenKey {
    fn new(
        level: usize,
        owner: classifier::center_lifecycle::CenterId,
        source_index: usize,
        bits_disc: u8,
    ) -> Self {
        Self {
            level,
            owner,
            source_index,
            bits_disc,
        }
    }
}

/// ★#487 生产/接线测试入口：接线层把挂起集合与同 bar 结构塔交给纯结构配对函数；
/// classifier 不读取 strategy 状态。`historical_seen` 按精确身份 + 信号坐标/类型去重，避免
/// frontier 重评把同一四边证书重复清算。
fn step_center_oscillation_historical(
    bar: usize,
    classification_i: &classifier::Classification,
    classification_step: &classifier::Classification,
    tower_i: &[Rc<Vec<classifier::recursive_tower::LeveledMove>>],
    historical_seen: &mut std::collections::HashSet<HistoricalSeenKey>,
    cl_machines: &mut Vec<classifier::center_lifecycle::CenterEventMachine>,
    osc_books: &mut Vec<super::super::strategy::center_oscillation_trade::CenterOscillationBook>,
    witness: &mut super::super::strategy::oscillation_campaign::CampaignWiringWitness,
    observe_rebase: bool,
) -> CenterOscillationStepOutput {
    step_center_oscillation_impl(
        bar,
        classification_i,
        classification_step,
        cl_machines,
        osc_books,
        witness,
        Some(tower_i),
        Some(historical_seen),
        observe_rebase,
    )
}

fn step_center_oscillation_impl(
    bar: usize,
    classification_i: &classifier::Classification,
    classification_step: &classifier::Classification,
    cl_machines: &mut Vec<classifier::center_lifecycle::CenterEventMachine>,
    osc_books: &mut Vec<super::super::strategy::center_oscillation_trade::CenterOscillationBook>,
    witness: &mut super::super::strategy::oscillation_campaign::CampaignWiringWitness,
    tower_i: Option<&[Rc<Vec<classifier::recursive_tower::LeveledMove>>]>,
    mut historical_seen: Option<&mut std::collections::HashSet<HistoricalSeenKey>>,
    observe_rebase: bool,
) -> CenterOscillationStepOutput {
    use super::super::strategy::center_oscillation_trade::{
        CenterDrift, CenterOscillationActionRecord, CenterOscillationBook,
        CenterOscillationTrigger, LineageLookup, TerminationSettlement, UnclosedWriteOffRequest,
    };
    use super::super::strategy::voice::VoiceSide;
    use classifier::center_lifecycle::{CenterEventMachine, CenterId, ChainConsumed, PointOutcome};

    let mut actions = Vec::new();
    let mut write_offs: Vec<UnclosedWriteOffRequest> = Vec::new();
    let mut rebase_observations = Vec::new();
    let n_levels = classification_i.levels.len();
    while cl_machines.len() < n_levels {
        let lvl = cl_machines.len() as u32;
        cl_machines.push(CenterEventMachine::new(lvl));
        osc_books.push(CenterOscillationBook::new(lvl));
    }
    for lvl in 0..n_levels {
        let chain: &[super::super::types::Center] = &classification_i.levels[lvl].centers;
        // #292 续修：重基（`ChainConsumed::Rebased`）到达时按身份核对新链——挂起对该级的
        // 处置见 `CenterOscillationBook::on_chain_rebase`（F 裁定：迁移/终结二分，禁悬空）。
        let (consumed, chain_observation) = if observe_rebase {
            cl_machines[lvl].consume_chain_observed(chain)
        } else {
            (cl_machines[lvl].consume_chain(chain), None)
        };
        match consumed {
            ChainConsumed::Advanced { events, .. } => {
                for ev in events.iter() {
                    witness.record_reset_alive_center_leak(ev);
                    let ev_out = osc_books[lvl].on_lifecycle_event(ev);
                    // 当前事件域下 Advanced 只产 Born/Superseded，Reset 只经点产出路径到达；
                    // 此处保留为穷尽性防御，与下方 continuations 穷尽分支同例。
                    witness.record_reset_termination_outcome(ev, &ev_out);
                    // ★#414：延续（`Superseded` 命中挂起 ⟹ 不终结、不清算）——只落观测。
                    for cont in ev_out.continuations.iter() {
                        witness.record_suspension_continued(lvl as u32, cont.side);
                    }
                    for outcome in ev_out.terminations {
                        witness.record_suspension_source(lvl as u32, outcome.side, outcome.source);
                        witness.record_settlement(lvl as u32, outcome.side, outcome.settlement);
                        if let Some(action) = outcome.cover_action {
                            actions.push(CenterOscillationActionRecord {
                                bar,
                                level: lvl as u32,
                                center: outcome.center,
                                action,
                                side: outcome.side, // ★#381：收手回补归属该终结所在的持仓侧
                            });
                        }
                        // ★#366/#472/#489：教义三类点不回补路径 ⟹ 未闭合减出核销；
                        // Reset 不会进入本终结分支。
                        if matches!(outcome.settlement, TerminationSettlement::WriteOffUnclosed) {
                            write_offs.push(UnclosedWriteOffRequest {
                                bar,
                                level: lvl as u32,
                                center: outcome.center,
                                side: outcome.side,
                            });
                        }
                    }
                }
            }
            ChainConsumed::Rebased { revived, .. } => {
                // ★#466 D0：挂起表必须在既有 on_chain_rebase 删除 vanished 条目前抓取。
                // 这里只读复制；下面核销/动作/见证路径逐字不改。
                let rebase_observation = chain_observation.map(|chain| RebaseObservationInput {
                    level: lvl as u32,
                    chain,
                    suspended_before: osc_books[lvl].suspended_identities(),
                    revived,
                });
                // ★#679 D1b：挂起随谱系迁移。谱系簿由本 bar 的塔构造事务证书建成
                // （`classifier::rebase_txn::emit` → `lineage_book::record_edges`，同线程同 bar），
                // 这里按 `(bar, level)` 取视图交给挂起簿判定；`THETA_REBASE_MIGRATE_SKIP=1` ⟹
                // `view_for` 返回 `None` ⟹ 逐字节回到旧行为（反证臂）。
                let lineage = super::super::lineage_book::view_for(bar, lvl);
                let (rebase_outcomes, tally) = osc_books[lvl].on_chain_rebase_lineage(
                    chain,
                    lineage.as_ref().map(|v| v as &dyn LineageLookup),
                );
                super::super::lineage_book::record_tally(&tally);
                if super::super::lineage_book::trace_enabled()
                    && (tally.migrated > 0 || tally.removed > 0 || tally.kept > 0)
                {
                    eprintln!(
                        "[LINEAGE-TRACE] bar={bar} level={lvl} migrated={} kept={:?} tally={tally:?}",
                        tally.migrated,
                        rebase_outcomes.iter().map(|o| (o.side, o.center)).collect::<Vec<_>>(),
                    );
                }
                for outcome in rebase_outcomes {
                    witness.record_suspension_source(lvl as u32, outcome.side, outcome.source);
                    witness.record_settlement(lvl as u32, outcome.side, outcome.settlement);
                    if let Some(action) = outcome.cover_action {
                        actions.push(CenterOscillationActionRecord {
                            bar,
                            level: lvl as u32,
                            center: outcome.center,
                            action,
                            side: outcome.side, // ★#381：收手回补归属该终结所在的持仓侧
                        });
                    }
                    // ★#472：重基悬空改产未闭合减出核销，本分支现为实到达路径；来源仍由
                    // `suspension_by_source.rebase_vanished` 分列。
                    if matches!(outcome.settlement, TerminationSettlement::WriteOffUnclosed) {
                        write_offs.push(UnclosedWriteOffRequest {
                            bar,
                            level: lvl as u32,
                            center: outcome.center,
                            side: outcome.side,
                        });
                    }
                }
                if let Some(observation) = rebase_observation {
                    rebase_observations.push(observation);
                }
            }
            ChainConsumed::Adopted { .. } => {}
        }
        // ★#487：挂起候选集合只在接线层形成。挂起簿给出首次绑定时冻结的完整 Center
        // （起止边 + ZD/ZG），再交 classifier 纯结构函数做旧框右边的紧邻配对。
        // RebaseVanished 已在上方先清表，故消失身份不会在这里复活。
        let historical_points: Vec<classifier::bsp::BspPoint> =
            if let (Some(tower), Some(seen)) = (tower_i, historical_seen.as_deref_mut()) {
                let mut by_event: std::collections::BTreeMap<
                    (usize, u8, CenterId),
                    classifier::bsp::BspPoint,
                > = std::collections::BTreeMap::new();
                let mut owner_bound_events: std::collections::BTreeSet<(usize, u8)> =
                    std::collections::BTreeSet::new();
                for cert in osc_books[lvl]
                    .suspended_frames()
                    .into_iter()
                    .filter_map(|c| {
                        classifier::historical_bound_third_cert(classification_i, tower, lvl, &c)
                    })
                {
                    let p = cert.point;
                    let owner = CenterId::of(&cert.center);
                    let disc = super::signal::bsp_bits_disc(&p.bits);
                    let seen_key = HistoricalSeenKey::new(lvl, owner, p.source_index, disc);
                    if seen.contains(&seen_key) {
                        continue;
                    }
                    // 同一紧邻三类事件可给多个冻结框各自产证；投递键保留 Owner，禁止首项覆盖。
                    // regular 副本抑制仍在下方只按 source/侧进行，不把最近中枢副本一并放进来。
                    let event_key = (p.source_index, disc);
                    if !owner_bound_events.insert(event_key) {
                        witness.record_historical_multi_owner_same_event(lvl as u32);
                    }
                    by_event.insert((p.source_index, disc, owner), p);
                }
                by_event.into_values().collect()
            } else {
                Vec::new()
            };

        let historical_event_keys: std::collections::HashSet<(usize, u8)> = historical_points
            .iter()
            .map(|p| (p.source_index, super::signal::bsp_bits_disc(&p.bits)))
            .collect();
        let regular_points = classification_step
            .levels
            .get(lvl)
            .into_iter()
            .flat_map(|step_level| step_level.bsp.iter())
            // 挂起旧框通过四边证时，所有合法 Owner 已各自产出 bound 点；这里仍按 source/侧
            // 抑制“最近中枢”regular 副本，防的是连坐非 Owner，不限制多个合法 Owner 各自清算。
            .filter(|p| {
                !historical_event_keys
                    .contains(&(p.source_index, super::signal::bsp_bits_disc(&p.bits)))
            })
            .map(|p| (p, false));
        let bound_points = historical_points.iter().map(|p| (p, true));
        // 旧框候选先落账；regular 中同事件副本已在上方抑制，其余点保持既有顺序。
        for (p, requires_binding) in bound_points.chain(regular_points) {
            let owner = match p.center {
                Some(classifier::bsp::OwnerRef::Center(c)) => Some(c),
                _ => None,
            };
            let target = owner.as_ref().map(CenterId::of);
            let is_bound = target.is_some_and(|id| {
                osc_books[lvl].is_suspended_side(VoiceSide::Long, id)
                    || osc_books[lvl].is_suspended_side(VoiceSide::Short, id)
            });
            if requires_binding && !is_bound {
                continue;
            }
            // strategy 挂起态只在接线层转成一次精确授权；只有上方四边配对产出的 bound 点
            // 才能走 historical-bound。普通点即使身份仍挂起，也走原 push_point ⟹ 配对失败的
            // 历史载体保持 Stale；classifier/生命周期机不反向读取账户状态。
            // ★#689：用 `broken_total`（`counts().1`）而非 `historical_bound_kills()` 判定这次
            // 投递是否真的杀掉了目标——改道成功可能落 `Alive`/`Tolerated`（不计入
            // `historical_bound_kills`，见 `push_point_historical_bound` 文档），但两者与
            // `HistoricalBound` 一样都会让 `broken_total` +1；只有这个量对「投递是否送达」
            // 三分支穷尽公平。
            let broken_before = cl_machines[lvl].counts().1;
            let is_historical_attempt = owner.is_some() && requires_binding && is_bound;
            let point_outcome = match owner {
                Some(c) if requires_binding && is_bound => {
                    witness.record_historical_bound_attempted(lvl as u32);
                    // ★#689（用户 2026-07-29 裁定）：锚（`c` 的 CenterId）若已在本级塔链上找不到
                    // （多次重基后旧三元组消失），经挂起簿 `current_identity_of` 折回它的当前
                    // 修订身份再投一次；折不回（无谱系迁移记录）⟹ `None`，行为不变。
                    // `THETA_HISTBIND_REROUTE_SKIP=1` 反证：强制 `None`，逐字节回到改道前旧行为。
                    let reroute_target = if histbind_reroute_skip() {
                        None
                    } else {
                        osc_books[lvl].current_identity_of(CenterId::of(&c))
                    };
                    let outcome = cl_machines[lvl].push_point_historical_bound(
                        p.bits,
                        p.source_index,
                        c,
                        reroute_target,
                    );
                    // seen 的唯一含义是“已完成实际投递”：建表候选与 is_bound 失败均不得登记。
                    let seen = historical_seen
                        .as_deref_mut()
                        .expect("bound 点只由带 historical_seen 的历史接线入口产生");
                    let inserted = seen.insert(HistoricalSeenKey::new(
                        lvl,
                        CenterId::of(&c),
                        p.source_index,
                        super::signal::bsp_bits_disc(&p.bits),
                    ));
                    debug_assert!(inserted, "建表 contains 已排除重复 historical seen key");
                    outcome
                }
                _ => cl_machines[lvl].push_point(p.bits, p.source_index, target),
            };
            if is_historical_attempt && cl_machines[lvl].counts().1 > broken_before {
                witness.record_historical_bound(lvl as u32);
            }
            if point_outcome.is_err() {
                witness.record_center_mis_kill(lvl as u32);
                // ★#689：`historical_bound_by_level` 只认成功分支曾对失败通道失明（两轮审计
                // 因此误判「通道零命中」）——失败也要按级别可见，见 `record_historical_bound_failed`。
                if is_historical_attempt {
                    witness.record_historical_bound_failed(lvl as u32);
                }
            }
            if let Ok(PointOutcome::Event(ev)) = point_outcome {
                witness.record_reset_alive_center_leak(&ev);
                let ev_out = osc_books[lvl].on_lifecycle_event(&ev);
                witness.record_reset_termination_outcome(&ev, &ev_out);
                // ★#414：本路径的 `Superseded` 不由买卖点驱动（`push_point` 只产 Broken/Reset），
                // 故延续在此恒空——留着是穷尽性，不靠「产不出」的隐含前提（同下方核销分支惯例）。
                for cont in ev_out.continuations.iter() {
                    witness.record_suspension_continued(lvl as u32, cont.side);
                }
                for outcome in ev_out.terminations {
                    witness.record_suspension_source(lvl as u32, outcome.side, outcome.source);
                    witness.record_settlement(lvl as u32, outcome.side, outcome.settlement);
                    if let Some(action) = outcome.cover_action {
                        actions.push(CenterOscillationActionRecord {
                            bar,
                            level: lvl as u32,
                            center: outcome.center,
                            action,
                            side: outcome.side,
                        });
                    }
                    if matches!(outcome.settlement, TerminationSettlement::WriteOffUnclosed) {
                        write_offs.push(UnclosedWriteOffRequest {
                            bar,
                            level: lvl as u32,
                            center: outcome.center,
                            side: outcome.side,
                        });
                    }
                }
            }
        }
    }
    // #292 触发源改码（B 裁定）：开启臂生产触发的唯一驱动源 = 次级别（lvl-1）本 bar 已确认
    // 买卖点——本级中枢在场（`alive_center()`，A 裁定）+ 次级别信号方向 + 该点价格 ⟹ 边界侧
    // 独立价格判据（`CenterOscillationTrigger::new` 同口径：卖点价=`pivot_high`、买点价=
    // `pivot_low`，与 `signal.rs::entry_structural_stop` 的 Long→pivot_low/Short→pivot_high
    // 同一读法）。level 0 无次级别（L0 是递归底），故从 lvl=1 起。盘背证据不参与（B 裁定：
    // 非必要条件）。
    for lvl in 1..n_levels {
        let Some(sub_level) = classification_step.levels.get(lvl - 1) else {
            continue;
        };
        let alive_with_index = cl_machines[lvl].alive_center();
        let alive = alive_with_index.map(|(c, _)| CenterId::of(&c));
        // ★#366：本级中枢链的位移态（89 课「中枢不下移」前置过滤的唯一算料）——在场中枢与
        // 其链上前驱**无重叠且整体更低**（`zg < prev.zd`）⟹ 下移；有重叠（中枢扩展/延伸）
        // 或链上无前驱 ⟹ 不下移。链视图取本级 `classification_i.levels[lvl].centers`（与
        // `cl_machines[lvl]` 本 bar 刚消费的同一张链），下标取 `alive_center()` 自带的链下标
        // ——不另立第二套链遍历（A 裁定「身份唯一源」的同精神）。
        //
        // ★口径声明（评审 §1.3/§1.4，2026-07-27 补录，只声明不改行为）：本判据是 89 课原文
        // （前瞻：「这次跌完会不会形成中枢下移」）的**零前视历史代理**（「上次是否已下移」），
        // 且严格小于 `<` 使「两中枢恰好相接」判为不下移＝放行——两处声明的正本见
        // `CenterDrift` 的类型文档，此处不复述、不改判。
        let drift = match alive_with_index {
            Some((alive_center, idx)) if idx > 0 => {
                match classification_i.levels[lvl].centers.get(idx - 1) {
                    Some(prev) if alive_center.zg < prev.zd => CenterDrift::MovedDown,
                    // 有重叠=中枢扩展/延伸（89 课「最多只是中枢扩展」）⟹ 回补放行。
                    Some(_) => CenterDrift::NoDownShift,
                    // 链下标越界（链已被重基缩短等）——不臆造下移结论，照实按「无前驱可比」。
                    None => CenterDrift::NoDownShift,
                }
            }
            _ => CenterDrift::NoDownShift,
        };
        for p in sub_level.bsp.iter() {
            let (signal_side, price) = if p.bits.conf_plus() {
                (VoiceSide::Long, p.pivot_low)
            } else if p.bits.conf_minus() {
                (VoiceSide::Short, p.pivot_high)
            } else {
                continue; // 无买/卖侧确认 bit（不应出现在 bsp 列表中）——防御性跳过，不构造。
            };
            let trigger_result = CenterOscillationTrigger::new(
                lvl as u32,
                alive,
                drift,
                signal_side,
                price,
                p.source_index,
            );
            witness.record_trigger_result(&trigger_result);
            if let Ok(trigger) = trigger_result {
                let center = alive_with_index
                    .map(|(center, _)| center)
                    .expect("触发构造成功蕴含完整在场中枢存在");
                // ★#381：同一次触发对**两侧**各产一条镜像动作（上沿：多头减/空头补；下沿：
                // 多头补/空头减，见 `CenterOscillationBook::on_trigger_side`）——两侧挂起表
                // 独立，各自的幽灵门各自把关（未挂起的收口腿仍返回 `None` 不构造）。侧序固定
                // Long→Short（确定性，与挂起表迭代序同锚）。
                // ★#679 D1b：动作记录挂在**稳定锚**上（未经谱系迁移时 = `trigger.center()`，
                // 逐字节不变）。campaign 的挂起归属账按来源中枢标签分批（`SuspensionBatch::center`），
                // 减出腿与其后的回补/核销必须落在同一个标签上——迁移后若这里改用新链身份，
                // 减出记新标签、核销走锚标签，账就会静默错位成「无主欠账」。
                let anchor = osc_books[lvl].resolve(trigger.center());
                for side in [VoiceSide::Long, VoiceSide::Short] {
                    if let Some(action) =
                        osc_books[lvl].on_trigger_side_bound(side, trigger, center)
                    {
                        actions.push(CenterOscillationActionRecord {
                            bar,
                            level: lvl as u32,
                            center: anchor,
                            action,
                            side,
                        });
                    }
                }
            }
        }
    }
    CenterOscillationStepOutput {
        actions,
        write_offs,
        rebase_observations,
    }
}

/// ★#366：`step_center_oscillation` 的单 bar 产出——减/补动作 + 「未闭合减出」核销请求两路。
/// 两路**分列**（不把核销伪装成一条 `Replenish` 动作）：核销不成交、不产 TwEvent，与真实
/// 减/补动作是不同性质的事件，混入同一 Vec 会让下游把「不回补的终局」记成一笔回补。
#[derive(Debug, Default)]
struct CenterOscillationStepOutput {
    actions: Vec<super::super::strategy::center_oscillation_trade::CenterOscillationActionRecord>,
    write_offs: Vec<super::super::strategy::center_oscillation_trade::UnclosedWriteOffRequest>,
    /// ★#466 D0：仅观测版调用可非空；普通调用恒空，不参与动作/核销/campaign。
    rebase_observations: Vec<RebaseObservationInput>,
}

/// issue #357（T4/#294 生产实例化）：`step_center_oscillation` 产出的减/补动作 → 每重
/// campaign 生死驱动 + 对偶事件记账（ShortDiff 成本基 + Realize 盈亏，经 closed_loop 带门
/// 通道）的接线点。纯函数化——可脱离完整 fill 循环直接单测（同 `step_center_oscillation`
/// 先例），不读取 `tower_i`/pan_div 门内部。
///
/// ★#880（SPEC #847 S2，ADR 0013 裁定二）：**三阶段实例单位 = 重**——`CampaignBook` 键 =
/// (标的, 操作级别)。本函数先把各**结构**级别的本仓快照经 `key_of_level` **聚合到重**
/// （分侧 Σ units / Σ cost_basis；同重跨结构级别共享同一 campaign 实例的接线落点在此），
/// 再每重每 bar 恰 `sync_position` 一次。塔尚无操作级别概念（S3 未落地），生产调用点传
/// legacy 单重键（全账户 = 一个重，同 #879 `ChongBook` 占位）；多重实例化随 S3 换
/// `key_of_level` 映射，本函数聚合语义不变。⚠️ 这不是 per-TInstance 回退——重 ≠ 塔层，
/// 聚合方向是「结构级别 → 重」，不是「每塔层一台」。
///
/// **重内单向**（ADR 0014 裁定一）：聚合后同重两侧同时有持仓 = enforcement 被改坏的
/// 警报——落 witness `chong_side_conflict` 桶（`CampaignViolation::SideConflict`），本 bar
/// 跳过该重的 sync（不猜该听哪一侧），存续 campaign 状态不被改写。
///
/// 顺序：先按本仓口径（编排者裁定 A：`Core{level}` 身份账户）逐级取数、按键聚合后
/// `sync_position`（重持仓空⟺持仓生死判据），再逐条消费本 bar 新产出的减/补动作
/// （`apply_action`，按 `key_of_level(rec.level)` 路由）——与生产调用点
/// `pi_theta_fill_loop_overlay` 的既有顺序一致。
///
/// ★#381（本票）：**两侧对称支持**——campaign 各自独立生死/记账（★#880 后按重分账、侧
/// 为开局属性），空头侧短差为多头镜像（减=回补空头、补=加回空头，判据在
/// `CenterOscillationBook::on_trigger_side`，记账镜像在 `ShortDiffAccount`）。下段 #357 关票
/// 条件 C 的「只支持多头侧」处置**已被 #381 取代**，保留为谱系注记：
/// `unsupported_short_position_count` 桶随之退役。
///
/// ★issue #357 关票条件 C（★已被 #381 取代，下段为历史口径）：**本接线只支持多头侧 campaign**（方案2）——`account_view.balance(account)`
/// 对同身份实例有符号净额求和（account.rs:341-347，多正空负），而 `identity_of` 把
/// `(FollowParent,Short)` 也映到 `Core{level}`（顺父级联空腿）；若改用净额，本级持有空头仓位时
/// 净额可能非正，会被 `sync_position` 的 `units()>0` 判据误判为空仓——campaign 永不开局，空头
/// 侧的震荡短差整支被静默丢弃。改用 `balance_side`/`cost_basis_side` 只读**多头侧**分量
/// （`VoiceSide::Long`），空头侧完全不参与本仓 campaign 的生死判据/sizing 现算——本级若持有
/// 空头仓位，多头侧读数如实为空仓，结构信号触发时的拒绝不算「预期经济场景」，而是「本接线未
/// 支持空头 campaign」，由下方 `is_short_side_held` 传给 witness 单独分桶
/// （`unsupported_short_position_count`，不与真空仓的 `no_active_campaign_count` 混计）。
/// `money` 字段口径 `as i64` 截断：**不再**援引 `TwLedgerThread::sync_basis_raw`
/// 先例——该先例是 `(units.abs()*entry_cost.abs())`（空头取绝对额=在险市值），与本接线改分侧
/// 后的多头侧口径同为正数但成因不同，两者截断写法只是形似，不构成同一惯例，不再混引。
///
/// ★#880 聚合口径（旧「符号不对即视同空仓」按侧按级保留）：逐侧取 `held`（空头侧翻符号）
/// 后 **`held` 截断为整数份数后 `>0` 才进聚合**——某级某侧符号异常（负）或 <1 lot 的分数
/// 持仓视同该级该侧空仓、不稀释同重其它级别的正持仓；成本基只累加有持仓级别的
/// `cost_basis_side`（恒正口径不变）。
#[allow(clippy::too_many_arguments)] // #880 增 key_of_level（结构级别→重映射），同仓惯例
fn drive_campaign_wiring(
    bar: usize,
    n_levels: u32,
    account_view: &strategy::account::ParallelAccountLedger,
    new_osc_actions: &[super::super::strategy::center_oscillation_trade::CenterOscillationActionRecord],
    new_write_offs: &[super::super::strategy::center_oscillation_trade::UnclosedWriteOffRequest],
    price: i64,
    risk_mode: super::super::closed_loop::state::RiskMode,
    campaign_book: &mut super::super::strategy::oscillation_campaign::CampaignBook,
    witness: &mut super::super::strategy::oscillation_campaign::CampaignWiringWitness,
    // ★#880：结构级别 → 重键映射（S3 未落地前生产恒 legacy 单重键）。
    key_of_level: &dyn Fn(u32) -> super::super::strategy::chong::ChongKey,
) {
    use super::super::strategy::chong::ChongKey;
    use super::super::strategy::oscillation_campaign::CampaignViolation;
    use super::super::strategy::short_diff_bucket::CoreCostBasisSnapshot;
    use super::super::strategy::voice::VoiceSide;

    // ★#880：逐（重, 侧）聚合——同重跨结构级别共享同一实例（ADR 0013 裁定二）。
    #[derive(Default)]
    struct ChongAgg {
        long_units: i64,
        long_cost_basis: i64,
        short_units: i64,
        short_cost_basis: i64,
    }
    let mut agg: std::collections::BTreeMap<ChongKey, ChongAgg> = std::collections::BTreeMap::new();
    for lvl in 0..n_levels {
        let account = strategy::account::AccountIdentity::Core { level: lvl };
        // ★#381：逐侧各自取数——空头侧余额是负数（多正空负，account.rs:341-347），按侧
        // **翻符号**（非取绝对值）折成「持有份数」：`held>0 ⟺ 该侧有仓`。取绝对值会把
        // 「多头侧余额意外为负」这类异常态伪装成有仓；翻符号保持「符号不对即视同空仓」
        // 的既有多头侧行为。`cost_basis_side` 恒为正的在险市值口径（account.rs:292
        // `delta.abs()*fill_px`），不翻。★#880：`held` 截断为整数份数后 >0 才进聚合
        // （见函数文档聚合口径）——<1 lot 的分数持仓按旧口径视同空仓，不得建出 units=0
        // 的聚合条目（否则下方 `(false,false) => unreachable!()` 会被触发）。
        for side in [VoiceSide::Long, VoiceSide::Short] {
            let signed = account_view.balance_side(account, side);
            let held = if matches!(side, VoiceSide::Short) {
                -signed
            } else {
                signed
            };
            // 先按旧口径截断成整数份数再判空仓：`held>0.0` 但 `held as i64==0`（分数持仓）
            // 直接进聚合会建出 units=0 的条目，触发 `unreachable!` panic。
            let units = held as i64;
            if units <= 0 {
                continue;
            }
            let entry = agg.entry(key_of_level(lvl)).or_default();
            let cb = account_view.cost_basis_side(account, side) as i64;
            // 迭代域只含 Long/Short（`Flat` 不参与）；用 if/else 避开第三变体的伪穷尽。
            if matches!(side, VoiceSide::Long) {
                entry.long_units += units;
                entry.long_cost_basis += cb;
            } else {
                entry.short_units += units;
                entry.short_cost_basis += cb;
            }
        }
    }
    // 每重每 bar 恰 sync 一次：有持仓的键按聚合快照 sync；簿内现存但本 bar 已无持仓的键
    // 以空仓快照 sync（死亡判据）——死亡事件的侧取自将死 campaign 自身，此处 `Long` 为
    // 占位（空仓快照不携侧，该入参在 (true→false) 分支不被消费）。
    fn sync_one(
        book: &mut super::super::strategy::oscillation_campaign::CampaignBook,
        witness: &mut super::super::strategy::oscillation_campaign::CampaignWiringWitness,
        bar: usize,
        key: &ChongKey,
        side: VoiceSide,
        units: i64,
        cost_basis: i64,
    ) {
        match book.sync_position(
            key.clone(),
            side,
            CoreCostBasisSnapshot::new(units, cost_basis),
            bar,
        ) {
            Ok(Some(event)) => witness.record_lifecycle(event),
            Ok(None) => {}
            // ★#880：穿零未经过空仓 bar（重内单向 enforcement 被改坏）——落警报桶，
            // 不静默翻侧。
            Err(violation) => witness.record_violation(side, violation),
        }
    }
    for (key, a) in &agg {
        match (a.long_units > 0, a.short_units > 0) {
            (true, true) => {
                // ★#880：重内单向（ADR 0014 裁定一）违例——同重两侧同时有持仓。落警报桶
                // 并跳过本 bar 该重的 sync（不猜听哪一侧，存续 campaign 不被改写）。
                witness.record_violation(
                    VoiceSide::Long,
                    CampaignViolation::SideConflict {
                        campaign_side: VoiceSide::Long,
                        incoming: VoiceSide::Short,
                    },
                );
            }
            (true, false) => sync_one(
                campaign_book,
                witness,
                bar,
                key,
                VoiceSide::Long,
                a.long_units,
                a.long_cost_basis,
            ),
            (false, true) => sync_one(
                campaign_book,
                witness,
                bar,
                key,
                VoiceSide::Short,
                a.short_units,
                a.short_cost_basis,
            ),
            (false, false) => unreachable!("聚合条目仅在整数份数 units>0 时建立"),
        }
    }
    let live_keys: Vec<ChongKey> = campaign_book.keys().cloned().collect();
    for key in &live_keys {
        if !agg.contains_key(key) {
            sync_one(campaign_book, witness, bar, key, VoiceSide::Long, 0, 0);
        }
    }
    for rec in new_osc_actions {
        witness.record_action(rec.level, rec.side, rec.action);
        let key = key_of_level(rec.level);
        match campaign_book.apply_action(&key, rec.side, rec.action, price, risk_mode, rec.center) {
            // ★#380 项三/项一/项四：旧版 `Ok(_outcome) => {}` 把成功产出整个丢弃——阶段推进事件
            // （`RecoverCapital`/`EnterEarning`，#368 切换开关的唯一可读证据）、亏损入账、挂起
            // 冲抵归属全部不可见。现逐项落 witness（纯观测，不改变任何决策）。
            Ok(outcome) => {
                if outcome.loss_accounted {
                    witness.record_loss_accounted(rec.side);
                }
                witness.record_cover(rec.side, &outcome.cover);
                // ★#383：阶段三等金额回补的报告层三项之二/之一（次数 + 净增股数）。
                if outcome.earning_replenish {
                    witness.record_earning_replenish(rec.side, outcome.earning_units_gained);
                }
                // ★#383 订正（ADR 补充十）：「free 够本金但挂起非空 ⟹ 到 0 推进被前置拦下」
                // 的正面读数——不静默（见 `CampaignWiringWitness::profit_ready_but_suspended`）。
                if outcome.stage_progress_suspended {
                    witness.record_profit_ready_but_suspended(rec.side);
                }
                if let Some(ev) = outcome.stage_event {
                    let bars_since_open = campaign_book
                        .campaign(&key)
                        .map(|c| c.bars_since_open(bar))
                        .unwrap_or(0);
                    witness.record_stage_event(rec.level, rec.side, bar, bars_since_open, ev);
                }
            }
            Err(violation) => {
                // ★#381：`is_short_side_held` 随 `unsupported_short_position_count` 桶退役——
                // 拒绝按侧自解释（★#880：含「重有 campaign 但在另一侧」的侧核验拒绝）。
                witness.record_violation(rec.side, violation);
            }
        }
    }
    // ★#366/#472/#489：**未闭合减出核销**——教义三类点不回补路径与 RebaseVanished 工程
    // 失踪路径把该中枢挂起从在途量核销，并分列呈报货缺口/现金。放在减/补动作**之后**：同一 bar
    // 内若该中枢的收手回补也在（闭合与核销互斥，同侧同中枢不会重复清算），顺序不影响结果；
    // 置后使既有动作路径的时序逐字节不变。
    for req in new_write_offs {
        let key = key_of_level(req.level);
        // ★#880：`req.level` 同时是来源中枢的**结构级别**归属（进 `UnclosedReduction.level`
        // 呈报），定位只认键+侧。
        match campaign_book.write_off_unclosed(&key, req.side, req.level, req.center) {
            Ok(Some(reduction)) => witness.record_write_off(&reduction),
            // 该侧重在该侧空仓无 campaign，或该中枢本就无挂起批次（高抛后已自然收口）——照实计数。
            Ok(None) => witness.record_write_off_nothing_to_settle(req.side),
            Err(violation) => witness.record_violation(req.side, violation),
        }
    }
}

#[cfg(test)]
mod campaign_wiring_tests {
    //! issue #357 单测：本仓取数（`Core{level}` 身份账户）→ campaign 生死 + 减/补动作真实
    //! 记账。覆盖：① 本仓口径落地（account_view 取数正确）；② sizing=1/3 落地（经
    //! `oscillation_campaign::OscillationCampaign::reduce_units` 间接见证）；③ campaign
    //! sync_position 随真实持仓事件流生死；④ witness 计数正确。
    use super::super::super::classifier::recursive_tower::ElementId;
    use super::super::super::closed_loop::state::RiskMode;
    use super::super::super::strategy::account::{
        AccountIdentity, AccountKey, AccountOrder, ActionReason,
    };
    use super::super::super::strategy::center_oscillation_trade::{
        CenterOscillationAction, CenterOscillationActionRecord,
    };
    use super::super::super::strategy::interp::{EntryCertificate, PositionNodeId};
    use super::super::super::strategy::ledger::TStage;
    use super::super::super::strategy::oscillation_campaign::{
        CampaignBook, CampaignWiringWitness,
    };
    use super::super::super::strategy::voice::VoiceSide;
    use super::*;

    fn core_key(level: u32) -> AccountKey {
        AccountKey::new(
            AccountIdentity::Core { level },
            level,
            PositionNodeId {
                carrier: ElementId { level, ordinal: 0 },
                entry_certificate: Some(EntryCertificate {
                    level,
                    source_index: 0,
                }),
                side: VoiceSide::Long,
                generation: 0,
            },
        )
    }

    /// ★#880：测试重键（键 = (标的, 操作级别)，ADR 0013 裁定二）。
    fn ck(op_level: u8) -> super::super::super::strategy::chong::ChongKey {
        super::super::super::strategy::chong::ChongKey {
            symbol: "T".to_string(),
            op_level,
        }
    }

    /// ★#880：测试默认映射——所有结构级别同属一重 ("T", 0)（= 生产 legacy 单重占位的同形）。
    fn one_chong(_: u32) -> super::super::super::strategy::chong::ChongKey {
        ck(0)
    }

    fn record(level: u32, action: CenterOscillationAction) -> CenterOscillationActionRecord {
        record_side(level, VoiceSide::Long, action)
    }

    /// ★#381：分侧动作记录构造（`record` = 多头侧特化，既有用例不动）。
    fn record_side(
        level: u32,
        side: VoiceSide,
        action: CenterOscillationAction,
    ) -> CenterOscillationActionRecord {
        CenterOscillationActionRecord {
            side,
            bar: 0,
            level,
            center: classifier::center_lifecycle::CenterId::of(
                &super::super::super::types::Center {
                    zd: 100,
                    zg: 200,
                    dd: 98,
                    gg: 202,
                    start_index: 0,
                    end_index: 10,
                },
            ),
            action,
        }
    }

    /// ★本仓取数正确：`account_view` 开仓 300 股 @10（cost_basis=3000）后，`drive_campaign_wiring`
    /// 应据此对 level 0 开局 campaign（notional_in/holding=3000，与 #197 account 层 `Core{0}`
    /// 取数一致），非编造/写死值。
    #[test]
    fn drive_campaign_wiring_reads_core_account_and_opens_campaign() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        let open = AccountOrder {
            key: core_key(0),
            reason: ActionReason::Open,
            qty_delta: 300.0,
            decision_bar: 0,
        };
        account_view.post(open, 10.0, 0); // 300 股 @10 ⟹ Core{0} balance=300, cost_basis=3000

        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );

        let campaign = book
            .campaign(&ck(0))
            .expect("Core{0} 持仓非空 ⟹ 应已开局 campaign");
        assert_eq!(
            campaign.tw().notional_in,
            3_000,
            "notional_in=本仓口径取数 cost_basis（非编造）"
        );
        assert_eq!(campaign.tw().holding, 3_000);
        assert_eq!(campaign.tw().stage, TStage::CostReduction);
        assert_eq!(
            witness.lifecycle_opened.get("long"),
            Some(&1),
            "witness 分侧记录一次开仓生事件（多头侧）"
        );
    }

    /// ★#366（补充裁定 2026-07-27）端到端：`drive_campaign_wiring` 消费「未闭合减出」核销请求
    /// ⟹ witness 分列呈报货缺口与现金盈余（不相减），TW 不因核销漂移。
    #[test]
    fn drive_campaign_wiring_settles_write_off_and_reports_gap_and_cash_separately() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::Open,
                qty_delta: 300.0,
                decision_bar: 0,
            },
            10.0,
            0,
        );
        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        let actions = vec![record(0, CenterOscillationAction::Reduce)];
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &actions,
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        let tw_before = book.campaign(&ck(0)).unwrap().tw();

        let write_offs = vec![
            super::super::super::strategy::center_oscillation_trade::UnclosedWriteOffRequest {
                bar: 1,
                level: 0,
                center: record(0, CenterOscillationAction::Reduce).center,
                side: VoiceSide::Long,
            },
        ];
        drive_campaign_wiring(
            1,
            1,
            &account_view,
            &[],
            &write_offs,
            9,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );

        assert_eq!(
            witness.unclosed_write_off_count.get("long"),
            Some(&1),
            "核销恰一条"
        );
        assert_eq!(
            witness.unclosed_write_off_units_gap.get("long"),
            Some(&100),
            "货缺口=100 股"
        );
        assert_eq!(
            witness.unclosed_write_off_cash_booked.get("long"),
            Some(&1_200),
            "多头侧桶实收=units·avg_cost+units·(price−avg_cost)=units·price=100·12（与货缺口分列，不相减）"
        );
        let campaign = book.campaign(&ck(0)).unwrap();
        assert_eq!(campaign.tw(), tw_before, "核销不产 TwEvent ⟹ TW 不漂移");
        assert_eq!(campaign.short_diff().bucket().open_units(), 0, "在途量归位");
        assert_eq!(
            campaign.short_diff().bucket().written_off_units(),
            100,
            "核销量留痕"
        );
        assert_eq!(witness.other_violation_count, 0, "正常核销路径不落违规桶");
    }

    /// ★#441（ADR 补充十二）端到端：主仓被全平（持仓→空仓）⟹ campaign 死亡时未收口挂起按
    /// 「未闭合减出」核销，货缺口与桶实收现金分列进 witness 死亡桶（与 #366/#472
    /// 结构终结核销桶分列）。
    #[test]
    fn drive_campaign_wiring_writes_off_suspensions_when_campaign_dies() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::Open,
                qty_delta: 300.0,
                decision_bar: 0,
            },
            10.0,
            0,
        );
        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        let actions = vec![record(0, CenterOscillationAction::Reduce)];
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &actions,
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            book.campaign(&ck(0))
                .unwrap()
                .short_diff()
                .bucket()
                .open_units(),
            100,
            "高抛后挂起在途量=100（未收口）"
        );

        // 主仓全平（本仓 300 股清空）⟹ 下一次接线调用即判死亡。
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::ReverseType1,
                qty_delta: -300.0,
                decision_bar: 1,
            },
            9.0,
            1,
        );
        drive_campaign_wiring(
            1,
            1,
            &account_view,
            &[],
            &[],
            9,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );

        assert!(book.campaign(&ck(0)).is_none(), "全平 ⟹ campaign 终结");
        assert_eq!(witness.lifecycle_died.get("long"), Some(&1));
        assert_eq!(
            witness.death_write_off_count.get("long"),
            Some(&1),
            "死亡吞挂起恰一条"
        );
        assert_eq!(
            witness.death_write_off_units_gap.get("long"),
            Some(&100),
            "货缺口=100 股"
        );
        assert_eq!(
            witness.death_write_off_cash_booked.get("long"),
            Some(&1_200),
            "多头侧桶实收=units·price=100·12（与货缺口分列，不相减）"
        );
        assert!(
            witness.unclosed_write_off_count.is_empty(),
            "不落结构终结核销桶（两条清算路径分列）"
        );
        assert_eq!(
            witness.other_violation_count, 0,
            "正常死亡核销路径不落违规桶"
        );
    }

    /// ★#366：核销请求到达但无可核销（该中枢无挂起批次）⟹ 落独立观测桶，不与真实核销读数
    /// 混计、也不记违规（零读数照实）。
    #[test]
    fn drive_campaign_wiring_records_nothing_to_settle_when_no_open_batch() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::Open,
                qty_delta: 300.0,
                decision_bar: 0,
            },
            10.0,
            0,
        );
        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        let write_offs = vec![
            super::super::super::strategy::center_oscillation_trade::UnclosedWriteOffRequest {
                bar: 0,
                level: 0,
                center: record(0, CenterOscillationAction::Reduce).center,
                side: VoiceSide::Long,
            },
        ];
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &write_offs,
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            witness.unclosed_write_off_nothing_to_settle.get("long"),
            Some(&1)
        );
        assert!(
            witness.unclosed_write_off_count.is_empty(),
            "无核销即无核销读数（不编造）"
        );
        assert_eq!(witness.other_violation_count, 0);
    }

    /// ★#383 端到端（评审挂账：`record_stage_event` 不再由单测直接手调，改走 campaign 本体
    /// 路径）：整支 `drive_campaign_wiring` 驱动到阶段三——`RecoverCapital`/`EnterEarning`
    /// 由生产接线自己落进 witness，切换时点/等金额回补次数/净增股数三项报告读数一并核验。
    ///
    /// 每 bar 一个动作（`drive_campaign_wiring` 单 bar 单价）：奇数 bar 高抛@12、偶数 bar
    /// 回补@8，每轮净赚 100·4=400 ⟹ 第 8 轮（bar 16）足额退本金，bar 17 的高抛上派
    /// `EnterEarning` ⟹ 等金额 sizing 自 bar 18 生效。
    #[test]
    fn drive_campaign_wiring_lands_stage_events_and_earning_readings_end_to_end() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::Open,
                qty_delta: 300.0,
                decision_bar: 0,
            },
            10.0,
            0,
        );
        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );

        let reduce = vec![record(0, CenterOscillationAction::Reduce)];
        let replenish = vec![record(0, CenterOscillationAction::Replenish)];
        for round in 1..=8usize {
            drive_campaign_wiring(
                2 * round - 1,
                1,
                &account_view,
                &reduce,
                &[],
                12,
                RiskMode::Normal,
                &mut book,
                &mut witness,
                &one_chong,
            );
            drive_campaign_wiring(
                2 * round,
                1,
                &account_view,
                &replenish,
                &[],
                8,
                RiskMode::Normal,
                &mut book,
                &mut witness,
                &one_chong,
            );
        }
        // bar 16 的回补上退本金——由生产接线自己记进 witness（非单测手调 record_stage_event）。
        assert_eq!(
            witness.stage_recover_capital_count, 1,
            "★RecoverCapital 经生产路径落 witness"
        );
        assert_eq!(
            witness.stage_events[0],
            super::super::super::strategy::oscillation_campaign::StageEventRecord {
                level: 0,
                side: "long",
                bar: 16,
                bars_since_open: 16,
                kind: "recover_capital",
                amount: 3_000,
            },
            "逐条明细：级别/侧/bar/开局以来 bar 数/退本金额"
        );

        // bar 17 的高抛：free 已够但挂起非空 ⟹ 阶段推进被前置拦下（★2026-07-27 判据订正，
        // ADR 补充十），观测桶记一次、不静默。
        drive_campaign_wiring(
            17,
            1,
            &account_view,
            &reduce,
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            witness.stage_enter_earning_count, 0,
            "★挂起非空 ⟹ 本 bar 不派 EnterEarning"
        );
        assert_eq!(
            witness.profit_ready_but_suspended.get("long"),
            Some(&1),
            "★「到 0 掺水被拦」经生产路径落 witness"
        );

        // bar 18：旧账（bar 17 卖出，阶段一锁定）等量收口 ⟹ 挂起归零，同 bar 派 EnterEarning。
        drive_campaign_wiring(
            18,
            1,
            &account_view,
            &replenish,
            &[],
            8,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            witness.stage_enter_earning_count, 1,
            "★EnterEarning 经生产路径落 witness"
        );
        assert_eq!(witness.stage_events[1].kind, "enter_earning");
        assert_eq!(witness.stage_events[1].bar, 18);
        assert_eq!(
            witness.earning_mode_switch_bar.get(&(0, "long")),
            Some(&19),
            "★切换时点读数=次 bar（19）"
        );
        assert!(
            !book.campaign(&ck(0)).unwrap().earning_active(),
            "事件 bar 上尚未换尺"
        );
        assert!(
            witness.earning_replenish_count.is_empty(),
            "旧账收口不算等金额回补（卖出时锁定）"
        );

        // bar 19 高抛@12（次 bar 起模式生效 ⟹ 阶段三锁定，1_200 进池）→ bar 20 等金额回补@8
        // = floor(1200/8)=150。
        drive_campaign_wiring(
            19,
            1,
            &account_view,
            &reduce,
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert!(
            book.campaign(&ck(0)).unwrap().earning_active(),
            "★次 bar 起模式生效"
        );
        assert_eq!(book.campaign(&ck(0)).unwrap().earning_pool(), 1_200);
        drive_campaign_wiring(
            20,
            1,
            &account_view,
            &replenish,
            &[],
            8,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            witness.earning_replenish_count.get("long"),
            Some(&1),
            "★等金额回补次数"
        );
        assert_eq!(
            witness.earning_units_gained.get("long"),
            Some(&50),
            "★阶段三累计净增股数=150−100"
        );
        assert!(
            witness.earning_cash_unsound_count.is_empty(),
            "阶段三硬门未触发（floor 取整保证不透支）"
        );
        assert_eq!(witness.other_violation_count, 0, "全程接线无记账错误");
    }

    /// ★sizing=1/3 落地 + 动作按 (级别, 动作) 归属正确：Core{0} 持仓 300 股，`Reduce` 动作应
    /// 卖出 100（300/3，#348 裁定），witness 归属分桶恰记一次 (0, reduce)。
    #[test]
    fn drive_campaign_wiring_sizes_reduce_to_one_third_and_tallies_action_by_level() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        let open = AccountOrder {
            key: core_key(0),
            reason: ActionReason::Open,
            qty_delta: 300.0,
            decision_bar: 0,
        };
        account_view.post(open, 10.0, 0);

        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        // 先开局（无动作），再喂一条 Reduce。
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        let actions = vec![record(0, CenterOscillationAction::Reduce)];
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &actions,
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );

        let campaign = book.campaign(&ck(0)).unwrap();
        assert_eq!(
            campaign.short_diff().bucket().open_units(),
            100,
            "sizing=当时持仓(300)/3=100（#348 裁定，整数除法）落地"
        );
        assert_eq!(
            witness.action_by_level.get(&(0, "long", "reduce")),
            Some(&1),
            "归属分桶：level 0 Reduce 恰一次"
        );
        assert!(
            witness.no_active_campaign_count.is_empty(),
            "campaign 已开局 ⟹ 无 NoActiveCampaign 拒绝"
        );
        assert_eq!(
            witness.other_violation_count, 0,
            "接线正常路径下其余通道拒绝恒 0"
        );
    }

    /// ★#526 P2 / #386 G5（#590 MEDIUM-3 措辞订正）：经 `drive_campaign_wiring`（非全 bar 循环
    /// e2e，直调装配函数）的 campaign wiring 走现役 `short_diff_bucket::record_and_apply_dual`，
    /// 同一笔 Reduce 的已实现盈亏在 R 账本 Π 与 TW `Realize` 漂移上必须同数；ShortDiff 成本基腿
    /// 独立守恒，桶现金恰等于「成本基释放 + 已实现盈亏」，不复造第二本 G5 账。
    #[test]
    fn pi_g5_realized_amount_matches_tw_and_r_ledger_through_campaign_wiring() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::Open,
                qty_delta: 300.0,
                decision_bar: 0,
            },
            10.0,
            0,
        );
        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        let before = book
            .campaign(&ck(0))
            .expect("Core{0} 开仓应实例化 campaign")
            .clone();

        let actions = vec![record(0, CenterOscillationAction::Reduce)];
        drive_campaign_wiring(
            1,
            1,
            &account_view,
            &actions,
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        let after = book.campaign(&ck(0)).expect("Reduce 后 campaign 仍存活");

        let child_realized = after.ledger().pi - before.ledger().pi;
        let tw_realized = after.tw().tw() - before.tw().tw();
        let short_diff_basis = before.tw().holding - after.tw().holding;
        let bucket_cash = after.short_diff().bucket().realized_cash()
            - before.short_diff().bucket().realized_cash();

        assert_eq!(child_realized, 200, "100 股 × (12−均价10) = 已实现 200");
        assert_eq!(
            tw_realized, child_realized,
            "G5 同数：R 账本 Π 增量 == TW Realize 漂移 == 子腿已实现盈亏"
        );
        assert_eq!(
            short_diff_basis, 1_000,
            "ShortDiff 成本基腿=100×均价10，单独守恒"
        );
        assert_eq!(
            bucket_cash,
            short_diff_basis + child_realized,
            "#386 单源：桶现金=ShortDiff 成本基释放+Realize，不双写第二套金额"
        );
        assert!(after.ledger().inv_holds(), "R=Π−A−W 恒等保持");
        // ★#590 LOW 脆锁风险注明：`is_err()` 只判「报错与否」不判错误变体——`assert_conserved`
        // 若未来改造出与「在途未回补」无关的新错误分支，本断言仍会绿，不构成该分支的判别力；
        // 本锁的判别力落在其上方三条 assert_eq!（数值同数/成本基/桶现金）。
        assert!(
            after.short_diff().assert_conserved().is_err(),
            "半轮 Reduce 在途未回补，恒仓锁应如实未闭合"
        );
        assert_eq!(
            witness.other_violation_count, 0,
            "生产接线正常路径无记账拒绝"
        );
    }

    /// ★campaign 随真实事件流生死：Core{0} 从空仓→持仓→全平，`drive_campaign_wiring` 逐 bar
    /// 消费 `account_view` 真实状态（非模拟快照），campaign 应恰好随之开局/终结。
    #[test]
    fn drive_campaign_wiring_lifecycle_follows_real_account_event_stream() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();

        // bar0：仍空仓——no-op。
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            10,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert!(book.campaign(&ck(0)).is_none());

        // bar1：真实开仓 fill（200 股 @15）——campaign 应开局。
        let open = AccountOrder {
            key: core_key(0),
            reason: ActionReason::Open,
            qty_delta: 200.0,
            decision_bar: 1,
        };
        account_view.post(open, 15.0, 1);
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            15,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert!(
            book.campaign(&ck(0)).is_some(),
            "真实持仓事件流 ⟹ campaign 开局"
        );
        assert_eq!(witness.lifecycle_opened.get("long"), Some(&1));

        // bar2：真实全平 fill——campaign 应终结。
        let close = AccountOrder {
            key: core_key(0),
            reason: ActionReason::ReverseType1,
            qty_delta: -200.0,
            decision_bar: 2,
        };
        account_view.post(close, 18.0, 2);
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            18,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert!(
            book.campaign(&ck(0)).is_none(),
            "真实全平事件流 ⟹ campaign 终结"
        );
        assert_eq!(witness.lifecycle_died.get("long"), Some(&1));
    }

    /// ★`NoActiveCampaign` 分桶：向未开局的级别喂动作，`apply_action` 返回 `NoActiveCampaign`——
    /// 本仓无持仓时结构信号仍可能触发（#292 CenterOscillationBook「无门」设计，独立于本级
    /// Core 持仓状态），这是**预期经济场景**而非接线错误，故计入 `no_active_campaign_count`
    /// 而非 `other_violation_count`（真正的接线/记账错误警报，本用例应恒 0）。
    #[test]
    fn drive_campaign_wiring_tallies_no_active_campaign_separately_from_other_violations() {
        let account_view = strategy::account::ParallelAccountLedger::new(); // 空仓——无 campaign
        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        let actions = vec![record(0, CenterOscillationAction::Reduce)];
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &actions,
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            witness.no_active_campaign_count.get("long"),
            Some(&1),
            "空仓级别喂动作 ⟹ NoActiveCampaign 按侧分桶计数（预期读数）"
        );
        assert_eq!(
            witness.other_violation_count, 0,
            "非 NoActiveCampaign 的其余违规恒 0（本用例不触发）"
        );
    }

    fn short_key(level: u32) -> AccountKey {
        AccountKey::new(
            AccountIdentity::Core { level },
            level,
            PositionNodeId {
                carrier: ElementId { level, ordinal: 0 },
                entry_certificate: Some(EntryCertificate {
                    level,
                    source_index: 0,
                }),
                side: VoiceSide::Short,
                generation: 0,
            },
        )
    }

    /// ★#381 验收①：本级只持空头仓位（FollowParent×Short 顺父级联核心仓，净额为负）时，
    /// `drive_campaign_wiring` 现在为**空头侧**开局 campaign——`units` 由分侧余额**翻符号**
    /// 折得（−50 → 50，非取绝对值，见 `drive_campaign_wiring` 内注释），`notional_in` 取分侧
    /// 成本基（在险市值 1000，恒为正）。原 #357 的
    /// `unsupported_short_position_count` 桶随之退役（本用例即其退役的正面对照）。
    #[test]
    fn drive_campaign_wiring_opens_short_side_campaign_from_short_only_core() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        let open_short = AccountOrder {
            key: short_key(0),
            reason: ActionReason::Open,
            qty_delta: -50.0,
            decision_bar: 0,
        };
        account_view.post(open_short, 20.0, 0); // 空头 50 股 @20（净额=-50，多头侧=0）

        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            20,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            book.active_count(),
            1,
            "★#880：只开一本（空头侧）——多头侧真空仓不开局（侧不进键，同一键即同一重）"
        );
        let short_campaign = book
            .campaign(&ck(0))
            .expect("★#381：空头侧持仓 ⟹ 空头 campaign 开局");
        assert_eq!(short_campaign.side(), VoiceSide::Short);
        assert_eq!(
            short_campaign.current_units(),
            50,
            "units=分侧余额翻符号（多正空负，−(−50)=50）"
        );
        assert_eq!(
            short_campaign.tw().notional_in,
            1_000,
            "notional_in=空头侧成本基（在险市值 50×20）"
        );
        assert_eq!(
            witness.lifecycle_opened.get("short"),
            Some(&1),
            "恰一次开仓生（空头侧）"
        );
        assert_eq!(
            witness.lifecycle_opened.get("long"),
            None,
            "多头侧无仓 ⟹ 该侧桶不出现"
        );

        // 空头侧「减」=回补空头：sizing=开局冻结 50/3=16，落空头 campaign 而非多头。
        let actions = vec![record_side(
            0,
            VoiceSide::Short,
            CenterOscillationAction::Reduce,
        )];
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &actions,
            &[],
            18,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            book.campaign(&ck(0))
                .unwrap()
                .short_diff()
                .bucket()
                .open_units(),
            16,
            "空头侧 sizing=当时持仓(50)/3=16（整数除法），记入空头 campaign"
        );
        assert_eq!(
            witness.action_by_level.get(&(0, "short", "reduce")),
            Some(&1),
            "动作分桶带持仓侧（#381 键增侧维）"
        );
        assert!(
            witness.no_active_campaign_count.is_empty(),
            "空头侧已开局 ⟹ 无 NoActiveCampaign 拒绝"
        );
        assert_eq!(witness.other_violation_count, 0, "正常记账路径无警报");
    }

    /// ★#381 验收③ 改写（★#880，ADR 0014 裁定一）：多空并存 = **两个重**（不同操作级别）
    /// 互不污染——重内单向，同一键不可多空并存；两侧各自独立 campaign，`notional_in` 各按
    /// 各重成本基（多头 3000 / 空头 1000），生死互不牵连。本条同时是 #880 验收单测：
    /// **同标的不同操作级别各自独立推进三阶段**（键 = (标的, 操作级别)，ADR 0013 裁定二）。
    #[test]
    fn drive_campaign_wiring_long_and_short_campaigns_coexist_without_contamination() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::Open,
                qty_delta: 300.0,
                decision_bar: 0,
            },
            10.0,
            0,
        );
        account_view.post(
            AccountOrder {
                key: short_key(1),
                reason: ActionReason::Open,
                qty_delta: -50.0,
                decision_bar: 0,
            },
            20.0,
            0,
        );

        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        // 两个重：结构级别 0 → 重 ("T",0)（多头），结构级别 1 → 重 ("T",1)（空头）。
        let per_level = |lvl: u32| ck(lvl as u8);
        drive_campaign_wiring(
            0,
            2,
            &account_view,
            &[],
            &[],
            15,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &per_level,
        );

        let long = book.campaign(&ck(0)).expect("多头重 campaign");
        let short = book.campaign(&ck(1)).expect("空头重 campaign");
        assert_eq!(
            long.tw().notional_in,
            3_000,
            "多头重 notional_in 不含空头重的 1000"
        );
        assert_eq!(
            short.tw().notional_in,
            1_000,
            "空头重 notional_in 不含多头重的 3000"
        );
        assert_eq!(long.current_units(), 300);
        assert_eq!(short.current_units(), 50);
        assert_eq!(
            (
                witness.lifecycle_opened.get("long"),
                witness.lifecycle_opened.get("short")
            ),
            (Some(&1), Some(&1)),
            "两重各一次开仓生——分侧重计数，不得相加成 2"
        );

        // 同一 bar 两重各一条镜像动作 ⟹ 各记各账，互不冲抵。
        let actions = vec![
            record_side(0, VoiceSide::Long, CenterOscillationAction::Reduce),
            record_side(1, VoiceSide::Short, CenterOscillationAction::Reduce),
        ];
        drive_campaign_wiring(
            0,
            2,
            &account_view,
            &actions,
            &[],
            15,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &per_level,
        );
        assert_eq!(
            book.campaign(&ck(0))
                .unwrap()
                .short_diff()
                .bucket()
                .open_units(),
            100,
            "多头重挂起=300/3"
        );
        assert_eq!(
            book.campaign(&ck(1))
                .unwrap()
                .short_diff()
                .bucket()
                .open_units(),
            16,
            "空头重挂起=50/3，与多头重互不污染"
        );

        // 多头重全平：只杀多头 campaign，空头重存活。
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::ReverseType1,
                qty_delta: -300.0,
                decision_bar: 1,
            },
            16.0,
            1,
        );
        drive_campaign_wiring(
            1,
            2,
            &account_view,
            &[],
            &[],
            16,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &per_level,
        );
        assert!(
            book.campaign(&ck(0)).is_none(),
            "多头重全平 ⟹ 多头 campaign 死"
        );
        assert!(
            book.campaign(&ck(1)).is_some(),
            "空头重仓位未动 ⟹ 空头 campaign 存活"
        );
        assert_eq!(
            (
                witness.lifecycle_died.get("long"),
                witness.lifecycle_died.get("short")
            ),
            (Some(&1), None),
            "恰一次死亡事件且归属多头侧（空头重存活 ⟹ 该侧无死亡计数）"
        );
    }

    /// ★#880 验收单测：**同重跨结构级别共享同一实例**——结构级别 0/1 的多头持仓经
    /// `key_of_level` 映到同一重 ("T",0) ⟹ 只开一本 campaign，`units`/`notional_in` 为两级
    /// 聚合（300+100 份 / 3_000+2_000）；两级各自派发的动作都落进这同一本账。
    #[test]
    fn drive_campaign_wiring_shares_one_campaign_across_structural_levels_in_same_chong() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::Open,
                qty_delta: 300.0,
                decision_bar: 0,
            },
            10.0,
            0,
        );
        account_view.post(
            AccountOrder {
                key: core_key(1),
                reason: ActionReason::Open,
                qty_delta: 100.0,
                decision_bar: 0,
            },
            20.0,
            0,
        );

        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            2,
            &account_view,
            &[],
            &[],
            15,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            book.active_count(),
            1,
            "同重跨结构级别共享同一实例（不开第二本）"
        );
        let c = book.campaign(&ck(0)).expect("唯一 campaign");
        assert_eq!(c.current_units(), 400, "units=两级聚合 300+100");
        assert_eq!(
            c.tw().notional_in,
            5_000,
            "notional_in=两级成本基聚合 3_000+2_000（汇进同一重的同一个成本）"
        );

        // 级别 1 的结构信号派发的动作落在同一本上（sizing 基准=开局冻结 400/3=133）。
        let actions = vec![record_side(
            1,
            VoiceSide::Long,
            CenterOscillationAction::Reduce,
        )];
        drive_campaign_wiring(
            1,
            2,
            &account_view,
            &actions,
            &[],
            12,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            book.campaign(&ck(0))
                .unwrap()
                .short_diff()
                .bucket()
                .open_units(),
            133,
            "级别 1 的动作落进同一重的同一本账（400/3=133）"
        );
    }

    /// ★issue #357 关票条件 C 的语义已两次改写：#381 改为「多头侧取数不被空头侧污染」，
    /// ★#880（ADR 0014 裁定一「重内单向」）再改为——**同一重内多空并存即违例**：聚合后同重
    /// 两侧同时有持仓 ⟹ 落 witness 警报桶 `chong_side_conflict` 且本 bar 跳过该重的 sync
    /// （不猜听哪一侧，一本 campaign 都不开）。合法的多空并存须分属两个重（不同操作级别），
    /// 见 `drive_campaign_wiring_long_and_short_campaigns_coexist_without_contamination`。
    #[test]
    fn drive_campaign_wiring_mixed_sides_in_one_chong_raises_side_conflict_alarm() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::Open,
                qty_delta: 300.0,
                decision_bar: 0,
            },
            10.0,
            0,
        );
        account_view.post(
            AccountOrder {
                key: short_key(0),
                reason: ActionReason::Open,
                qty_delta: -50.0,
                decision_bar: 0,
            },
            20.0,
            0,
        );

        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            15,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );

        assert_eq!(
            book.active_count(),
            0,
            "同重多空并存 = 重内单向违例 ⟹ 跳过 sync，一本都不开"
        );
        assert_eq!(
            witness.other_violation_count, 1,
            "落一次警报（其余违规总计数）"
        );
        assert_eq!(
            witness
                .other_violation_by_kind
                .get(&("long", "chong_side_conflict")),
            Some(&1),
            "警报桶 = chong_side_conflict（重内单向被改坏）"
        );
        assert!(
            witness.lifecycle_opened.is_empty(),
            "违例 bar 不产生任何开仓生事件"
        );
    }

    /// ★#880 review 回归锁：<1 lot 的分数持仓按旧口径视同空仓——不进聚合、不开 campaign，
    /// 不得触发聚合循环的 `(false,false) => unreachable!()`（修前：`held>0.0` 建出 units=0
    /// 的条目即 panic）。
    #[test]
    fn drive_campaign_wiring_fractional_lot_treated_as_flat_not_panic() {
        let mut account_view = strategy::account::ParallelAccountLedger::new();
        account_view.post(
            AccountOrder {
                key: core_key(0),
                reason: ActionReason::Open,
                qty_delta: 0.5,
                decision_bar: 0,
            },
            10.0,
            0,
        );

        let mut book = CampaignBook::new();
        let mut witness = CampaignWiringWitness::new();
        drive_campaign_wiring(
            0,
            1,
            &account_view,
            &[],
            &[],
            10,
            RiskMode::Normal,
            &mut book,
            &mut witness,
            &one_chong,
        );
        assert_eq!(
            book.active_count(),
            0,
            "分数持仓(<1 lot) 视同空仓，不开 campaign"
        );
        assert!(witness.lifecycle_opened.is_empty());
    }
}

#[cfg(test)]
mod center_oscillation_wiring_tests {
    //! #292 T2 落点门控接线单测（★★触发源改码，用户裁定 2026-07-26）：`step_center_oscillation`
    //! 纯函数化后可脱离完整 fill 循环直接单测（不依赖 tower_i/gate/pan_div/真实市场数据）。
    //! 覆盖验收各项：
    //! - 门控开启臂 · 触发通路：次级别（lvl-1）已确认买卖点驱动 `CenterOscillationTrigger`，
    //!   两边界侧（次级别卖点=上沿高抛 `Reduce`、次级别买点=下沿回补 `Replenish`）均可见；
    //!   **无盘背证据**（本测试模块自 #292 触发源改码后已不再构造任何 `PanDivTrigger`）仍可
    //!   触发——盘背非必要条件（B 裁定）的最强证据即本模块编译期已不存在该依赖。
    //! - 门控开启臂 · 终结通路：中枢链推进+确认三类点 ⟹ 生命周期终结动作可见。
    //! - 门控关闭臂：fill.rs 主循环里本函数整段不被调用（`pan_div_hist=None` 分支跳过），
    //!   `FillOutput.center_oscillation_actions` 恒空——由 v1/dual 路径的诚实空 Vec 字面量
    //!   保证（编译期可见，见 `FillOutput` 三处构造点），本测试补运行期证据。
    //! - #292 续修（二轮评审）：链重基（`ChainConsumed::Rebased`）到达时挂起按身份核对新链——
    //!   仍在链上⟹跟随迁移，从新链消失⟹终结，端到端经 `step_center_oscillation` 可见（见
    //!   `gate_on_chain_rebase_migrates_survivor_and_terminates_vanished_suspension`）。
    use super::super::super::strategy::center_oscillation_trade::{
        CenterDrift, CenterOscillationAction, CenterOscillationBook, CenterOscillationTrigger,
    };
    use super::super::super::strategy::voice::VoiceSide;
    use super::super::super::types::{BspBits, Center, Direction, Side, Tick};
    use super::*;
    use classifier::center::UnitRange;
    use classifier::center_lifecycle::CenterId;
    use classifier::recursive_tower::{ElementId, LeveledMove};
    use classifier::{bsp::BspPoint, bsp::OwnerRef, Classification, LevelState};
    use std::rc::Rc;

    fn center(start_index: usize, end_index: usize, zd: i64, zg: i64) -> Center {
        Center {
            zd,
            zg,
            dd: zd - 2,
            gg: zg + 2,
            start_index,
            end_index,
        }
    }

    fn level_with_centers(centers: Vec<Center>) -> LevelState {
        LevelState {
            centers: Rc::new(centers),
            ..LevelState::default()
        }
    }

    fn level_with_bsp(points: Vec<BspPoint>) -> LevelState {
        LevelState {
            bsp: Rc::new(points),
            ..LevelState::default()
        }
    }

    fn l0_move(
        ordinal: u64,
        direction: Direction,
        start_index: usize,
        end_index: usize,
        lo: Tick,
        hi: Tick,
    ) -> LeveledMove {
        LeveledMove::from_unit(
            &UnitRange {
                start_index,
                end_index,
                direction,
                lo,
                hi,
            },
            ElementId { level: 0, ordinal },
        )
    }

    fn bind_side(book: &mut CenterOscillationBook, center: Center, side: VoiceSide) {
        let (signal_side, price) = match side {
            VoiceSide::Long => (VoiceSide::Short, center.zg),
            VoiceSide::Short => (VoiceSide::Long, center.zd),
            VoiceSide::Flat => panic!("挂起只允许 Long/Short"),
        };
        let trigger = CenterOscillationTrigger::new(
            book.level(),
            Some(CenterId::of(&center)),
            CenterDrift::NoDownShift,
            signal_side,
            price,
            center.end_index,
        )
        .unwrap();
        assert_eq!(
            book.on_trigger_side_bound(side, trigger, center),
            Some(CenterOscillationAction::Reduce)
        );
    }

    struct HistoricalWiringFixture {
        empty_step: Classification,
        cl_machines: Vec<classifier::center_lifecycle::CenterEventMachine>,
        osc_books: Vec<CenterOscillationBook>,
        witness: super::super::super::strategy::oscillation_campaign::CampaignWiringWitness,
        historical_seen: std::collections::HashSet<HistoricalSeenKey>,
    }

    impl HistoricalWiringFixture {
        fn new(initial_centers: Vec<Center>) -> Self {
            let empty_step = Classification {
                levels: vec![LevelState::default()],
            };
            let initial = Classification {
                levels: vec![level_with_centers(initial_centers)],
            };
            let mut fixture = Self {
                empty_step,
                cl_machines: Vec::new(),
                osc_books: Vec::new(),
                witness:
                    super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new(
                    ),
                historical_seen: std::collections::HashSet::new(),
            };
            let _ = step_center_oscillation(
                0,
                &initial,
                &fixture.empty_step,
                &mut fixture.cl_machines,
                &mut fixture.osc_books,
                &mut fixture.witness,
            );
            fixture
        }

        fn bind(&mut self, center: Center, side: VoiceSide) {
            bind_side(&mut self.osc_books[0], center, side);
        }

        fn consume(
            &mut self,
            bar: usize,
            classification: &Classification,
        ) -> CenterOscillationStepOutput {
            step_center_oscillation(
                bar,
                classification,
                &self.empty_step,
                &mut self.cl_machines,
                &mut self.osc_books,
                &mut self.witness,
            )
        }

        fn regular(
            &mut self,
            bar: usize,
            classification: &Classification,
            classification_step: &Classification,
        ) -> CenterOscillationStepOutput {
            step_center_oscillation(
                bar,
                classification,
                classification_step,
                &mut self.cl_machines,
                &mut self.osc_books,
                &mut self.witness,
            )
        }

        fn historical(
            &mut self,
            bar: usize,
            classification: &Classification,
            classification_step: Option<&Classification>,
            tower: &[Rc<Vec<LeveledMove>>],
            observe_rebase: bool,
        ) -> CenterOscillationStepOutput {
            let step = classification_step.unwrap_or(&self.empty_step);
            step_center_oscillation_historical(
                bar,
                classification,
                step,
                tower,
                &mut self.historical_seen,
                &mut self.cl_machines,
                &mut self.osc_books,
                &mut self.witness,
                observe_rebase,
            )
        }
    }

    fn third_class_buy_break(source_index: usize, owner: Center) -> BspPoint {
        BspPoint {
            source_index,
            bits: BspBits {
                buy3: true,
                ..BspBits::default()
            },
            pivot_low: 0,
            pivot_high: 0,
            center: Some(OwnerRef::Center(owner)),
            struct_break_dir: None,
            force: None,
            retrace_breaks_type1: None,
        }
    }

    /// ★#366：本级三类**卖**点破坏（`sell3`，载体=在场中枢）——三卖终局（未闭合减出核销）
    /// 的驱动源，与 `third_class_buy_break` 同规格、只换 bit。
    fn third_class_sell_break(source_index: usize, owner: Center) -> BspPoint {
        BspPoint {
            source_index,
            bits: BspBits {
                sell3: true,
                ..BspBits::default()
            },
            pivot_low: 0,
            pivot_high: 0,
            center: Some(OwnerRef::Center(owner)),
            struct_break_dir: None,
            force: None,
            retrace_breaks_type1: None,
        }
    }

    /// ★#489：本级一类点只广播 Reset；`owner` 仅保留生产点形状，不再授权杀中枢。
    fn first_class_reset(source_index: usize, owner: Center, side: Side) -> BspPoint {
        let bits = match side {
            Side::Long => BspBits {
                buy1: true,
                ..BspBits::default()
            },
            Side::Short => BspBits {
                sell1: true,
                ..BspBits::default()
            },
        };
        BspPoint {
            source_index,
            bits,
            pivot_low: 0,
            pivot_high: 0,
            center: Some(OwnerRef::Center(owner)),
            struct_break_dir: None,
            force: None,
            retrace_breaks_type1: None,
        }
    }

    /// 次级别（lvl-1）已确认买卖点：`side=Long` ⟹ buy1 bit（次级别买点，价格落 `pivot_low`），
    /// `side=Short` ⟹ sell1 bit（次级别卖点，价格落 `pivot_high`）——与生产读法
    /// （`step_center_oscillation`：Long→pivot_low/Short→pivot_high）同口径，供 #292 B 裁定
    /// 独立价格判据消费。无载体（次级别买卖点触发不读次级别中枢，A/B 裁定只认本级
    /// `alive_center()` + 次级别信号方向，`center: None` 即证无门读取次级别账户/结构状态）。
    fn sub_level_bsp_point(source_index: usize, side: VoiceSide, price: Tick) -> BspPoint {
        let (bits, pivot_low, pivot_high) = match side {
            VoiceSide::Long => (
                BspBits {
                    buy1: true,
                    ..BspBits::default()
                },
                price,
                0,
            ),
            VoiceSide::Short => (
                BspBits {
                    sell1: true,
                    ..BspBits::default()
                },
                0,
                price,
            ),
            VoiceSide::Flat => (BspBits::default(), 0, 0),
        };
        BspPoint {
            source_index,
            bits,
            pivot_low,
            pivot_high,
            center: None,
            struct_break_dir: None,
            force: None,
            retrace_breaks_type1: None,
        }
    }

    /// 两级 Classification：level 0（次级别，仅本 bar bsp）+ level 1（本级中枢在场）。
    fn two_level_step(sub_bsp: Vec<BspPoint>) -> Classification {
        Classification {
            levels: vec![level_with_bsp(sub_bsp), LevelState::default()],
        }
    }

    /// 门控开启臂 · 触发通路（B 裁定）：本级（level 1）中枢在场（born 由 consume_chain 推出）
    /// + 次级别（level 0）已确认卖点（`Short`=上沿高抛试探）⟹ `Reduce` 动作可见，身份=本级
    /// `alive_center()`。本测试**不构造任何 `PanDivTrigger`**——`step_center_oscillation` 签名
    /// 已不接受盘背触发参数，编译期即证盘背非必要（B 裁定最强形式）。
    #[test]
    fn gate_on_sub_level_sell_point_produces_visible_reduce_action() {
        let c0 = center(5, 10, 100, 200);
        let classification = Classification {
            levels: vec![LevelState::default(), level_with_centers(vec![c0])],
        };
        let step = two_level_step(vec![sub_level_bsp_point(11, VoiceSide::Short, 200)]); // 中轴150，200≥中轴=上半区
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
        let actions = step_center_oscillation(
            7,
            &classification,
            &step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;
        assert_eq!(actions.len(), 1, "门开+在场+次级别卖点 ⟹ 恰一条动作可见");
        assert_eq!(actions[0].bar, 7);
        assert_eq!(
            actions[0].level, 1,
            "触发落在本级（level 1），非次级别（level 0）"
        );
        assert_eq!(actions[0].center, CenterId::of(&c0), "身份=alive_center()");
        assert_eq!(
            actions[0].action,
            CenterOscillationAction::Reduce,
            "次级别卖点=上沿高抛"
        );
        assert!(osc_books[1].is_suspended(CenterId::of(&c0)));
        assert_eq!(
            witness.trigger_attempts, 1,
            "★issue #357：触发构造尝试计入 witness"
        );
        assert_eq!(witness.dropped_center_not_alive, 0, "本级在场 ⟹ 不丢弃");
    }

    /// 门控开启臂 · 触发通路（B 裁定，另一边界侧）：次级别（level 0）已确认买点（`Long`=下沿
    /// 回补试探）——先高抛挂起，再喂次级别买点 ⟹ `Replenish` 动作可见，挂起清空。
    #[test]
    fn gate_on_sub_level_buy_point_produces_visible_replenish_action() {
        let c0 = center(5, 10, 100, 200);
        let classification = Classification {
            levels: vec![LevelState::default(), level_with_centers(vec![c0])],
        };
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
        let empty_step = two_level_step(Vec::new());
        let reduce_step = two_level_step(vec![sub_level_bsp_point(10, VoiceSide::Short, 200)]);
        let _ = step_center_oscillation(
            0,
            &classification,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;
        let reduce_actions = step_center_oscillation(
            1,
            &classification,
            &reduce_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;
        assert_eq!(reduce_actions[0].action, CenterOscillationAction::Reduce);
        assert!(osc_books[1].is_suspended(CenterId::of(&c0)));

        let cover_step = two_level_step(vec![sub_level_bsp_point(20, VoiceSide::Long, 100)]); // 100≤中轴150=下半区
        let actions = step_center_oscillation(
            2,
            &classification,
            &cover_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;
        // ★#381：同一次下沿触发对两侧各产一条镜像动作——多头侧收口（`Replenish`，回补买入），
        // 空头侧开局（`Reduce`，回补空头）。侧序固定 Long→Short。
        assert_eq!(
            actions.len(),
            2,
            "门开+挂起+次级别买点 ⟹ 多头回补 + 空头开局各一条"
        );
        assert_eq!(actions[0].side, VoiceSide::Long);
        assert_eq!(
            actions[0].action,
            CenterOscillationAction::Replenish,
            "次级别买点=多头侧下沿回补"
        );
        assert_eq!(actions[0].center, CenterId::of(&c0));
        assert_eq!(actions[1].side, VoiceSide::Short);
        assert_eq!(
            actions[1].action,
            CenterOscillationAction::Reduce,
            "空头侧镜像：下沿=减（回补空头）"
        );
        assert!(
            !osc_books[1].is_suspended(CenterId::of(&c0)),
            "多头侧回补出口=该侧挂起清空"
        );
        assert!(
            osc_books[1].is_suspended_side(VoiceSide::Short, CenterId::of(&c0)),
            "空头侧此刻转为挂起（镜像开局腿）"
        );
    }

    /// 门控开启臂 · 终结通路：先触发挂起，再喂本级三类买点破坏（`buy3`，载体=在场中枢）⟹
    /// 生命周期终结事件产出 `Replenish` 收手回补动作，经 `step_center_oscillation` 可见。
    #[test]
    fn gate_on_lifecycle_broken_event_produces_visible_replenish_action() {
        let c0 = center(5, 10, 100, 200);
        let classification = Classification {
            levels: vec![level_with_centers(vec![c0])],
        };
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
        // 先驱动一次空 step 让链同步（Adopted）+ 触发一次高抛挂起（不经本函数：直接摆状态）。
        let empty_step = Classification {
            levels: vec![LevelState::default()],
        };
        let _ = step_center_oscillation(
            0,
            &classification,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;
        osc_books[0].on_trigger(
            super::super::super::strategy::center_oscillation_trade::CenterOscillationTrigger::new(
                0,
                Some(CenterId::of(&c0)),
                CenterDrift::NoDownShift,
                VoiceSide::Short,
                200, // == ZG：向上离开中枢（★#366 判据；旧中轴二分注记已作废）
                5,
            )
            .unwrap(),
        );
        assert!(osc_books[0].is_suspended(CenterId::of(&c0)));

        // 本 bar 喂一枚三类买点破坏（buy3=Long 破坏），载体=在场实例 c0。
        let step_with_bsp = Classification {
            levels: vec![level_with_bsp(vec![third_class_buy_break(20, c0)])],
        };
        let actions = step_center_oscillation(
            1,
            &classification,
            &step_with_bsp,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;
        assert_eq!(actions.len(), 1, "三类买点破坏终结 ⟹ 收手回补动作可见");
        assert_eq!(actions[0].action, CenterOscillationAction::Replenish);
        assert_eq!(actions[0].center, CenterId::of(&c0));
        assert_eq!(
            witness
                .suspension_by_source
                .get(&(0, "long", "broken_by_third_class_buy")),
            Some(&1),
            "★issue #357：挂起归宿分桶记录三类买点破坏终结来源"
        );
        assert!(
            !osc_books[0].is_suspended(CenterId::of(&c0)),
            "终结=挂起清空"
        );
    }

    /// ★#489：Reset 事件照发，但只记「到场时仍有活中枢」漏发警报；不 take 中枢、不终结
    /// 挂起、不产核销。随后原中枢自己的三类买点仍可清算这笔挂起。
    #[test]
    fn gate_reset_broadcast_keeps_center_and_suspension_until_third_class_point() {
        let c0 = center(5, 10, 100, 200);
        let classification = Classification {
            levels: vec![level_with_centers(vec![c0])],
        };
        let empty_step = Classification {
            levels: vec![LevelState::default()],
        };
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
        let _ = step_center_oscillation(
            0,
            &classification,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        bind_side(&mut osc_books[0], c0, VoiceSide::Long);

        let reset_step = Classification {
            levels: vec![level_with_bsp(vec![first_class_reset(20, c0, Side::Short)])],
        };
        let reset_out = step_center_oscillation(
            1,
            &classification,
            &reset_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        assert_eq!(cl_machines[0].counts(), (0, 0, 1), "Reset 事件照发并计数");
        assert_eq!(
            cl_machines[0].alive_center(),
            Some((c0, 0)),
            "Reset 不 take 在场中枢"
        );
        assert!(
            osc_books[0].is_suspended(CenterId::of(&c0)),
            "Reset 不终结挂起"
        );
        assert!(reset_out.actions.is_empty(), "Reset 不产生回补动作");
        assert!(
            reset_out.write_offs.is_empty(),
            "Reset 不产生未闭合减出核销"
        );
        assert_eq!(
            witness
                .reset_alive_center_leak_by_level_side
                .get(&(0, "short")),
            Some(&1),
            "漏发警报按 Reset 级别与买卖侧分桶"
        );
        // 0 的原因是本次真实 Reset 消费输出为空，不是类型上不可能出现非零。
        assert_eq!(
            witness.reset_settlement_count(),
            0,
            "Reset 实测消费输出为空"
        );
        assert!(
            witness.center_mis_kill_by_level.is_empty(),
            "Reset 广播不进入 MisKill"
        );

        let broken_step = Classification {
            levels: vec![level_with_bsp(vec![third_class_buy_break(21, c0)])],
        };
        let broken_out = step_center_oscillation(
            2,
            &classification,
            &broken_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        assert_eq!(
            broken_out.actions.len(),
            1,
            "挂起活到自己的三类买点并收手回补"
        );
        assert!(broken_out.write_offs.is_empty(), "三买走闭合终局，不核销");
        assert!(
            !osc_books[0].is_suspended(CenterId::of(&c0)),
            "三类点才终结挂起"
        );
    }

    /// ★#366（补充裁定 2026-07-27）门控开启臂 · **三卖终局**通路：先触发挂起，再喂本级三类
    /// **卖**点破坏 ⟹ 不产回补动作，改产一条「未闭合减出」核销请求（两终局分账的接线证据）。
    #[test]
    fn gate_on_third_class_sell_produces_write_off_request_not_a_cover_action() {
        let c0 = center(5, 10, 100, 200);
        let classification = Classification {
            levels: vec![level_with_centers(vec![c0])],
        };
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
        let empty_step = Classification {
            levels: vec![LevelState::default()],
        };
        let _ = step_center_oscillation(
            0,
            &classification,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;
        osc_books[0].on_trigger(
            super::super::super::strategy::center_oscillation_trade::CenterOscillationTrigger::new(
                0,
                Some(CenterId::of(&c0)),
                CenterDrift::NoDownShift,
                VoiceSide::Short,
                200, // == ZG：向上离开中枢（#366 判据）
                5,
            )
            .unwrap(),
        );
        let step_with_bsp = Classification {
            levels: vec![level_with_bsp(vec![third_class_sell_break(20, c0)])],
        };
        let out = step_center_oscillation(
            1,
            &classification,
            &step_with_bsp,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        assert!(out.actions.is_empty(), "三卖终局不回补 ⟹ 无动作");
        assert_eq!(out.write_offs.len(), 1, "改产一条未闭合减出核销请求");
        assert_eq!(out.write_offs[0].center, CenterId::of(&c0));
        assert_eq!(out.write_offs[0].side, VoiceSide::Long);
        assert_eq!(out.write_offs[0].bar, 1);
    }

    /// ★#366：三**买**终局仍只产回补动作、**不**产核销请求（两终局互斥，不重复清算）。
    #[test]
    fn gate_on_third_class_buy_produces_cover_action_and_no_write_off() {
        let c0 = center(5, 10, 100, 200);
        let classification = Classification {
            levels: vec![level_with_centers(vec![c0])],
        };
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
        let empty_step = Classification {
            levels: vec![LevelState::default()],
        };
        let _ = step_center_oscillation(
            0,
            &classification,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;
        osc_books[0].on_trigger(
            super::super::super::strategy::center_oscillation_trade::CenterOscillationTrigger::new(
                0,
                Some(CenterId::of(&c0)),
                CenterDrift::NoDownShift,
                VoiceSide::Short,
                200,
                5,
            )
            .unwrap(),
        );
        let step_with_bsp = Classification {
            levels: vec![level_with_bsp(vec![third_class_buy_break(20, c0)])],
        };
        let out = step_center_oscillation(
            1,
            &classification,
            &step_with_bsp,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        assert_eq!(out.actions.len(), 1);
        assert_eq!(out.actions[0].action, CenterOscillationAction::Replenish);
        assert!(
            out.write_offs.is_empty(),
            "闭合终局走回补，不再核销（两终局互斥）"
        );
    }

    /// #292 续修（issue #292 二轮评审：挂起悬空泄漏）端到端接线证据：`step_center_oscillation`
    /// 在遇到 `ChainConsumed::Rebased` 时正确接入 `on_chain_rebase`——重基后仍在新链上的挂起
    /// 身份跟随迁移（原样保留），从新链消失的挂起身份终结（不回补，故本 bar 无 cover_action
    /// 可见动作），并产出未闭合减出核销请求。
    #[test]
    fn gate_on_chain_rebase_migrates_survivor_and_writes_off_vanished_suspension() {
        let c0 = center(5, 10, 100, 200);
        let c1 = center(20, 25, 300, 400);
        let c2 = center(22, 27, 500, 600);
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();

        // bar0：链=[c0]，首次消费（Adopted），不产生任何生命周期事件。
        let bar0_classification = Classification {
            levels: vec![level_with_centers(vec![c0])],
        };
        let empty_step = Classification {
            levels: vec![LevelState::default()],
        };
        let _ = step_center_oscillation(
            0,
            &bar0_classification,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;

        // 直接摆两笔挂起（c0 已在场；c1 尚未在链上——挂起按身份匹配，不要求当前在场，D 裁定）。
        osc_books[0].on_trigger(
            super::super::super::strategy::center_oscillation_trade::CenterOscillationTrigger::new(
                0,
                Some(CenterId::of(&c0)),
                CenterDrift::NoDownShift,
                VoiceSide::Short,
                200, // c0 中轴150，200≥中轴=上半区
                1,
            )
            .unwrap(),
        );
        osc_books[0].on_trigger(
            super::super::super::strategy::center_oscillation_trade::CenterOscillationTrigger::new(
                0,
                Some(CenterId::of(&c1)),
                CenterDrift::NoDownShift,
                VoiceSide::Short,
                400, // c1 中轴350，400≥中轴=上半区
                2,
            )
            .unwrap(),
        );
        assert!(osc_books[0].is_suspended(CenterId::of(&c0)));
        assert!(osc_books[0].is_suspended(CenterId::of(&c1)));

        // bar1：链前缀分叉为 [c1, c2]（已消费的第 0 格身份从 c0 改写为 c1）⟹ Rebased。
        // 新链含 c1、不含 c0。
        let bar1_classification = Classification {
            levels: vec![level_with_centers(vec![c1, c2])],
        };
        let out = step_center_oscillation_observed(
            1,
            &bar1_classification,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        assert_eq!(
            out.rebase_observations.len(),
            1,
            "一笔 Rebased 必须产一笔 D0 事务观测"
        );
        let rebase = &out.rebase_observations[0];
        assert_eq!(rebase.level, 0);
        assert_eq!(rebase.chain.before, vec![CenterId::of(&c0)]);
        assert_eq!(
            rebase.chain.after,
            vec![CenterId::of(&c1), CenterId::of(&c2)]
        );
        assert_eq!(
            rebase.suspended_before,
            vec![
                (VoiceSide::Long, CenterId::of(&c0)),
                (VoiceSide::Long, CenterId::of(&c1))
            ],
            "必须在 on_chain_rebase 删除 vanished 挂起前抓取完整分侧挂起表"
        );
        assert!(
            out.actions.is_empty(),
            "RebaseVanished 终结不回补，本 bar 无 cover_action 可见动作"
        );
        assert_eq!(
            out.write_offs.len(),
            1,
            "Rebased 路径必须产出一条未闭合减出核销请求"
        );
        assert_eq!(out.write_offs[0].bar, 1);
        assert_eq!(out.write_offs[0].level, 0);
        assert_eq!(out.write_offs[0].center, CenterId::of(&c0));
        assert_eq!(out.write_offs[0].side, VoiceSide::Long);
        assert!(
            !osc_books[0].is_suspended(CenterId::of(&c0)),
            "c0 已从新链消失⟹终结，不再悬空"
        );
        assert!(
            osc_books[0].is_suspended(CenterId::of(&c1)),
            "c1 仍在新链上⟹跟随迁移，挂起原样保留"
        );
    }

    /// ★★#679 D1b 端到端接线证据：同一 bar 的塔构造证书在谱系簿里给出 `c0 → c1` 的 1→1 边时，
    /// `step_center_oscillation` 的 `Rebased` 分支**不再**核销 c0 的挂起，而是把身份锚迁到 c1；
    /// 反证开关按下（`consumer_enabled=false`，生产由 `THETA_REBASE_MIGRATE_SKIP=1` 触发）⟹
    /// 同一输入逐字回到 `RebaseVanished` 核销。
    ///
    /// 这条测试锁的是**接线**（簿 → `view_for(bar, lvl)` → `on_chain_rebase_lineage`），
    /// 判定规则本身的三族覆盖在 `center_oscillation_trade` 域层单测。
    #[test]
    fn gate_lineage_certificate_migrates_suspension_end_to_end() {
        use super::super::super::lineage_book;
        let c0 = center(5, 10, 100, 200);
        let c1 = center(5, 12, 110, 200); // 同 seed 窗重算：start 不变、zd 修订（wf8 seq=3 型）
        let c2 = center(22, 27, 500, 600);
        let empty_step = Classification {
            levels: vec![LevelState::default()],
        };

        // 两臂共用的建仓段：bar0 采纳链 [c0]，在 c0 上挂起一笔多头。
        let arm = |migrate_on: bool| {
            lineage_book::reset_book();
            lineage_book::test_set_consumer(Some(migrate_on));
            let mut cl_machines = Vec::new();
            let mut osc_books = Vec::new();
            let mut witness =
                super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
            let bar0 = Classification {
                levels: vec![level_with_centers(vec![c0])],
            };
            let _ = step_center_oscillation(
                0,
                &bar0,
                &empty_step,
                &mut cl_machines,
                &mut osc_books,
                &mut witness,
            );
            osc_books[0].on_trigger(
                super::super::super::strategy::center_oscillation_trade::CenterOscillationTrigger::new(
                    0, Some(CenterId::of(&c0)), CenterDrift::NoDownShift, VoiceSide::Short, 200, 1,
                )
                .unwrap(),
            );
            assert!(osc_books[0].is_suspended(CenterId::of(&c0)));
            // 本 bar 的构造证书：c0 → c1 是 1→1 连续边（真实路径由 `rebase_txn::emit` 写入，
            // 这里直接喂簿以隔离接线本身）。这条测试锁的是接线机制本身，非严格/宽读法之别
            // （#679 用户 2026-07-29 裁定后宽读法转生产默认），两个映射都喂同一条边，
            // 不受 `THETA_REBASE_MIGRATE_STRICT` 默认值影响。
            lineage_book::record_edges(
                1,
                0,
                4242,
                "cert-digest",
                &[(CenterId::of(&c0), CenterId::of(&c1))],
                &[(CenterId::of(&c0), CenterId::of(&c1))],
                &[],
                &[],
            );
            let bar1 = Classification {
                levels: vec![level_with_centers(vec![c1, c2])],
            };
            let out = step_center_oscillation(
                1,
                &bar1,
                &empty_step,
                &mut cl_machines,
                &mut osc_books,
                &mut witness,
            );
            lineage_book::test_set_consumer(None);
            lineage_book::reset_book();
            (out, osc_books)
        };

        let (migrated, books) = arm(true);
        assert!(
            migrated.write_offs.is_empty(),
            "有 1→1 构造证书 ⟹ 挂起随谱系迁移，不产未闭合减出核销"
        );
        assert!(
            books[0].is_suspended(CenterId::of(&c1)),
            "新链身份可问到这条挂起"
        );
        assert!(
            books[0].is_suspended(CenterId::of(&c0)),
            "首次绑定身份经别名仍可问到"
        );
        assert_eq!(
            books[0].resolve(CenterId::of(&c1)),
            CenterId::of(&c0),
            "身份锚不动 ⟹ campaign 挂起归属账的来源中枢标签不必同步迁移"
        );

        let (kept, books) = arm(false);
        assert_eq!(
            kept.write_offs.len(),
            1,
            "反证臂：逐字回到 RebaseVanished 核销"
        );
        assert_eq!(kept.write_offs[0].center, CenterId::of(&c0));
        assert!(!books[0].is_suspended(CenterId::of(&c0)));
        assert!(!books[0].is_suspended(CenterId::of(&c1)));
    }

    /// ★#466 D1c 端到端接线证据：构造证书判 `removed`（真删除/构造窗撤出）时，
    /// `step_center_oscillation` 的 `Rebased` 分支按 `ConstructionRemoved` 核销（清算仍
    /// `WriteOffUnclosed`），witness 的 `suspension_by_source` 记 `construction_removed`、
    /// **不**记 `rebase_vanished`——RebaseVanished 工程警报桶归 0。
    #[test]
    fn gate_removed_certificate_writes_off_as_construction_removed_end_to_end() {
        use super::super::super::lineage_book;
        let c0 = center(5, 10, 100, 200);
        let c2 = center(22, 27, 500, 600); // 新链不含 c0（构造窗撤出，wf8 seq=66 型）
        let empty_step = Classification {
            levels: vec![LevelState::default()],
        };
        lineage_book::reset_book();
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
        let bar0 = Classification {
            levels: vec![level_with_centers(vec![c0])],
        };
        let _ = step_center_oscillation(
            0,
            &bar0,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        osc_books[0].on_trigger(
            super::super::super::strategy::center_oscillation_trade::CenterOscillationTrigger::new(
                0,
                Some(CenterId::of(&c0)),
                CenterDrift::NoDownShift,
                VoiceSide::Short,
                200,
                1,
            )
            .unwrap(),
        );
        assert!(osc_books[0].is_suspended(CenterId::of(&c0)));
        // 本 bar 构造证书：c0 判 removed（真删除），无连续边。
        lineage_book::record_edges(
            1,
            0,
            4661,
            "removed-cert",
            &[],
            &[],
            &[CenterId::of(&c0)],
            &[CenterId::of(&c0)],
        );
        let bar1 = Classification {
            levels: vec![level_with_centers(vec![c2])],
        };
        let out = step_center_oscillation(
            1,
            &bar1,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        assert_eq!(
            out.write_offs.len(),
            1,
            "真删除 ⟹ 仍产一条未闭合减出核销请求（清算同族）"
        );
        assert_eq!(out.write_offs[0].center, CenterId::of(&c0));
        assert!(
            !osc_books[0].is_suspended(CenterId::of(&c0)),
            "c0 已真删除 ⟹ 终结"
        );
        assert_eq!(
            witness
                .suspension_by_source
                .get(&(0, "long", "construction_removed")),
            Some(&1),
            "真删除记 construction_removed，不记 rebase_vanished"
        );
        assert_eq!(
            witness
                .suspension_by_source
                .get(&(0, "long", "rebase_vanished")),
            None,
            "RebaseVanished 工程警报桶应打到 0"
        );
        lineage_book::reset_book();
    }

    /// ★★#414 端到端接线证据（ADR 补充十一）：`step_center_oscillation` 遇 `Superseded` 时
    /// **不终结**挂起、只落延续观测；挂起延续到**原中枢**的三类买点到达才按 #366 闭合终局清算
    /// （产出一条真实 `Replenish` 收手回补动作 + `cover_and_close` 终局分桶）。
    ///
    /// 三拍：bar0 采纳链 [c0] 并在 c0 上挂起 → bar1 链推进为 [c0,c1]（c0 被取代）→ bar2 在
    /// c0（此时的容读格）上落三类买点。
    #[test]
    fn gate_superseded_continues_suspension_until_original_center_third_class_point() {
        let c0 = center(5, 10, 100, 200);
        let c1 = center(20, 25, 300, 400);
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
        let empty_step = Classification {
            levels: vec![LevelState::default()],
        };

        // bar0：链=[c0] 首次消费（Adopted），随后在 c0 上开一笔挂起（上沿高抛）。
        let bar0 = Classification {
            levels: vec![level_with_centers(vec![c0])],
        };
        let _ = step_center_oscillation(
            0,
            &bar0,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        )
        .actions;
        osc_books[0].on_trigger(
            super::super::super::strategy::center_oscillation_trade::CenterOscillationTrigger::new(
                0,
                Some(CenterId::of(&c0)),
                CenterDrift::NoDownShift,
                VoiceSide::Short,
                200, // = c0.zg，向上离开中枢（含端点）
                1,
            )
            .unwrap(),
        );
        assert!(osc_books[0].is_suspended(CenterId::of(&c0)));

        // bar1：链推进为 [c0, c1] ⟹ Advanced{Superseded(c0), Born(c1)}。
        let bar1 = Classification {
            levels: vec![level_with_centers(vec![c0, c1])],
        };
        let step1 = step_center_oscillation(
            1,
            &bar1,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        assert!(step1.actions.is_empty(), "取代不产任何动作");
        assert!(step1.write_offs.is_empty(), "取代不产核销请求");
        assert!(
            osc_books[0].is_suspended(CenterId::of(&c0)),
            "★#414：被取代不终结挂起——挂起延续，等原中枢三类点"
        );
        assert_eq!(
            witness.suspension_continued_count.get(&(0, "long")),
            Some(&1),
            "延续计数落 witness（产物级可见，非静默）"
        );
        assert_eq!(
            witness.suspension_by_source.get(&(0, "long", "superseded")),
            None,
            "★桶退役：取代不再是挂起归宿"
        );

        // bar2：原中枢 c0（容读格）上的三类买点 ⟹ #366 闭合终局（收手回补）。
        let step2_bsp = Classification {
            levels: vec![level_with_bsp(vec![third_class_buy_break(77, c0)])],
        };
        let step2 = step_center_oscillation(
            2,
            &bar1,
            &step2_bsp,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        assert_eq!(
            step2.actions.len(),
            1,
            "延续的挂起在原中枢三类买点上收手回补"
        );
        assert_eq!(step2.actions[0].action, CenterOscillationAction::Replenish);
        assert_eq!(
            step2.actions[0].center,
            CenterId::of(&c0),
            "归属原中枢，不误挂到新在场的 c1"
        );
        assert_eq!(
            witness
                .suspension_by_source
                .get(&(0, "long", "broken_by_third_class_buy")),
            Some(&1),
            "归宿=三类买点（清算分流读数）"
        );
        assert_eq!(
            witness
                .settlement_by_side
                .get(&(0, "long", "cover_and_close")),
            Some(&1),
            "终局=闭合（与未闭合减出核销分列）"
        );
        assert!(
            !osc_books[0].is_suspended(CenterId::of(&c0)),
            "清算后挂起离场"
        );
    }

    /// ★#487：目标已滑出主格/容读格，但精确挂起绑定授权其 Owner 三类点命中历史分支。
    /// 同一事件只清算 c0；c1 挂起不连坐。买三对多头闭合、对空头核销，矩阵两路同时可见。
    #[test]
    fn gate_historical_bound_center_outside_tolerance_settles_exact_owner() {
        let c0 = center(0, 10, 100, 200);
        let c1 = center(20, 30, 300, 400);
        let c2 = center(40, 50, 500, 600);
        let mut fixture = HistoricalWiringFixture::new(vec![c0]);
        fixture.bind(c0, VoiceSide::Long);
        fixture.bind(c0, VoiceSide::Short);

        let advanced = Classification {
            levels: vec![level_with_centers(vec![c0, c1, c2])],
        };
        let _ = fixture.consume(1, &advanced);
        fixture.bind(c1, VoiceSide::Long);

        let tower = vec![Rc::new(vec![
            l0_move(0, Direction::Up, 10, 15, 190, 260),
            l0_move(1, Direction::Down, 15, 20, 240, 280),
        ])];
        let out = fixture.historical(2, &advanced, None, &tower, false);

        assert_eq!(out.actions.len(), 1, "买三只为多头产 cover_and_close");
        assert_eq!(out.actions[0].center, CenterId::of(&c0));
        assert_eq!(out.actions[0].side, VoiceSide::Long);
        assert_eq!(out.actions[0].action, CenterOscillationAction::Replenish);
        assert_eq!(
            out.write_offs.len(),
            1,
            "同一买三对空头走 write_off_unclosed"
        );
        assert_eq!(out.write_offs[0].center, CenterId::of(&c0));
        assert_eq!(out.write_offs[0].side, VoiceSide::Short);
        assert!(!fixture.osc_books[0].is_suspended_side(VoiceSide::Long, CenterId::of(&c0)));
        assert!(!fixture.osc_books[0].is_suspended_side(VoiceSide::Short, CenterId::of(&c0)));
        assert!(
            fixture.osc_books[0].is_suspended_side(VoiceSide::Long, CenterId::of(&c1)),
            "同一三类事件不得连坐其它 Owner"
        );
        assert_eq!(fixture.cl_machines[0].historical_bound_kills(), 1);
        assert_eq!(fixture.cl_machines[0].mis_kills(), 0);
        assert_eq!(fixture.witness.historical_bound_by_level.get(&0), Some(&1));
        assert_eq!(
            fixture
                .witness
                .settlement_by_side
                .get(&(0, "long", "cover_and_close")),
            Some(&1)
        );
        assert_eq!(
            fixture
                .witness
                .settlement_by_side
                .get(&(0, "short", "write_off_unclosed")),
            Some(&1)
        );
    }

    /// ★#487 反例：同一个出窗 Owner 没有挂起授权时仍走原 Stale，绝不借 historical 分支放宽。
    #[test]
    fn gate_historical_owner_without_binding_remains_stale() {
        let c0 = center(0, 10, 100, 200);
        let c1 = center(20, 30, 300, 400);
        let c2 = center(40, 50, 500, 600);
        let mut fixture = HistoricalWiringFixture::new(vec![c0]);
        let advanced = Classification {
            levels: vec![level_with_centers(vec![c0, c1, c2])],
        };
        let _ = fixture.consume(1, &advanced);
        let point = Classification {
            levels: vec![level_with_bsp(vec![third_class_buy_break(77, c0)])],
        };
        let out = fixture.regular(2, &advanced, &point);

        assert!(out.actions.is_empty());
        assert!(out.write_offs.is_empty());
        assert_eq!(fixture.cl_machines[0].stale_requests(), 1);
        assert_eq!(fixture.cl_machines[0].historical_bound_kills(), 0);
        assert_eq!(fixture.cl_machines[0].mis_kills(), 0);
    }

    /// ★#487 正例：旧框首次挂起时冻结。即使同身份中枢后来延伸了右边，仍以旧 `end_index`
    /// 后真正紧邻的 leave/retest 配对，命中出窗绑定。同 source/侧的 regular 副本按票面
    /// “一事件一 Owner 一清算”抑制，不能再杀当前 alive。
    #[test]
    fn gate_true_immediate_pair_reaches_one_owner_and_suppresses_regular_duplicate() {
        let c0 = center(0, 10, 100, 200);
        let c0_extended = Center {
            end_index: 30,
            ..c0
        };
        let c1 = center(40, 50, 300, 400);
        let c2 = center(60, 70, 500, 600);
        let mut fixture = HistoricalWiringFixture::new(vec![c0]);
        fixture.bind(c0, VoiceSide::Long);
        let advanced = Classification {
            levels: vec![level_with_centers(vec![c0_extended, c1, c2])],
        };
        let tower = vec![Rc::new(vec![
            // 共享枢轴坐标：leave.start_index == 旧框 end_index 是“右边之后第一条”。
            l0_move(0, Direction::Up, 10, 15, 190, 260),
            l0_move(1, Direction::Down, 15, 20, 240, 280),
        ])];

        // 同一 source 另有“最近中枢”副本；旧框证通过后按“一事件一 Owner 一清算”
        // 只投递 c0 Owner，不能先后破坏 c0 与当前 alive c2。
        let regular_duplicate = Classification {
            levels: vec![level_with_bsp(vec![third_class_buy_break(20, c2)])],
        };
        let out = fixture.historical(1, &advanced, Some(&regular_duplicate), &tower, false);

        assert_eq!(out.actions.len(), 1);
        assert_eq!(out.actions[0].center, CenterId::of(&c0));
        assert_eq!(out.actions[0].action, CenterOscillationAction::Replenish);
        assert!(out.write_offs.is_empty());
        assert_eq!(fixture.cl_machines[0].historical_bound_kills(), 1);
        assert_eq!(fixture.cl_machines[0].mis_kills(), 0);
        assert_eq!(fixture.witness.historical_bound_by_level.get(&0), Some(&1));
        assert_eq!(
            fixture.cl_machines[0]
                .alive_center()
                .map(|(c, _)| CenterId::of(&c)),
            Some(CenterId::of(&c2)),
            "一事件一 Owner 一清算：regular 副本被抑制，alive c2 不得连坐"
        );
    }

    /// ★#487 反例一：旧框右边第一支与紧随下一支同向时，立即判负；不得越过首支，
    /// 把后面的反向相邻对补作 leave/retest。
    #[test]
    fn gate_same_direction_immediate_successor_does_not_scan_forward() {
        let c0 = center(0, 10, 100, 200);
        let c1 = center(20, 30, 100, 200);
        let c2 = center(40, 50, 500, 600);
        let mut fixture = HistoricalWiringFixture::new(vec![c0]);
        fixture.bind(c0, VoiceSide::Long);
        let advanced = Classification {
            levels: vec![level_with_centers(vec![c0, c1, c2])],
        };
        let tower = vec![Rc::new(vec![
            l0_move(0, Direction::Up, 10, 15, 150, 190),
            l0_move(1, Direction::Up, 15, 20, 190, 260),
            l0_move(2, Direction::Down, 20, 25, 240, 280),
        ])];

        let out = fixture.historical(1, &advanced, None, &tower, false);

        assert!(out.actions.is_empty());
        assert!(out.write_offs.is_empty());
        assert!(fixture.osc_books[0].is_suspended(CenterId::of(&c0)));
        assert!(fixture.historical_seen.is_empty(), "无证即不进入投递集合");
        assert_eq!(fixture.cl_machines[0].historical_bound_kills(), 0);
        assert_eq!(fixture.cl_machines[0].mis_kills(), 0);
    }

    /// ★#487 反例二：首个紧邻 leave/retest 虽反向但价格失败，不得滑到远期反向对回填旧框。
    #[test]
    fn gate_remote_pair_after_failed_immediate_retest_does_not_refill_old_frame() {
        let c0 = center(0, 10, 100, 200);
        let c1 = center(30, 40, 300, 400);
        let c2 = center(50, 60, 500, 600);
        let mut fixture = HistoricalWiringFixture::new(vec![c0]);
        fixture.bind(c0, VoiceSide::Long);
        let advanced = Classification {
            levels: vec![level_with_centers(vec![c0, c1, c2])],
        };
        let tower = vec![Rc::new(vec![
            l0_move(0, Direction::Up, 10, 15, 190, 260),
            l0_move(1, Direction::Down, 15, 20, 150, 280),
            l0_move(2, Direction::Up, 20, 25, 190, 260),
            l0_move(3, Direction::Down, 25, 30, 240, 280),
        ])];
        let remote_point = Classification {
            levels: vec![level_with_bsp(vec![third_class_buy_break(30, c0)])],
        };

        let out = fixture.historical(1, &advanced, Some(&remote_point), &tower, false);

        assert!(out.actions.is_empty());
        assert!(out.write_offs.is_empty());
        assert!(fixture.osc_books[0].is_suspended(CenterId::of(&c0)));
        assert_eq!(
            fixture.cl_machines[0].stale_requests(),
            1,
            "远期普通点不得借挂起绑定绕过 Stale"
        );
        assert_eq!(fixture.cl_machines[0].historical_bound_kills(), 0);
        assert_eq!(fixture.cl_machines[0].mis_kills(), 0);
    }

    /// ★#487 反例三：同核心不同时间框各只认领自己右边的紧邻对；晚框事件不得回头挂到旧框。
    #[test]
    fn gate_same_core_different_time_frames_keep_owner_by_adjacent_pair() {
        let c0 = center(0, 10, 100, 200);
        let c1 = center(20, 30, 100, 200);
        let c2 = center(50, 60, 500, 600);
        let c3 = center(70, 80, 700, 800);
        let mut fixture = HistoricalWiringFixture::new(vec![c0]);
        fixture.bind(c0, VoiceSide::Long);
        fixture.bind(c1, VoiceSide::Long);
        let advanced = Classification {
            levels: vec![level_with_centers(vec![c0, c1, c2, c3])],
        };
        let tower = vec![Rc::new(vec![
            l0_move(0, Direction::Up, 10, 15, 190, 260),
            l0_move(1, Direction::Down, 15, 20, 240, 280),
            l0_move(2, Direction::Up, 30, 35, 190, 260),
            l0_move(3, Direction::Down, 35, 40, 240, 280),
        ])];

        let out = fixture.historical(1, &advanced, None, &tower, false);

        let owners: Vec<_> = out.actions.iter().map(|action| action.center).collect();
        assert_eq!(owners, vec![CenterId::of(&c0), CenterId::of(&c1)]);
        let owner_sources: std::collections::HashSet<_> = fixture
            .historical_seen
            .iter()
            .map(|key| (key.owner, key.source_index))
            .collect();
        assert_eq!(
            owner_sources,
            std::collections::HashSet::from([(CenterId::of(&c0), 20), (CenterId::of(&c1), 40),]),
            "旧框只认 source=20；晚框 source=40 只归晚框 Owner"
        );
        assert_eq!(fixture.cl_machines[0].historical_bound_kills(), 2);
        assert_eq!(fixture.cl_machines[0].mis_kills(), 0);
    }

    /// ★#487/A2：新尾中枢已 Broken 使 alive=None 时，consumed 链内旧 Owner 的精确绑定
    /// 仍须经 HistoricalBound 投递并完成清算，不能先被 ArenaEmpty 吞掉。
    #[test]
    fn gate_alive_none_still_settles_consumed_exact_historical_binding() {
        let c0 = center(0, 10, 100, 200);
        let c1 = center(20, 30, 300, 400);
        let mut fixture = HistoricalWiringFixture::new(vec![c0]);
        fixture.bind(c0, VoiceSide::Long);
        let advanced = Classification {
            levels: vec![level_with_centers(vec![c0, c1])],
        };
        let kill_new_tail = Classification {
            levels: vec![level_with_bsp(vec![third_class_buy_break(31, c1)])],
        };
        let first = fixture.regular(1, &advanced, &kill_new_tail);
        assert!(first.actions.is_empty());
        assert_eq!(fixture.cl_machines[0].alive_center(), None);
        assert!(fixture.osc_books[0].is_suspended(CenterId::of(&c0)));

        let tower = vec![Rc::new(vec![
            l0_move(0, Direction::Up, 10, 15, 190, 260),
            l0_move(1, Direction::Down, 15, 20, 240, 280),
        ])];
        let out = fixture.historical(2, &advanced, None, &tower, false);

        assert_eq!(out.actions.len(), 1);
        assert_eq!(out.actions[0].center, CenterId::of(&c0));
        assert_eq!(out.actions[0].action, CenterOscillationAction::Replenish);
        assert!(!fixture.osc_books[0].is_suspended(CenterId::of(&c0)));
        assert_eq!(fixture.cl_machines[0].historical_bound_kills(), 1);
        assert_eq!(fixture.cl_machines[0].mis_kills(), 0);
        assert_eq!(
            fixture
                .witness
                .settlement_by_side
                .get(&(0, "long", "cover_and_close")),
            Some(&1)
        );
    }

    /// ★#487/A3：同一紧邻三类事件可同时给多个冻结 Owner 过证；每个 Owner 各自清算，
    /// 不得因同 source/侧竞争而 panic、丢投或把未投递候选提前记入 seen。
    #[test]
    fn gate_same_event_two_bound_owners_both_settle() {
        let c0 = center(0, 10, 100, 200);
        let c1 = center(1, 10, 100, 200);
        let c2 = center(20, 30, 500, 600);
        let mut fixture = HistoricalWiringFixture::new(vec![c0, c1, c2]);
        fixture.bind(c0, VoiceSide::Long);
        fixture.bind(c1, VoiceSide::Long);
        let classification = Classification {
            levels: vec![level_with_centers(vec![c0, c1, c2])],
        };
        let tower = vec![Rc::new(vec![
            l0_move(0, Direction::Up, 10, 15, 190, 260),
            l0_move(1, Direction::Down, 15, 20, 240, 280),
        ])];

        let out = fixture.historical(1, &classification, None, &tower, false);

        let action_matrix: Vec<_> = out
            .actions
            .iter()
            .map(|a| (a.center, a.side, a.action))
            .collect();
        assert_eq!(
            action_matrix,
            vec![
                (
                    CenterId::of(&c0),
                    VoiceSide::Long,
                    CenterOscillationAction::Replenish,
                ),
                (
                    CenterId::of(&c1),
                    VoiceSide::Long,
                    CenterOscillationAction::Replenish,
                ),
            ]
        );
        assert!(!fixture.osc_books[0].is_suspended(CenterId::of(&c0)));
        assert!(!fixture.osc_books[0].is_suspended(CenterId::of(&c1)));
        assert_eq!(fixture.historical_seen.len(), 2);
        assert_eq!(fixture.cl_machines[0].mis_kills(), 0);
        assert_eq!(
            fixture.witness.historical_multi_owner_same_event.get(&0),
            Some(&1)
        );
        assert_eq!(
            fixture
                .witness
                .settlement_by_side
                .get(&(0, "long", "cover_and_close")),
            Some(&2)
        );
    }

    /// ★#466 D0：生产实际调用的 historical wrapper 在 observe_rebase=true 时仍于改表前抓取
    /// 事务快照；不是只锁旧 observed 测试入口。
    #[test]
    fn production_historical_wrapper_preserves_d0_rebase_snapshot() {
        let c0 = center(5, 10, 100, 200);
        let c1 = center(20, 25, 300, 400);
        let c2 = center(22, 27, 500, 600);
        let mut fixture = HistoricalWiringFixture::new(vec![c0]);
        fixture.bind(c0, VoiceSide::Long);
        fixture.bind(c1, VoiceSide::Long);
        let rebased = Classification {
            levels: vec![level_with_centers(vec![c1, c2])],
        };
        let empty_tower = vec![Rc::new(Vec::new())];

        let out = fixture.historical(1, &rebased, None, &empty_tower, true);

        assert_eq!(out.rebase_observations.len(), 1);
        let observation = &out.rebase_observations[0];
        assert_eq!(observation.chain.before, vec![CenterId::of(&c0)]);
        assert_eq!(
            observation.chain.after,
            vec![CenterId::of(&c1), CenterId::of(&c2)]
        );
        assert_eq!(
            observation.suspended_before,
            vec![
                (VoiceSide::Long, CenterId::of(&c0)),
                (VoiceSide::Long, CenterId::of(&c1)),
            ]
        );
        assert_eq!(out.write_offs.len(), 1);
        assert_eq!(out.write_offs[0].center, CenterId::of(&c0));
    }

    /// 门控双轨（#292 项目二）：原测试用空 bars——`bars.is_empty()` 本身已让 `pan_div_hist=None`，
    /// 恒真无判别力（门控是否真生效根本没被触达）。改为非空 bars + 真实触发条件（本级中枢
    /// 在场 + 次级别已确认卖点，价格落中枢上半区）上的 `enabled=false`/`enabled=true` 对照：
    /// 门关时零动作（真实门控生效，非"从未触达"的假阴性）、门开时动作可见（真判别力）。
    #[test]
    fn gate_dual_track_nonempty_bars_off_zero_on_visible() {
        fn mk_bar(idx: usize) -> super::super::super::types::Bar {
            super::super::super::types::Bar {
                source_index: idx,
                timestamp: idx as i64,
                open: 10_000_000_000,
                high: 10_000_000_000,
                low: 10_000_000_000,
                close: 10_000_000_000,
                volume: 1.0,
                untradable: false,
            }
        }
        let bars: Vec<super::super::super::types::Bar> = (0..3).map(mk_bar).collect();

        let c0 = center(5, 10, 100, 200); // 中轴 = 150
        let sell_point = sub_level_bsp_point(3, VoiceSide::Short, 200); // 200≥中轴=上半区
        let classification = Classification {
            levels: vec![
                level_with_bsp(vec![sell_point]),
                level_with_centers(vec![c0]),
            ],
        };

        let config_off = super::super::super::config::ThetaConfig::default();
        assert!(
            !config_off.center_oscillation.enabled,
            "默认门关（回归锁前提）"
        );
        let cls_off = classification.clone();
        let out_off = pi_theta_fill_loop(
            move |i| {
                let cls = if i == 0 {
                    cls_off.clone()
                } else {
                    Classification::default()
                };
                (
                    cls,
                    Vec::new(),
                    Vec::new(),
                    i as u64,
                    i as u64,
                    std::rc::Rc::new(Vec::new()),
                )
            },
            &bars,
            1.0,
            &config_off,
            None,
        );
        assert!(
            out_off.center_oscillation_actions.is_empty(),
            "门关：非空 bars + 真实触发条件下仍零动作（真实门控生效，非从未触达的假阴性）"
        );

        let mut config_on = config_off.clone();
        config_on.center_oscillation.enabled = true;
        let cls_on = classification;
        let out_on = pi_theta_fill_loop(
            move |i| {
                let cls = if i == 0 {
                    cls_on.clone()
                } else {
                    Classification::default()
                };
                (
                    cls,
                    Vec::new(),
                    Vec::new(),
                    i as u64,
                    i as u64,
                    std::rc::Rc::new(Vec::new()),
                )
            },
            &bars,
            1.0,
            &config_on,
            None,
        );
        assert_eq!(
            out_on.center_oscillation_actions.len(),
            1,
            "门开：同一非空 bars + 同一触发条件 ⟹ 恰一条可见动作（真判别力）"
        );
        assert_eq!(
            out_on.center_oscillation_actions[0].action,
            CenterOscillationAction::Reduce
        );
    }

    /// ★★#689 端到端接线证据（用户 2026-07-29 裁定）：锚（首次挂起冻结的旧身份）经谱系簿
    /// 1→1 迁移后被 `adopt()` 整体移出本级塔链——历史绑定投递的**主格路径**（锚本身当
    /// `target`）必然 `MisKill`；接线层现在还会用 `CenterOscillationBook::current_identity_of`
    /// 折回当前修订身份再投一次，命中链尾主格（`Alive`）成功终结，不再永久卡死。
    ///
    /// 同时锁 `historical_bound_attempted_by_level`/`historical_bound_by_level` 的接线：
    /// 投递本身算成功（不管落哪个内部分支），`historical_bound_failed_by_level`/
    /// `center_mis_kill_by_level` 均不落——这是 #689 计数器修复（item 2）的生产接线证据，
    /// 不止 [`crate::theta_v0::strategy::oscillation_campaign::tests::historical_bound_attempted_success_failed_buckets_are_independent_by_level`]
    /// 那种纯计数器单测。
    #[test]
    fn gate_689_historical_bound_reroutes_when_anchor_rebased_away() {
        use super::super::super::lineage_book;
        let c0 = center(0, 10, 100, 200);
        let c1 = center(0, 10, 90, 200); // 迁移后的当前修订身份（同 seed 窗重算：start 不变、zd 修订）
        let empty_step = Classification {
            levels: vec![LevelState::default()],
        };
        let mut cl_machines = Vec::new();
        let mut osc_books = Vec::new();
        let mut witness =
            super::super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
        let mut historical_seen = std::collections::HashSet::new();

        lineage_book::reset_book();
        lineage_book::test_set_consumer(Some(true));

        // bar0：链=[c0]，首次采纳；c0 上挂起一笔多头。
        let bar0 = Classification {
            levels: vec![level_with_centers(vec![c0])],
        };
        let _ = step_center_oscillation(
            0,
            &bar0,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        bind_side(&mut osc_books[0], c0, VoiceSide::Long);
        assert!(osc_books[0].is_suspended(CenterId::of(&c0)));

        // bar1：本 bar 构造证书给出 c0 → c1 的 1→1 边；新链=[c1]——锚被 `adopt()` 整体移出
        // `consumed`，但挂起随谱系迁移（不核销）。
        lineage_book::record_edges(
            1,
            0,
            6890,
            "cert-689-fill",
            &[(CenterId::of(&c0), CenterId::of(&c1))],
            &[(CenterId::of(&c0), CenterId::of(&c1))],
            &[],
            &[],
        );
        let bar1 = Classification {
            levels: vec![level_with_centers(vec![c1])],
        };
        let _ = step_center_oscillation(
            1,
            &bar1,
            &empty_step,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
        );
        lineage_book::test_set_consumer(None);
        lineage_book::reset_book();
        assert_eq!(
            cl_machines[0].alive_center(),
            Some((c1, 0)),
            "链尾主格=迁移后身份"
        );
        assert!(
            osc_books[0].is_suspended(CenterId::of(&c0)),
            "挂起随谱系迁移，未核销"
        );
        assert_eq!(
            osc_books[0].current_identity_of(CenterId::of(&c0)),
            Some(CenterId::of(&c1)),
            "谱系簿已把锚折回当前修订身份——接线层据此改道"
        );

        // bar2：旧框右边紧邻 leave/retest 四边证——沿用既有 #487 测试同款塔几何（c0 形状同源，
        // 见 `gate_historical_bound_center_outside_tolerance_settles_exact_owner`）。
        let tower = vec![Rc::new(vec![
            l0_move(0, Direction::Up, 10, 15, 190, 260),
            l0_move(1, Direction::Down, 15, 20, 240, 280),
        ])];
        let out = step_center_oscillation_historical(
            2,
            &bar1,
            &empty_step,
            &tower,
            &mut historical_seen,
            &mut cl_machines,
            &mut osc_books,
            &mut witness,
            false,
        );

        assert_eq!(
            out.actions.len(),
            1,
            "改道命中 Alive ⟹ 三类买点仍正常产出收手回补"
        );
        assert_eq!(
            out.actions[0].center,
            CenterId::of(&c0),
            "结算读数经 on_lifecycle_event 独立折回锚（ADR 补充十四：清算仍按冻结旧框判）"
        );
        assert_eq!(out.actions[0].action, CenterOscillationAction::Replenish);
        assert!(
            !osc_books[0].is_suspended(CenterId::of(&c0)),
            "挂起已清算离场"
        );
        assert_eq!(cl_machines[0].mis_kills(), 0, "改道生效后不再落 MisKill");
        assert_eq!(cl_machines[0].historical_bound_reroutes(), 1);

        assert_eq!(
            witness.historical_bound_attempted_by_level.get(&0),
            Some(&1)
        );
        assert_eq!(
            witness.historical_bound_by_level.get(&0),
            Some(&1),
            "投递成功——不管落分类机内部哪个分支，接线层都算一次成功"
        );
        assert_eq!(witness.historical_bound_failed_by_level.get(&0), None);
        assert_eq!(witness.center_mis_kill_by_level.get(&0), None);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  #625 发现3 观测探针（review-625.md 发现3，登记）——入场止损逆侧计数
// ════════════════════════════════════════════════════════════════════════════
// 常驻探针（ancok.rs 同惯例，thread_local Cell）：纯观测旁路，挂在生产 `open_trades` 唯一
// 写入点（entry_structural_stop 调用处，见下方 pi_theta_fill_loop_overlay 内）——只计数
// 「入场时结构止损价已在入场价逆侧」（多仓 stop_px≥entry_px / 空仓 stop_px≤entry_px），
// 不改 entry_stop 取值/判定（structural_stop 取价与 stop_hit 逻辑逐字节不动）。

/// 入场止损逆侧分侧计数（review-625.md 发现3 观测量）。
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub(super) struct EntryStopReverseProbe {
    /// 多仓入场：`stop_px >= entry_px`（结构止损已在入场价上方/同价，逆侧）次数。
    pub(super) long_reverse: u64,
    /// 空仓入场：`stop_px <= entry_px`（结构止损已在入场价下方/同价，逆侧）次数。
    pub(super) short_reverse: u64,
}

thread_local! {
    static ENTRY_STOP_REVERSE_PROBE: std::cell::Cell<EntryStopReverseProbe> =
        const { std::cell::Cell::new(EntryStopReverseProbe { long_reverse: 0, short_reverse: 0 }) };
}

/// 归零入场止损逆侧探针（wf8 run 前调用）。
pub(super) fn entry_stop_reverse_probe_reset() {
    ENTRY_STOP_REVERSE_PROBE.with(|c| c.set(EntryStopReverseProbe::default()));
}

/// 读取入场止损逆侧探针快照（wf8 run 后调用）。
pub(super) fn entry_stop_reverse_probe_snapshot() -> EntryStopReverseProbe {
    ENTRY_STOP_REVERSE_PROBE.with(std::cell::Cell::get)
}

// ── #647 阶段一归因 dump（env `ENTRY_STOP_REVERSE_DUMP=<path>`；未设 = no-op）──
// 仅在逆侧命中时写一行 JSONL（wf8 全窗 49 行），未设 env 时连文件都不开 ⟹ 生产零开销、
// 零行为影响（与上方计数探针同款纯观测旁路）。
thread_local! {
    /// `None` = 未初始化；`Some(None)` = env 未设（永久 no-op）；`Some(Some(f))` = 已开文件。
    static ENTRY_STOP_REVERSE_DUMP: std::cell::RefCell<Option<Option<std::fs::File>>> =
        const { std::cell::RefCell::new(None) };
}

/// 逆侧命中逐笔明细写一行（#647 阶段一归因）。
fn entry_stop_reverse_dump_line(line: &str) {
    ENTRY_STOP_REVERSE_DUMP.with(|c| {
        let mut slot = c.borrow_mut();
        if slot.is_none() {
            *slot = Some(
                std::env::var(crate::theta_v0::env_registry::ENTRY_STOP_REVERSE_DUMP)
                    .ok()
                    .and_then(|p| {
                        std::fs::OpenOptions::new()
                            .create(true)
                            .append(true)
                            .open(p)
                            .ok()
                    }),
            );
        }
        if let Some(Some(f)) = slot.as_mut() {
            use std::io::Write;
            let _ = writeln!(f, "{line}");
        }
    });
}

/// 逆侧命中一笔的归因明细（#647 阶段一）：候选坐标 / 证书类型 / pivot / 中枢 / 止损 /
/// 决策 bar 收盘 / exec bar OHLC——供离线逐笔核对机制。
///
/// 单源：`(level, source_index) → BspPoint` 查询改调 [`classifier::bsp::bsp_at`]（issue #747 C1，
/// 与 `signal.rs::entry_structural_stop` 逐字节并集单源；newtype 边界降级为不做，理由见
/// `classifier::bsp` 族头注释）。
#[allow(clippy::too_many_arguments)]
fn entry_stop_reverse_dump_row(
    c: &super::super::strategy::interp::Candidate,
    classification: &classifier::Classification,
    bars: &[Bar],
    i: usize,
    exec_index: Option<usize>,
    px: f64,
    stop: super::super::types::Tick,
    config: &ThetaConfig,
) {
    use classifier::bsp::bsp_at;
    // env 未设时 dump_line 内部 no-op，但字符串拼装在此之前 ⟹ 先探一次开关，避免常态开销。
    if ENTRY_STOP_REVERSE_DUMP.with(|c| matches!(&*c.borrow(), Some(None))) {
        return;
    }
    let ts = config.tick.tick_size;
    let bsp = classification
        .levels
        .get(c.level as usize)
        .and_then(|lvl| bsp_at(&lvl.bsp, c.source_index));
    let (pivot_low, pivot_high, zg, zd, owner) = match bsp {
        Some(p) => {
            let (zg, zd, owner) = match p.center {
                Some(super::super::classifier::bsp::OwnerRef::Center(ct)) => {
                    (ct.zg, ct.zd, "center")
                }
                Some(super::super::classifier::bsp::OwnerRef::Type1Anchor(_)) => {
                    (0, 0, "type1anchor")
                }
                None => (0, 0, "none"),
            };
            (p.pivot_low, p.pivot_high, zg, zd, owner)
        }
        None => (0, 0, 0, 0, "missing"),
    };
    let src = bars.get(c.source_index);
    let ex = exec_index.and_then(|ei| bars.get(ei));
    let line = format!(
        concat!(
            r#"{{"decision_bar":{},"exec_bar":{},"src_bar":{},"lag_bars":{},"level":{},"dir":"{}","#,
            r#""bsp_class":{},"bits":{},"buy1":{},"buy2":{},"buy3":{},"sell1":{},"sell2":{},"sell3":{},"#,
            r#""nest_confirmed":{},"owner":"{}","stop_tick":{},"stop_px":{},"decision_close":{},"#,
            r#""src_close":{},"src_high":{},"src_low":{},"exec_close":{},"exec_high":{},"exec_low":{},"#,
            r#""pivot_low_px":{},"pivot_high_px":{},"zg_px":{},"zd_px":{}}}"#,
        ),
        i,
        exec_index.map(|e| e as i64).unwrap_or(-1),
        c.source_index,
        i as i64 - c.source_index as i64,
        c.level,
        voice_side_str(c.dir),
        c.bsp_class,
        c.bits.class_index(),
        c.bits.buy1,
        c.bits.buy2,
        c.bits.buy3,
        c.bits.sell1,
        c.bits.sell2,
        c.bits.sell3,
        c.nest_confirmed,
        owner,
        stop,
        stop as f64 * ts,
        px,
        src.map(|b| b.close as f64 * ts).unwrap_or(f64::NAN),
        src.map(|b| b.high as f64 * ts).unwrap_or(f64::NAN),
        src.map(|b| b.low as f64 * ts).unwrap_or(f64::NAN),
        ex.map(|b| b.close as f64 * ts).unwrap_or(f64::NAN),
        ex.map(|b| b.high as f64 * ts).unwrap_or(f64::NAN),
        ex.map(|b| b.low as f64 * ts).unwrap_or(f64::NAN),
        pivot_low as f64 * ts,
        pivot_high as f64 * ts,
        zg as f64 * ts,
        zd as f64 * ts,
    );
    entry_stop_reverse_dump_line(&line);
}

// ════════════════════════════════════════════════════════════════════════════
//  #647 入场结构复检门——拒单计数（分侧 × 分级 × 分类别）
//  定稿（2026-07-29 用户 HITL）：门 = 破自己的底即拒，全类别同判，力度轴不进生产门。
//  一/二/三类拒单统一经同一判据（`signal::entry_stop_recheck_reject`）判定——判据本身零分桶。
//  #678：类别桶为纯观测面增补（读出 by_class_* 不反哺任何判据/订单流），与 by_level_* 同通道。
// ════════════════════════════════════════════════════════════════════════════

/// 入场结构复检拒单计数（#647 + #678）：分持仓侧 + 分级别（`by_level_*[ℓ]`）+ 分类别
/// （`by_class_*[0/1/2]` = 一/二/三类拒单数）。判据全类别同判，本结构体只做事后观测分桶。
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(super) struct EntryStopRecheckProbe {
    /// 多仓候选被拒次数（结构止损已在入场价上方/同价）。
    pub(super) long_rejected: u64,
    /// 空仓候选被拒次数（结构止损已在入场价下方/同价）。
    pub(super) short_rejected: u64,
    /// 分级别拒单（下标 = 候选 `level`），多仓侧。
    pub(super) by_level_long: Vec<u64>,
    /// 分级别拒单（下标 = 候选 `level`），空仓侧。
    pub(super) by_level_short: Vec<u64>,
    /// 分类别拒单（下标 0/1/2 = 一/二/三类，即 `bsp_class` 1/2/3），多仓侧。
    pub(super) by_class_long: [u64; 3],
    /// 分类别拒单（下标 0/1/2 = 一/二/三类），空仓侧。
    pub(super) by_class_short: [u64; 3],
}

thread_local! {
    static ENTRY_STOP_RECHECK_PROBE: std::cell::RefCell<EntryStopRecheckProbe> =
        const { std::cell::RefCell::new(EntryStopRecheckProbe {
            long_rejected: 0,
            short_rejected: 0,
            by_level_long: Vec::new(),
            by_level_short: Vec::new(),
            by_class_long: [0; 3],
            by_class_short: [0; 3],
        }) };
}

/// 归零入场结构复检拒单计数（run 前调用）。
pub(super) fn entry_stop_recheck_probe_reset() {
    ENTRY_STOP_RECHECK_PROBE.with(|c| *c.borrow_mut() = EntryStopRecheckProbe::default());
}

/// 读取入场结构复检拒单计数快照（run 后调用）。
pub(super) fn entry_stop_recheck_probe_snapshot() -> EntryStopRecheckProbe {
    ENTRY_STOP_RECHECK_PROBE.with(|c| c.borrow().clone())
}

/// 反证开关（ADR-0001 基线重订常例，#607 `THETA_T3INC_SKIP` 同款）：`THETA_ENTRY_STOP_RECHECK_SKIP=1`
/// ⟹ 门整体旁路 ⟹ 旧行为（门落地前基线）逐字节恢复（差异源单一性的 counterfactual 证据）。
/// 保留用途：合入本票时的反证复核——旁路后 trades 产物须与门前基线逐字节比对（cmp=0），
/// 证明门本身是本次差异的唯一来源，非其他并发改动混入。仅供审计复跑，生产不设。
pub(super) fn entry_stop_recheck_skip() -> bool {
    static SKIP: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *SKIP.get_or_init(|| {
        std::env::var(crate::theta_v0::env_registry::THETA_ENTRY_STOP_RECHECK_SKIP)
            .map(|v| v == "1")
            .unwrap_or(false)
    })
}

/// 反证开关（#689，用户 2026-07-29 裁定同款）：`THETA_HISTBIND_REROUTE_SKIP=1` ⟹ 历史绑定
/// 投递的改道整体旁路（`reroute_target` 恒 `None`），逐字节回到 #689 落地前的旧行为
/// （锚重订常例）——用于合入本票时的反证复核。仅供审计复跑，生产不设。
fn histbind_reroute_skip() -> bool {
    static SKIP: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *SKIP.get_or_init(|| {
        std::env::var(crate::theta_v0::env_registry::THETA_HISTBIND_REROUTE_SKIP)
            .map(|v| v == "1")
            .unwrap_or(false)
    })
}

/// 记一次拒单（门内唯一写入点）。`bsp_class`：候选最小成立类号 1/2/3（#678 类别桶键，
/// 判据本身不读该值——见上方结构体注释）。
fn entry_stop_recheck_probe_bump(dir: strategy::voice::VoiceSide, level: u32, bsp_class: u8) {
    ENTRY_STOP_RECHECK_PROBE.with(|c| {
        let mut p = c.borrow_mut();
        let long = match dir {
            strategy::voice::VoiceSide::Long => true,
            strategy::voice::VoiceSide::Short => false,
            // Flat 候选不开仓 ⟹ 门内恒不判逆侧（`entry_stop_recheck_reject` 返 false），不可达。
            strategy::voice::VoiceSide::Flat => return,
        };
        if long {
            p.long_rejected += 1;
        } else {
            p.short_rejected += 1;
        }
        let by_level = if long {
            &mut p.by_level_long
        } else {
            &mut p.by_level_short
        };
        let idx = level as usize;
        if by_level.len() <= idx {
            by_level.resize(idx + 1, 0);
        }
        by_level[idx] += 1;
        // 到达本门的候选恒有效分类（`interp::min_class` 1/2/3；Flat 已在上方 return，
        // MAX 无类候选不构成可交易 candidate，不会流入 step_gamma_trade）。
        debug_assert!(
            (1..=3).contains(&bsp_class),
            "candidate bsp_class 越界: {bsp_class}"
        );
        if (1..=3).contains(&bsp_class) {
            let by_class = if long {
                &mut p.by_class_long
            } else {
                &mut p.by_class_short
            };
            by_class[(bsp_class - 1) as usize] += 1;
        }
    });
}

pub(super) fn pi_theta_fill_loop_overlay<F>(
    mut classify_at: F,
    bars: &[Bar],
    initial_nav: f64,
    config: &ThetaConfig,
    chi: Option<ChiFilterCtx>,
    mut overlay: Option<&mut super::super::strategy::overlay_state::OverlayState>,
    // ★LEE M1 `level_ledger`（multi-level-native-execution-design-20260719 §D M1，#644 语义
    // 重放自 kimi-nest-mainline）：与 overlay 并列的第二重只读旁路——同一决策点同一
    // `step_trace.sep_legs` 按 `id.level`≡formation_level 分桶步进
    // [`LevelLedgerMirror`](super::super::strategy::level_ledger::LevelLedgerMirror)。`None` ⟹
    // 整段跳过，逐字节不变（bit-exact 回归锁）。**只读**：不改 `order`/`cash`/`units`/`p_t`
    // 任何决策变量（#644 票面边界——level_order/level_risk sizing 接线不在本票，归 #755）。
    mut level_ledger: Option<&mut super::super::strategy::level_ledger::LevelLedgerMirror>,
    mut voice_exec: Option<&mut super::super::strategy::overlay_state::VoiceExecBook>,
) -> FillOutput
where
    // ★工位 4g/on2w2：闭包返回四元组——第三个 u64 = 塔代次（candidate 段判据）；第四个 u64 =
    // forest_epoch（K_i 森林段 O(1) 命中判据，on2w2 O(n²) 修复）。
    F: FnMut(
        usize,
    ) -> (
        classifier::Classification,
        Vec<std::rc::Rc<Vec<classifier::recursive_tower::LeveledMove>>>,
        Vec<usize>,
        u64,
        u64,
        // ★#883：本 bar 因果前缀的 L0 笔序列（Rc 共享只读，source_index 域）——
        // nest 门 L2 旧臂 div_cand 的 ForceL 力度数据源（#873/#989/#990）。
        std::rc::Rc<Vec<super::super::types::Stroke>>,
    ),
{
    use super::super::strategy::coverage::{self, PiThetaWeights};
    use super::super::strategy::exec::fill_bar_index;
    use super::super::strategy::interp::{self, ActiveLeg};
    use super::super::strategy::overlay_state::{VoiceOrder, VoiceOrderKind};

    let n = bars.len();
    let nav0 = if initial_nav > 0.0 { initial_nav } else { 1.0 };
    let fee_rate =
        (config.exec.commission_bps + config.exec.slippage_bps + config.exec.tax_bps) / 10_000.0;
    // ★#360/#419（⚠MED-6 恢复）：声部执行簿的成交费率走 `FeeQuoter`（未标定档恒返回
    //   三常数合成率 = 上方 `fee_rate` 逐位同值；标定档按 (q_v, px, 方向) 解析 datum）。
    //   净额账户路径（`apply_order`）仍用标量 `fee_rate`——其 fee_quoter 接线属另票
    //   （treasury.rs `scalar_cost_rate` 文档登记的两个消费面同款缝）。
    let fees = super::treasury::fee_quoter(&config.exec);
    let weights = PiThetaWeights::from_risk(&config.risk);

    let mut cash: f64 = nav0;
    let mut units: f64 = 0.0; // p_t = 净 lot（apply_order 维护，有符号：正多/负空/0空仓）
    let mut entry_cost: f64 = 0.0;
    // ★#879（SPEC #847 S1）：重簿——现状全账户 = 一个重（legacy 占位键，ADR 0010 §一/
    // ADR 0013 裁定一·二）。专属筹码 Q = nav0（单重独占全部资金），全局上限同值（不等式
    // 约束，多重后 Σ 各重已用 ≤ 上限）。**单重 ⟹ 账户净持仓即该重持仓**（重内单向落地后
    // 全账户无第二份筹码可与其抵消）；多重实例化随 SPEC #847 S3 落地，届时簿的构造上移
    // runner（那里有 `Dataset.symbol`）。保证金经本簿逐仓计提进风控门（#834 定落点）。
    let chong_key = super::super::strategy::chong::ChongBook::legacy_single_key(
        super::super::strategy::chong::ChongBook::LEGACY_SYMBOL,
    );
    let mut chong_book = super::super::strategy::chong::ChongBook::new(nav0)
        .expect("#879：nav0>0 已保证（initial_nav≤0 退化 1.0）");
    chong_book
        .register(chong_key.clone(), nav0)
        .expect("#879：空簿注册单重必成功");
    // [C] 活动集台账（thread 跨 bar；interp::interpret 闭环递归）。
    let mut prev_active: Vec<ActiveLeg> = Vec::new();
    // #196 阶段 A：shadow 双链比对簿（零行为变更——只读生产状态，channel 适配层在组合层
    // 裁决点之后并行跑，分歧仅入本簿内存 + env 门控落盘；不改裁决与订单流）。
    let mut shadow_book = super::super::strategy::shadow::ShadowVoiceBook::default();
    // ★persistent overlay（anc.pdf §4-§9）：跨 bar 持久元素注册表 Pi。
    // 修复 Q4 "LiveDetached 误处理成 Stale" → depth>0 腿被 AncOK 系统性剪掉 → #5α=0。
    // Pi+1 = merge(Pi, Ei+1, held legs)（§9）：snapshot 匹配刷新 + held 找不到标记 LiveDetached。
    let mut registry = super::super::strategy::persistent::PersistentRegistry::new();
    // ★确认-bar 部署 seen-set（append-only "只增不改"；已部署买卖点身份键，stream.rs:162 同构）。
    let mut seen_bsps: std::collections::HashSet<(usize, usize, u8)> =
        std::collections::HashSet::new();
    // ★#487：挂起候选三类证书按 (level, 精确 Owner, source, bits) 去重。Owner 必须入键：
    // 同一 retest 对不同四边框的配对是不同归属证书，不能复用普通 BSP 不含 Owner 的 seen 键。
    let mut seen_historical_bound_bsps: std::collections::HashSet<HistoricalSeenKey> =
        std::collections::HashSet::new();
    // 延迟成交队列（spec:50：订单在 exec_index bar 成交，沿用既有执行契约）。
    let mut pending: Vec<Vec<Order>> = vec![Vec::new(); n];
    // 工位 K 性能：tree-prefix 缓存（§16 confirmed prefix immutable；跨 bar 复用 extract_elements）。
    let mut tree_cache = interp::TreeCache::new();
    // ★工位 4h：candidate 段前缀缓存（源(b) O(n²) 真修；caller B merge 路径 gamma-free + 前缀复用）。
    let mut cand_cache = interp::CandidateCache::new();
    // ★工位 4f：上一 bar merge 用的 tree Rc——`Rc::ptr_eq` 命中（同一 Rc::clone）⟹ tree 逐字节不变
    // ⟹ merge tree 段跳过 step 1'/2'（confirmed prefix 增量维护，消 O(tree)/bar）。
    let mut prev_merge_tree: Option<std::rc::Rc<Vec<coverage::CoverageElement>>> = None;
    // #82 DC-E：默认关闭时整段惰性（不算 MACD、不评生产门、不上触发轨），订单轨 frozen。
    // 开启时首见证书只经 econ_positive 的 Nest/XZD 单一门产触发事件（#282：账面形态已删，
    // 门内不产订单、不写子腿簿——触发链保留为 #274 原料）。
    let mut pan_div_state = super::pan_div::PanDivProductionState::default();
    // #292（T2 落点门控接线）：中枢生命周期事件机（每级别一台，T1 单一真相源，与
    // opsem_dump::feed_center_lifecycle 同款 consume_chain/push_point 驱动方式，状态独立不
    // 交叉——同一张塔链表的两个只读消费者）+ 中枢震荡挂起账（每级别一台）。惰性按级增长
    // （新级涌现补建）；门关（`config.center_oscillation.enabled=false`）⟹ 本段整体不构造
    // 不驱动，零开销，订单轨逐字节不变（bit-exact 不破）。
    let mut cl_machines: Vec<classifier::center_lifecycle::CenterEventMachine> = Vec::new();
    let mut osc_books: Vec<
        super::super::strategy::center_oscillation_trade::CenterOscillationBook,
    > = Vec::new();
    let mut osc_actions: Vec<
        super::super::strategy::center_oscillation_trade::CenterOscillationActionRecord,
    > = Vec::new();
    // ★issue #357（#294/#278 生产接线最后一公里）：每重 campaign 账簿（★#880 键 =
    // (标的, 操作级别)，BTreeMap 惰性按键增长；结构振荡簿 `osc_books` 仍是每级别一台、与
    // 三阶段账簿粒度不同）+ 生产接线观测统计。门关 ⟹ 本段整体不驱动（下方消费点全在
    // `pan_div_hist` 门内），二者恒 default/空，零开销，订单轨逐字节不变（bit-exact 不破）。
    let mut campaign_book = super::super::strategy::oscillation_campaign::CampaignBook::new();
    let mut campaign_witness =
        super::super::strategy::oscillation_campaign::CampaignWiringWitness::new();
    let pan_div_hist = if config.center_oscillation.enabled && !bars.is_empty() {
        let closes: Vec<f64> = bars
            .iter()
            .map(|bar| bar.close as f64 / config.tick.tick_size)
            .collect();
        Some(super::super::classifier::divergence::compute_macd(&closes, &config.macd).hist)
    } else {
        None
    };
    // ── ★nest-gate（进场准入升格路径 b，nest-gate-elevation-design-20260719 §3 实装卡）：
    //    开仓准入门消费 typed nest 证书（build_gate_certificate 单一裁决源）。门源依赖 MACD
    //    hist——复用 pan_div_hist（已算则零成本），否则门开启时无条件算一次 compute_macd
    //    （同 config.macd，确定性 O(n) 一次性；不构成 bit-exact 风险，只构成成本）。门关闭
    //    ⟹ None ⟹ 门段整体跳过，逐字节不变（bit-exact 回归锁）。──
    let nest_gate_hist: Option<Vec<f64>> = if nest_cert_gate_enabled() && !bars.is_empty() {
        match &pan_div_hist {
            Some(h) => Some(h.clone()),
            None => {
                let closes: Vec<f64> = bars
                    .iter()
                    .map(|bar| bar.close as f64 / config.tick.tick_size)
                    .collect();
                Some(super::super::classifier::divergence::compute_macd(&closes, &config.macd).hist)
            }
        }
    } else {
        None
    };
    // ── ★#75（N3-T2 真链切换）：门开 ⟹ typed 真链门状态（增量事件账本 + 证书索引 +
    //    provider 域序列，一次性 O(n) 构建）；门关 ⟹ None ⟹ 门段整体跳过，逐字节不变。──
    let mut nest_chain_gate: Option<NestChainGate> = if nest_gate_hist.is_some() {
        Some(NestChainGate::new(bars, config))
    } else {
        None
    };
    // nest-gate 观测统计（门开启时逐候选落账；门关闭恒零、不输出）。
    let mut nest_gate_stats = NestGateStats::default();

    let mut equity_curve = Vec::with_capacity(n);
    let mut trade_pnls: Vec<f64> = Vec::new();
    let mut trades: Vec<metrics::TradeRecord> = Vec::new();
    let mut pos_entry_bar: Option<usize> = None;
    let mut n_orders_executed: usize = 0;
    // ── ★W1 声部独立执行层（churn 修复臂，netting-vs-voice-execution-audit-20260719 §7）：
    //    Some ⟹ 决策层由净额影子账本（上方 cash/units/entry_cost 全部原有逻辑原样跑）驱动——
    //    typed_ledger/TW/sep_legs 与净额臂逐字节一致；真实执行投影走 VoiceExecBook（声部独立
    //    持仓 + 事件驱动 fill + 开仓冻结 sizing），输出层（equity/trade_pnls/trades/n_orders/
    //    r_decomp）换声部账户口径。None ⟹ 本块全部变量闲置、声部分支全跳过（bit-exact 回归锁）。──
    let voice_enabled = voice_exec.is_some();
    let mut pending_voice: Vec<Vec<VoiceOrder>> = if voice_enabled {
        vec![Vec::new(); n]
    } else {
        Vec::new()
    };
    let mut n_voice_fills: usize = 0;
    let mut voice_trade_pnls: Vec<f64> = Vec::new(); // 声部平仓 fill 费后已实现（不含强平）
    let mut voice_trades: Vec<metrics::TradeRecord> = Vec::new();
    let mut cum_funding_v: f64 = 0.0; // 声部账户持仓成本（cost_model=None ⟹ 恒 0）
    let mut cum_borrow_v: f64 = 0.0;
    let mut cum_liq_v: f64 = 0.0;
    // ── G4 typed ledger（#134）：腿级在飞表（voice_id → 入场登记）+ 已结算 typed 交易。 ──
    let mut open_trades: std::collections::HashMap<
        classifier::recursive_tower::ElementId,
        LedgerOpen,
    > = std::collections::HashMap::new();
    let mut typed_ledger: Vec<TypedTrade> = Vec::new();
    // #201 阶段 B 裁决账本轨（加轨不减轨）：逐 bar 消费 StepTrace.verdicts 的显式
    // per-voice 裁决序列（含显式 Hold）；与 typed_ledger/账户镜像/opsem/TW 全正交。
    let mut verdict_ledger: Vec<VoiceVerdictRec> = Vec::new();
    // #197 并行记账视图（expand 只读旁路）：(account, level) 键全链携带的分实例账本。
    // 镜像开/关腿生命周期事件过账，不改净额路径任何语义（三把 bit-exact 锁为界）；
    // 消费这些类型修复归属现病属修复票 #198/#199/#200。
    let mut account_view = strategy::account::ParallelAccountLedger::new();
    // ★LEE M3 `clock_ℓ`（multi-level-native-execution-design-20260719 §D M3，#644 语义重放）：
    // clock_ℓ 钟点的逐决策点累计读数（**release 可见**——「稀疏」若只有定义没有读数等于没有
    // 证据）。**只读**：本读数不参与任何门控（`level_order.regate` 不在 #644 范围，归 #755），
    // 纯粹的诊断累计，不影响 `order`/`cash`/`units`。
    let mut level_clock_stats = super::super::strategy::level_clock::LevelClockStats::default();
    // ★LEE 归因算子（`strategy::level_attrib::attribute_total`，#644 语义重放）逐 bar 只读诊断
    // 计数：决策点总数 / 落残差桶决策点数 / 经比例缩放决策点数（见下方调用点注释）。
    let mut level_attrib_n_bars: u64 = 0;
    let mut level_attrib_n_residual_bars: u64 = 0;
    let mut level_attrib_n_rescaled_bars: u64 = 0;
    // ★opsem-dump（基因 073a/274号）：env `OPSEM_DUMP_DIR` 启用时开两个 JSONL 写入器。
    // 未启用 ⟹ None，所有 write_trade/diff_tower 调用 no-op ⟹ 生产路径 bit-exact 不变。
    let mut opsem = OpsemDump::from_env();
    // ★#71 Gap-2 Γ_t 候选级只读 dump：独立 env 开关（`OPSEM_GAMMA_DUMP_DIR`）；不进任何生产
    // 类型或门控。未设 ⟹ None ⟹ 下方两处 `gamma_dump.is_some()/as_mut()` 分支不进入，无分配
    // 无写入，生产路径逐字节不变。
    // ⚠#614 并线手工移植（待人工复核）：本钩子原在 kimi 线 `fill.rs`（#563/#600），本合并树
    // 取 main 线 `fill.rs`，故按 kimi 侧注释钉死的不变量（「须在下游 Nest/Xzd 收窄同一 Vec
    // **之前**取 χ 真值」+「step_gamma／生产 χ 成员／step_trace 三者首次同时在手」）在
    // 结构同形的对应位点重放，未改动任何生产判据。见 #614 合并报告 ⚠-4。
    let mut gamma_dump = super::gamma_dump::GammaDump::from_env();
    // ★A7（Task #165）：出场 z 账本态维（t_stage/eta_bucket/risk_mode）取自出场 bar 决策点的
    //   `ext_i`。窗口终点 censored Hold 在主循环外结算 ⟹ 需保留**最后一个决策点** ext_i（末可交易
    //   bar 的账本态真值，与 censored 兑现价同 bar）。主循环内每决策点刷新；无决策点（全窗不可交易）
    //   ⟹ ZExt::NONE（账本态维诚实 None，无 bar 决策点可取——同 entry_z 裸口径）。
    let mut last_ext: super::selector::ZExt = super::selector::ZExt::NONE;
    // ★A9（Task #166，级别容器.pdf p14/§13）：campaign generation 高水位表——carrier(ElementId) →
    //   该 carrier 已见最高 generation。同一 carrier close→reopen 时新 campaign 的 generation =
    //   高水位 +1（首次入场 = 0）。`ActiveLeg::id`/`voice_id` 会跨 campaign 复用（close 后同 carrier
    //   可再 open，见 interpret 无历史 tombstone + open_trades.insert 二次覆盖），高水位表使
    //   position_node_id 四元组严格不碰撞（时序再入场可达，codex a9-posnode 裁定 C）。
    let mut gen_hiwater: std::collections::HashMap<classifier::recursive_tower::ElementId, u32> =
        std::collections::HashMap::new();
    // ── #124 裁定4：TW 账本单一生产真值源（TwState 接入 π 路径；run_closed_loop 降级纯结构
    //    验证工具）。注资口径 = funded_campaign 同款（state.rs:219）：整窗 = 一个 campaign，
    //    投入 = 初始 NAV 取整（free = notional_in = ⌊nav0⌋）。i64 取整粒度诚实声明：TW 账本是
    //    **结构谓词源**（P2/P3/P4 判据消费 stage/open_legacy_legs/holding/free/withdrawn），
    //    非逐分对账账本——其在生产 π 的唯一消费者是 I_Θ 组合层 TW 谓词 + tw_final 物证。
    //    ★可达性（codex GAP3 终局裁定 A' 落地，2026-07-03）：**已实现利润有入 free 通道**——
    //    每笔实际平仓 fill 的费后 PnL 经 ②'' `TwEvent::Realize` 入账（可正可负），TW 漂移 =
    //    量化已实现 PnL 累计 ⟹ holding≥notional_in ∧ free≥recover_target 在 L2 变价 + 足额
    //    已实现利润下可满足 ⟹ P2/P3/P4 生产触发**现实可达**（可达性见证 `pi_loop_realized_
    //    profit_reaches_earning_shares`）。L0 同价下平仓 PnL≡0 ⟹ 仍不可达（L0 同价无盈亏
    //    定理，见 earning_shares_unreachable_l0_same_price_zero_pnl）。
    // ★B-M3b-expand（#90）：TW 账本线程收敛为 TwLedgerThread（~10 处 tw_step 散点聚出）。
    // κ=0 最小基线（PDF §10 canonical 默认，runner.rs:702 生产口径）。
    // ★A10 附则A（裁定接口冻结）：优先序写死 env `KAPPA_BARRIER_*`（L2 敏感性诊断覆写，codex
    // `.kappa-ruling-20260704`，M7 网格 {0,0.5,1,2}=`0/1,1/2,1/1,2/1`）> `config.risk_policy` >
    // baseline κ=0——**env 未设 ∧ config=None ⟹ baseline κ=0**，所有生产/测试路径逐字节不变
    // （bit-exact）。κ 只在此单点注入，经 stage_progression 门控三阶段推进；env 纯诊断，不改生产
    // 冻结值（正 κ 生产选择是 M8 L3 的事，codex 已裁，A10 附则A 留编排者选择类）。与
    // M7_WITNESS_BARS 同为 L2 诊断 env 惯例。
    let mut tw_thread = TwLedgerThread::new(nav0, kappa_policy_resolved(config.risk_policy));

    // ── M6 R 分解成本累计（路线.pdf p16 第十一关：R = ΣN_tΔP_t − Commission − Slippage −
    //    Funding − Borrow − LiquidationLoss）。cost_model=None ⟹ funding/borrow/liq 恒 0
    //    （bit-exact——不改 units/cash，只多算三个恒 0 累计），commission_slippage 仍如实累计
    //    （守恒断言用，不改现金流）。──
    let mut cum_fee: f64 = 0.0; // Commission+Slippage+Tax（apply_fill 独立测得，非从 net 反推）
    let mut cum_funding: f64 = 0.0;
    let mut cum_borrow: f64 = 0.0;
    let mut cum_liq_loss: f64 = 0.0;
    // 价格 PnL 毛额 Σ_t N_t·ΔP_t（逐 bar：p_t（前 bar 收盘的净持仓）×（px_t − px_{t−1}）×
    //   |合约乘数=1|，units 已是名义手数）。首 bar 无前价 ⟹ 不计。
    let mut cum_price_pnl: f64 = 0.0;
    let mut prev_px: Option<f64> = None;
    // 强平罚金边沿触发（一次一集）：进入 {Insolvent,Liquidation} 且持仓 ⟹ 收一次罚金，
    // 置 true；离开强平态 ⟹ 复位。避免强平态跨 bar 持续（exec 延迟平仓期间）重复罚。
    let mut liq_active: bool = false;

    for i in 0..n {
        let bar = &bars[i];
        let px = bar.close as f64 * config.tick.tick_size;

        // ── M6 ①⁻ 价格 PnL 毛额累计（ΣN_tΔP_t）：本 bar 开头 units 是**前 bar 收盘持仓**
        //    （尚未经本 bar ① 成交），px−prev_px 是本 bar 价格变动 ⟹ 贡献 = units·Δpx。
        //    这是含浮盈的 MtM 价格贡献，与 equity_curve 的价格重估同源（守恒断言校验）。──
        if let Some(pp) = prev_px {
            if px > 0.0 {
                cum_price_pnl += units * (px - pp);
            }
        }
        // ★W1：声部簿价格 PnL 累计（同一 Δpx 口径——簿内持仓是前 bar 收盘持仓，在本 bar
        //    声部 fill 之前累计，与上方净额影子累计同一时点）。
        if voice_enabled {
            voice_exec
                .as_deref_mut()
                .expect("voice_enabled ⟹ Some")
                .mark_to_market(px);
        }

        // ── ① 延迟成交：本 bar 到达 exec_index 的挂单 fill（apply_order，先平后开）。 ──
        if !pending[i].is_empty() && !bar.untradable && px > 0.0 {
            let orders = std::mem::take(&mut pending[i]);
            for o in &orders {
                if o.qty > 0 {
                    let units_before = units;
                    // A'（清单③）：累加本 fill 的费后已实现 PnL（多 fill 同 bar 聚合——推导链第 9 条）。
                    let fill = apply_order(
                        o,
                        px,
                        fee_rate,
                        &mut cash,
                        &mut units,
                        &mut entry_cost,
                        &mut trade_pnls,
                    );
                    tw_thread.add_realized(fill.realized);
                    cum_fee += fill.fee;
                    if fill.executed_qty > 0.0 {
                        // 轨迹与执行计数只消费真实成交；全拒单不再伪造 L2 执行事实。
                        track_position_transition(
                            &mut trades,
                            &mut pos_entry_bar,
                            units_before,
                            units,
                            i,
                            false,
                        );
                        n_orders_executed += 1;
                    }
                }
            }
        }
        // ── ★W1 ①-voice 声部 fill（执行投影）：本 bar 到达的声部订单逐声部成交（hedge-mode
        //    簿，每声部独立 units_v/entry_cost_v）；平仓结算产 trade_pnls/TradeRecord 行。──
        if voice_enabled && !pending_voice[i].is_empty() && !bar.untradable && px > 0.0 {
            let vos = std::mem::take(&mut pending_voice[i]);
            let vb = voice_exec.as_deref_mut().expect("voice_enabled ⟹ Some");
            for vo in &vos {
                let out = match vo.kind {
                    VoiceOrderKind::Open => vb.apply_open(vo.voice, vo.side, vo.qty, px, i, &fees),
                    VoiceOrderKind::Close => vb.apply_close(vo.voice, px, i, &fees),
                };
                if out.executed_qty > 0.0 {
                    n_voice_fills += 1;
                }
                if let Some(cinfo) = out.closed {
                    voice_trade_pnls.push(cinfo.pnl);
                    voice_trades.push(metrics::TradeRecord {
                        entry_bar: cinfo.entry_bar,
                        exit_bar: i,
                        hold_bars: i.saturating_sub(cinfo.entry_bar).max(1),
                        qty: cinfo.qty as f64,
                        long: cinfo.long,
                        forced_close: false,
                    });
                }
            }
        }

        // ── M6 ①⁺ Funding + Borrow 持仓期成本计提（本 bar 成交后持仓的持有成本；px>0 才计——
        //    untradable bar（px=0）无有效 mark ⟹ 跳过计提，与 cum_price_pnl 的 px>0 累计口径
        //    一致，守恒才成立）。从 cash 扣除 ⟹ equity_curve 反映拖累。cost_model=None ⟹ 恒 0
        //    （bit-exact）。──
        if let Some(cost) = config.cost_model.as_ref() {
            if px > 0.0 && units != 0.0 {
                let net_notional_usd = units.abs() * px;
                let equity_pre = cash + units * px; // 计提前权益（借入名义 = max(0,|N|−E)）
                let funding = cost.funding_accrual(i, net_notional_usd);
                let borrow = cost.borrow_accrual(net_notional_usd, equity_pre);
                cash -= funding + borrow;
                cum_funding += funding;
                cum_borrow += borrow;
            }
        }
        // ★W1 ①⁺-voice：声部账户持仓成本镜像（对 N_derived=Σσ_v q_v 名义计费，现金真扣 ⟹
        //    守恒断言覆盖；cost_model=None ⟹ 恒 0 不调用）。触发时点与净额影子同（本 bar 成交后）。
        if voice_enabled {
            if let Some(cost) = config.cost_model.as_ref() {
                let vb = voice_exec.as_deref_mut().expect("voice_enabled ⟹ Some");
                let nv = vb.net_signed() as f64;
                if px > 0.0 && nv != 0.0 {
                    let net_notional_usd = nv.abs() * px;
                    let equity_pre = vb.cash() + nv * px;
                    let funding = cost.funding_accrual(i, net_notional_usd);
                    let borrow = cost.borrow_accrual(net_notional_usd, equity_pre);
                    vb.debit_cash(funding + borrow);
                    cum_funding_v += funding;
                    cum_borrow_v += borrow;
                }
            }
        }

        // ── ② p_t = 净 lot（成交后真实持仓）。 ──
        let p_t = units;
        // #879：单重簿同步——该重持仓 = 账户净持仓（重内单向 ⟹ 无第二份筹码可抵消；
        // 异重反向持仓未来由多重簿分行承载，出口仍走净额，ADR 0014 有效域注记）。
        chong_book
            .set_position_lots(&chong_key, p_t)
            .expect("#879：chong_key 已在循环外注册");
        let current_nav = cash + units * px;
        let equity_nav = if current_nav > 0.0 { current_nav } else { nav0 };

        // ── ②' TW 成本划转（#124）：真实成本基（|units|·均价，空头取绝对额=在险市值）方向差分
        //    ⟹ ShortDiff 划转（free⇄holding，TW 守恒构造子）。shadow 追真实、入账钳制（cash-sound）。──
        tw_thread.sync_basis(units, entry_cost);

        // ── ②'' TW 已实现利润入账（codex GAP3 裁定 A' 清单③）：本 bar 平仓 fill 的费后 PnL
        //    聚合（推导链第 9 条：同 bar 多 fill 聚合）经 `TwEvent::Realize(d_pi)` 入 free。
        //    ★硬边界2：置于 ②' 成本基 ShortDiff **之后**、③ TwStepCtx（stage 判据）之前——
        //    同一成交先成本基后利润。★量化口径：对累计值取整再派差分（tw_seen_basis 同款
        //    shadow 模式）⟹ 截断误差有界不累积，TW 漂移恒 = ⌊realized_cum⌋（清单⑥不变量）。
        //    ★可正可负（推导链第 5 条）：亏损如实入账——负 d_pi 使 free 下降；若累计亏损超
        //    free（做空爆亏），free 为负是真实现金透支的诚实镜像（f64 账本 cash 同步为负），
        //    非静默账目错误——stage 门（free≥recover_target>0）在负 free 下恒不过 = 安全侧。
        tw_thread.sync_realized();

        if !bar.untradable && px > 0.0 {
            // ── ③ [A] 前缀因果重分类（classify_at(i)=classify(l0[0..=i]) → 因果塔 + 因果
            //      分类，只用 ≤i 数据 → 因果）+ 切当步候选 + [B] base_units U_ℓ + [C] thread + 风控门。 ──
            let (classification_i, tower_i, confirmed_lens, tower_gen, forest_epoch, strokes_i) =
                classify_at(i);
            // ★opsem-dump：diff tower_i vs prev_tower → 写塔事件（仅交易活跃区间，env-gated）。
            if let Some(dump) = opsem.as_mut() {
                dump.diff_tower(i, &tower_i);
            }
            // ★当步候选 = 前缀因果塔里**本 bar 新确认**的买卖点（append-only diff vs seen，确认-bar
            // 部署）——非 source_index==i 切片（买卖点回溯确认，其触发点常在更晚 bar 才入前缀塔 ⟹
            // source_index==i 切恒空 ⟹ 零订单）。买卖点在被确认那根 bar（source_index≤i）部署=因果。
            let classification_step = newly_confirmed_step(&classification_i, &mut seen_bsps);
            // ★#291（SPEC #274 T1）：中枢生命周期事件机只读旁路（born/broken/reset →
            // center_lifecycle.jsonl）。opsem env 未设 ⟹ None ⟹ 零开销，生产路径 bit-exact 不变；
            // 事件只外化落盘，不回馈任何决策（票面边界：结构地基，动作 = #292）。
            if let Some(dump) = opsem.as_mut() {
                dump.feed_center_lifecycle(i, &classification_i, &classification_step);
            }
            let base_units = equity_nav / px; // U_ℓ：NAV/价 = 可建名义手数（方案A协变）
                                              // 风控门也用**前缀因果分类**（leg 止损 bsp 因果查得，非全窗非因果——与 σ_p 同因果口径）。
                                              // #879：风控门保证金基数 = 重簿逐仓全额计提名义（Σₖ |nₖ|·px；单重 ⟹ |p_t|·px，
                                              // 与旧净额行同值但语义已锚定「逐仓极性全额」——ADR 0014 裁定二，#834 定落点）。
            let chong_posted_notional_usd = chong_book.posted_notional_usd(&|_| px);
            // #890（S7）：毛+净杠杆门（leverage_ok）随 enforce_gross_cap 开关接进风控门——
            // Some(γ)=激活（毛/净同 γ，#122）；None（default）= 不激活（bit-exact 不变）。
            let gross_leverage_cap = config.risk.enforce_gross_cap.then_some(config.risk.gamma);
            let (gate, risk_mode_i, stop_risk_seeds) = k_theta_risk_gate(
                &prev_active,
                &open_trades,
                bar,
                equity_nav,
                p_t,
                chong_posted_notional_usd,
                px,
                gross_leverage_cap,
                config.margin.as_ref(),
            );
            // ── M6 ③⁻ LiquidationLoss 强平罚金（边沿触发，一次一集）：本 bar 进入
            //    {Insolvent,Liquidation} 且持仓 ⟹ 收一次罚金（强平清算费/滑点），从 cash 扣。
            //    liq_active 边沿去抖：强平态跨 bar 持续（exec 延迟平仓期间）不重复罚；离开强平态复位。
            //    cost_model=None ⟹ 恒 0（bit-exact）。RiskExit 优先级由 gate.force_flat 上游承担
            //    （coverage P1 屏蔽 P2..P10），本罚金是该强平事件的**成本记账**，不改平仓触发逻辑。──
            {
                use super::super::strategy::risk::global_risk_close;
                let in_liq = global_risk_close(risk_mode_i);
                if let Some(cost) = config.cost_model.as_ref() {
                    if in_liq && !liq_active && p_t != 0.0 && px > 0.0 {
                        let penalty = cost.liquidation_penalty(p_t.abs() * px);
                        cash -= penalty;
                        cum_liq_loss += penalty;
                    }
                }
                // ★W1 ③⁻-voice：声部账户强平罚金镜像（触发边沿与净额影子同一 liq_active 去抖；
                //    罚金名义 = |N_derived|·px——声部账户自身真实持仓，非影子 p_t）。
                if voice_enabled {
                    if let Some(cost) = config.cost_model.as_ref() {
                        let vb = voice_exec.as_deref_mut().expect("voice_enabled ⟹ Some");
                        let nv = vb.net_signed() as f64;
                        if in_liq && !liq_active && nv != 0.0 && px > 0.0 {
                            let penalty = cost.liquidation_penalty(nv.abs() * px);
                            vb.debit_cash(penalty);
                            cum_liq_v += penalty;
                        }
                    }
                }
                liq_active = in_liq;
            }
            // ── A10 C5（裁定 (b) TW 桥 G1，零账本侵入）：`cum_holding_cost` i64 shadow =
            //    funding+borrow+liq **累计量化**（`tw_seen_basis`/`tw_seen_realized` 同款「对累计值
            //    量化」模式；f64→定点口径与 treasury `Realize(⌊realized_cum⌋)` 一致——向零截断，
            //    三项恒 ≥0 ⟹ 截断=⌊⌋）。G1 缺口：持盾成本只扣 f64 `cash`（①⁺/③⁻），TW 账本不经
            //    任何构造子见到它（GAP3 A' 构造子冻结不动）⟹ 未修正 η=tw() **高估**真实在险权益
            //    ⟹ enter_ready 易过=激进侧（不安全）。修正全部在**策略层消费侧**：η_bucket
            //    （ZExt 第 15 维）与 TwStepCtx.eta_correction 读**同一本变量**（F4 同源强制——
            //    裁定 C5 第 4 条：两处不同步则 z 维与判据裂口）。cost_model=None ⟹ 三项恒 0
            //    ⟹ shadow=0 ⟹ 与历史判据同值 bit-exact（回归锁）。──
            let cum_holding_cost: i64 = (cum_funding + cum_borrow + cum_liq_loss) as i64;
            // 桥接对账断言（裁定 C5 裁决1，取整界内）：η_corrected := tw() − cum_holding_cost
            // ⟹ tw() − η_corrected == ⌊cum_holding_cost⌋——此处断言 shadow 与 f64 真值的量化
            // 界 <1 个量化单位（三项恒 ≥0 保号；断言即断言，不降格为告警）。
            debug_assert!(
                cum_funding + cum_borrow + cum_liq_loss >= 0.0
                    && ((cum_funding + cum_borrow + cum_liq_loss) - cum_holding_cost as f64).abs() < 1.0,
                "A10 C5 桥接对账：tw()−η_corrected == ⌊cum_holding_cost⌋ 取整界破——shadow={} f64真值={}",
                cum_holding_cost,
                cum_funding + cum_borrow + cum_liq_loss
            );
            // G3（#138）z 第 10-13 维装配：π 路径候选不经 Nest/Xzd 准入门（cand_channel/nest_depth
            // None 诚实口径，origin_level 由 z_of_candidate 填 Some(c.level) 起始=执行真值）；
            // risk_mode = 当 bar 账本态真值。**同一 ext_i 同时喂 χ 查询（filter）与训练登记
            // （entry_z）** ⟹ 训练/查询同口径在共享变量层保证（G2 护航点同款）。
            // #149 第 14 维 t_stage = tw.stage 当 bar 决策点相位真值：②'/②'' 账本更新之后、
            // 本 bar stage_progression（step_trace.tw_event 写点）之前读取——与 TwStepCtx.state
            // 喂给 P2/P3/P4 谓词的是同一 tw 值，账本相位单一真值源（#124 裁定4）无第二口径。
            // #175 第 15 维 eta_bucket = γ_t 四桶（PDF §10 分段式；终裁 a5-etabucket-stance-
            // ruling-20260704.md：η_t=tw.tw() 即 enter_ready 判据左操作数、η_*=tw_policy.eta_star）
            // ——与 t_stage 读同一 tw 变量同一时点（非另开账本查询，零时序错位）。
            // ★A10 C5（F4 同源修正）：η 左操作数经 cum_holding_cost 修正（η_corrected =
            // tw() − cum_holding_cost）——与下方 TwStepCtx.eta_correction **同一变量同一时点**，
            // 裁定 C5 第 4 条「η_bucket 与 enter_ready 左操作数同源修正为一笔改动」的落点。
            let ext_i = super::selector::ZExt {
                risk_mode: Some(risk_mode_i),
                t_stage: Some(tw_thread.tw.stage),
                eta_bucket: Some(
                    tw_thread
                        .policy
                        .eta_bucket_eta_corrected(&tw_thread.tw, cum_holding_cost),
                ),
                ..super::selector::ZExt::NONE
            };
            // A7（#165）：记录当前决策点账本态——窗口终点 censored Hold（主循环外）取此末值作 exit_z
            // 账本态维（末可交易 bar 决策点真值，与 censored 兑现价同 bar 口径）。
            last_ext = ext_i;
            // exec_index：延迟成交 bar（spec:50；尾部无可成交 bar ⟹ 不挂单）。
            let exec_index = fill_bar_index(i, bars, &config.exec);
            // 环5+6+7：pi_theta_step（父容器 σ_p=attach_bsp_to_tree(因果塔) + 风控门）→ (A_{t+1}, p*, O)。
            // 工位 K 性能：tree-prefix 缓存（§16，命中省 extract_elements 重建）。pi_theta_step 用
            // newly-confirmed step 候选；merge 用全 classification 候选——两者共享同一 tower tree-prefix 缓存。
            // ★热点② O(n²) 消除：tree=Rc::clone O(1)，candidate 段单独 Vec，ElementView 双段零拷贝。
            let (step_tree, step_candidates, step_gamma) = {
                let _g = classifier::stage_profile::stage("cand_build_step");
                interp::coverage_elements_and_gamma_with_tower_cached_gen(
                    &classification_step,
                    &tower_i,
                    &mut Some(&mut tree_cache),
                    Some(tower_gen),
                    Some(forest_epoch),
                )
            };
            // ★工位 4d 热点①②：注入缓存的 base（tree 前缀）兄弟/ID 索引（命中 Rc::clone O(1)），消除
            // coverage_step_from_buckets 内每 bar build_prev_sibling_index/build_tree_id_index O(tree)/bar。
            let mut step_work = coverage::ElementView::from_parts(&step_tree, step_candidates);
            if let Some((sib, id)) = tree_cache.tree_sibling_and_id() {
                step_work = step_work.with_base_indices(sib, id);
            }
            // ── ③' χ_t 阈值过滤（task #41）：Γ_t → Γ_t^trade={γ:μ(z_γ)>θ}（§13）。 ──
            // χ 仅滤候选集（喂 interpret 的 gamma）；step_work(tree/candidates) 不受影响——
            // coverage_step_prebuilt 内 gamma→interpret 三桶 与 work→AncOK 准入解耦（gamma 滤掉
            // μ≤θ 候选 ⟹ interpret 不归 open ⟹ 不开仓 = χ_t 语义）。None ⟹ χ≡1 全覆盖（不滤）。
            let step_gamma_trade = match &chi {
                // σ_higher 真值穿透（codex-q1 G2 护航点）：生产 χ 查询与训练表同经塔真值构 z——
                // 训练 Some/查询 None 的静默"未见类别"退化在此被接口封死。
                Some(ctx) => super::selector::filter_gamma_with_admission(
                    &step_gamma,
                    ctx.est,
                    ctx.theta,
                    ctx.z_alpha,
                    ctx.shrink_tau_sq,
                    ctx.treat_empty_as_pass,
                    &tower_i,
                    bars,
                    &ext_i,
                ),
                None => step_gamma.clone(), // χ≡1：原候选集（bit-exact 不变）
            };
            // 仅在 dump 开启时保存生产 χ 过滤结果的成员键。下游 Nest/Xzd 会继续收窄同一 Vec，
            // 故须在其消费前取 χ 真值；关闭时不分配。
            // #563 L5 订正：「生产路径零额外指令」应读作「零额外**分配/写入**」——关闭时本
            // 分支仍逐 bar 求值一次 O(1) 布尔判断，只是不进入 collect 的分配与写入。行为无变。
            // ★#712 收 #645 LOW-2：本订正原随 #600 Std MED-4 同步写回设计稿正文
            // （`chanlun/review-results/gap2-gamma-candidate-dump-design-20260719.md` §4①），
            // 该设计稿已随 main #504 归档整删；恢复指针 = kimi 侧 blob `d290516b34`（`git show
            // 797c9ad35c:...` 树下，见 #614 合并报告 ⚠LOW-10）。
            let gamma_chi_admitted: Vec<usize> = if gamma_dump.is_some() {
                step_gamma_trade.iter().map(|c| c.gamma_index).collect()
            } else {
                Vec::new()
            };
            // ── ★nest-gate（升格路径 b，实装卡 §3.2；#75 真链切换）：Γ_t^trade → Γ_t^cert={γ:持
            //    typed N^δ/Xzd 证书}。#75 起 **typed 真链为唯一 nest 判定源**（N^δ 跨级递归链
            //    判定，nest.rs n_delta 递归核；增量喂法 + 索引消费见 NestChainGate 文档）；typed
            //    无证时回退旧臂 Xzd 通道（Xzd 无 typed 对应物，经 build_xzd_fallback 单一来源）。
            //    L2 旧臂 build_gate_certificate 双读落账供对照差（进 NEST_GATE_CHAIN cross
            //    计数；复用通道 admit≡old_admit by construction 自证，单独计 reuse 不入对照差）。
            //    证书 None 或谓词 false ⟹ 剔除 ⟹ interpret 不归 open ⟹ 不开仓（与 χ 门
            //    同一语义层，:1556-1559 注释同款「gamma 滤掉 ⟹ 不开仓」）。**拒绝不经 μ 桶键**：
            //    ext_i/entry_z 三维不动（R5-1 铁律不触碰）。nest_gate_hist=None（门关闭）⟹ 直通，
            //    逐字节不变。──
            let step_gamma_trade = match &nest_gate_hist {
                Some(hist) => {
                    let gate = nest_chain_gate
                        .as_mut()
                        .expect("THETA_NEST_CERT_GATE=1 ⟹ 真链门状态已构建");
                    gate.sync_events(&tower_i, &confirmed_lens, i);
                    // 索引惰性重建（精确，决策逐字节不变）：T4 (#173) 起唯一前置 =
                    // `chain_key_hint`（链键域 `by_triple_anchor` 保守超集——脚可解析 ∧
                    // 任一链事件级键有身份集）。T5a (#207) 去方向位后 hint 不再携方向
                    //（Flat 候选不进链求值 ⟹ 恒 false，前置精确性逐字保留；等价性论证
                    // 见 `chain_key_hint` 注释：旧 hint=true 候选逐点保持 true，多出的
                    // 触发 = 方向退役解放人口，`index_builds` 差异按足迹列账）。索引唯一
                    // 读者 = `chain_lookup`（仅经 `by_triple_anchor` 键取身份后 `index.get`）：
                    // hint=false ⟹ 链读出必不触索引（脚不可解 ⟹ NoChain；键全空 ⟹ 逐级
                    // 键域查无）⟹ 无需重建；hint=true ⟹ 本前置触发重建 ⟹ 查询点索引内容
                    // = 当前（重建是 (classification, events_by_level) 的确定函数 ⟹ 与基线
                    // 逐字节一致；诊断计数 index_builds 与末次重建时点变化属预期足迹，
                    // 不进任何判定）。事件账本仍逐 bar 维护首次观察纪律。
                    let needs_index = step_gamma_trade.iter().any(|c| {
                        use super::super::strategy::voice::VoiceSide;
                        if matches!(c.dir, VoiceSide::Flat) {
                            return false; // Flat：不进链求值（admit_inner 早退）⟹ 前置恒 false
                        }
                        classification_i.levels.get(c.level as usize).is_some()
                            && gate.chain_key_hint(c, &classification_i)
                    });
                    if needs_index {
                        gate.sync_index(&classification_i);
                    }
                    step_gamma_trade
                        .into_iter()
                        .filter(|c| {
                            let (admit, channel, obs) =
                                gate.admit(&tower_i, c, hist, i, &classification_i, &strokes_i);
                            // T5a (#207) shadow dump（#[cfg(test)]，env 未设 = no-op）：
                            // 逐候选落新链结果（三态+谱系+缺断）+ admit/channel。
                            #[cfg(test)]
                            super::admission::t5a_chain_dump::record(i, c, &obs, admit, channel);
                            let would_close =
                                exit_candidate_would_close(c.level, c.dir, &prev_active);
                            // #1147 StepFail 归因 dump（#[cfg(test)]，env 未设 = no-op）：
                            // 逐候选落旧臂 StepFail 桶（#846 A/B/C + div_cand cond1-4）+ admit/channel
                            // + would_close（出场侧 χ^{σ_p} 反向项，N7 消费线重叠面读数）。
                            #[cfg(test)]
                            super::econ_positive::stepfail_probe::record(
                                i,
                                c,
                                &tower_i,
                                hist,
                                &classification_i,
                                &strokes_i,
                                gate.gauge,
                                admit,
                                channel,
                                would_close,
                            );
                            nest_gate_stats.observe_exit_candidate(admit, would_close);
                            nest_gate_stats.observe(admit, channel, obs);
                            admit
                        })
                        .collect()
                }
                None => step_gamma_trade, // 门关闭 ⟹ 逐字节不变（bit-exact 回归锁）
            };
            // ── ★#647 入场结构复检门（2026-07-29 用户 HITL 定稿：破自己的底即拒，全类别
            //    同判，力度轴不进生产门）：候选自身的结构位若在**决策时点**已被价格越过
            //    （多仓 `stop_px ≥ px` / 空仓 `stop_px ≤ px`），该点在入场时点已不成立
            //    ⟹ 剔除 ⟹ interpret 不归 open ⟹ 不开仓（与 χ/nest 门同一语义层，:3560 注释
            //    同款「gamma 滤掉 ⟹ 不开仓」）。一/二/三类同一判据、不分桶（101 课最弱二类因
            //    未破自身底而天然不触门，非门内特例放行）。门名分 = 系统自设风控参数（#659
            //    登记，非缠论判据），只表达是否值得建仓，不代判点是否成立。判据全文见
            //    [`super::signal::entry_stop_recheck_reject`] 文档。`entry_stop=None`
            //    （非该方向交易点）或 `px≤0`（不可交易 bar 的退化价）⟹ **不判**，直通。
            //    拒绝不经 μ 桶键（ext_i/entry_z 三维不动，R5-1 铁律同 nest 门）。──
            let step_gamma_trade: Vec<_> = if px > 0.0 && !entry_stop_recheck_skip() {
                step_gamma_trade
                    .into_iter()
                    .filter(|c| {
                        // ★范围铁律（票面「入场复检 ⟹ 逆侧拒单」）：本门只拒**开仓**。同一候选
                        // 若在本步还承担关仓职责（反向信号关现役腿，`exit_candidate_would_close`
                        // 与 nest 门同一 helper），一律放行——结构失效判据只否定「据此建新仓」，
                        // 不授权顺带压制平仓（平仓侧另有 channel/风控门单源，不在本票范围）。
                        if exit_candidate_would_close(c.level, c.dir, &prev_active) {
                            return true;
                        }
                        if super::signal::entry_stop_recheck_reject(
                            c,
                            &classification_i,
                            px,
                            config.tick.tick_size,
                        ) {
                            entry_stop_recheck_probe_bump(c.dir, c.level, c.bsp_class);
                            false
                        } else {
                            true
                        }
                    })
                    .collect()
            } else {
                step_gamma_trade
            };
            // ── #196 shadow 输入适配：parent_projections 生产构造（现成单源
            //    `interp::parent_certificate_projection` 逐候选构造；cand_elems = step_work
            //    candidate 段只读切片、tree = step_tree，与生产同一份数据；χ 后口径——
            //    step_gamma_trade 之外的候选不产投影）。──
            let step_parent_projections: Vec<
                super::super::strategy::interp::ParentCertificateProjection,
            > = step_gamma_trade
                .iter()
                .filter_map(|c| {
                    interp::parent_certificate_projection(c, step_work.overlay(), &step_tree)
                })
                .collect();
            // ── #124 裁定4 TW 谓词 ctx（P2/P3/P4 进 fold）：在飞腿 entry_v 映射从 typed ledger
            //    在飞表取（entry_v 入场固定，与 TW open_legacy_legs 计数同源）。#145 T1：由原
            //    ShortDiff id 半镜像升级为全量 entry_v 映射——P2 过滤在组合层按
            //    `== ReverseOpen` 判（语义 bit-exact），且兼作反向关闭 typed 裁决的
            //    reverse_exit_type 原料（组合层单点，本处不再结算补算）；risk_mode 从
            //    strategy::risk 五态投影到 closed_loop::state 五态（两枚举同锚 Origin 五构造子，
            //    此处只读逐变体映射，非第二权威源——判定仍单源 k_theta_risk_gate）。 ──
            let entry_v_map: std::collections::HashMap<
                classifier::recursive_tower::ElementId,
                super::super::strategy::coverage::Vertical,
            > = open_trades.iter().map(|(id, o)| (*id, o.entry_v)).collect();
            let tw_risk_mode = {
                use super::super::closed_loop::state::RiskMode as ClRiskMode;
                use super::super::strategy::risk::RiskMode as StRiskMode;
                match risk_mode_i {
                    StRiskMode::Insolvent => ClRiskMode::Insolvent,
                    StRiskMode::Liquidation => ClRiskMode::Liquidation,
                    StRiskMode::Deleverage => ClRiskMode::Deleverage,
                    StRiskMode::CloseOnly => ClRiskMode::CloseOnly,
                    StRiskMode::Normal => ClRiskMode::Normal,
                }
            };
            let twc = coverage::TwStepCtx {
                state: &tw_thread.tw,
                policy: &tw_thread.policy,
                risk_mode: tw_risk_mode,
                entry_v: &entry_v_map,
                // A10 C5（裁定 (b)）：enter_ready 的 η 左操作数同源修正（与上方 η_bucket 同一
                // cum_holding_cost 变量，F4）；0 ⟹ 历史判据 bit-exact（cost_model=None 回归锁）。
                eta_correction: cum_holding_cost,
            };
            // #82 DC-E（#282 收缩）：门内段 = 触发链——首见 PanDivCert 经 Nest/XZD 单一门
            // 产触发事件上协议轨（#274 原料）。父腿快照/sync、候选路由、P10 Record、
            // 账面 apply 与净额叠加出口全部随 S6 账面形态删除。
            let mut protocol_events = super::super::strategy::protocol::ProtocolEventSet::hold(0);
            // ★LEE M3 clock_ℓ（#644 语义重放）：本 bar 首见并过门的盘整背驰证书所在级别——
            // `strategy::level_clock` 模块头「E6 结构：该级盘整背驰证书首见并过门」通道。
            let mut pan_levels: Vec<u32> = Vec::new();
            // #292（B 裁定，用户 2026-07-26）：PanDivTrigger 降格为可选辅助——不再驱动开启臂
            // 生产触发（驱动源已改为次级别买卖点，见下方 `step_center_oscillation` 调用）。本段
            // 仍保留盘背证据上协议轨（#274 原料，与 #292 触发源解耦，不喂 `step_center_oscillation`）。
            if let Some(hist) = pan_div_hist.as_deref() {
                for (lvl, ls) in classification_i.levels.iter().enumerate() {
                    for cert in ls.pan_div.iter() {
                        // 首见先落 seen；门闭也终局，后续 bar 不重试（与统计通道 τin 同时序）。
                        if !pan_div_state.observe_raw(lvl as u32, cert) {
                            continue;
                        }
                        let sub_centers: &[super::super::types::Center] = if lvl > 0 {
                            &classification_i.levels[lvl - 1].centers
                        } else {
                            &[]
                        };
                        let sub_bsp: &[super::super::classifier::bsp::BspPoint] = if lvl > 0 {
                            &classification_i.levels[lvl - 1].bsp
                        } else {
                            &[]
                        };
                        let Some(gated) = super::econ_positive::gate_pan_div_for_production(
                            &tower_i,
                            lvl,
                            cert,
                            hist,
                            i,
                            &ls.bsp,
                            sub_centers,
                            sub_bsp,
                            &strokes_i, // ★#883：本 bar 因果前缀笔序列（ForceL 数据源）
                            config.divergence_gauge,
                        ) else {
                            pan_div_state.note_gate_rejected();
                            continue;
                        };
                        // DA-Q2：PanDiv 触发证据留在协议轨（#274 消费点；本层不产订单）。
                        let trigger = pan_div_state.prepare(gated);
                        protocol_events = protocol_events.with_center_oscillation(trigger);
                        // ★LEE M3 clock_ℓ（#644）：首见并过门 ⟹ 本级入 PanDivCert 钟点通道。
                        // ★#758 issue766 MED-4 登记：本行无条件 push，是 kimi
                        // `fill.rs::pan_candidates`（只收 `PreparedPanDiv::Candidate` 分支，
                        // `Record(_reason)`——"无合法 parent/lot identity 时不伪造候选"——不入）
                        // 的**真超集**：main 侧 `prepare` 经 #282 收缩后已无 Candidate/Record
                        // 二分，多收"首见过门但无合法 parent/lot"的那部分。这不是 bug——更贴合
                        // 本模块头 E6 定义"首见并过门"——但与 kimi 的取数源不等价，接口清单须登记
                        // （#693 裁定②，见 issue766-644-tail 报告项4/6）。
                        pan_levels.push(lvl as u32);
                    }
                }
                // #292（T2 接线点二，触发源改码）：级数对齐 + 逐级驱动本 bar 中枢生命周期事件
                // （born/broken/reset/superseded）+ 次级别买卖点 → `CenterOscillationTrigger` 构造
                // 消费（A 裁定：中枢身份取本级 `alive_center()`；B 裁定：触发源=次级别买卖点，
                // 不依赖上面的 pan_div_hist/gate）→ 挂起账减补动作（接线可见性证据）。
                // ★#366：产出改两路（减/补动作 + 未闭合减出核销请求，见
                // [`CenterOscillationStepOutput`]）——核销不成交、不产 TwEvent，与动作分列。
                // ★#466 D0：事务快照只在 OPSEM_DUMP_DIR 已启用时抓取；未启用时仍走原
                // 入口，不复制旧链/新链或挂起表。观测发生在 on_chain_rebase 改写挂起表之前，
                // 落盘发生在本步决策完成之后，两者都不参与任何决策。
                let osc_step = step_center_oscillation_historical(
                    i,
                    &classification_i,
                    &classification_step,
                    &tower_i,
                    &mut seen_historical_bound_bsps,
                    &mut cl_machines,
                    &mut osc_books,
                    &mut campaign_witness,
                    opsem.is_some(),
                );
                if let Some(dump) = opsem.as_mut() {
                    for observation in &osc_step.rebase_observations {
                        dump.write_rebase_observation_fail_open(i, observation);
                    }
                }
                let new_osc_actions = osc_step.actions;
                // ★issue #357（T4/#294 生产实例化，编排者裁定 A：本仓=`Core{level}` 身份账户）：
                // 每重 campaign 生死驱动 + 减/补动作落成对偶事件（ShortDiff 成本基 + Realize
                // 盈亏）经 closed_loop 带门通道（OQ-9 + CashUnsound）入 TW——独立抽为
                // `drive_campaign_wiring`（可脱离完整 fill 循环直接单测，同 `step_center_oscillation`
                // 先例）。
                //
                // 取数时点（可复检）：`account_view` 反映的是**本 bar 尚未过账前**（前 bar 收盘）
                // 的 Core{level} 持仓——本段落在本 bar 主策略核心仓开/平仓镜像（下方「关闭消费
                // 循环」/「开腿：准入信号腿登记」段）之前执行，与 `step_center_oscillation`
                // 本身的调用时点一致（次级别信号驱动的震荡短差决策，读的是「进入本 bar 时」的
                // 本仓持仓，非本 bar 内主策略自身信号造成的仓位变化——两者是同 bar 内正交的
                // 两条独立决策源，不应互相以未定义的执行顺序静默耦合）。
                drive_campaign_wiring(
                    i,
                    classification_i.levels.len() as u32,
                    &account_view,
                    &new_osc_actions,
                    &osc_step.write_offs,
                    px as i64,
                    tw_risk_mode,
                    &mut campaign_book,
                    &mut campaign_witness,
                    // ★#880（SPEC #847 S2）：结构级别→重映射。塔尚无操作级别概念（S3 未
                    // 落地），生产恒 legacy 单重键（全账户 = 一个重，与本函数 #879 的
                    // `chong_book` 同键）；多重实例化随 S3 换本映射，聚合语义不变。
                    &|_| chong_key.clone(),
                );
                osc_actions.extend(new_osc_actions);
            }
            let (next_active, standard_p_star, (mut order, _protocol_event), step_trace) =
                coverage::pi_theta_step_traced_with_risk_seeds(
                    step_work,
                    &step_gamma_trade,
                    &prev_active,
                    p_t,
                    exec_index.unwrap_or(i),
                    base_units,
                    &config.risk,
                    weights,
                    gate,
                    &stop_risk_seeds,
                    &config.voice,
                    &registry,
                    Some(&twc),
                    &protocol_events,
                );
            // ── #1306 对拍观测（sink 未激活 ⟹ 一次 thread_local 布尔检查，零行为变化）：
            //    把批量侧决策点内部状态（sep_legs/风控门/risk seeds/TW 谓词/候选过滤口径/
            //    p_t/equity_nav）外化给对拍 harness。#1308 门控扩为 backtest_bin feature。──
            #[cfg(any(test, feature = "backtest_bin"))]
            super::diff_capture::push_decision(
                i,
                &step_trace.sep_legs,
                gate,
                stop_risk_seeds.len(),
                step_trace.tw_event.is_some(),
                step_trace.overlay_closes.len(),
                step_gamma.len(),
                step_gamma_trade.len(),
                p_t,
                equity_nav,
            );
            // ── ★LEE M4 级别帽（#783 返工，评审 shadow-review-755-20260729 HIGH×2 清偿）：
            //    施加点已前移到 `pi_theta_step_*` 之前——`coverage_step_from_buckets_sep_with_
            //    risk_seeds` 内 `apply_level_cap`（strategy/coverage/leg.rs）对 `level_nets` 施加
            //    同一 clamp 后再折叠 `p_tilde`/打包 `sep_legs`。本处不再有任何账户层投影后的
            //    二次裁剪覆盖 `order`：`standard_p_star`/`order`/`step_trace.sep_legs` 读同一
            //    裁剪后值，投影产出的 `p*` 恒在 𝒦_Θ 可行集内（HIGH-1 越界清零、HIGH-2 两账
            //    分裂清零）。门禁 `enforce_level_cap` default=false ⟹ 零执行路径（M0-M3
            //    bit-exact 不变）。
            // ★#783 HIGH-1 回归锁（§16 单一决策出口）：`order` 必须是 `standard_p_star` 经
            //   `schedule_order` 的唯一产出——任何账户层投影后的二次裁剪覆盖 `order`（旧 #755
            //   形态：`lee_capped_total` 覆盖不回 𝒦_Θ 可行集）都会在此立即红（debug 构建）。
            debug_assert_eq!(
                order,
                coverage::schedule_order(standard_p_star, p_t, exec_index.unwrap_or(i)),
                "#783 HIGH-1 回归锁：order 必须是 standard_p_star 经 §16 单出口的唯一产出"
            );
            // #71 钩子符号重锚：#69 合流后 PanDiv 的候选准备已移到 step_trace 之前；此处仍是
            // step_gamma/生产 χ 成员/step_trace 三者首次同时在手、且在 PanDiv 最终选址消费前。
            if let Some(dump) = gamma_dump.as_mut() {
                let gamma_opened: Vec<usize> = step_trace
                    .opened
                    .iter()
                    .map(|(candidate, _)| candidate.gamma_index)
                    .collect();
                let dump_path = dump.path().to_path_buf();
                dump.write_step(
                    super::gamma_dump::GammaBarContext {
                        bar: i,
                        gamma_raw: &step_gamma,
                        tower: &tower_i,
                        bars,
                        ext: &ext_i,
                    },
                    super::gamma_dump::GammaChiContext {
                        admitted_indices: &gamma_chi_admitted,
                        opened_indices: &gamma_opened,
                        chi: chi.as_ref(),
                    },
                )
                .unwrap_or_else(|error| {
                    panic!("写入 GammaDump 文件 {} 失败：{error}", dump_path.display())
                });
            }
            // ── #196 阶段 A shadow：组合层裁决点之后并行跑 channel 适配层——只记录分歧，
            //    不改裁决与订单流（零行为变更；分歧报告 env 门控落盘，见主循环后）。
            //    #201：生产事实由 step_trace.verdicts 显式裁决序列单源推导（trace/裁决层统一）。──
            shadow_book.observe_and_compare(
                i,
                &prev_active,
                &step_gamma_trade,
                &entry_v_map,
                gate.force_flat,
                &step_parent_projections,
                &step_trace,
            );
            // ── ★LEE M3 clock_ℓ 事件钟（multi-level-native-execution-design-20260719 §C.2 变化
            //    部分① / §D M3，#644 语义重放自 kimi-nest-mainline）：本 bar 各级事件集。七通道
            //    全部取自**已有**产出（禁第二查法、禁重算结构）：新确认 BSP 走 `classification_step`
            //    （`newly_confirmed_step` 的 append-only diff），腿生命周期五通道走 `step_trace`，
            //    盘整背驰走本 bar 首见并过门的 `pan_levels`（上方 PanDivCert 循环收集）。事件集
            //    的最小完备定义、与 `LevelState` 的逐字段对齐见 `strategy::level_clock` 模块头
            //    ——不在此重复。
            //    ★#644 票面边界：本读数**只读**——不消费 `ticks.ticked_levels()` 去门控任何目标
            //    重估（kimi 侧 `plan_level_gated_order`/`level_order.regate` 不在本票范围，归
            //    #755）。`level_clock_stats.observe` 是纯累计，不改 `order`/`cash`/`units`。
            //    ★#758 issue766 MED-3 订正：两段读数的唯一出口是 `OverlayRunResult`
            //    （`runner.rs::level_clock`/`level_attrib_n_*`），只有 `level_ledger=Some` 的
            //    overlay 臂会把它们接出去；净额臂（`pi_theta_fill_loop`）与声部臂
            //    （`pi_theta_fill_loop_voice`）都以 `level_ledger=None` 调用本函数，产物落进
            //    `RunResult`（无此二字段）逐 bar 白算白丢。门控与 `level_ledger` 同一个 `Option`
            //    信号（M1 段既有纪律），零新增状态位。 ──
            if level_ledger.is_some() {
                let clock_ticks = {
                    use super::super::strategy::level_clock::collect_ticks;
                    let bsp_levels: Vec<u32> = classification_step
                        .levels
                        .iter()
                        .enumerate()
                        .filter(|(_, ls)| !ls.bsp.is_empty())
                        .map(|(lvl, _)| lvl as u32)
                        .collect();
                    let closed_levels: Vec<u32> = step_trace
                        .closed
                        .iter()
                        .map(|(leg, _, _)| leg.level)
                        .collect();
                    let opened_levels: Vec<u32> =
                        step_trace.opened.iter().map(|(_, leg)| leg.level).collect();
                    let silent_levels: Vec<u32> = step_trace
                        .silent_drops
                        .iter()
                        .map(|leg| leg.level)
                        .collect();
                    let overlay_levels: Vec<u32> = step_trace
                        .overlay_closes
                        .iter()
                        .map(|leg| leg.level)
                        .collect();
                    let risk_levels: Vec<u32> =
                        step_trace.risk_exits.iter().map(|leg| leg.level).collect();
                    collect_ticks(
                        &bsp_levels,
                        &closed_levels,
                        &opened_levels,
                        &silent_levels,
                        &overlay_levels,
                        &risk_levels,
                        &pan_levels,
                    )
                };
                level_clock_stats.observe(&clock_ticks);
                // ── ★LEE 归因算子（`strategy::level_attrib::attribute_total`，#644 语义重放）逐 bar
                //    **只读**诊断：把本 bar 已经由生产 M0 路径算出的净额目标 `standard_p_star`
                //    （本读数只读消费，不回写、不改 `order`）按结构基准 `level_nets(sep_legs)` 归因
                //    到各级——纯粹的记账读数，`out` 本身丢弃，只留统计。基准与 M1 镜像 `level_nets`
                //    单源（同 `level_ledger.rs` 文档「M2 归因基准单源」纪律）。 ──
                let lot = config.risk.default_lot.max(1) as i64;
                let basis =
                    super::super::strategy::level_ledger::level_nets(&step_trace.sep_legs, lot);
                let total = standard_p_star.round() as i64;
                let (_out, residual, rescaled) =
                    super::super::strategy::level_attrib::attribute_total(&basis, total);
                level_attrib_n_bars += 1;
                if residual {
                    level_attrib_n_residual_bars += 1;
                }
                if rescaled {
                    level_attrib_n_rescaled_bars += 1;
                }
            }
            // #282（#280 裁定）：门内执行段（select_for_bar 优先级、KΘ 容量/P9 经济减仓
            // 门、pan_div_state.apply 账面写入、signed_live_child_units 净额叠加出口）已随
            // S6 开空腿账面形态删除——门内只余触发链（上方 protocol_events 上轨），
            // 订单轨在门开启臂也不再被子腿叠加改写。
            // ── ★M5 overlay 簿步进（多空对冲.pdf p16 关卡10）：sep_legs=P^sep_{t+1} 目标 → hedge-mode
            //    逐声部账本 → ΔN 订单 + 逐声部 pnl_v 累计。只读旁路（不改净额 fill 的 cash/units/
            //    trade_pnls ⟹ 现有臂 bit-exact）。overlay=None（现有臂）⟹ 整段跳过。 ──
            if let Some(ov) = overlay.as_deref_mut() {
                let ostep = ov.step(
                    &step_trace.sep_legs,
                    px,
                    i,
                    config.risk.default_lot.max(1) as i64,
                );
                // ★ΔN 守恒（验收断言1，PDF p16 `Order_t=N_t−N_{t−1}`）：overlay 订单恒 = 净敞口增量。
                debug_assert_eq!(
                    ostep.order,
                    ostep.net_after - ostep.net_before,
                    "M5 ΔN 守恒违例：order={} ≠ N_t−N_{{t−1}}={}−{}",
                    ostep.order,
                    ostep.net_after,
                    ostep.net_before
                );
            }
            // ── ★LEE M1 级别账本镜像步进（multi-level-native-execution-design-20260719 §D M1，
            //    #644 语义重放）：同一决策点同一 sep_legs 按 id.level≡formation_level 分桶重放
            //    （与 overlay 并列的只读旁路，不改净额 fill 任何状态）。level_ledger=None ⟹
            //    整段跳过（bit-exact 回归锁）。 ──
            if let Some(ll) = level_ledger.as_deref_mut() {
                let lstep = ll.step(
                    &step_trace.sep_legs,
                    px,
                    i,
                    config.risk.default_lot.max(1) as i64,
                );
                // ── #1306 对拍观测：级别账本步进产出（账本面逐 bar 左端读数）。──
                #[cfg(any(test, feature = "backtest_bin"))]
                super::diff_capture::set_level_step(lstep);
                // ★LEE-Net 恒等（M1 验收断言，设计文档 §C.2）：Σ_ℓ net_ℓ 恒 = overlay 净敞口 N——
                // 逐级分解是 Net 的加性细化（整数手数求和，精确成立非 eps 容差）。恒等的验证锚
                // 需要 overlay 同时 Some 才有独立真值可比对；overlay=None 时镜像仍步进（账本本身
                // 自洽），只是本 bar 不产 witness 读数。
                if let Some(ov) = overlay.as_deref() {
                    debug_assert_eq!(
                        lstep.total_net,
                        ov.net(),
                        "LEE-Net 恒等违例（M1 加性细化）：Σ_ℓ net_ℓ={} ≠ N={} @bar{}",
                        lstep.total_net,
                        ov.net(),
                        i
                    );
                    // ★#289 影子评审 MED ① 同款纪律：恒等的 release 非平凡证据——逐决策点累计
                    // max|Σ_ℓ net_ℓ − N| 与 max|N|，release 同样执行；「残差 0 且 max|N|>0」才算
                    // 见证成立。
                    ll.observe_lee_net(ov.net());
                }
            }
            // ── ③'' G4 typed ledger（#134）：消费 StepTrace 腿级生命周期事件。 ──
            // ★#200 次序（先平后开，`A_raw=(A_t∖D_t)∪O_t` 买卖点2 p.6/14 §9）：**关闭消费
            // 循环先于开腿登记循环**——OpenShort 通道的二类「先平后开」在同 bar 同 carrier
            // 上平旧 campaign + 开新 campaign（位置节点身份 = carrier id，A9 generation
            // 单调 +1）；若先 insert 后 remove，新 entry 覆盖旧 entry、关闭循环误删新
            // campaign（typed/账户双轨同错）。故开腿登记移至四个关闭循环之后（下方
            // 「开腿：准入信号腿登记」段）。
            // 反向关闭：typed 裁决消费 trace 第三分量（#145 T1——组合层决策点已经
            // reverse_exit_type 单源判定，本处不补算；登记腿必在 entry_v 映射 ⟹ 裁决非回退值）。
            // ★#209 断言②批次收集：本步一类 × Core 镜像过的 level（批末硬门检查集，
            // 见本循环结束点「断言②终态硬门」段）。★#237：检查集扩为 (level, 批次方向)
            // ——批次方向由被关腿方向单源表达（Exit_v δ(γ)=−σ_v：卖批关 Long、买批关
            // Short），与断言① l.dir 同源同口径。
            let mut t1_core_levels: Vec<(u32, strategy::voice::VoiceSide)> = Vec::new();
            for (leg, trig, exit_type) in &step_trace.closed {
                if let Some(open) = open_trades.remove(&leg.id) {
                    // #145 T1 不变量：登记腿必在本步 entry_v 映射（closed ⊆ prev_active ⊆ 本 bar
                    // 快照 open_trades），组合层裁决非 Ambient 回退值。映射构建与消费之间若未来
                    // 插入 open_trades 突变，此断言先炸而非静默错型。
                    debug_assert!(
                        entry_v_map.contains_key(&leg.id),
                        "#145 T1：trace.closed 腿 {:?} 不在本步 entry_v 映射（裁决为回退值）",
                        leg.id
                    );
                    if open.entry_v == super::super::strategy::coverage::Vertical::ReverseOpen {
                        tw_thread.close_share_leg(); // TW 腿计数（#124）
                    }
                    let pushed = TypedTrade {
                        entry_z: open.entry_z,
                        voice_id: leg.id,
                        entry_bar: open.entry_bar,
                        exit_bar: i,
                        exit_type: *exit_type,
                        entry_px: open.entry_px,
                        exit_px: px,
                        via_structural_prune: false, // 真信号平仓（反向候选触发）
                        position_node_id: open.position_node_id,
                        entry_stop_dist: open.entry_stop_dist, // A6：入场止损距离 d（μ_R 分母）
                        exit_z: super::selector::exit_z_of(open.entry_z, &ext_i), // A7 #165：出场时刻 z 快照
                        units: open.units, // B1 步骤4：腿级 sizing 透传（不进 μ estimand）
                    };
                    // ★opsem-dump：反向关闭外化（trig.bsp_class = 触发候选类）。
                    if let Some(dump) = opsem.as_mut() {
                        dump.mark_exit(i);
                        let _ = dump.write_trade(&pushed, &open, Some(trig.bsp_class));
                    }
                    typed_ledger.push(pushed);
                    // #197/#199：关闭镜像——账户=entry_v×方向（与理由正交）；理由按账户分流
                    // （#199「仅残余才纠错」：核心腿二类 ⟹ 核心残余实测非零（并行视图
                    // balance(Core{level})≠0）才发 CoreResidualCorrection，否则二类不生
                    // 本仓卖单（None 不镜像）；ReverseOpen/Short 腿二类 ⟹ ReverseType2
                    // 合法二类卖；一/三类委托 reason_of_reverse 单源）。
                    // 触发类 1/2/3 外不镜像，与 open 侧 None 口径对称，不伪造理由。
                    let account_id = strategy::account::identity_of(
                        open.entry_v,
                        open.position_node_id.side,
                        leg.id.level,
                    );
                    let core_residual = account_id.is_some_and(|a| account_view.has_residual(a));
                    if let Some(reason) = account_id.and_then(|a| {
                        strategy::account::reason_of_reverse_close(a, trig.bsp_class, core_residual)
                    }) {
                        // ★#209：一类 × Core 镜像 ⟹ 记录 level（批末断言②硬门检查集）。
                        // ★#237：连方向一并记录——批次方向=被关腿方向（与断言① l.dir 同源，
                        // 卖批关 Long 查多侧、买批关 Short 查空侧）。
                        if reason == strategy::account::ActionReason::ReverseType1
                            && matches!(
                                account_id,
                                Some(strategy::account::AccountIdentity::Core { .. })
                            )
                        {
                            t1_core_levels.push((leg.id.level, leg.dir));
                        }
                        account_mirror_close(&mut account_view, &open, leg.id.level, reason, px, i);
                    }
                }
                // 表中无登记（本窗开跑前已持/restore 祖先腿）⟹ 非本窗信号入场，不入 ledger。
            }
            // ★#209 断言②终态硬门（批次边界，用户裁 A 2026-07-23：S7 级别内全平是必须
            // 非应当）：一类批末（该级全部核心腿平仓完）balance(Core{level})==0。检查点 =
            // 反向关闭循环结束、其余关闭/开腿循环之前——一类全平批的多条 AccountOrder
            // 已逐腿 post（每腿恰一，reason=ReverseType1 经 reason_of_reverse_close 单源），
            // 同 bar 开腿镜像尚未发生（#200 次序），此时该级本仓必清零。多腿场景逐笔
            // post 后余额仍含未平同级腿，故硬门不挂单笔粒度（见 account_mirror_post 断言②
            // 注释）。形态 = debug 构建 panic + 违例探针恒在计数（release 可观测），与
            // 断言③同款。历史对照（勿删）：#199 测量态 BTC train 窗实测违例=1。
            // ★#237 按方向拆查（与断言①同源同口径，用户裁 2026-07-24）：一类卖批 ⇒ 查
            // 该级**多侧**分量=0（`balance_side(Core{lv}, Long)`）；一类买批 ⇒ 查**空侧**
            // 分量=0——分侧账禁净额（P_sep：净额 balance 同时掩盖双侧残余，ker N 不可
            // 识别）。顺父级联 Short 腿归空侧（实例键 position.side，#185 映射不动），
            // 卖批下合法存活不计入（#234 Q4.3；m3 (1,470) 误报面的账侧同口径收口）。
            t1_core_levels.sort_unstable_by(|a, b| (a.0, a.1 as u8).cmp(&(b.0, b.1 as u8)));
            t1_core_levels.dedup();
            for (lv, side) in t1_core_levels {
                let bal = account_view
                    .balance_side(strategy::account::AccountIdentity::Core { level: lv }, side);
                if bal != 0.0 {
                    t1_core_residual_probe_bump();
                }
                debug_assert!(
                    bal == 0.0,
                    "#237 断言②终态违例：一类全平批末 balance(Core{{{lv}}} {side:?}侧) = {bal} ≠ 0——S7 级别内全平是必须（按方向拆查）"
                );
            }
            // 静默离场（§13 AncOK 连带剪/Stale prune，无触发信号）：归属判据抽为
            // [`silent_drop_exit_type`]（#198：仅首开反向腿记 CloseReverseOpen，其余归 core structural
            // exit；账户=entry_v×方向经 #197 account 层映射，剪枝理由=via_structural_prune 轴）。
            for leg in &step_trace.silent_drops {
                if let Some(open) = open_trades.remove(&leg.id) {
                    use super::super::strategy::coverage::Vertical;
                    if open.entry_v == Vertical::ReverseOpen {
                        tw_thread.close_share_leg(); // TW 腿计数（#124）
                    }
                    let exit_type = silent_drop_exit_type(open.entry_v);
                    let pushed = TypedTrade {
                        entry_z: open.entry_z,
                        voice_id: leg.id,
                        entry_bar: open.entry_bar,
                        exit_bar: i,
                        exit_type,
                        entry_px: open.entry_px,
                        exit_px: px,
                        via_structural_prune: true, // §13 父驱动连带剪枝，非独立信号（μ 侧可分离）
                        position_node_id: open.position_node_id,
                        entry_stop_dist: open.entry_stop_dist, // A6：入场止损距离 d（μ_R 分母）
                        exit_z: super::selector::exit_z_of(open.entry_z, &ext_i), // A7 #165：出场时刻 z 快照
                        units: open.units, // B1 步骤4：腿级 sizing 透传（不进 μ estimand）
                    };
                    // ★opsem-dump：静默离场外化（无触发候选，trigger_bsp_class=null）。
                    if let Some(dump) = opsem.as_mut() {
                        dump.mark_exit(i);
                        let _ = dump.write_trade(&pushed, &open, None);
                    }
                    typed_ledger.push(pushed);
                    // #197：关闭镜像——§13 结构剪枝（account=entry_v×方向，reason=StructuralPrune，
                    // 正交拆分即 #185 修复 a 的视图层前身：FollowParent 归 Core 账 + 剪枝理由）。
                    account_mirror_close(
                        &mut account_view,
                        &open,
                        leg.id.level,
                        strategy::account::ActionReason::StructuralPrune,
                        px,
                        i,
                    );
                }
            }
            // 风险强平出场（★#594 订正：本桶非只承载 P1）：① #124 P1（PDF §7 C_1 屏蔽
            // P2..P10）force_flat ⟹ prev_active 全部 RiskExit（无触发候选，上游短路清空
            // next_active）；② #572 risk_close_seeds 逐腿 stop（非全局强平）命中的直接父腿——
            // 其子树后代经现役子树机关连坐清除，落 silent_drops 非本桶（见 StepTrace.risk_exits doc）。
            for leg in &step_trace.risk_exits {
                if let Some(open) = open_trades.remove(&leg.id) {
                    if open.entry_v == super::super::strategy::coverage::Vertical::ReverseOpen {
                        tw_thread.close_share_leg();
                    }
                    let pushed = TypedTrade {
                        entry_z: open.entry_z,
                        voice_id: leg.id,
                        entry_bar: open.entry_bar,
                        exit_bar: i,
                        exit_type: super::super::strategy::interp::ExitType::RiskExit,
                        entry_px: open.entry_px,
                        exit_px: px,
                        via_structural_prune: false, // 强平=风险信号平仓，非结构剪枝
                        position_node_id: open.position_node_id,
                        entry_stop_dist: open.entry_stop_dist, // A6：入场止损距离 d（μ_R 分母）
                        exit_z: super::selector::exit_z_of(open.entry_z, &ext_i), // A7 #165：出场时刻 z 快照
                        units: open.units, // B1 步骤4：腿级 sizing 透传（不进 μ estimand）
                    };
                    // ★opsem-dump：强平外化（无触发候选，trigger_bsp_class=null）。
                    if let Some(dump) = opsem.as_mut() {
                        dump.mark_exit(i);
                        let _ = dump.write_trade(&pushed, &open, None);
                    }
                    typed_ledger.push(pushed);
                    // #197：关闭镜像——P1 风险强平逐腿展开为单账户 AccountOrder
                    // （#185 断言5「风险全平展开为多条单账户」的视图层天然形态）。
                    account_mirror_close(
                        &mut account_view,
                        &open,
                        leg.id.level,
                        strategy::account::ActionReason::RiskExit,
                        px,
                        i,
                    );
                }
            }
            // P2 CloseOverlay（#124 裁定4，PDF §7 C_2）：TW StageII 重叠腿关闭——真实订单已经
            // 同一 schedule/fill（组合层合成 close 桶复用 𝒟_x 通道）；typed 归 CloseReverseOpen
            // （关的正是 legacy ReverseOpen 重叠腿，PDF §9 五枚举内最近语义）。
            for leg in &step_trace.overlay_closes {
                if let Some(open) = open_trades.remove(&leg.id) {
                    if open.entry_v == super::super::strategy::coverage::Vertical::ReverseOpen {
                        tw_thread.close_share_leg();
                    }
                    let pushed = TypedTrade {
                        entry_z: open.entry_z,
                        voice_id: leg.id,
                        entry_bar: open.entry_bar,
                        exit_bar: i,
                        exit_type: super::super::strategy::interp::ExitType::CloseReverseOpen,
                        entry_px: open.entry_px,
                        exit_px: px,
                        via_structural_prune: false, // TW 账本谓词驱动的真实平仓，非结构剪枝
                        position_node_id: open.position_node_id,
                        entry_stop_dist: open.entry_stop_dist, // A6：入场止损距离 d（μ_R 分母）
                        exit_z: super::selector::exit_z_of(open.entry_z, &ext_i), // A7 #165：出场时刻 z 快照
                        units: open.units, // B1 步骤4：腿级 sizing 透传（不进 μ estimand）
                    };
                    // ★opsem-dump：P2 overlay 关闭外化（无触发候选，trigger_bsp_class=null）。
                    if let Some(dump) = opsem.as_mut() {
                        dump.mark_exit(i);
                        let _ = dump.write_trade(&pushed, &open, None);
                    }
                    typed_ledger.push(pushed);
                    // #197：关闭镜像——TW StageII 重叠腿关闭（reason=OverlayClose）。
                    account_mirror_close(
                        &mut account_view,
                        &open,
                        leg.id.level,
                        strategy::account::ActionReason::OverlayClose,
                        px,
                        i,
                    );
                }
            }
            // ── #201 阶段 B 裁决账本轨（加轨不减轨）：消费 StepTrace.verdicts 显式 per-voice
            //    裁决序列（含显式 Hold）——每 bar 每解释器裁决域持仓声部恰一枚，schema 冻结
            //    （阶段 C 换内核在本契约上对齐）。只入本轨；不改 typed_ledger/account_view/
            //    opsem/TW 任何既有轨（Hold 无成交，不入 TypedTrade）。──
            for v in &step_trace.verdicts {
                verdict_ledger.push(VoiceVerdictRec {
                    bar: i,
                    leg: v.leg,
                    exit_type: v.exit,
                });
            }
            // 开腿：准入信号腿登记（z 塔真值，与生产 χ 查询同经 z_of_candidate——训练/查询同口径）。
            // A6（#159）：z_of_candidate 内读 c.force（Candidate 透传 BspPoint.force）填 force_state
            // 第 8 维——entry_z（训练）与上方 filter_gamma（查询）同函数同候选 ⟹ 同口径自动成立，
            // fullz 置换 records 的 force_state 自此携真值（一类 A/C 对候选 Some）。
            // ★#200：本循环位于四个关闭消费循环**之后**（先平后开，次序依据见 ③'' 段首注释）。
            for (c, leg) in &step_trace.opened {
                use super::super::strategy::interp::{EntryCertificate, PositionNodeId};
                // ★A9 generation：carrier 首次入场 = 0；close→reopen（表中已有）= 高水位 +1（单调）。
                let generation = match gen_hiwater.get(&leg.id) {
                    Some(&hi) => hi + 1,
                    None => 0,
                };
                gen_hiwater.insert(leg.id, generation);
                let position_node_id = PositionNodeId {
                    carrier: leg.id,
                    entry_certificate: Some(EntryCertificate {
                        level: c.level,
                        source_index: c.source_index,
                    }),
                    side: c.dir,
                    generation,
                };
                // ★A6（prereg-rev2-20260704）：入场结构止损距离 d=|entry_px−stop|（美元，ex-ante）。
                // 决策 bar 因果分类 classification_i 查开腿候选 BspPoint（(level,source_index) 键，与
                // k_theta_risk_gate 止损回查同源 structural_stop），stop_side 由候选方向定。None =
                // structural_stop 返 None（非该方向交易点）/ BspPoint 缺失 ⟹ μ_R 剔除（诚实缺口）。
                // ★族A：入场一次性冻结 structural_stop（Tick）到 LedgerOpen.entry_stop，逐 bar 风控门
                // 读此冻结值（消除旧路径 drifted leg.source_index 回查 ⟹ 静默跳过 stop）。dist 同源导出。
                let entry_stop = entry_structural_stop(c, &classification_i);
                let entry_stop_dist =
                    entry_stop.map(|stop| (px - stop as f64 * config.tick.tick_size).abs());
                // ★#625 发现3 观测（review-625.md 发现3，登记）：入场时结构止损是否已落在
                // 持仓逆侧——纯计数，不动 entry_stop 取值/判定。
                if let Some(stop) = entry_stop {
                    let stop_px = stop as f64 * config.tick.tick_size;
                    match c.dir {
                        strategy::voice::VoiceSide::Long if stop_px >= px => {
                            ENTRY_STOP_REVERSE_PROBE.with(|cell| {
                                let mut p = cell.get();
                                p.long_reverse += 1;
                                cell.set(p);
                            });
                            entry_stop_reverse_dump_row(
                                c,
                                &classification_i,
                                bars,
                                i,
                                exec_index,
                                px,
                                stop,
                                config,
                            );
                        }
                        strategy::voice::VoiceSide::Short if stop_px <= px => {
                            ENTRY_STOP_REVERSE_PROBE.with(|cell| {
                                let mut p = cell.get();
                                p.short_reverse += 1;
                                cell.set(p);
                            });
                            entry_stop_reverse_dump_row(
                                c,
                                &classification_i,
                                bars,
                                i,
                                exec_index,
                                px,
                                stop,
                                config,
                            );
                        }
                        _ => {}
                    }
                }
                // ★B1（步骤4，codex review conditional 修复）：入场 sizing target 快照（开腿当步
                // SepLeg.q_units，含 dir_weight）。sep_legs 经 coverage.rs:2342-2353 filter_map(work.get) 构造 ⟹
                // opened 腿 id 通常在其中，但 filter_map 可跳过 work 不含的 e_idx，理论非 100% 保证。
                // debug_assert 抓测试期不变量违例；release 防御性 0.0（μ 不读 units ⟹ 不破坏 μ；
                // execution 诊断见 0.0 = sizing 信息缺失信号，**非真实 sizing=0**——
                // opsem 的 b1_sizing_available 字段把两种情况在 dump 层分开）。
                let b1_sep = step_trace.sep_legs.iter().find(|s| s.id == leg.id);
                // ★opsem-dump：入场时刻操作语义快照（env-gated，未启用零字段零开销）。
                let opsem_snap = if opsem.is_some() {
                    let (sa_macd, sc_macd, sa_dif, sc_dif, fstate) = match c.force {
                        Some(fp) => (
                            Some(fp.seg_a.macd_area),
                            Some(fp.seg_c.macd_area),
                            Some(fp.seg_a.dif_peak),
                            Some(fp.seg_c.dif_peak),
                            c.force.as_ref().map(|fp| force_state_str(fp.force_state())),
                        ),
                        None => (None, None, None, None, None),
                    };
                    let pid = leg.parent_id.map(|p| (p.level, p.ordinal));
                    // ★L2-P5/P6：真嵌套深度（根=0，沿 parent_id 链；coverage.rs:1559-1567
                    // `element_depth` 同口径——铁律：来自 parent 链，非级别差）。
                    // 链源 = 本步 sep_legs 的 id→parent_id 映射（A_{t+1} 全集，含 registry
                    // restore 注入的祖先）；新开腿自身缺席 sep_legs（D-V-2 情形）时
                    // 仍可从 leg.parent_id 起跳计数，祖先在集合内即得真深度。
                    let voice_tree_depth = {
                        let sep_parent: std::collections::HashMap<_, _> = step_trace
                            .sep_legs
                            .iter()
                            .map(|s| (s.id, s.parent_id))
                            .collect();
                        let mut d: u8 = 0;
                        let mut cur = leg.parent_id;
                        while let Some(pid) = cur {
                            d = d.saturating_add(1);
                            if d >= 16 {
                                break; // 防腐化死循环（常态 depth ≤ max_depth=3）
                            }
                            cur = sep_parent.get(&pid).copied().flatten();
                        }
                        d
                    };
                    if let Some(dump) = opsem.as_mut() {
                        dump.mark_entry(i);
                    }
                    OpsemEntrySnapshot {
                        cand_level: c.level,
                        cand_source_index: c.source_index,
                        cand_bits: c.bits.class_index(),
                        third_class_entry: c.bits.third_class_entry,
                        cand_dir: voice_side_str(c.dir),
                        cand_bsp_class: c.bsp_class,
                        cand_nest_confirmed: c.nest_confirmed,
                        // R5-c：区间套深度（纯结构读数，与生产门 rungs.len() 同口径，不依赖 hist）。
                        nest_depth: super::econ_positive::structural_nest_depth(
                            &tower_i,
                            c.level as usize,
                            c.source_index,
                        ),
                        cand_role: Box::leak(operation_role_str(c.role).into_boxed_str()),
                        seg_a_macd_area: sa_macd,
                        seg_c_macd_area: sc_macd,
                        seg_a_dif_peak: sa_dif,
                        seg_c_dif_peak: sc_dif,
                        force_state: fstate,
                        gamma_count: step_gamma_trade.len(),
                        // ★L1-P1：χ 门是否参与本步过滤（π overlay 生产路径 chi=None ⟹ false）。
                        chi_filter_active: chi.is_some(),
                        // ★L2-P4：B1 sizing 是否成功从 sep_legs 取得（false ⟹ units=0.0 是兜底）。
                        b1_sizing_available: b1_sep.is_some(),
                        voice_tree_depth,
                        // ★L2-P6：该深度实际消费的 w_depth（[0.60,0.30,0.10] 按深度索引，越界 0.0）。
                        w_depth_at_entry: super::super::strategy::voice::depth_weight(
                            voice_tree_depth as u32,
                            &config.voice,
                        ),
                        prev_active_count: prev_active.len(),
                        // R5-a：本步 LexArgmin top-3（step 级，opened 内共享；traced 正常路径填充）。
                        lex_top3: step_trace.lex_top3.clone(),
                        parent_id: pid,
                        t_stage: t_stage_str(tw_thread.tw.stage),
                        eta_bucket: ext_i.eta_bucket.map(eta_bucket_str).unwrap_or("null"),
                        risk_mode: ext_i.risk_mode.map(risk_mode_str).unwrap_or("null"),
                    }
                } else {
                    OpsemEntrySnapshot::default()
                };
                debug_assert!(
                    b1_sep.is_some(),
                    "B1: opened leg {:?} not in step_trace.sep_legs (coverage work.get 跳过？)",
                    leg.id
                );
                let leg_units = b1_sep.map(|s| s.q_units).unwrap_or(0.0);
                open_trades.insert(
                    leg.id,
                    LedgerOpen {
                        entry_bar: i,
                        entry_px: px,
                        entry_stop,
                        entry_stop_dist,
                        // G3：与本 bar χ 查询共用同一 ext_i（训练/查询同口径，共享变量层保证）。
                        entry_z: super::selector::z_of_candidate(c, &tower_i, bars, &ext_i),
                        entry_v: c.role.v,
                        position_node_id,
                        opsem: opsem_snap,
                        units: leg_units,
                    },
                );
                // #197 并行记账视图：开腿镜像（只读旁路，不改净额路径；账户身份 = entry_v × 方向）。
                account_mirror_open(
                    &mut account_view,
                    c,
                    leg.id.level,
                    position_node_id,
                    leg_units,
                    px,
                    i,
                );
            }
            // TW 腿事件（#124）：legacy ReverseOpen 腿开仓驱动 open_legacy_legs 计数（P2 的 H
            // 判据与生产腿同源同步；关侧在上方四个消费循环内经 open.entry_v 判定派
            // CloseShareLeg）。CloseShareLeg(0) 口径声明：净额架构无腿级损益分账 ⟹ profit
            // 口径量 0 承载（cum_net_cash 非承重分量——P2/P3/P4 谓词不消费它；唯一承重 =
            // open_legacy_legs 计数），非簿记伪造。
            // OQ-9 守卫：EarningShares 阶段开 legacy 腿 PDF 定义为非法（is_legal_from）——
            // A' 后该 stage 生产可达（已实现利润入账，见 TW 初始化注释）；达 earning 后此腿
            // 不计 legacy 计数，关侧 legs>=1 守卫对称跳过（合法性语义，非掩盖）。
            for (c, _leg) in &step_trace.opened {
                if c.role.v == super::super::strategy::coverage::Vertical::ReverseOpen {
                    tw_thread.open_share_leg();
                }
            }
            // P3/P4 TWEvent_t（#124 裁定4）：账本推进单点（组合层只读产出事件分量，此处是
            // 生产 π 内唯一的 stage 推进写点——stage_progression 派生事件生产恒合法）。
            if let Some(ev) = step_trace.tw_event {
                tw_thread.on_stage_event(ev);
            }
            // ── ④ 挂单到 exec_index（延迟成交；qty>0 才挂）。 ──
            if order.qty > 0 {
                if let Some(ei) = exec_index {
                    if ei < n {
                        pending[ei].push(order);
                    }
                }
            }
            // ── ★W1 ④-voice 声部挂单（事件驱动，churn 修复）：决策单源 = 本步 step_trace 五类
            //    生命周期事件（与 typed_ledger 消费同源，禁第二裁决源）；无事件 bar 零订单。
            //    sizing 冻结：q_v 取开仓 bar 决策层 SepLeg.q_units（base_units×w_depth×w_dir 已在
            //    coverage 算好，单源复用）取整为手数，落簿后存续期不再随 NAV/价每 bar 重定
            //    （治 runner base_units=equity_nav/px 每 bar 重算导致的声部目标漂移，审计 §4/§5）。
            //    平单先挂、开单后挂：同 bar close→reopen 同 carrier 时 fill 序 = 先平后开
            //    （与 apply_fill 段序同义）；跨 bar 天然按挂单方面时序排列。──
            if voice_enabled {
                if let Some(ei) = exec_index {
                    if ei < n {
                        let lot = config.risk.default_lot.max(1) as i64;
                        for leg in step_trace
                            .closed
                            .iter()
                            .map(|(l, _, _)| l) // 三方合并适配：merged StepTrace.closed 三元化（#145 T1），W1 声部挂单只读腿
                            .chain(step_trace.silent_drops.iter())
                            .chain(step_trace.risk_exits.iter())
                            .chain(step_trace.overlay_closes.iter())
                        {
                            pending_voice[ei].push(VoiceOrder {
                                voice: leg.id,
                                side: leg.dir,
                                qty: 0, // Close = fill 时刻 flatten 簿内该声部全部持仓（执行真值）
                                kind: VoiceOrderKind::Close,
                                exec_index: ei,
                            });
                        }
                        for (c, leg) in &step_trace.opened {
                            // B1 同源快照（typed ledger units 字段同值）：opened 腿在 sep_legs 缺席
                            // （coverage work.get filter_map 跳过）⟹ 0.0 ⟹ q<lot 不开（诚实退化，
                            // 与 B1 release 防御同口径——不伪造 sizing）。
                            let q_units = step_trace
                                .sep_legs
                                .iter()
                                .find(|s| s.id == leg.id)
                                .map(|s| s.q_units)
                                .unwrap_or(0.0);
                            let q = (q_units / lot as f64).round() as i64 * lot;
                            if q >= lot {
                                pending_voice[ei].push(VoiceOrder {
                                    voice: leg.id,
                                    side: c.dir,
                                    qty: q, // ★冻结：开仓时刻快照，存续期不重定
                                    kind: VoiceOrderKind::Open,
                                    exec_index: ei,
                                });
                            }
                        }
                    }
                }
            }
            // ── ⑤ thread 活动集台账（喂下一 bar interpret 闭环）+ persistent registry 合并。 ──
            // ★persistent overlay（anc.pdf §9）：Pi+1 = merge(Pi, Ei+1, held legs)。
            // 用本 bar snapshot（elements）+ held legs（next_active）刷新 registry。
            // 关闭的腿（buckets.close）在 registry 中标记 invalidated（§9 rule 5）。
            {
                // ★工位 4h：caller B gamma-free + candidate 前缀缓存路径（源(b) O(n²) 真修）。merge 只
                // 消费 candidates（不读 gamma/role，codex Q1）⟹ 跳遍历2 + candidate 前缀复用（codex Q2/Q3）。
                let (tree_ref, candidates_ref) = {
                    let _g = classifier::stage_profile::stage("cand_build_merge");
                    interp::coverage_elements_with_tower_cached_gen(
                        &classification_i,
                        &tower_i,
                        &mut tree_cache,
                        &mut cand_cache,
                        Some(tower_gen),
                        Some(forest_epoch),
                    )
                };
                classifier::stage_profile::record_span("cand_count", candidates_ref.len() as u64);
                let cand_dirty = cand_cache.dirty; // ★on2w3：candidates 逐字节变？否 ⟹ merge cand 段跳过。
                                                   // ★工位 4f：双段 merge（消 as_contiguous materialize O(tree) + step 1'/2' tree 全量 O(tree)）。
                                                   // tree_dirty=false（Rc::ptr_eq 命中，tree 同上 bar）⟹ 跳过 tree 段（断言1-3 bit-exact）。
                let tree_dirty = prev_merge_tree
                    .as_ref()
                    .map(|p| !std::rc::Rc::ptr_eq(p, &tree_ref))
                    .unwrap_or(true);
                {
                    let _g = classifier::stage_profile::stage("cand_merge_consume");
                    registry.merge_in_place_split(
                        &tree_ref,
                        tree_dirty,
                        &candidates_ref,
                        cand_dirty,
                        &next_active,
                    );
                }
                prev_merge_tree = Some(tree_ref);
            }
            // ── #1306 对拍观测：⑤ 段末持久注册表长度（状态面右端读数）。──
            #[cfg(any(test, feature = "backtest_bin"))]
            super::diff_capture::set_registry_len(registry.len());
            prev_active = next_active;
        }

        // ── ⑥ 权益曲线（mark-to-market，归一化 ÷nav0）。 ──
        // ★W1：声部臂输出声部账户权益（cash_v + N_derived·px；设计性改变——费用路径不同）；
        //    净额影子权益不进输出（决策层真值源，非本臂账户）。
        let eq_mtm = if voice_enabled {
            let vb = voice_exec.as_deref().expect("voice_enabled ⟹ Some");
            vb.cash() + vb.net_signed() as f64 * px
        } else {
            cash + units * px
        };
        equity_curve.push(eq_mtm / nav0);
        // M6：记录本 bar 有效价供下 bar 价格 PnL 差分（px>0 才更新——untradable/零价 bar 不刷，
        // 避免 Δpx 跨越无效价产生伪价格贡献）。
        if px > 0.0 {
            prev_px = Some(px);
        }
    }

    // ── #196 shadow 分歧报告：门控落盘（默认 None 零 IO，bit-exact 原路径；sidecar 文本，
    //    不进 opsem dump、不进订单轨——run 结束一次性写出）。失败显式 eprintln 而非静默
    //    `.ok()?`（OpsemDump 先例）：分歧报告是本票交付物，落盘失败必须可见——但不中断
    //    回测（shadow 是观测旁路，报告可重跑再生）。──
    if let Some(path) = shadow_divergence_path() {
        if let Err(e) = std::fs::write(&path, shadow_book.render_report()) {
            eprintln!("#196 shadow 分歧报告落盘失败（{path:?}）：{e}");
        }
    }

    // ── 窗口终点强平锚：末可交易 bar 与其收盘价（#289 LOW-1 单源化，#644 语义重放——overlay
    //    与 LEE M1 镜像两处曾逐字重复同一 last_i/last_px 推导，任一侧口径改动会静默漂移。单源
    //    后「同价同 bar」由构造保证，不再靠两段代码碰巧一致）。
    //    ★#758 issue766 LOW-3 登记：单源化把 `(0..n).rev().find(...)` 提到两个
    //    `if let Some(...)` 之外——overlay 与 level_ledger **均为 None**（净额臂/声部臂）时
    //    也会反向扫一遍 `bars` 找末可交易 bar（O(n)，全窗一次，非逐 bar）。与 kimi 原版一致
    //    （kimi `fill.rs:1952` 同款无条件扫描），数值零影响；不为此偏离 kimi 形状，登记备查。 ──
    let forced_flat_anchor = (0..n)
        .rev()
        .find(|&j| !bars[j].untradable && bars[j].close > 0)
        .map(|last_i| (last_i, bars[last_i].close as f64 * config.tick.tick_size));
    // ── ★M5 overlay 窗口终点强平：全部活动声部按末可交易 bar close 离场（记 exit_v/冻结 pnl_v）。
    //    价格 PnL 已在末决策点 step 累计到末价 ⟹ 此处只搬账本行（含浮盈口径，与净额侧同理）。 ──
    if let Some(ov) = overlay.as_deref_mut() {
        if let Some((last_i, last_px)) = forced_flat_anchor {
            ov.force_flat(last_px, last_i);
        }
    }
    // ── ★LEE M1 级别账本镜像窗口终点强平（#644 语义重放）：与 overlay 同价同 bar 按级重排。 ──
    if let Some(ll) = level_ledger.as_deref_mut() {
        if let Some((last_i, last_px)) = forced_flat_anchor {
            ll.force_flat(last_px, last_i);
        }
    }

    // ── 窗口终点强平（含浮盈口径，编排者铁律「不把浮盈算上不合理」）──
    let mut trade_pnls_with_forced = if voice_enabled {
        voice_trade_pnls.clone()
    } else {
        trade_pnls.clone()
    };
    // ★W1：声部臂 final equity 的真值 = cash_v + N_derived·final_px——在下方虚拟兑现（清空
    //    positions）之前捕获 N_derived（cash_v 不被虚拟兑现改动，r_decomp 装配处直读）。
    let voice_end_net: i64 = if voice_enabled {
        voice_exec
            .as_deref()
            .expect("voice_enabled ⟹ Some")
            .net_signed()
    } else {
        0
    };
    if voice_enabled {
        // 声部臂：逐声部强平（虚拟兑现，与净额臂 forced_pnl 同口径——不改现金、不计 fill）；
        // forced pnl 行 + TradeRecord（forced_close=true）按声部产（条数 = 在飞声部数）。
        if let Some(last_bar) = bars.last() {
            let last_px = last_bar.close as f64 * config.tick.tick_size;
            if last_px > 0.0 {
                let exit_bar = n.saturating_sub(1);
                let vb = voice_exec.as_deref_mut().expect("voice_enabled ⟹ Some");
                for cinfo in vb.settle_forced_virtual(last_px, exit_bar, &fees) {
                    trade_pnls_with_forced.push(cinfo.pnl);
                    voice_trades.push(metrics::TradeRecord {
                        entry_bar: cinfo.entry_bar,
                        exit_bar,
                        hold_bars: exit_bar.saturating_sub(cinfo.entry_bar).max(1),
                        qty: cinfo.qty as f64,
                        long: cinfo.long,
                        forced_close: true,
                    });
                }
            }
        }
    } else if units != 0.0 {
        if let Some(last_bar) = bars.last() {
            let last_px = last_bar.close as f64 * config.tick.tick_size;
            if last_px > 0.0 {
                let pos_sign = units.signum();
                let px_exit_net = last_px * (1.0 - pos_sign * fee_rate);
                let forced_pnl = pos_sign * (px_exit_net - entry_cost) * units.abs();
                trade_pnls_with_forced.push(forced_pnl);
                if let Some(entry_bar) = pos_entry_bar.take() {
                    let exit_bar = n.saturating_sub(1);
                    let hold_bars = exit_bar.saturating_sub(entry_bar).max(1);
                    trades.push(metrics::TradeRecord {
                        entry_bar,
                        exit_bar,
                        hold_bars,
                        qty: units.abs(),
                        long: units > 0.0,
                        forced_close: true,
                    });
                }
            }
        }
    }

    // ── G4 typed ledger 窗口终点 censored（PDF §9 P0 Hold）：未离场腿兑现到末可交易 bar
    //    close（与旧 build_mu_from_bars censored 语义/窗口终点强平含浮盈同理，不偷看窗外）。──
    if let Some(last_i) = (0..n)
        .rev()
        .find(|&j| !bars[j].untradable && bars[j].close > 0)
    {
        let last_px = bars[last_i].close as f64 * config.tick.tick_size;
        // 确定序输出（HashMap 迭代序不定 ⟹ 按 (entry_bar, voice_id) 排序，bit-exact 可复现）。
        let mut censored: Vec<(classifier::recursive_tower::ElementId, LedgerOpen)> =
            open_trades.drain().collect();
        censored.sort_by_key(|(id, o)| (o.entry_bar, id.level, id.ordinal));
        for (id, open) in censored {
            let pushed = TypedTrade {
                entry_z: open.entry_z,
                voice_id: id,
                entry_bar: open.entry_bar,
                exit_bar: last_i,
                exit_type: super::super::strategy::interp::ExitType::Hold,
                entry_px: open.entry_px,
                exit_px: last_px,
                via_structural_prune: false, // censored 窗口边界，非结构剪枝
                position_node_id: open.position_node_id,
                entry_stop_dist: open.entry_stop_dist, // A6：入场止损距离 d（μ_R 分母）
                // A7 #165：censored 出场账本态取末决策点 last_ext（末可交易 bar 决策点真值，
                // 与 last_px 兑现价同 bar 口径）；全窗无决策点 ⟹ ZExt::NONE 账本态维诚实 None。
                exit_z: super::selector::exit_z_of(open.entry_z, &last_ext),
                units: open.units, // B1 步骤4：腿级 sizing 透传（不进 μ estimand）
            };
            // ★opsem-dump：censored Hold 外化（无触发候选，trigger_bsp_class=null）。
            if let Some(dump) = opsem.as_mut() {
                dump.mark_exit(last_i);
                let _ = dump.write_trade(&pushed, &open, None);
            }
            typed_ledger.push(pushed);
            // #197：关闭镜像——窗口终点 censored（reason=WindowEnd；末可交易 bar 兑现价）。
            // 口径声明：视图按腿级账本兑现归零；净额路径窗口终点仅追加 PnL、未真实成交归零
            // （#185 存疑区 5）——两口径分叉为 expand 阶段已知差异，修复票消费时须正视。
            account_mirror_close(
                &mut account_view,
                &open,
                id.level,
                strategy::account::ActionReason::WindowEnd,
                last_px,
                last_i,
            );
        }
    }

    // ── M6 R 分解组装（路线.pdf p16 第十一关）+ 账目守恒断言 ──
    // ledger_delta 从**实际账本**（cash/units 经 apply_fill + 成本扣减独立演化）测得的净变动，
    // net_r 从**独立累计器**（cum_price_pnl 在循环顶部按 units·Δpx 累加、cum_fee 由 apply_fill
    // 独立返回、funding/borrow/liq 独立累计）组装——两条独立路径应恒等（守恒），残差 ≈0 是
    // 「资金无泄漏」的物证。final MtM 用 prev_px（末有效价）避免末 bar untradable（px=0）伪归零。
    let final_px = prev_px.unwrap_or(0.0);
    let final_equity_abs = cash + units * final_px;
    let ledger_delta = final_equity_abs - nav0;
    // A10 C5 TW 桥对账行：= ⌊cum_funding+cum_borrow+cum_liq_loss⌋（与循环内 shadow 同一量化
    // 口径——对累计值截断，三项恒 ≥0 ⟹ 截断=⌊⌋）；cost_model=None ⟹ 0（bit-exact）。
    let tw_holding_cost_bridge: i64 = (cum_funding + cum_borrow + cum_liq_loss) as i64;
    // ★W1：声部臂 R 分解换声部账户口径（价格 PnL/费/持仓成本/ledger_delta 全部来自声部簿
    //    与其镜像累计器；守恒断言同一公式同样成立——审计 §7.4 要求）。tw_holding_cost_bridge
    //    行换声部账户自身持仓成本量化（声部账户的 TW 桥对账行；净额影子 TW 账本不受影响）。
    let (r_price, r_fee, r_fund, r_borr, r_liq, r_ledger_delta, r_bridge) = if voice_enabled {
        let vb = voice_exec.as_deref().expect("voice_enabled ⟹ Some");
        let final_equity_v = vb.cash() + voice_end_net as f64 * final_px;
        (
            vb.account_price_pnl(),
            vb.cum_fee(),
            cum_funding_v,
            cum_borrow_v,
            cum_liq_v,
            final_equity_v - nav0,
            (cum_funding_v + cum_borrow_v + cum_liq_v) as i64,
        )
    } else {
        (
            cum_price_pnl,
            cum_fee,
            cum_funding,
            cum_borrow,
            cum_liq_loss,
            ledger_delta,
            tw_holding_cost_bridge,
        )
    };
    let r_decomp = super::super::strategy::risk::RDecomposition::assemble(
        r_price,
        r_fee,
        r_fund,
        r_borr,
        r_liq,
        r_ledger_delta,
        r_bridge,
    );
    // 守恒断言（no-patch-mentality：残差超容差 = 真实资金泄漏 bug，不静默）。容差按名义规模缩放
    // （f64 累加 O(n) 舍入；nav0 量级 + 累计项量级）——绝对容差 max(1e-6, 1e-9·(|nav0|+|price_pnl|)）。
    let cons_tol = 1e-6_f64.max(1e-9 * (nav0.abs() + r_price.abs()));
    debug_assert!(
        r_decomp.conservation_residual.abs() <= cons_tol,
        "M6 R 分解守恒残差 {} 超容差 {}（net_r={} vs ledger_delta={}）——资金泄漏",
        r_decomp.conservation_residual,
        cons_tol,
        r_decomp.net_r,
        r_ledger_delta
    );

    let daily_returns = bar_returns(&equity_curve);
    // ★nest-gate 拒绝率实测落账（实装卡 §3.4-3）：门开启时输出分通道统计（env 纯诊断惯例，
    // 门关闭恒零不输出）。分账口径：cert_none/nest_n_delta_false/xzd_gate_fail = 门实装生效
    // （可修复分量已修）；其中 rungs 空基例放行占比高 = 跨级链稀薄（内禀于塔现状，挂路径 c）。
    // ★#75：增打真链命中/链深构成（准拒分账）+ L2 旧臂对照差 + Xzd 回退；NEST_GATE_INDEX 行
    // 落索引侧链深构成（对照 72.7% 单级基线）与增量喂法成本计数（派生次数/索引重建次数）。
    // ★#94 两行分工（Spec A1 字面错位消除）：NEST_GATE_STATS = 准入判定分账（total/admitted/
    // 分通道准拒——「门放不放行」的账面）；NEST_GATE_CHAIN = 对照读数行。T4 (#173)：CHAIN
    // 行的并集/single comparison shadow 列（typed_found/typed_none/rungs 准拒分账/
    // level_hits/single_multi_divergence）随旧桥退役删除，仅剩 Xzd 回退计数与 L2 旧臂
    // cross 对照（链深构成读数由 NEST_GATE_INDEX 行承担）。
    // ★#94 cross 口径：复用通道（typed 无证 ∧ 旧臂 Xzd 复用，admit≡old_admit by construction）
    // **不计入对照差**（agree/old_pass_new_rej/old_rej_new_pass 仅含两路独立判定），
    // 单独计 reuse 列——剔除自证成分，对照差只反映真链/回退与旧臂的真实分歧。
    if nest_gate_hist.is_some() {
        let s = &nest_gate_stats;
        eprintln!(
            "NEST_GATE_STATS total={} admitted={} rejected={} | nest_pass={} xzd_pass={} | rej: flat_dir={} no_level={} cert_none={} nest_n_delta_false={} xzd_gate_fail={}",
            s.total,
            s.admitted,
            s.total - s.admitted,
            s.nest_pass,
            s.xzd_pass,
            s.rej_flat_dir,
            s.rej_no_level,
            s.rej_cert_none,
            s.rej_nest_n_delta,
            s.rej_xzd_gate,
        );
        eprintln!(
            "NEST_GATE_CHAIN xzd_fallback={} | cross agree={} old_pass_new_rej={} old_rej_new_pass={} reuse={}",
            s.xzd_fallback,
            s.cross_agree,
            s.cross_old_pass_new_rej,
            s.cross_old_rej_new_pass,
            s.cross_reuse,
        );
        // ★T3 (#172) → T5a (#207)：链判定读数行（纯增量新行——NEST_GATE_STATS/CHAIN 行
        // schema 逐字节不动，红线对照直接可比；chain_pass = 链确认读数，wf7 结算面对
        // T3 时代 39 / 并集 17 基线）。T5a：dir_witness_divergence 列随方向见证退役删除
        // （「方向分歧」是非概念，ADR 20260723 裁定 1）。
        eprintln!(
            "NEST_GATE_T3 chain_pass={} chain_reject={}(missing={} broken={}) chain_none={} | top_dist={:?}",
            s.chain_pass,
            s.chain_reject,
            s.chain_reject_missing,
            s.chain_reject_broken,
            s.chain_none,
            s.chain_top_dist,
        );
        if let Some(gate) = &nest_chain_gate {
            let st = gate.index.stats();
            let share = st
                .single_level_share()
                .map(|v| format!("{v:.4}"))
                .unwrap_or_else(|| "na".to_string());
            let events: usize = gate.events_by_level.iter().map(Vec::len).sum();
            eprintln!(
                "NEST_GATE_INDEX events={} events_seen={} base_events={} assembled={} indexed={} rungs_0={} rungs_1={} rungs_2p={} single_level_share={} | derivations={} index_builds={} provider_errors={}",
                events,
                gate.n_events_seen,
                st.base_events,
                st.assembled,
                st.indexed,
                st.rungs_0,
                st.rungs_1,
                st.rungs_2_plus,
                share,
                gate.n_derivations,
                gate.n_index_builds,
                gate.n_provider_errors,
            );
            // ★#214（spec endorsement-failure-instrument-20260724 ID-5）：背书失败原因
            // 测量——纯增量新行，NEST_GATE_STATS/CHAIN/T3/INDEX 行 schema 逐字节冻结
            // （T3 先例）；读数 = 全量计数（v3：无抽样、无概率推断）。两行分工：
            // NEST_GATE_FAIL = Trend 四桶 + owner 子计数 + 点级（类 × owner 判同）二维 +
            // 遍历计数 + Pan 成功/失败总数；NEST_GATE_LEVEL = base/assembled/indexed
            // 按级 × kind 两维分解（行 = 级别槽，列 [Trend, Consolidation]，{:?} 沿用
            // T3 top_dist 先例）。
            // ★#218 面 B（spec owner-attribution-fix-20260724 ID-4，行族 schema 演进随票
            // 登记——#214 新增行族、非冻结红线面）：桶名 owner_start_neq → owner_anchor_neq
            // （判同机制换两族锚）；owner_pts_id_missing → owner_pts_anchor_missing（语义
            // 重定 = 锚不可解）；新增 band_eq_start_neq（带碰撞观察，US-08）与
            // scan_pts 三计数（遍历计数，ID-5 不变量断言集读数）。
            let inst = gate.index.instrument();
            let tp = inst.trend_pts;
            eprintln!(
                "NEST_GATE_FAIL trend={} success={} owner_anchor_neq={} out_of_window={} opposite_side={} no_valid_point={}(book_missing={} book_empty={}) owner_pts_anchor_missing={} owner_pts_real_neq={} band_eq_start_neq={} | pts_eq/total c1={}/{} c2={}/{} c3={}/{} | scan_pts book_total={} in_window={} same_side={} | pan_success={} pan_fail={}",
                inst.trend_total(),
                inst.trend_success,
                inst.trend_owner_anchor_neq,
                inst.trend_out_of_window,
                inst.trend_opposite_side,
                inst.trend_no_valid_point,
                inst.nvp_book_missing,
                inst.nvp_book_empty,
                inst.owner_anchor_missing_pts,
                inst.owner_real_neq_pts,
                inst.band_eq_start_neq_pts,
                tp[0][0], tp[0][0] + tp[0][1],
                tp[1][0], tp[1][0] + tp[1][1],
                tp[2][0], tp[2][0] + tp[2][1],
                inst.scan_book_total,
                inst.scan_in_window,
                inst.scan_in_window_same_side,
                inst.pan_success,
                inst.pan_fail,
            );
            eprintln!(
                "NEST_GATE_LEVEL base_lk={:?} assembled_lk={:?} indexed_lk={:?} | base_trend={} base_pan={}",
                inst.base_by_level_kind,
                inst.assembled_by_level_kind,
                inst.indexed_by_level_kind,
                inst.base_trend(),
                inst.base_consolidation(),
            );
        }
        eprintln!("{}", s.exit_cand_report_line());
    }
    // ★#689 面2 修复：run 结束时把每级别机的累计特批命中/改道快照进 witness——此前这两个数字
    // 只活在 `cl_machines` 内部，报告行完全没接（评审指出的「反向新增失明」）。只读末态计数，
    // 不改任何决策路径、不影响订单流。
    for (lvl, m) in cl_machines.iter().enumerate() {
        let kills = m.historical_bound_kills();
        if kills > 0 {
            campaign_witness
                .historical_bound_kills_by_level
                .insert(lvl as u32, kills);
        }
        let reroutes = m.historical_bound_reroutes();
        if reroutes > 0 {
            campaign_witness
                .historical_bound_reroutes_by_level
                .insert(lvl as u32, reroutes);
        }
    }
    // ── #1306 对拍观测：窗口末持久注册表全量快照（状态面右端终态）。──
    #[cfg(any(test, feature = "backtest_bin"))]
    super::diff_capture::set_final_registry(&registry);
    FillOutput {
        equity_curve,
        daily_returns,
        // ★W1：声部臂输出声部账户口径（平仓 fill 费后已实现/逐声部 TradeRecord/声部 fill
        //    事件数）——设计性改变（审计 §7.4 如实登记），非回归；净额影子对应量不进输出。
        trade_pnls_realized: if voice_enabled {
            voice_trade_pnls
        } else {
            trade_pnls
        },
        trade_pnls_with_forced,
        trades: if voice_enabled { voice_trades } else { trades },
        n_orders: if voice_enabled {
            n_voice_fills
        } else {
            n_orders_executed
        },
        typed_ledger,
        voice_verdicts: verdict_ledger,
        tw_final: Some(tw_thread.finish()),
        r_decomp: Some(r_decomp),
        account_view,
        center_oscillation_actions: osc_actions,
        campaign_book,
        campaign_witness,
        level_clock: level_clock_stats,
        level_attrib_n_bars,
        level_attrib_n_residual_bars,
        level_attrib_n_rescaled_bars,
        // #1208 ①件：turn_class 生产桥运行末态（门关闭 ⟹ None ⟹ 零行为变化）。
        turn_class_rows: nest_chain_gate
            .as_ref()
            .and_then(|gate| gate.turn_class_rows.clone()),
    }
}

/// π fill loop 的完整产出（双口径 trade_pnls + 操作语义随机对照的输入）。
pub(super) struct FillOutput {
    /// 逐 bar 归一化权益曲线（MtM 含浮盈）。
    pub(super) equity_curve: Vec<f64>,
    /// 逐 bar returns（Sharpe/显著性输入）。
    pub(super) daily_returns: Vec<f64>,
    /// 已实现成交盈亏（**不含**窗口终点强平浮盈，§3.4 bootstrap 输入）。
    pub(super) trade_pnls_realized: Vec<f64>,
    /// 含浮盈成交盈亏（窗口终点强平未平仓持仓，编排者铁律「浮盈算上」）。
    pub(super) trade_pnls_with_forced: Vec<f64>,
    /// 交易执行轨迹（[`metrics::TradeRecord`]，含强平笔；随机对照输入）。
    pub(super) trades: Vec<metrics::TradeRecord>,
    /// 执行订单数（n_orders_executed > 0 ⟺ is_l2）。
    pub(super) n_orders: usize,
    /// 腿级 typed 交易 ledger（G4；π 路径 [`pi_theta_fill_loop`] 产出，v1 路径
    /// 已退役 v1 路径无腿级台账 ⟹ 恒空，诚实不伪造）。
    pub(super) typed_ledger: Vec<TypedTrade>,
    /// #201 阶段 B 裁决账本轨：π 路径逐 bar 消费的显式 per-voice 裁决序列（含显式 Hold，
    /// schema 冻结见 [`VoiceVerdictRec`]）；v1/dual 路径无腿级裁决 ⟹ 恒空（诚实不伪造，
    /// 同 `typed_ledger` 先例）。加轨不减轨——不进 μ estimand、不改任何既有轨。
    pub(super) voice_verdicts: Vec<VoiceVerdictRec>,
    /// TW 账本终态（#124 裁定4：TwState 生产真值源在 π fill loop；TStage/ηBucket「生产者已
    /// 就位」的可观测物证——G3 ZExt 桥/诊断消费）。v1 路径无 TW 接线 ⟹ `None`（诚实不伪造）。
    pub(super) tw_final: Option<TwState>,
    /// M6 R 分解表（路线.pdf p16 第十一关：R=ΣN_tΔP_t−Commission−Slippage−Funding−Borrow−
    /// LiquidationLoss + 账目守恒残差）。π 路径 [`pi_theta_fill_loop`] 产出；v1 路径
    /// 已退役 v1 路径未接 R 分解 ⟹ `None`（诚实不伪造）。
    pub(super) r_decomp: Option<super::super::strategy::risk::RDecomposition>,
    /// #197 并行记账视图（expand 只读旁路）：π 路径逐腿镜像开/关生命周期事件过账的
    /// （账户, 级别, 仓位节点）分实例账本；v1/dual 路径无腿级生命周期事件 ⟹ 恒空
    /// （诚实不伪造，同 `typed_ledger` 先例）。不改净额路径任何语义。
    pub(super) account_view: strategy::account::ParallelAccountLedger,
    /// #292（T2 门控接线可见性证据）：逐条「触发→减补动作」记录。π overlay 路径
    /// [`pi_theta_fill_loop_overlay`] 在 `config.center_oscillation.enabled` 时产出；v1/dual
    /// 路径未接线 ⟹ 恒空（诚实不伪造，同 `typed_ledger` 先例）。真实记账是 T3（#293）职责，
    /// 本轨不改任何既有订单/账本语义。
    pub(super) center_oscillation_actions:
        Vec<super::super::strategy::center_oscillation_trade::CenterOscillationActionRecord>,
    /// issue #357（T4/#294 生产实例化）：每重 campaign 账簿终态（★#880 键 = (标的, 操作级别)）
    /// ——π overlay 路径逐 bar `sync_position`/`apply_action` 驱动；v1/dual 路径未接线 ⟹ 恒空账簿
    /// （诚实不伪造，同 `center_oscillation_actions` 先例）。
    pub(super) campaign_book: super::super::strategy::oscillation_campaign::CampaignBook,
    /// issue #357 验收③：enabled=true wf8 产物级见证读数（减补动作归属分桶/`CenterNotAlive`
    /// 丢弃率/挂起归宿/campaign 生死事件）。v1/dual 路径未接线 ⟹ 恒 `default()`。
    pub(super) campaign_witness:
        super::super::strategy::oscillation_campaign::CampaignWiringWitness,
    /// ★LEE M3 `clock_ℓ`（#644 语义重放）：逐 bar 事件钟点只读累计读数（`level_ledger` 参数与
    /// 本读数彼此独立——本读数不需要 `level_ledger=Some` 才产出，逐 bar 无条件计入）。
    pub(super) level_clock: super::super::strategy::level_clock::LevelClockStats,
    /// ★LEE 归因算子（#644 语义重放）逐 bar 只读诊断计数——见 [`super::runner::OverlayRunResult`]
    /// 同名字段文档（单源，不在此重复）。
    pub(super) level_attrib_n_bars: u64,
    pub(super) level_attrib_n_residual_bars: u64,
    pub(super) level_attrib_n_rescaled_bars: u64,
    /// #1208 ①件 turn_class 生产桥出口（`NestChainGate.turn_class_rows` 运行末态快照）：
    /// 索引重建同点投影的稀疏注解行（bar 升序）。`None` = 门关闭或零重建——行缺失 =
    /// 零行为变化（capability guard；`SignalTape.turn_class_rows` 传输位同款口径）。
    pub(super) turn_class_rows: Option<Vec<classifier::TurnClassRow>>,
}

/// voice_qty 同步（fill 后更新；depth 超界跳过，诚实边界不应发生）。
///
/// ★v1 方向中性：`voice_qty` 是该 depth 声部的**绝对持仓手数**（`act_state` 判 open/hold/close
/// 用，与持仓方向解耦——方向由 `HeldVoice.side` 记）。在退役 v1 数据流中 plan_orders
/// 的 build_open_order 产 **Buy（开多）/ Sell（开空）**、build_exit_order 产 **Close（平仓）**——
/// 故 **Buy/Add/Sell = 开仓侧（绝对手数增）**，**Close/Reduce = 平仓侧（绝对手数减）**。
/// 修复前 long-only 把 Sell 当减仓 ⟹ Short 根开空后 voice_qty 恒 0 ⟹ act_state 恒 Open ⟹ 重复
/// 开空不止（v1 缺陷根因之一）。
pub(super) fn apply_voice_fill(voice_qty: &mut [u32], depth: usize, fill: FillOutcome) {
    if let Some(slot) = voice_qty.get_mut(depth) {
        // 订单可“先平后开”，且开仓余量可能因现金不足被拒；声部账必须按两个真实成交段
        // 分别扣/加，绝不能按原始请求量或 action 推断。
        let closed = fill.closed_qty.round().clamp(0.0, u32::MAX as f64) as u32;
        let opened = fill.opened_qty.round().clamp(0.0, u32::MAX as f64) as u32;
        debug_assert!((fill.closed_qty - closed as f64).abs() < 1e-9);
        debug_assert!((fill.opened_qty - opened as f64).abs() < 1e-9);
        *slot = slot.saturating_sub(closed).saturating_add(opened);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  #647 入场结构复检门——生产路径回归测试
// ════════════════════════════════════════════════════════════════════════════
#[cfg(test)]
mod entry_stop_recheck_gate_tests {
    //! 门在**生产 fill 循环**里的判别力：同一场景只改结构止损价的一侧，逆侧候选不得开仓、
    //! 顺侧候选照常开仓（对照臂同时锁住「门没把正常入场也拒掉」与「测试确有判别力」）。
    use super::super::super::types::{Bar, BspBits, Direction, Tick};
    use super::*;
    use classifier::center::UnitRange;
    use classifier::recursive_tower::{ElementId, LeveledMove};
    use classifier::{bsp::BspPoint, Classification, LevelState};
    use std::rc::Rc;

    /// 入场价（tick）：tick_size=1e-8 ⟹ 100.00 美元。
    const PX: Tick = 10_000_000_000;

    fn flat_bar(idx: usize) -> Bar {
        Bar {
            source_index: idx,
            timestamp: idx as i64,
            open: PX,
            high: PX,
            low: PX,
            close: PX,
            volume: 1.0,
            untradable: false,
        }
    }

    /// 一类买点（结构止损 = `pivot_low`）。
    fn buy1_point(source_index: usize, pivot_low: Tick) -> BspPoint {
        BspPoint {
            source_index,
            bits: BspBits {
                buy1: true,
                ..BspBits::default()
            },
            pivot_low,
            pivot_high: 0,
            center: None,
            struct_break_dir: None,
            force: None,
            retrace_breaks_type1: None,
        }
    }

    /// 二类买点（结构止损 = `pivot_low`）。
    fn buy2_point(source_index: usize, pivot_low: Tick) -> BspPoint {
        BspPoint {
            source_index,
            bits: BspBits {
                buy2: true,
                ..BspBits::default()
            },
            pivot_low,
            pivot_high: 0,
            center: None,
            struct_break_dir: None,
            force: None,
            retrace_breaks_type1: None,
        }
    }

    /// 三类买点（结构止损 = `pivot_low`）。
    fn buy3_point(source_index: usize, pivot_low: Tick) -> BspPoint {
        BspPoint {
            source_index,
            bits: BspBits {
                buy3: true,
                ..BspBits::default()
            },
            pivot_low,
            pivot_high: 0,
            center: None,
            struct_break_dir: None,
            force: None,
            retrace_breaks_type1: None,
        }
    }

    /// 单级场景：L0 一段上行走势 + 其右端点上的二类买点（`pivot_low` 由参数给）。
    fn run_with_pivot_low(pivot_low: Tick) -> FillOutput {
        run_with_points(vec![buy2_point(2, pivot_low)])
    }

    /// 单级场景：L0 一段上行走势 + 其右端点上任意组合的买点集合（同一 source_index 上可挂
    /// 多个不同类别的证书——#678 逐例对拍测试用，验证 by_class 分桶与拒单事件一一对应）。
    fn run_with_points(points: Vec<BspPoint>) -> FillOutput {
        let bars: Vec<Bar> = (0..8).map(flat_bar).collect();
        let mv = LeveledMove::from_unit(
            &UnitRange {
                start_index: 0,
                end_index: 2,
                direction: Direction::Up,
                lo: PX,
                hi: PX,
            },
            ElementId {
                level: 0,
                ordinal: 0,
            },
        );
        let cls = Classification {
            levels: vec![LevelState {
                bsp: Rc::new(points),
                ..LevelState::default()
            }],
        };
        let tower: Vec<Rc<Vec<LeveledMove>>> = vec![Rc::new(vec![mv])];
        let config = super::super::super::config::ThetaConfig::default();
        pi_theta_fill_loop(
            move |i| {
                // bar 2 起该买卖点已在因果分类里（首次出现 ⟹ 本 bar 确认 ⟹ 部署）。
                let c = if i >= 2 {
                    cls.clone()
                } else {
                    Classification::default()
                };
                (
                    c,
                    tower.clone(),
                    vec![1],
                    i as u64,
                    i as u64,
                    std::rc::Rc::new(Vec::new()),
                )
            },
            &bars,
            1.0,
            &config,
            None,
        )
    }

    /// 顺侧（`pivot_low` = 90 < 入场价 100）：门不干预，候选照常开仓——对照臂，兼作本测试
    /// 有判别力的证据（若这里也开不出仓，下面的"拒"就是假阳性）。
    #[test]
    fn stop_below_entry_still_opens() {
        entry_stop_recheck_probe_reset();
        let out = run_with_pivot_low(9_000_000_000);
        assert!(
            !out.typed_ledger.is_empty(),
            "顺侧候选（止损 90 在入场价 100 下方）必须照常开仓——否则本测试无判别力"
        );
        assert_eq!(
            entry_stop_recheck_probe_snapshot(),
            EntryStopRecheckProbe::default(),
            "顺侧不应产生任何拒单"
        );
    }

    /// 逆侧（`pivot_low` = 110 > 入场价 100）：结构在决策时点已破 ⟹ 拒单，一笔不开。
    #[test]
    fn stop_above_entry_is_rejected() {
        entry_stop_recheck_probe_reset();
        let out = run_with_pivot_low(11_000_000_000);
        assert!(out.typed_ledger.is_empty(), "逆侧候选必须被拒 ⟹ 零入场");
        let p = entry_stop_recheck_probe_snapshot();
        assert_eq!(p.long_rejected, 1, "多仓侧拒单计数");
        assert_eq!(p.short_rejected, 0);
        assert_eq!(p.by_level_long, vec![1], "分级计数落 level 0");
        assert_eq!(
            p.by_class_long,
            [0, 1, 0],
            "#678 二类买点落 by_class_long 下标1"
        );
        assert_eq!(p.by_class_short, [0, 0, 0]);
    }

    /// #678 逐例对拍：同一 source_index 挂一/二/三类三张证书，全部逆侧 ⟹ 三笔皆拒。
    /// 桶计数须与拒事件逐例一致：`long_rejected`=3，`by_class_long`=[1,1,1]（各类恰一例）。
    #[test]
    fn by_class_bucket_matches_reject_events_one_per_class() {
        entry_stop_recheck_probe_reset();
        let reversed_pivot_low = 11_000_000_000; // 110 > 入场价 100 ⟹ 三张证书皆判逆侧
        let out = run_with_points(vec![
            buy1_point(2, reversed_pivot_low),
            buy2_point(2, reversed_pivot_low),
            buy3_point(2, reversed_pivot_low),
        ]);
        assert!(out.typed_ledger.is_empty(), "三张证书皆逆侧 ⟹ 零入场");
        let p = entry_stop_recheck_probe_snapshot();
        assert_eq!(p.long_rejected, 3, "三张证书逐例皆拒，总数须与桶之和一致");
        assert_eq!(p.short_rejected, 0);
        assert_eq!(
            p.by_class_long.iter().sum::<u64>(),
            p.long_rejected,
            "分类别桶之和须等于该侧拒单总数（逐例对拍不变量）"
        );
        assert_eq!(p.by_class_long, [1, 1, 1], "一/二/三类各恰一例拒单，无串桶");
        assert_eq!(p.by_level_long, vec![3], "三例皆在 level 0");
    }

    /// 边界恰等（`pivot_low` == 入场价）：判逆侧 ⟹ 拒（d=0 且 `stop_hit` 含等号即触及）。
    #[test]
    fn stop_exactly_at_entry_is_rejected() {
        entry_stop_recheck_probe_reset();
        let out = run_with_pivot_low(PX);
        assert!(out.typed_ledger.is_empty(), "恰等口径 = 拒");
        assert_eq!(entry_stop_recheck_probe_snapshot().long_rejected, 1);
    }
}
