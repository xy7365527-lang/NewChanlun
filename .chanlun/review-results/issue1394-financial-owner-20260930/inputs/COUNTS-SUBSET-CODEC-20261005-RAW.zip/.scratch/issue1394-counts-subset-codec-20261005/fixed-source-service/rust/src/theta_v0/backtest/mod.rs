//! Θ v0 回测 harness（Phase 4，task #81）——对接 theta_v0 **冻结接口**的可证伪检验执行层。
//!
//! ## 纲领（docs/backtest-protocol-v0.md）
//!
//! 用 frozen Reference Θ v0（`ThetaConfig::default()`）在 8 个真实 1min 品种上执行
//! **预注册**回测协议。协议在看任何结果前冻结（§0），harness 照跑、不事后改判据。
//!
//! ## 认识论等级（formalization-validity-domain 231号，强制标注）
//!
//! | 组件 | 等级 | 理由 |
//! |------|------|------|
//! | 数据加载/清洗（[`data`]） | **L1** | 管线正确性（读 JSON→量化→bar），零信息增量 |
//! | 指标计算（[`metrics`]） | **L1** | 给定权益曲线算 CAGR/Sharpe/... 是确定性变换，验证算法正确，不验证 Θ |
//! | 管线串联（[`runner`]） | **L1**（管线就绪后） | parse→classify→plan_orders→fill 串通 = 验证管线，不验证 Θ 有效 |
//! | **真实历史数据回测结论** | **L2** | 用真实 OHLC 跑 frozen Θ，扣成本后风险调整收益可被否证（正信息增量） |
//!
//! **关键诚实声明**：harness 框架本身（data+metrics+runner 管线串通）是 **L1**——
//! 合成数据"验证"管线只能确认无 bug，不能确认 Θ 在市场有效（合成数据的独立性验证是
//! 同义反复，231号）。**只有喂真实历史数据跑出的扣成本指标才是 L2**。严禁用合成数据
//! 跑通管线后声称"回测已验证 Θ v0"。
//!
//! ## 现状订正（#744：此前描述的「阻塞点 A/B」已解除，不再是当前架构）
//!
//! `classifier::classify` 产出非空 [`Classification`]（BSP/走势/中枢标签齐全，π 生产路径
//! 的分类前端，`IncrementalClassifier::classify_at` 逐 bar 调）；`strategy::recognize`
//! 仍是存活公开 API（`StrategyFamily::pi` strategy/mod.rs:1070 在调）。**已退役的是 v1
//! *runner***（`run_theta_v0`/`plan_and_fill_mtm`，每 bsp 一 `VoiceDecision`，离散择时；
//! #499 退役，全窗 L3 8/8 已否证）。**生产路径**是 [`runner::run_theta_v0_pi`]/
//! `run_theta_v0_pi_chi`/`run_theta_v0_pi_chi_shrink`——七链 π_Θ 引擎
//! （`coverage::pi_theta_step`），只是生产 π 路径不经 `recognize`，per-bar 三适配器驱动
//! 订单产出，详见该函数组的 doc。
//!
//! ## 子模块拓扑
//!
//! - [`data`]：读 `analysis/data_cache/*.json` → 清洗 → 量化为整数 tick [`Bar`]。
//!   日期窗切片（OOS/Holdout/walk-forward，协议 §2）。**独立于断裂的管线，当前 L1 可验证。**
//! - [`metrics`]：权益曲线 → 协议 §3 全套指标（CAGR/Sharpe/Sortino/MaxDD/Calmar/CVaR/
//!   换手/胜率/盈亏比/费用敏感性）。**独立于引擎，当前 L1 可验证。**
//! - [`runner`]：串联 data→引擎→订单→fill→权益曲线→metrics。管线尾部阻塞于引擎。
//!
//! ## 协议锚点（docs/backtest-protocol-v0.md，冻结）
//!
//! - 数据快照只读（§1.2）；OOS=2023-01-01→2025-06-30，Holdout=2025-07-01→末尾（§2.1）。
//! - 费用基线：commission 1bp/side、slippage 2bp/side、tax 0bp（`ExecConfig::default()`）。
//! - 随机对照 seed=20260625（§4）；失败判据 §5 看结果前冻结。
//!
//! [`Bar`]: super::types::Bar

/// S3 捕获率回测（task #11）：walk-forward OOS，训练窗定 λ_gap、测试窗只读，因果重放入场。
#[cfg(test)]
mod capture_oos;
pub mod data;
pub mod decontam;
/// a3 acc-highlow-power：μ̂(z_L0 | D_hi) 条件化估计量（区间套统计版，694 号；prereg
/// highlow-a3-20260704 冻结）。继承 backtest cfg(test) 门控。
#[cfg(test)]
mod highlow_mu;
pub mod incremental;
pub mod metrics;
pub mod mu_estimator;
pub mod perm_test;
/// S2 段口径复核 + λ_gap 穿越分布（task #10，R3 §4 遗留）。只产报告不定参，L2 描述性。
#[cfg(test)]
mod segment_gn;
/// 逐笔成交数据接入（tick → Bar → 判定链 seam 左半边，issue #973）。与 [`data`] 并列：
/// 逐笔 bar 非等时长，不复用 `bar_seconds`（#971 ③），只复用 `Bar`/`quantize`/判定链。
pub mod tick;
#[cfg(test)]
mod wverify_run;

mod admission;
/// 双账本（hedge-mode 分腿头寸簿，关⑤方案 B）：M14 `P^sep` 账户层兑现——q⁺/q⁻ 分腿
/// 不先净额（M13 父仓保持）+ 嵌入恒等（现行净语义为其子集，D8 逐字节对拍锁）。
pub mod dual_ledger;
mod fill;
mod gamma_dump;
mod ledger;
mod open_ledger;
mod opsem_dump;
mod pan_div;
pub mod pooling_icc;
pub mod prereg_windows;
pub mod runner;
pub mod selector;
mod signal;

/// 经济正条件逐信号分解（《经济正条件.pdf》§5 可捕获价差判据 L2 诊断）。
/// 证明链 L0 见 `.chanlun/proofs/economic-positive-condition-chain.md`；实装设计见
/// `economic-positive-impl-design.md`。非 cfg(test)——backtest_bin feature 下供真实数据 L2 诊断调用。
pub mod econ_positive;

/// Treasury 薄适配层（task #9 S1）：μ 摆动 → `TwEvent::Realize` 费后结算。
/// 账本真值源唯一 = `strategy::ledger::TwState`（#124 裁定4）；本模块零新账本。
/// 计划见 `chanlun/review-results/treasury-execution-plan-20260707.md`。
pub mod treasury;

/// 全窗 L3 定论测试模块（task #75，owner=l3-fullwindow 工位，Lead 登记）。
/// 复现 [`runner`] 的 `l3_falsify_multi_symbol_significance` 但 `cut=全窗`（非 60K 截断），
/// 定论缠论择时 alpha。整个 `backtest` 已被 `#[cfg(test)]` 门控（theta_v0/mod.rs:88），本子模块
/// 继承门控——只在 `cargo test --lib` 编译，不污染 cdylib；integration test（独立 crate）看不到
/// （故全窗测试只能挂此处，见文件头机器坐实 E0433）。
mod l3_fullwindow;

/// Phase-1 可行性探针（pi 七链生产 runner 的 O(n²) substrate 时标 + 信号/交易计数）。
/// 决定 L2/L3 用全窗还是可行子集。继承 backtest cfg(test) 门控。
mod l3_pi_probe;

/// Phase-2 L2/L3 pi 否证（驱动 run_theta_v0_pi 七链生产 runner；双口径门 + 分层诊断）。
/// 镜像 [`l3_fullwindow`] 口径但驱动 pi（非 v1 recognize）；O(n²) 致用可行子集截断窗。
mod l3_pi_falsify;

/// #5 多声部对冲深度贡献根因诊断（231 诊断非 alpha）——instrument 计数区分 (a) ρ漂移剪枝
/// vs (b) 结构不产。O(n²) CL/BTC 32K，继承 backtest cfg(test) 门控。
mod l3_pi_depth_diag;

/// Phase-3 ΔR 净额增量 alpha 否证（task #42 delta-r-alpha）——χ_t 选择器是否产生正净额增量
/// alpha。walk-forward μ（OOS-split）+ ΔR 序列（codex Q2：非两条 equity 的 Sharpe 差）+ 三层
/// 判定（codex Q4：跨品种符号检验）。O(n²) 截断窗，继承 backtest cfg(test) 门控。
mod l3_delta_r_alpha;

/// ★issue #837 探针（map #787，喂 #834）：跨级别反向动作的真实频次 D1/D2/D3。
/// 整模块 `#[cfg(test)]` ⟹ 零生产行为改动；数据源 = 生产 `run_theta_v0_pi_overlay` 的
/// `OverlayRunResult.level_ledger`（LEE M1 只读旁路镜像）+ 生产 `IncrementalClassifier`。
#[cfg(test)]
mod issue837_probe;

/// ★issue #841 探针（map #787，喂 #839）：两张按级别分钱的权重表是不是同一根轴。
/// 整模块 `#[cfg(test)]` ⟹ 零生产行为改动；数据源 = 生产 `extract_carrier_forest`/`leg_target`
/// （结构口径）+ 生产 `run_theta_v0_pi_overlay` 的 `level_ledger`（资金口径）。
#[cfg(test)]
mod issue841_probe;

/// #1306 对拍 harness v1：批量 fill loop 的逐 bar 只读观测 sink（thread_local）。
/// `#[cfg(test)]` 门控扩为 `any(test, feature = "backtest_bin")`（#1308 验收报告器 bin 复用——
/// 未激活 sink 时仅一次 thread_local 布尔检查，默认 cdylib 构建仍不编译）。
#[cfg(any(test, feature = "backtest_bin"))]
mod diff_capture;

/// #1306 对拍 harness v1：回放（stream）vs 批量（fill loop）三面 diff + 预期差机械清单。
/// #1308 第二批：核心对拍引擎（`run_batch`/`run_stream`/`diff`/`DiffReport`）升级为公开 API
/// 供一键验收命令 `theta_accept` 复用（不再只是 `#[cfg(test)]` 单测）。
#[cfg(any(test, feature = "backtest_bin"))]
pub mod theta_pi_diff;

/// #1308 第二批：回放 driver 核心（从 `theta_replay` bin 抽出的可复用半边——排序 dump +
/// env 钉死 + 同输入双跑逐位自检），供 `theta_accept` 与 `theta_replay` 共用同一份回放物证。
#[cfg(any(test, feature = "backtest_bin"))]
pub mod replay_dump;

/// #1317 M1 最终实验：多空双开百分位测量（#1282 预注册判据的同口径移植）——生产引擎
/// 交易流上的 MT19937 bit-exact 随机基线 + 双开腿拆解（`dual_leg_metrics`）。供
/// `theta_m1_dual` bin 复用；模块无市场数据依赖，测试锁对拍 CPython `random.Random`。
#[cfg(any(test, feature = "backtest_bin"))]
pub mod m1_dual;
