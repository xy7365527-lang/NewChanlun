//! 背驰度量（reference-theta-v0.md:34,37）——MACD 辅助 + **A/B/C 趋势/盘整背驰框架**。
//!
//! ## 两层结构（★no-patch：力度原语 + A/B/C 框架层）
//!
//! 本文件分两层，对应缠论背驰的两个语义层（第24课:22-24 + beichi.md v1.1 已结算）：
//!
//! - **力度原语层**（§A）：MACD 段面积比较（`segment_macd_area` / `is_divergence` /
//!   `segments_diverge`）——「后段面积 `<` 前段面积」的纯算术，对齐契约锚
//!   `Origin.Divergence.IsDivergence`（`d.forceC.area < d.forceA.area`，Divergence.lean:83）+
//!   `Origin.ForceInterface.ForceMeasure`（force_conformance 已退役，样板留档见 .chanlun/review-results/）。这是**正确的
//!   力度比较原语**（C段 < A段），被 force_conformance + 次级别背驰（mod.rs）复用，**保留**。
//!
//! - **A/B/C 框架层**（§B，本次新增，消解 grammar-audit 头号缺口）：把力度原语组装为缠论
//!   **趋势背驰 vs 盘整背驰**判定。退化的旧实现只有力度原语，`judge_first` 直接用「任意前
//!   同向段」喂原语——**无 A/B/C 走势分解、无趋势/盘整区分、无 τ 门控**，产假背驰=假买卖点。
//!   本层补上 A/B/C 的精确结构（第24课:22-24）：
//!   · **A/B/C 是走势级别三段**：A=前一离开段、B=中间中枢、C=后一离开段（**不是**次级别 a-b-c，
//!     也不是力度段）。第24课原文:22「同向趋势之间一定有一个盘整或反向趋势连接，把这三段分别
//!     称为 A、B、C 段」。
//!   · **趋势背驰**（[`trend_divergence`]）：走势类型 τ=Trend（≥2 依次同向中枢，reference:34
//!     「同级别趋势≥两同向中枢后」+ maimai.md:105「≥2个依次同向的同级别中枢」）。A=相邻**前
//!     一中枢**的离开段，C=相邻**后一中枢**的离开段（破中枢段）。C段面积 < A段面积 ⟹ 趋势背驰。
//!   · **盘整背驰**（[`consolidation_divergence`]）：τ=Consolidation（恰 1 中枢，zoushi.md:107）。
//!     A、C 是**同一中枢**的两次同向离开段（第24课:34-36 + beichi.md:113）。C < A ⟹ 盘整背驰。
//!   · **τ 门控**：已迁 decompose.rs（task #143 局部趋势门，复用 `center::classify_relation`）——
//!     ≥2 全链同向 → Trend；1 中枢 → Consolidation；mixed/扩张 → 非趋势非盘整（不产第一类）。
//!     第一类买卖点**只由趋势背驰产生**（盘整背驰不产第一类，beichi.md #4 + maimai.md:56 已结算）。
//!
//! ## bit-exact 注意点（★浮点域隔离）
//!
//! MACD 是 v0 的**辅助**度量（结构前提优先）。MACD 浮点运算**隔离在本文件**，按固定
//! 约简顺序计算，**不漏入整数 tick 域**（types.rs 的结构判定全在 i64）。背驰输出是
//! bool（严格变小），bool 无浮点歧义——浮点只在内部面积比较时出现，且用严格 `<`。
//! A/B/C 框架层的中枢关系判定（趋势门控，decompose.rs）在**整数 tick 域**（`center::classify_relation`），
//! 浮点只在力度原语层（面积比较）出现——两域不混。
//!
//! ## MACD(12,26,9) 算法（reference-theta-v0.md:37，固定约简顺序）
//!
//! - `EMA[0] = close[0]`（★首值取首 close，非 SMA 预热）。
//! - `EMA[i] = α*close[i] + (1-α)*EMA[i-1]`，`α = 2/(period+1)`。
//! - `DIF = EMA_fast - EMA_slow`（逐 bar）。
//! - `DEA = EMA(DIF, signal)`，DEA 首值取首 DIF。
//! - `hist = DIF - DEA`（逐 bar）。
//!
//! ## 背驰判据（reference-theta-v0.md:34,37；契约锚 `Origin.Divergence` + `Origin.ForceInterface`）
//!
//! 力度原语「同向段面积**严格**变小才成立，等值不成立」。段面积 = 该段 bar 区间内 `|hist|` 之和。
//! 后一同向段面积 `<` 前一同向段面积 ⟹ 力度衰减（严格 `<`，等值返回 false）。契约锚
//! `Origin.Divergence.IsDivergence`（`d.forceC.area < d.forceA.area`，Divergence.lean:83）。
//! A/B/C 框架层把该原语限定到正确的 A/C 段配对（趋势=跨相邻中枢 / 盘整=同中枢两次离开）。
//!
//! ## 认识论（formalization-validity-domain）
//!
//! MACD 常数从 config 读（fast/slow/signal）。EMA 首值规则 + 面积规则标 `[L3经验待标定]`
//! （reference-theta-v0.md:37）——v0 默认占位，L2/L3 标定不归本工位。本文件证的是
//! 「给定 MACD 参数后 A/B/C 段配对 + 面积比较确定」（**L1** 管线正确性），**不**证「MACD 趋势
//! 背驰预测在真实行情有效」（**L2/L3**，否证检验，不在本工位；alpha 影响须统一 L3 验证）。
//! 趋势/盘整门控判据（中枢同向关系）是 **L0**（纯整数几何，不依赖经验数据）。

use super::super::config::MacdConfig;
#[cfg(test)]
use super::super::types::Stroke;
use super::super::types::{Center, Direction, Segment, Side, Tick};

/// MACD 逐 bar 输出（DIF/DEA/hist，浮点域，隔离在本结构）。
#[derive(Debug, Clone, PartialEq)]
pub struct MacdSeries {
    pub dif: Vec<f64>,
    pub dea: Vec<f64>,
    pub hist: Vec<f64>,
}

/// EMA（首值取首元素，reference-theta-v0.md:37）。
///
/// `out[0]=src[0]`；`out[i]=α*src[i]+(1-α)*out[i-1]`，`α=2/(period+1)`。
/// bit-exact：α 与递推按固定顺序计算（先 `α*src[i]`，再 `(1-α)*prev`，最后相加）。
/// 边界条件：`src` 为空 ⟹ 空序列；`period=0` 在 config 校验层拒绝（此处假设 >=1）。
fn ema(src: &[f64], period: u32) -> Vec<f64> {
    let mut out = Vec::with_capacity(src.len());
    if src.is_empty() {
        return out;
    }
    let alpha = 2.0 / (period as f64 + 1.0);
    out.push(src[0]); // 首值取首元素（非 SMA 预热）。
    for i in 1..src.len() {
        // 固定约简顺序：α*src[i] + (1-α)*prev。
        let prev = out[i - 1];
        let v = alpha * src[i] + (1.0 - alpha) * prev;
        out.push(v);
    }
    out
}

/// 计算 MACD 序列（reference-theta-v0.md:37，固定约简顺序）。
///
/// `closes` 是逐 bar 收盘价（已量化的 tick 转 f64——MACD 在浮点域，但输入来自整数 tick
/// 的确定转换，无额外浮点引入）。返回 DIF/DEA/hist 三序列（等长 = closes 长度）。
pub fn compute_macd(closes: &[f64], cfg: &MacdConfig) -> MacdSeries {
    let ema_fast = ema(closes, cfg.fast);
    let ema_slow = ema(closes, cfg.slow);
    // DIF = EMA_fast - EMA_slow（逐 bar，等长）。
    let dif: Vec<f64> = ema_fast
        .iter()
        .zip(ema_slow.iter())
        .map(|(f, s)| f - s)
        .collect();
    // DEA = EMA(DIF, signal)，首值取首 DIF。
    let dea = ema(&dif, cfg.signal);
    // hist = DIF - DEA。
    let hist: Vec<f64> = dif.iter().zip(dea.iter()).map(|(d, e)| d - e).collect();
    MacdSeries { dif, dea, hist }
}

/// 单 bar MACD 输出（增量 API 用，与 [`MacdSeries`] 同浮点域）。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct MacdPoint {
    pub dif: f64,
    pub dea: f64,
    pub hist: f64,
}

/// MACD 增量递推状态（per-bar substrate O(n²) 根因解法，231号纯性能非 alpha）。
///
/// 携带 EMA_fast / EMA_slow / DEA 三条 EMA 的末值与已处理 bar 数，使每 bar
/// 以 O(1) 延伸而非 O(merged) 全量重算。bit-exact 镜像 [`compute_macd`]：
/// - α = `2.0/(period+1.0)`（与 [`compute_macd`] 内 `ema` 同公式）。
/// - EMA 递推顺序 `alpha*x + (1-alpha)*prev`（与 `ema` 同约简顺序）。
/// - 首值规则：EMA_fast[0]=EMA_slow[0]=close[0]；DIF[0]=0；DEA[0]=首 DIF=0（`ema` 首值取首元素）。
///
/// 边界条件：`bars_processed == 0` 时本状态对应首 bar（init 契约）；
/// `cfg` 的 fast/slow/signal 须 >=1（config 校验层拒绝 0，此处假设）。
/// 认识论：L1（管线 bit-exact 等价于全量版），不携带 alpha 信息——增量只是把同一
/// 浮点约简从「全量重算」改成「逐 bar 延伸」，数值不变（231号：纯性能）。
#[derive(Debug, Clone, PartialEq)]
pub struct MacdState {
    bars_processed: u64,
    ema_fast: f64,
    ema_slow: f64,
    dea: f64,
    alpha_fast: f64,
    alpha_slow: f64,
    alpha_signal: f64,
}

impl MacdState {
    /// 从首 bar 初始化增量状态（镜像 [`compute_macd`] 对 `closes[0..=0]` 的输出）。
    ///
    /// 等价于 `compute_macd(&[first_close], cfg)` 后取末状态。首 bar 输出：
    /// DIF = first_close - first_close = 0；DEA = EMA(DIF, signal) 首值 = 首 DIF = 0；
    /// hist = DIF - DEA = 0。
    pub fn init(first_close: f64, cfg: &MacdConfig) -> Self {
        Self {
            bars_processed: 1,
            ema_fast: first_close,
            ema_slow: first_close,
            dea: 0.0,
            alpha_fast: 2.0 / (cfg.fast as f64 + 1.0),
            alpha_slow: 2.0 / (cfg.slow as f64 + 1.0),
            alpha_signal: 2.0 / (cfg.signal as f64 + 1.0),
        }
    }

    /// 已处理的 bar 数（init 后 =1，每 append +1）。
    pub fn bars_processed(&self) -> u64 {
        self.bars_processed
    }

    /// 当前 bar 的 MACD 输出（由当前状态直接派生，O(1)）。
    ///
    /// DIF = ema_fast - ema_slow；hist = DIF - DEA。与全量版对应位置逐位相等。
    pub fn current_point(&self) -> MacdPoint {
        let dif = self.ema_fast - self.ema_slow;
        MacdPoint {
            dif,
            dea: self.dea,
            hist: dif - self.dea,
        }
    }

    /// 增量延伸一个 bar（O(1)），返回新状态。
    ///
    /// 递推顺序严格镜像全量版：先更新 EMA_fast/slow（得到新 DIF），再用新 DIF
    /// 递推 DEA（signal EMA 的输入是 DIF 序列）。这是 bit-exact 关键——DEA 必须用
    /// **本 bar 的新 DIF** 而非上一 bar 的旧 DIF（全量版 `dea = ema(&dif, signal)` 中
    /// dif/dea 同索引对齐，即 DEA[i] 用 DIF[i] 递推）。
    pub fn append(&self, new_close: f64) -> Self {
        // EMA 递推：alpha*x + (1-alpha)*prev（与 `ema` 同约简顺序）。
        let new_ema_fast = self.alpha_fast * new_close + (1.0 - self.alpha_fast) * self.ema_fast;
        let new_ema_slow = self.alpha_slow * new_close + (1.0 - self.alpha_slow) * self.ema_slow;
        let new_dif = new_ema_fast - new_ema_slow;
        // DEA = EMA(DIF, signal)，本 bar 用新 DIF 递推（全量版同索引对齐）。
        let new_dea = self.alpha_signal * new_dif + (1.0 - self.alpha_signal) * self.dea;
        Self {
            bars_processed: self.bars_processed + 1,
            ema_fast: new_ema_fast,
            ema_slow: new_ema_slow,
            dea: new_dea,
            alpha_fast: self.alpha_fast,
            alpha_slow: self.alpha_slow,
            alpha_signal: self.alpha_signal,
        }
    }
}

/// 增量 MACD API：基于上一状态延伸一个 bar（O(1)），返回新状态。
///
/// `prev` 由 [`MacdState::init`]（首 bar）或上一次本函数的返回值（后续 bar）提供。
/// 每次调用对应一个新 close，返回状态的 [`MacdState::current_point`] 即该 bar 输出。
/// bit-exact：逐 bar append 的输出 == [`compute_macd`](closes) 对应位置（见测试）。
///
/// 这是 per-bar substrate O(n²) 根因之一的全量 MACD 重算的 O(n) 替代——
/// 把每 bar `compute_macd(merged)` 的 O(merged) 降为 O(1) 延伸（231号纯性能）。
pub fn compute_macd_append(prev: &MacdState, new_close: f64) -> MacdState {
    prev.append(new_close)
}

/// 由完整 closes 用增量 API 构造末状态（供 bit-exact 对照与下游接入验证）。
///
/// 从 `MacdState::init(closes[0])` 起，逐 bar `append`，返回末状态。
/// 等价于 `compute_macd(closes)` 的末状态 + 全序列 `current_point` 轨迹。
pub fn macd_state_from_closes(closes: &[f64], cfg: &MacdConfig) -> MacdState {
    let mut state = MacdState::init(closes[0], cfg);
    for &c in &closes[1..] {
        state = state.append(c);
    }
    state
}

/// 同向段 MACD 面积（#988 / #985 裁定一）= 段 bar 区间 `[start,end]` 内**与段方向同色**的 hist 带号和。
///
/// 教义 `060:44`【正文】「力度比较的是下面所有红柱子的面积之和」（向上看红柱 / 向下看绿柱，
/// `024:24`）⟹ 只计入 `sign(hist) == sign(dir)` 的柱，取绝对值累加。旧口径 `Σ|hist|` 把反向柱
/// 计入，数学上是 DEA 的缩放总变差（TV 候选代理，非教义定义 L=Δv 的代理——codex 对抗验证
/// `.chanlun/review-results/force-calculus-codex-adversarial-20260816.md` P4(c)）。
///
/// `[start, end]` 是闭区间 bar 索引。越界（end>=len 或 start>end）⟹ 0.0（空段无面积）。
/// bit-exact：求和按 bar 索引升序累加（固定顺序）。
pub fn segment_macd_area(hist: &[f64], start: usize, end: usize, dir: Direction) -> f64 {
    if start > end || end >= hist.len() {
        return 0.0;
    }
    // 单一实现收敛（#799）：同色和只有 same_color_area 一份；本函数是 Direction 门面。
    // 映射与 segments_diverge_or 同款：Up ⟹ 红柱（Side::Short），Down ⟹ 绿柱（Side::Long）。
    let side = match dir {
        Direction::Up => Side::Short,
        Direction::Down => Side::Long,
    };
    same_color_area(hist, start, end, side)
}

/// 背驰判定（reference-theta-v0.md:37）：后一同向段面积**严格**小于前一同向段。
///
/// `prev_area`/`curr_area` 是两个同向段的 MACD 面积。`curr < prev`（严格 `<`）⟹ 背驰
/// 成立；等值（`curr == prev`）或变大 ⟹ 不成立。等值不成立是 reference-theta-v0.md:37
/// 明确规则（不是浮点容差问题——段面积相等表示力度未衰减，非背驰）。
pub fn is_divergence(prev_area: f64, curr_area: f64) -> bool {
    curr_area < prev_area
}

/// 两段背驰判定（端到端）：从 hist 序列取两同向段面积并比较。
///
/// `prev_seg`/`curr_seg` 是 `(start,end)` 闭区间 bar 索引对。后段面积严格小于前段 ⟹ 力度衰减
/// （力度原语，A/B/C 框架层 §B 用它比较已定位的 A/C 段）。
///
/// ## ★诚实 gap（缠师第17课，编排者 2026-07-01 坐实——识别非实装）
///
/// 缠师第17课原文（017-第17课.md:248/250）：「用均线或 MACD 看背驰都是**辅助性**的，都不是最
/// 重要的」「没有 MACD 就判断不了背驰？显然不是。**那只是辅助**」。背驰的**定义**是「两相邻同向
/// 趋势间后者比前者的**走势力度**减弱」——**走势力度**才是判据，MACD 面积只是一个 proxy。
///
/// 本实装的背驰**仅由 MACD 段面积**判定（`segment_macd_area` = Σ|hist|），**无独立的走势力度
/// 判据**（价格振幅/速度/成交量力度等）。已退役 force_conformance（留档）的 `ForceMeasure.strength` 亦只
/// 包 MACD area（见其模块头 L2 未验证声明）。这是比 P2 veto **更根本的简化**：辅助指标（MACD）
/// 被当成了背驰的**唯一判据**，与缠师原文相悖（同构：区间套同一性证书零调用、简化被当完整）。
///
/// ponytail: MACD-area-only 力度判据，真走势力度（振幅/速度/量能，第17课定义）留待后续大工程；
/// 本 gap 已诚实标注（编排者裁定：识别并标注，不顺手实装）。升级路径 = ForceMeasure 增非-MACD
/// strength 实例（价格振幅/速度），MACD area 降为多 proxy 之一，与 P2「MACD 降 feature」同精神。
pub fn segments_diverge(
    hist: &[f64],
    prev_seg: (usize, usize),
    curr_seg: (usize, usize),
    dir: Direction,
) -> bool {
    let prev_area = segment_macd_area(hist, prev_seg.0, prev_seg.1, dir);
    let curr_area = segment_macd_area(hist, curr_seg.0, curr_seg.1, dir);
    is_divergence(prev_area, curr_area)
}

// ═══════════════════════════════════════════════════════════════════════════
// § A3. 力度或关系原语（2026-07-17 代理裁定 R1/R2，p112/p113 实证 + doc-pan §2/doc-trend §3）
//
// 教义锚：027:32「只要其中一个符合就可以是一个背弛的信号」、026:521「两个只要出现一个就要
// 注意」、025:38「黄白线不能创新高，**或者**柱子的面积**或者**伸长的高度」——面积/黄白线/柱高
// 三信号以『或者』并联，面积单通道必要门窄于原文（doc-pan §2.2 推理 4）。面积口径本身取
// **同色柱**（060:44「力度比较的是下面所有红柱子的面积之和」、057:40、024:40），混合柱 Σ|hist|
// 把反向柱计入是 060:44 之外的人为加严（p113 §2.3 turn=739707 标本）。
// ═══════════════════════════════════════════════════════════════════════════

/// 同色柱面积（060:44/057:40/024:40『全部同色柱子面积之和』）。
///
/// `side` = 离开方向候选：Long=向下离开 ⟹ 绿柱（hist<0）绝对值和；Short=向上离开 ⟹ 红柱
/// （hist>0）和。`[lo,hi]` 闭区间 close 下标；越界/空 ⟹ 0.0。
/// bit-exact：按 bar 升序累加（固定顺序），与 p113 探针 `same_color_area` 逐行同构。
pub fn same_color_area(hist: &[f64], lo: usize, hi: usize, side: Side) -> f64 {
    if lo > hi || hi >= hist.len() {
        return 0.0;
    }
    let mut area = 0.0;
    for &h in &hist[lo..=hi] {
        match side {
            Side::Long if h < 0.0 => area += h.abs(),
            Side::Short if h > 0.0 => area += h,
            _ => {}
        }
    }
    area
}

/// 同向柱峰（025:16/025:38『柱子伸长的高度』）。
///
/// Long（向下离开）⟹ 段内最深绿柱 |min|（无绿柱 ⟹ 0.0）；Short（向上离开）⟹ 最高红柱 max
/// （无红柱 ⟹ 0.0）。与 p113 探针 `same_dir_hist_peak` 逐行同构。
pub fn same_dir_hist_peak(hist: &[f64], lo: usize, hi: usize, side: Side) -> f64 {
    if lo > hi || hi >= hist.len() {
        return 0.0;
    }
    match side {
        Side::Long => hist[lo..=hi]
            .iter()
            .copied()
            .fold(f64::INFINITY, f64::min)
            .min(0.0)
            .abs(),
        Side::Short => hist[lo..=hi]
            .iter()
            .copied()
            .fold(f64::NEG_INFINITY, f64::max)
            .max(0.0),
    }
}

/// 力度或关系（027:32/026:521/025:38）：同色面积 C<A ∨ 黄白线峰 C<A ∨ 同向柱峰 C<A。
///
/// 三信号任一成立即『背弛的信号』（027:32「两个都满足就更标准了」——单信号即充分）。严格 `<`，
/// 等值不算衰减（与 `is_divergence` 同口径）。`a_idx`/`c_idx` 是 A/C 段的 close 下标闭区间
/// （`map_src_to_close_idx` 同源映射）。side ⟷ direction 对应：Long=向下离开（DIF 取负峰）。
pub fn segments_diverge_or(
    hist: &[f64],
    dif: &[f64],
    side: Side,
    a_idx: (usize, usize),
    c_idx: (usize, usize),
) -> bool {
    let dir = match side {
        Side::Long => Direction::Down,
        Side::Short => Direction::Up,
    };
    same_color_area(hist, c_idx.0, c_idx.1, side) < same_color_area(hist, a_idx.0, a_idx.1, side)
        || segment_dif_peak(dif, c_idx.0, c_idx.1, dir)
            < segment_dif_peak(dif, a_idx.0, a_idx.1, dir)
        || same_dir_hist_peak(hist, c_idx.0, c_idx.1, side)
            < same_dir_hist_peak(hist, a_idx.0, a_idx.1, side)
}

/// 黄白线回拉 0 轴（025:761/024:24，p112 主口径 cross_dif）：`[lo,hi]` 闭区间 close 下标内
/// 存在 DIF 触 0（`dif[t] == 0.0`）或相邻 bar 变号（`dif[t]*dif[t-1] < 0`）。越界 ⟹ false
/// （025:761：回拉不可验 ⟹ 「在该级别就不存在什么背驰」，诚实判负）。
pub fn dif_crosses_zero(dif: &[f64], lo: usize, hi: usize) -> bool {
    if lo > hi || hi >= dif.len() {
        return false;
    }
    for t in lo..=hi {
        if dif[t] == 0.0 || (t > lo && dif[t] * dif[t - 1] < 0.0) {
            return true;
        }
    }
    false
}

// ═══════════════════════════════════════════════════════════════════════════
// § A2. 多力度原语 + Weak_Θ 词典序（P2 方案A §4/§7 改点5；第17课「黄白线主，面积次」+ 第34课）
//
// ★存在论位置（p2-plan §4 + codex-review-20260701-2251 护栏3/6）：这些是**力度原语层**——
// 供 **selector 层** Weak_Θ 力度门消费的多 proxy（DIF/价格振幅/速度），**不下沉 buy1 定义层**
// （buy1 判据仍 `segments_diverge`=MACD 面积，class_index 语义冻结，护栏3）。DIF 逻辑移植 rust
// 顶层旧引擎 `src/divergence.rs`（dif_peak/T6），坐标系改为 theta_v0 的 `dif` 序列 + 段闭区间。
//
// ★认识论（formalization-validity-domain 231号，强制）：
// - **L1**：原语接口正确性（给定 dif/closes 求峰值/振幅/速度是确定性算术，逐例可验）。
// - **L2/L3**：「哪个 mode 有 alpha / 词典序优于单 MACD」需三套 OOS（MACD/Force/LEX），
//   **本层不声明**，留 W-VERIFY（#23）。weak_theta 只提供判定纯函数，不声明择时有效性。
//
// ★有效域边界更新（A6 #159 后）：R2 时代「Candidate 无段 close 序列 ⟹ 算不了振幅/速度 ⟹ 不造
// 死字段」的前提已被两步解除——#115 在 `BspPoint.force` 收进 signal 抽取层算好的 A/C 段 5 proxy
// （单一来源），A6（#159）令 `Candidate.force` 纯透传该值进 gamma 组装 ⟹ z 装配点
// （`selector::z_of_candidate`）读 `c.force` 填 `force_state` 第 8 维（统计层与生产 π fill loop
// 同经此路，无死字段）。
//
// ★A3（#164）接入定位（671号纠正——原注误指 filter_gamma）：Weak 力度判据的 canonical 归属是
// **judge 的参数化 D 判定**（`DivergenceGauge`，一类买卖点.pdf p10 §9.3 `Type1Cand` 第5条
// `Weak(s,A)=1` 的实装点），**不是 `filter_gamma` 的力度 veto 门**。671号已结算：力度=**feature**
// （`force_state` 第 8 维进 χ 的 z），**不作 selector 一票否决**——P2-R2/671 消除了「MACD C≥A 预删」
// 选择偏差，在 selector 加硬力度门会重引入同一偏差。故 A3 的 Weak 非-MACD 化落点：
//   · A2（#163）：`ThetaDom`（Θ_DOM 支配序）已接 judge；
//   · A3（#164）：`ThetaLex`（Θ_LEX 词典序，`weak_theta(Lex)` 唯一生产消费者）接 judge——
//     `weak_theta`/`WeakThetaMode` 原语自此**非死代码**（confirm_divergence ThetaLex 分支消费）。
// 诚实声明：原语 ✓，透传 ✓（A6），judge Θ_DOM ✓（A2），judge Θ_LEX ✓（A3）；𝒜_ℓ 第6成员
// SubMovePower 仍缺（见 `ForceStateA5` 头，数据源未达 signal 抽取层，诚实缺口）。
// ═══════════════════════════════════════════════════════════════════════════

/// 段力度多 proxy（P2 §6 selector 状态 z 的力度分量：MACD 面积 / DIF 峰值 / 价格振幅 / 速度）。
///
/// 三 proxy 对应第17课「黄白线（DIF）最重要，面积次之」+ 价格振幅/速度（走势力度的直接度量，
/// 非 MACD proxy）。由 [`force_features`] 从段区间算出，供 [`weak_theta`] 词典序比较。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ForceFeatures {
    /// MACD 段面积 = Σ|hist|（力度原语，`segment_macd_area`）。
    pub macd_area: f64,
    /// DIF 段峰值绝对值（黄白线主判据，第17课「黄白线最重要」；移植旧引擎 dif_peak）。
    pub dif_peak: f64,
    /// 价格振幅 |端价差|（L0 整数 tick，走势力度直接度量，非 MACD proxy）。
    pub price_amplitude: i64,
    /// 价格速度 |端价差|/Δbar（f64，单位时间价格变动）。
    pub price_speed: f64,
    // #994：tv（全变差）字段已处决删除——出处与依据见 beichi.md v1.7。
}

/// A/C 段力度 proxy 对（趋势背驰的两段并置——`Weak_Θ(seg_a, seg_c)` 用它比较）。
///
/// 一类候选（趋势背驰）由 A 段（倒数第二中枢离开）+ C 段（破最后中枢）配对，每段一个
/// [`ForceFeatures`]。这是 selector Weak_Θ 力度门 / 离线多 proxy 交叉验证（W-VERIFY #13）的输入。
/// **认识论 L1**：段坐标→proxy 是确定性算术；「哪个 proxy 有 alpha」是 L2/L3（本层不声明）。
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ForceProxies {
    /// A 段（前趋势离开段）力度。
    pub seg_a: ForceFeatures,
    /// C 段（破最后中枢段）力度。
    pub seg_c: ForceFeatures,
}

/// 力度支配态（`关于背驰.pdf` §9.1 `ForceState`，5-proxy 近似 = `ForceStateA5`）。
///
/// 支配序四态（§5-6 p6 `s ≺_𝒜 s'`）：C 段（后离开段）相对 A 段（前离开段）在允许力度族
/// 𝒜₅={macd_area, dif_peak, price_amplitude, price_speed, tv} 上的支配关系。**背驰 = C 力度衰减 =
/// `Dominated`**（C 在全部 5 proxy 上 ≤ A 且至少一个 <）。
///
/// **命名（beta-bucket-design v2 §2.3 / codex-beta ② / q3 D-1 残余）**：`A5` 后缀诚实标注现有
/// 5 proxy——TV（全变差）已并入本口径族；原文完整 𝒜_ℓ 仍缺递归次级别力度 SubMovePower
/// （Σ_{次级别同向段} m_{ℓ-1}(u)），其数据源未达 signal 抽取层（signal.rs 只有 hist/dif/closes，
/// 无塔次级别段），登记诚实缺口——裁定见 codex-a4-force-20260704.md。补齐后可升名 `ForceState`。
/// 单调性：补维只会把 `Dominated`/`Dominates`/`Tie` 变 `Incomparable`（新增口径可能冲突），反向
/// 不会 ⟹ `ForceStateA5` 的 `Dominated` 是完整支配序 `Dominated` 的**超集（宽判背驰）**。
///
/// **认识论 L1**：给定 A/C ForceFeatures 求支配态是确定性算术（管线正确性）。「哪个态有 alpha」=L2/L3。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum ForceStateA5 {
    /// C 在全部 5 proxy 上 ≤ A 且至少一个 <——**确定背驰**（C 力度衰减）。
    Dominated,
    /// C 在全部 5 proxy 上 ≥ A 且至少一个 >——确定力度延续（非背驰）。
    Dominates,
    /// C 与 A 全部 5 proxy 相等。
    Tie,
    /// 口径冲突（部分 proxy C<A、部分 C>A）——**不作背驰确认**（codex-beta ②）。
    Incomparable,
}

impl ForceProxies {
    /// 𝒜₅ 支配序比较（唯一支配序原语，beta-bucket-design v2 §6 路由 ⑤——不在别处重算）。
    ///
    /// 逐 proxy 比较 C(`seg_c`) vs A(`seg_a`)：任一 proxy `c<a` 记 weaker，`c>a` 记 stronger。
    /// 全 ≤ 且有 weaker ⟹ `Dominated`；全 ≥ 且有 stronger ⟹ `Dominates`；全等 ⟹ `Tie`；
    /// 既有 weaker 又有 stronger ⟹ `Incomparable`。price_amplitude/tv 是 i64，其余 f64（严格
    /// `<`/`>`，与 `is_divergence` 同「等值不算衰减」口径）。
    pub fn force_state(&self) -> ForceStateA5 {
        let (a, c) = (&self.seg_a, &self.seg_c);
        // 四 proxy 的 (c<a, c>a) 布尔对（#994：TV 第 5 维已处决——非缠师概念，
        // 关于背驰.pdf 𝒜_ℓ 兜底被 #873 精确定义取代；枚举名 A5 保留不改，
        // 值域=4-proxy 支配序）。
        let cmps = [
            (c.macd_area < a.macd_area, c.macd_area > a.macd_area),
            (c.dif_peak < a.dif_peak, c.dif_peak > a.dif_peak),
            (
                c.price_amplitude < a.price_amplitude,
                c.price_amplitude > a.price_amplitude,
            ),
            (c.price_speed < a.price_speed, c.price_speed > a.price_speed),
        ];
        let weaker = cmps.iter().any(|&(lt, _)| lt);
        let stronger = cmps.iter().any(|&(_, gt)| gt);
        match (weaker, stronger) {
            (true, false) => ForceStateA5::Dominated,
            (false, true) => ForceStateA5::Dominates,
            (false, false) => ForceStateA5::Tie,
            (true, true) => ForceStateA5::Incomparable,
        }
    }

    /// Θ_SCORE 归一化力度标量（prereg-a2-thetadom-oos-20260704 冻结：m=dif_peak，第17课黄白线主）。
    ///
    /// `β_norm = (m_A − m_C) / (m_A + m_C) ∈ [−1,1]`——归一化差非比值（有界、对称、避免 m_A→0
    /// 爆炸，beta-bucket-design v2 §4.2）。`β_norm > 0` = C 弱于 A（背驰域）。dif_peak 恒 ≥0
    /// （`segment_dif_peak` 取绝对峰）⟹ 分母 ≥0；双零（A/C 均无 DIF 峰）⟹ 无力度可比 ⟹ 0.0
    /// （非背驰，prereg 冻结口径）。
    pub fn theta_score(&self) -> f64 {
        let (m_a, m_c) = (self.seg_a.dif_peak, self.seg_c.dif_peak);
        let denom = m_a + m_c;
        if denom == 0.0 {
            return 0.0;
        }
        (m_a - m_c) / denom
    }
}

/// Θ_SCORE K=3 分箱（prereg-a2-thetadom-oos-20260704 冻结边界 { ≤0: 非背驰, (0,0.33): 弱, ≥0.33: 强 }，
/// 边界不得事后调——beta-bucket-design v2 §4.2「每个边界都是一个 Θ 选择」）。
///
/// 角色（§4.3 方案 B）：分层键候选，**不是判定口径**（三判定口径见 [`DivergenceGauge`]）——
/// 分层键接入点在 mu_estimator/ResidualTrade（并发工位域），本层只提供原语；接入前是诚实
/// 未消费原语（prereg 已登记），非死字段冒充。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ThetaScoreBin {
    /// `β_norm ≤ 0`：C 力度不弱于 A（非背驰）。
    NonDivergent,
    /// `0 < β_norm < 0.33`：弱背驰。
    Weak,
    /// `β_norm ≥ 0.33`：强背驰。
    Strong,
}

/// `β_norm` → K=3 箱（冻结边界 0 / 0.33，见 [`ThetaScoreBin`]）。
pub fn theta_score_bin(beta_norm: f64) -> ThetaScoreBin {
    if beta_norm <= 0.0 {
        ThetaScoreBin::NonDivergent
    } else if beta_norm < 0.33 {
        ThetaScoreBin::Weak
    } else {
        ThetaScoreBin::Strong
    }
}

/// 趋势背驰 D 的判定口径开关（A2 #163 + A3 #164，关于背驰.pdf §9.2 三套 Θ 预注册）。
///
/// D = 一类买卖点 buy1/sell1 的背驰确认谓词（`judge_first_cached` 的 `below_last_center` 源）——
/// 即 `一类买卖点.pdf` p10 §9.3 `Type1Cand` 第 5 条 `Weak(s, A) = 1` 的实装点。p6 明文「`Weak`
/// should be defined by a **force measure**, not only MACD area」——本开关正是把 Weak 从「仅 MACD
/// 面积」升级为**力度签名合规判定**（关于背驰.pdf §5「支配序，而不是单一指标」）的承载。
/// 默认 [`MacdArea`](DivergenceGauge::MacdArea)（现行冻结判据，bit-exact 不变）——判定口径变更
/// 改变信号集合（⟹ ledger ⟹ 残差样本），属预注册敏感，**显式配置才切换，不默认**。
///
/// **Weak 的 canonical 归属在 judge（本开关），非 selector 力度 veto**（671号已结算）：力度作为
/// **feature**（`force_state` 第 8 维，#159 已透传进 χ 的 z），**不作 `filter_gamma` 一票否决**——
/// P2-R2/671 消除了「MACD C≥A 预删」选择偏差，再在 selector 加硬力度门会重引入同一偏差。故
/// Weak 力度判据的接入点是**参数化 D 判定**（本 gauge），与 A2 的 `ThetaDom` 同款模式。
///
/// 有效域（诚实边界）：只作用于趋势背驰 D（一类）。盘整背驰证书（`judge_pan_div`）、二类
/// `divergence_of` 不在本开关范围。
/// ★#883 起扩大一处：区间套下钻判据 `cand_predicate::div_cand`（含其 #814 D-3 盘整背驰入口）
/// 的条件4 亦经本 gauge（`confirm_divergence_l`）——同一判据原语，禁第二套力度引擎（#979
/// 裁定二）；生产默认 ForceL，`MacdArea` 为显式对照档。
///
/// 关于背驰.pdf §9.2 三套预注册 Θ ↔ 本枚举：`Θ_DOM`=[`ThetaDom`](DivergenceGauge::ThetaDom)、
/// `Θ_LEX`=[`ThetaLex`](DivergenceGauge::ThetaLex)、`Θ_SCORE`=分层键候选（[`ForceProxies::theta_score`]，
/// 非判定口径）。三套「分别 OOS 回测，不能先看结果再选」——见 `wverify_run::thetadom_three_gauge_oos`。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum DivergenceGauge {
    /// ★#990 I-2（G2 #978 裁定三）：**教义判据（默认）**——`L(C) < L(B)`，
    /// `L(段) = v(末笔) − v(首笔)`（#873，beichi.md v1.6），段→笔经 `stroke_span_of_segment`
    /// 反查（#989）。无 strokes 数据 ⟹ 该点不判背驰（不冒充）。
    #[default]
    ForceL,
    /// G1 对照基线（**降为非默认对照档**，ADR-0005 对照臂）：`Area(C) < Area(A)`
    /// （`segments_diverge` 同色口径）。显式 config 激活才进判定。
    MacdArea,
    /// G2 `Θ_DOM`：`ForceStateA5(C,A) == Dominated`（𝒜₅ 全支配衰减，A5 amended 口径）。
    ThetaDom,
    /// G3 Conjunction：G1 ∧ G2（MACD 面积衰减 ∧ 全支配序衰减）。
    Conjunction,
    /// G4 `Θ_LEX`（关于背驰.pdf §9.2「结构 > DIF > 面积」词典序）：级别内 `weak_theta(Lex)` —
    /// DIF 主判据（第17课黄白线最重要），DIF 不可判（相等）退面积次判据。**「结构」层（级别）
    /// 由 selector 级别分桶承载**（护栏3：`weak_theta` 是同级别内的力度词典序，MuClass.level 承载
    /// 级别元门），故 gauge 内 lex 退化为「DIF ▷ 面积」两层——与 [`WeakThetaMode::Lex`] 一致。
    ThetaLex,
}

/// 四口径 D 判定（单一判定点——`judge_first_cached` 唯一消费者，不在别处重算组合逻辑）。
///
/// `macd_c_lt_a` = G1 原语结果（`AbcDivergence::diverges`，调用方已算——G1/G3 复用，不重算面积）；
/// `force` = A/C 段 5 proxy（`BspPoint.force` 同源）。ThetaDom/ThetaLex/Conjunction 下 `force=None`
/// （dif/closes 无源，旧测试/合成入口）⟹ **false**（无 5-proxy 无背驰确认——诚实不判，
/// 不 fallback 回 MACD 口径；no-workaround：口径混用=两种矛盾理解都能通过）。
///
/// ThetaLex 语义：`weak_theta(Lex, seg_a, seg_c)` = C 段（后离开段）力度**词典序严格小于** A 段
/// （背驰=力度衰减，`ForceProxies.seg_a`=前段A / `seg_c`=后段C，与 `Weak(C,A)=1` 逐字对齐）。
///
/// 认识论 L1：给定原语结果求 D 是确定性布尔。「哪个口径有 alpha」= L2/L3（四口径 OOS，本函数不声明）。
pub fn confirm_divergence(
    gauge: DivergenceGauge,
    macd_c_lt_a: bool,
    force: Option<&ForceProxies>,
) -> bool {
    confirm_divergence_impl(gauge, macd_c_lt_a, force, None)
}

/// `confirm_divergence` 的 ForceL 全参版（#990）：`l_c_lt_b = Some(b)` ⟹ 教义判据
/// `L(C) < L(B)` 生效；`None` ⟹ ForceL 档无数据不判（诚实，与「无 MACD 不判」同款），
/// 其余档位不受影响。
pub fn confirm_divergence_l(
    gauge: DivergenceGauge,
    macd_c_lt_a: bool,
    force: Option<&ForceProxies>,
    l_c_lt_b: Option<bool>,
) -> bool {
    confirm_divergence_impl(gauge, macd_c_lt_a, force, l_c_lt_b)
}

#[allow(clippy::too_many_arguments)]
fn confirm_divergence_impl(
    gauge: DivergenceGauge,
    macd_c_lt_a: bool,
    force: Option<&ForceProxies>,
    l_c_lt_b: Option<bool>,
) -> bool {
    let dominated = || {
        force
            .map(|f| f.force_state() == ForceStateA5::Dominated)
            .unwrap_or(false)
    };
    let lex_weak = || {
        force
            .map(|f| weak_theta(WeakThetaMode::Lex, &f.seg_a, &f.seg_c))
            .unwrap_or(false)
    };
    match gauge {
        // ★#990：教义判据默认档。无 L 数据 ⟹ 不判（不冒充，不降级到别的判据）。
        DivergenceGauge::ForceL => l_c_lt_b.unwrap_or(false),
        DivergenceGauge::MacdArea => macd_c_lt_a,
        DivergenceGauge::ThetaDom => dominated(),
        DivergenceGauge::Conjunction => macd_c_lt_a && dominated(),
        DivergenceGauge::ThetaLex => lex_weak(),
    }
}

/// DIF 段峰值绝对值（黄白线主判据原语，第17课；移植旧引擎 `dif_peak_for_range` 到 theta_v0）。
///
/// `dif` 是 `compute_macd(...).dif` 序列（黄白线，与 hist 同坐标系）。`[start,end]` 闭区间 bar
/// 下标。向上段取区间内 `max(dif)`（正峰），向下段取 `min(dif)` 的绝对值（负峰）——与旧引擎
/// `dif_peak_for_range(up)` 语义一致（up→max 正值 / down→|min 负值|）。越界/空 ⟹ 0.0。
///
/// bit-exact：按 bar 升序扫描取极值（固定顺序），`f64` 比较用 `max`/`min`（无 NaN 前提，dif 由
/// EMA 差得，有限）。
pub fn segment_dif_peak(dif: &[f64], start: usize, end: usize, direction: Direction) -> f64 {
    if start > end || end >= dif.len() {
        return 0.0;
    }
    let slice = &dif[start..=end];
    match direction {
        // 向上段：黄白线正峰（max）。缠师顶背驰看黄白线新高与否。
        Direction::Up => slice
            .iter()
            .copied()
            .fold(f64::NEG_INFINITY, f64::max)
            .max(0.0),
        // 向下段：黄白线负峰（|min|）。底背驰看黄白线新低。
        Direction::Down => slice
            .iter()
            .copied()
            .fold(f64::INFINITY, f64::min)
            .min(0.0)
            .abs(),
    }
}

/// 段价格振幅 |端价差|（L0 整数 tick，走势力度的直接度量，第17课「走势力度」非 MACD proxy）。
///
/// `closes` 段端点（下标 `start`/`end`）close 的有向差绝对值。越界 ⟹ 0（空段无振幅）。
/// **整数域**（无浮点）——close 已量化为 tick（types.rs），振幅是 tick 差。
pub fn segment_price_amplitude(closes: &[Tick], start: usize, end: usize) -> i64 {
    if start > end || end >= closes.len() {
        return 0;
    }
    (closes[end] - closes[start]).abs()
}

/// 段价格速度 |端价差|/Δbar（单位时间价格变动，f64）。
///
/// 振幅 / 段跨度（`end-start`，至少 1 避免除零）。越界 ⟹ 0.0。
pub fn segment_price_speed(closes: &[Tick], start: usize, end: usize) -> f64 {
    if start > end || end >= closes.len() {
        return 0.0;
    }
    let amp = (closes[end] - closes[start]).abs() as f64;
    let span = (end - start).max(1) as f64;
    amp / span
}

// #994：segment_total_variation（全变差原语）已处决删除——TV 非力度（beichi.md v1.7）。

/// 从段区间算全部力度 proxy（`ForceFeatures`）——MACD 面积 + DIF 峰值 + 价格振幅 + 速度 + TV。
///
/// `hist`/`dif` 是 `compute_macd` 的 hist/dif 序列；`closes` 是 close(tick) 序列；三者同坐标系
/// （bar 下标对齐）。`(start,end)` 闭区间，`direction` 段方向（DIF 峰值方向敏感）。
pub fn force_features(
    hist: &[f64],
    dif: &[f64],
    closes: &[Tick],
    start: usize,
    end: usize,
    direction: Direction,
) -> ForceFeatures {
    ForceFeatures {
        macd_area: segment_macd_area(hist, start, end, direction),
        dif_peak: segment_dif_peak(dif, start, end, direction),
        price_amplitude: segment_price_amplitude(closes, start, end),
        price_speed: segment_price_speed(closes, start, end),
    }
}

/// Weak_Θ 力度比较模式（第34课 Θ=(level,DIF,area,amplitude,speed,…) 参数化；「三套 OOS」+ 默认 Lex）。
///
/// 每个 mode 定义「后段力度 `<` 前段力度」（背驰=力度衰减）的判据用哪个 proxy。`Lex` 是缠师第17课
/// 「黄白线主 ▷ 面积次」的词典序（DIF 可判用 DIF，否则退面积）。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WeakThetaMode {
    /// 纯 MACD 面积（`segments_diverge` 同判据，与 buy1 冻结判据一致——作对照基线）。
    MacdArea,
    /// 纯 DIF 峰值（黄白线主判据，第17课「黄白线最重要」）。
    Dif,
    /// 纯价格振幅（走势力度直接度量，非 MACD proxy）。
    PriceAmplitude,
    /// 词典序（第17课/第34课默认）：DIF 主 ▷ 面积次——DIF 严格可判则用 DIF，DIF 相等则退面积。
    Lex,
}

/// Weak_Θ 力度衰减判定（第34课参数化弱化关系，`Weak_Θ(A段,C段)` = C 段力度**严格小于** A 段）。
///
/// **词典序语义**（p2-plan §4 + 第17课「黄白线最重要，面积次之」+ swarm 待判点 B「非 AND/OR」）：
/// - `MacdArea`：`C.macd_area < A.macd_area`（与 buy1 冻结判据一致，对照基线）。
/// - `Dif`：`C.dif_peak < A.dif_peak`（黄白线主）。
/// - `PriceAmplitude`：`C.price_amplitude < A.price_amplitude`。
/// - `Lex`：DIF 主 ▷ 面积次——`C.dif < A.dif` ⟹ true（背驰）；`C.dif > A.dif` ⟹ false（力度延续）；
///   `C.dif == A.dif`（DIF 不可判）⟹ 退面积 `C.area < A.area`。**非 AND/OR**（027:30「只要其中
///   一个符合就可以」否证 AND；第34课「黄白线最重要」否证纯 OR）。
///
/// ★接入点（671号纠正）：本函数的生产消费者是 [`confirm_divergence`] 的 `ThetaLex` 分支（judge 层
/// 参数化 D 判定，A3 #164）——**非 selector 力度 veto**（671：力度=feature 不作 filter_gamma 一票
/// 否决）。默认口径（`MacdArea`）下 buy1 判据仍 `segments_diverge`=MACD 面积（class_index 语义不动，
/// bit-exact）；仅 `DivergenceGauge::ThetaLex` 显式激活时本词典序进 D。level 元门（级别配套）不在此
/// 函数（selector 已按 level 分桶，元门由 MuClass.level 承载）——本函数是同级别内的力度词典序。
///
/// ★认识论 L1（给定 A/C ForceFeatures 求 Weak 是确定性布尔，验证判定逻辑）——「哪个 mode 有
/// alpha」是 L2/L3（W-VERIFY，本函数不声明）。
pub fn weak_theta(mode: WeakThetaMode, seg_a: &ForceFeatures, seg_c: &ForceFeatures) -> bool {
    match mode {
        WeakThetaMode::MacdArea => seg_c.macd_area < seg_a.macd_area,
        WeakThetaMode::Dif => seg_c.dif_peak < seg_a.dif_peak,
        WeakThetaMode::PriceAmplitude => seg_c.price_amplitude < seg_a.price_amplitude,
        WeakThetaMode::Lex => {
            // 词典序：DIF 主判据。DIF 严格可判（≠）时用 DIF；DIF 相等则退面积（次判据）。
            if seg_c.dif_peak != seg_a.dif_peak {
                seg_c.dif_peak < seg_a.dif_peak
            } else {
                seg_c.macd_area < seg_a.macd_area
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// § B. A/B/C 趋势/盘整背驰框架层（第24课:22-24 + beichi.md v1.1 已结算）
// ═══════════════════════════════════════════════════════════════════════════

/// A/B/C 背驰段对（第24课:22-24 走势级别三段；契约锚 `Origin.Divergence.DivergencePair`）。
///
/// - `seg_a`：A 段（前一离开段）的 source_index 闭区间 `(start,end)`。
/// - `seg_c`：C 段（后一离开段/破中枢段）的 source_index 闭区间。
/// - `is_trend`：true=趋势背驰（A/C 跨相邻两中枢，B=中间中枢）；false=盘整背驰（A/C 同一中枢两次离开）。
///
/// B 段在结构上是 A 与 C 之间的中枢（趋势背驰=后一中枢；盘整背驰=唯一中枢），由调用方的中枢序列
/// 隐含定位——本结构只携 A/C 段坐标（力度比较的两端），B 的存在性由 τ 门控（≥1 中枢）保证。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct AbcDivergence {
    pub seg_a: (usize, usize),
    pub seg_c: (usize, usize),
    pub is_trend: bool,
}

impl AbcDivergence {
    /// 背驰判定（C段面积 < A段面积，力度原语）。`src_to_idx`：source_index→closes 下标的升序映射。
    /// 段无法映射到 closes 区间（越界/空）⟹ false（无面积=非背驰，与 judge_first 越界口径一致）。
    pub fn diverges(
        &self,
        hist: &[f64],
        a_idx: (usize, usize),
        c_idx: (usize, usize),
        dir: Direction,
    ) -> bool {
        segments_diverge(hist, a_idx, c_idx, dir)
    }
}

/// 趋势背驰的 A **离开走势区间**定位（第24课:22-24 + Q5 裁决 task #145，趋势 τ=Trend）。
///
/// ★Q5 谱系（一类买卖点.pdf 裁决，2026-07 #145）：「A/C 应为次级别走势类型，不应默认是单一线段。
/// If a lower-level departure move consists of multiple segments, the MACD/force comparison should
/// cover the whole lower-level move type interval：I(A)=[λ_A,ρ_A]，Area(A)=Σ_{t∈I(A)}|hist_t|。」
/// A = 离开 C_prev 的次级别走势类型（同向 d）——**不是**其中最后一个同向段。
///
/// 在 ≥2 同向中枢的趋势中，C = **最后一个中枢**之后破中枢的离开走势（由 judge_first 定位）；
/// A = **倒数第二个中枢**之后的同向离开走势区间。窗口过滤与旧单段实现相同
/// （direction==trend_dir ∧ start_index ≥ prev_center.end_index ∧ start_index < last_center.end_index），
/// 区间 = **当前离开 episode**（首匹配段起点..末匹配段终点，含中间反向段 bar，Q5 面积口径）。
///
/// ★episode 定界（codex ac4 审查 #1 修复）：「失败离开→回中枢→重新离开」是两个独立 episode，
/// 不桥接。边界 = 窗口内**最后一个回中枢段**（[`departure_episode_start`]，与 judge_pan_div
/// `reenters` 同一判据——反向段端点回到 prev_center 核心 [zd,zg] 内侧）。无回中枢段 ⟹ 整窗口
/// 一个 episode（与修复前行为相同）；恰一个匹配段 ⟹ 与旧单段返回值 bit 相同（兼容）。
///
/// ★A/C 跨相邻中枢配对（消解退化的「任意前同向段」）：A 不是序列序任意前同向段，而是趋势中**相邻
/// 前一中枢**的离开走势——第24课:24「A 之前已有一个中枢，B 是这个大趋势的另一个中枢」。`segments`
/// 按 start_index 升序；`last_center`/`prev_center` 是趋势的最后两个相邻中枢。
///
/// 返回 A 区间 `(λ_A, ρ_A)`（source_index 闭区间）；无匹配段/最后回中枢段之后无同向段 ⟹ None。
/// 离开走势方向 = 趋势方向（向下趋势=向下离开=底背驰候选；向上趋势=顶背驰候选）。
pub fn locate_departure_move_a(
    segments: &[Segment],
    anchors: &[Option<Direction>],
    prev_center: &Center,
    last_center: &Center,
    trend_dir: Direction,
) -> Option<(usize, usize)> {
    let lo = segments.partition_point(|s| s.start_index < prev_center.end_index);
    let hi = segments.partition_point(|s| s.start_index < last_center.end_index);
    let win = &segments[lo..hi];
    let awin = &anchors[lo..hi];
    let lambda_a = episode_start_in(win, awin, prev_center, trend_dir)?;
    // ★Q7-#1 裁定C：A 段候选筛选用 anchor 方向——fallback 单元不作 A 段方向锚（仍是区间成员）。
    // ★p117（686 窄域授权，终端背书裁定 T2）：生产第一类调用方（judge_segment）改传结构方向锚
    // （self），本过滤在该路径退化为结构同向筛选（行程方向=τ）；provenance 锚实参仅余
    // CandDelta 诊断 provider（recursive_tower）与探针仪器消费——判据函数体未动。
    let mut it = win
        .iter()
        .zip(awin)
        .filter(|(s, a)| **a == Some(trend_dir) && s.start_index >= lambda_a)
        .map(|(s, _)| s);
    let first = it.next()?;
    let last = it.last().unwrap_or(first);
    // I(A) = [episode 首段起点, episode 末同向段终点]（Q5：多段时含中间反向段 bar）。
    Some((first.start_index, last.end_index))
}

/// 当前离开 episode 的起点 λ（Q5 + codex ac4 审查 #1/#2 修复的共享定界原语）。
///
/// `win` = 离开中枢 `c` 的候选段窗口（start_index 升序切片）；episode 边界 = 窗口内**最后一个
/// 回中枢段**（反向段端点回到 c 核心 [zd,zg] 内侧——Down 离开侧 end ≥ zd / Up 离开侧 end ≤ zg，
/// 与 judge_pan_div `reenters` 同一判据）。λ = 边界之后首个同向段的 start_index；无回中枢段 ⟹
/// 窗口首个同向段（整窗口一个 episode）；边界后无同向段 ⟹ None（episode 无同向体，诚实无定位）。
///
/// 生产（signal.rs extract 循环 λ_C）/漏斗探针/oracle/judge_pan_div 全部经本函数取 episode 起点
/// ——单一来源，无坐标 fork（675号）。
/// L0/测试便捷（Q7-#1 裁定C）：段方向即锚方向——L0 线段有内在缠论方向，锚资格 ≡ 结构方向。
pub fn self_anchors(segs: &[Segment]) -> Vec<Option<Direction>> {
    segs.iter().map(|s| Some(s.direction)).collect()
}

/// ★Q7-#1 裁定C（codex-q7-fallback-20260703）：`anchors` 与 `win` 平行——离开段（首同向段）
/// 选取用 anchor 方向（`anchors[j] == Some(dir)`），fallback 单元（None）不得作离开段方向锚。
/// 回中枢段边界（reenters）用结构方向（`s.direction`）——回中枢是几何角色，非裁决三锚之一。
/// ★p117（686 窄域授权，终端背书裁定 T2）：生产第一类调用方（judge_segment）改传结构方向锚
/// （self），首同向段选取在该路径 = 结构同向筛选（行程方向=τ）；provenance 锚实参仅余
/// CandDelta 诊断 provider 与探针仪器——判据函数体未动。
pub fn episode_start_in(
    win: &[Segment],
    anchors: &[Option<Direction>],
    c: &Center,
    dir: Direction,
) -> Option<usize> {
    let reenters = |s: &Segment| {
        s.direction != dir
            && match dir {
                Direction::Down => s.end_price >= c.zd,
                Direction::Up => s.end_price <= c.zg,
            }
    };
    let boundary = win
        .iter()
        .rev()
        .find(|s| reenters(s))
        .map_or(0, |r| r.end_index);
    win.iter()
        .zip(anchors)
        .find(|(s, a)| **a == Some(dir) && s.start_index >= boundary)
        .map(|(s, _)| s.start_index)
}

/// λ_C（Q5 + codex ac4 审查 #2 修复）：离开中枢 `c` 的**当前** episode 首同向段起点，窗口截至
/// `until_start`（含——判破段 seg 自身在窗口内）。窗口 = start_index ∈ [c.end_index, until_start]
/// 的段；episode 定界经 [`episode_start_in`]（回中枢段边界，单一来源）。
///
/// 旧实现（c_start_cache 按 c_idx 缓存「中枢后第一个同向段起点」）无 reentry 检测——「失败离开→
/// 回中枢→重新离开触发 broke」场景下 λ_C 过早，污染 I(C) 面积（codex #2 致命）。本函数按
/// (c, dir, until_start) 逐段计算（λ_C 依赖 seg 前的回中枢段集合，不再可按 c_idx 缓存）。
pub fn departure_move_c_start(
    segments: &[Segment],
    anchors: &[Option<Direction>],
    c: &Center,
    dir: Direction,
    until_start: usize,
) -> Option<usize> {
    let lo = segments.partition_point(|s| s.start_index < c.end_index);
    let hi = segments.partition_point(|s| s.start_index <= until_start);
    episode_start_in(&segments[lo..hi], &anchors[lo..hi], c, dir)
}

/// 走势区间包络（037:20/061:28 破极值判据的参照极值；b 包络/c 包络共用原语，单一来源）。
/// 段须**整支**落入 span（start_index ≥ span.0 ∧ end_index ≤ span.1）；包络 = 各段
/// [min(start,end), max(start,end)] 的 (min,max) 折叠——含区间内部反向段（Q5 全区间口径，
/// 与 level_view T2/trend_confirm_time 同一原语）。纯 Tick 整数域，无浮点（bit-exact 安全）。
/// 无段整支落入 ⟹ None（无参照极值 ⟹ 037:20 不可验 ⟹ 诚实判负）。
///
/// ★p117（037:20 破极值补项，终端背书裁定 T3，D2 单一来源核准）：自 `level_view.rs` 私有
/// `range_envelope` 迁移（函数体逐字相同，fold 语义不变）；level_view 删私有副本、别名导入
/// （`move_range_envelope as range_envelope`，三调用点零改动）——BSP 侧（signal.rs
/// `judge_first_cached` 037:20 合取）与 D2 侧（R1 T2）共用同一原语同区间语义，禁口径 fork
/// （675 号单一来源纪律、`departure_move_c_start`「无坐标 fork」先例）。
pub(crate) fn move_range_envelope(
    segments: &[Segment],
    span: (usize, usize),
) -> Option<(Tick, Tick)> {
    segments
        .iter()
        .filter(|segment| segment.start_index >= span.0 && segment.end_index <= span.1)
        .fold(None, |acc, segment| {
            let lo = segment.start_price.min(segment.end_price);
            let hi = segment.start_price.max(segment.end_price);
            Some(match acc {
                None => (lo, hi),
                Some((old_lo, old_hi)) => (old_lo.min(lo), old_hi.max(hi)),
            })
        })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ctr(zd: Tick, zg: Tick, dd: Tick, gg: Tick, ei: usize) -> Center {
        Center {
            zd,
            zg,
            dd,
            gg,
            start_index: 0,
            end_index: ei,
        }
    }
    use super::super::super::types::Tick;

    /// ★p117（037:20 补项，终端背书裁定 T3）：`move_range_envelope` 迁移等价锁——span 过滤
    /// （段须整支落入）、含反向段的全区间 fold、空窗 None。函数体逐字迁移自 level_view 旧私有
    /// `range_envelope`（fold 语义不变）；level_view 三调用点经别名导入同一原语，行为由既有
    /// R1 测试网覆盖（单一来源，无第二实现可对拍 ⟹ 逐值手算断言锁定）。
    #[test]
    fn move_range_envelope_span_filter_and_fold() {
        let seg = |dir: Direction, si: usize, ei: usize, sp: Tick, ep: Tick| Segment {
            direction: dir,
            start_index: si,
            end_index: ei,
            start_price: sp,
            end_price: ep,
        };
        let segs = vec![
            seg(Direction::Down, 8, 12, 500, 300), // 左跨界（start<10）⟹ 排除
            seg(Direction::Down, 10, 14, 400, 250), // 整支落入：lo=250, hi=400
            seg(Direction::Up, 14, 18, 250, 450),  // 整支落入（反向段同样折叠）：lo=250, hi=450
            seg(Direction::Up, 18, 22, 450, 460),  // 右跨界（end>20）⟹ 排除
        ];
        // span 过滤 + 全区间 fold（含反向段；跨界段不贡献极值——500/460 被吸收即错）。
        assert_eq!(move_range_envelope(&segs, (10, 20)), Some((250, 450)));
        // 空窗（无段整支落入）⟹ None（无参照极值 ⟹ 037:20 不可验 ⟹ 诚实判负）。
        assert_eq!(move_range_envelope(&segs, (13, 14)), None);
        // 单段整支落入 ⟹ 该段 [min(start,end), max(start,end)]（Down 段 start>end 仍取 lo/hi）。
        assert_eq!(move_range_envelope(&segs, (10, 14)), Some((250, 400)));
        // 整窗全含 ⟹ 全段折叠（含两跨界段极值 300..500 与 450..460）。
        assert_eq!(move_range_envelope(&segs, (8, 22)), Some((250, 500)));
    }

    #[test]
    fn ema_first_value_is_first_close() {
        // EMA 首值取首 close（reference-theta-v0.md:37）。
        let src = vec![10.0, 20.0, 30.0];
        let out = ema(&src, 2);
        assert_eq!(out[0], 10.0); // 首值 = src[0]
                                  // α=2/3：out[1]=2/3*20+1/3*10=16.666...
        let alpha = 2.0 / 3.0;
        assert!((out[1] - (alpha * 20.0 + (1.0 - alpha) * 10.0)).abs() < 1e-12);
    }

    #[test]
    fn ema_empty_yields_empty() {
        assert_eq!(ema(&[], 12), Vec::<f64>::new());
    }

    #[test]
    fn macd_series_equal_length() {
        let closes: Vec<f64> = (0..50).map(|i| 100.0 + (i as f64)).collect();
        let cfg = MacdConfig::default();
        let m = compute_macd(&closes, &cfg);
        assert_eq!(m.dif.len(), closes.len());
        assert_eq!(m.dea.len(), closes.len());
        assert_eq!(m.hist.len(), closes.len());
    }

    #[test]
    fn macd_hist_equals_dif_minus_dea() {
        // hist = DIF - DEA（reference-theta-v0.md:37）逐 bar 验证。
        let closes: Vec<f64> = (0..40).map(|i| 100.0 + (i as f64 * 0.5)).collect();
        let cfg = MacdConfig::default();
        let m = compute_macd(&closes, &cfg);
        for i in 0..m.hist.len() {
            assert!((m.hist[i] - (m.dif[i] - m.dea[i])).abs() < 1e-12);
        }
    }

    #[test]
    fn segment_area_same_color_only() {
        // #988 同色口径：只计入与段方向同色的柱（060:44）。
        let hist = vec![1.0, -2.0, 3.0, -4.0];
        // Up 段 [0,2]：红柱 = 1+3 = 4（绿柱 -2 不计入）。
        assert_eq!(segment_macd_area(&hist, 0, 2, Direction::Up), 4.0);
        // Down 段 [0,2]：绿柱 = 2。
        assert_eq!(segment_macd_area(&hist, 0, 2, Direction::Down), 2.0);
        // Up 段 [1,3]：红柱 = 3；Down 段 [1,3]：绿柱 = 2+4 = 6。
        assert_eq!(segment_macd_area(&hist, 1, 3, Direction::Up), 3.0);
        assert_eq!(segment_macd_area(&hist, 1, 3, Direction::Down), 6.0);
    }

    /// #988 验收锁：混合柱样例两口径面积不等（同色 ≠ 绝对值和）。
    #[test]
    fn segment_area_same_color_differs_from_abs() {
        let hist = vec![1.0, -5.0, 2.0];
        let sc = segment_macd_area(&hist, 0, 2, Direction::Up);
        let abs_sum: f64 = hist.iter().map(|h| h.abs()).sum();
        assert_eq!(sc, 3.0);
        assert_ne!(sc, abs_sum); // abs 口径 = 8 ≠ 3 ⟹ 口径切换真实生效
    }

    #[test]
    fn segment_area_out_of_bounds_zero() {
        let hist = vec![1.0, 2.0];
        assert_eq!(segment_macd_area(&hist, 0, 5, Direction::Up), 0.0); // end 越界
        assert_eq!(segment_macd_area(&hist, 3, 1, Direction::Up), 0.0); // start>end
    }

    #[test]
    fn divergence_strict_less_only() {
        // 严格变小 ⟹ 背驰（reference-theta-v0.md:37）。
        assert!(is_divergence(10.0, 5.0));
        // 等值 ⟹ 不成立（等值不成立的明确规则）。
        assert!(!is_divergence(10.0, 10.0));
        // 变大 ⟹ 不成立。
        assert!(!is_divergence(10.0, 15.0));
    }

    #[test]
    fn segments_diverge_end_to_end() {
        // 前段 [0,1] 面积大，后段 [2,3] 面积小 ⟹ 背驰。
        let hist = vec![5.0, -5.0, 1.0, -1.0];
        // Up 同色：前段红 5 vs 后段红 1 → 严格小 ⟹ 背驰。
        assert!(segments_diverge(&hist, (0, 1), (2, 3), Direction::Up));
        // 反向：后段大 ⟹ 不背驰。
        assert!(!segments_diverge(&hist, (2, 3), (0, 1), Direction::Up));
        // Down 同色：前段绿 5 vs 后段绿 1 → 同判。
        assert!(segments_diverge(&hist, (0, 1), (2, 3), Direction::Down));
    }

    /// property：面积非负（|hist| 之和）。
    #[test]
    fn property_area_nonnegative() {
        let closes: Vec<f64> = (0..30).map(|i| 100.0 + ((i * 7 % 13) as f64)).collect();
        let cfg = MacdConfig::default();
        let m = compute_macd(&closes, &cfg);
        for start in 0..m.hist.len() {
            for end in start..m.hist.len() {
                assert!(segment_macd_area(&m.hist, start, end, Direction::Up) >= 0.0);
                assert!(segment_macd_area(&m.hist, start, end, Direction::Down) >= 0.0);
            }
        }
    }

    // ── § A3. 力度或关系原语（R1/R2 裁定：027:32/026:521/025:38/060:44）────────────

    #[test]
    fn same_color_area_counts_only_move_color_bars() {
        // 060:44 同色口径：Long=向下离开 ⟹ 只计绿柱（hist<0）；Short 只计红柱（hist>0）。
        let hist = vec![3.0, -1.0, -2.0, 5.0, -4.0];
        assert_eq!(
            same_color_area(&hist, 0, 4, Side::Long),
            7.0,
            "绿柱 |−1|+|−2|+|−4|"
        );
        assert_eq!(same_color_area(&hist, 0, 4, Side::Short), 8.0, "红柱 3+5");
        // 子区间与越界。
        assert_eq!(same_color_area(&hist, 1, 2, Side::Long), 3.0);
        assert_eq!(same_color_area(&hist, 0, 99, Side::Long), 0.0);
        // 全反向柱 ⟹ 同色面积 0（060:44 下无力度可读，区别于混合柱 Σ|hist|>0）。
        let opp = vec![2.0, 4.0];
        assert_eq!(same_color_area(&opp, 0, 1, Side::Long), 0.0);
        assert_eq!(
            segment_macd_area(&opp, 0, 1, Direction::Up),
            6.0,
            "对照：Up 段同色口径把红柱计入（=旧混合口径的值）"
        );
    }

    #[test]
    fn same_dir_hist_peak_takes_deepest_move_color_bar() {
        // 025:38 柱高：Long 取最深绿柱 |min|，Short 取最高红柱 max；无同色柱 ⟹ 0。
        let hist = vec![3.0, -1.0, -2.0, 5.0, -4.0];
        assert_eq!(same_dir_hist_peak(&hist, 0, 4, Side::Long), 4.0);
        assert_eq!(same_dir_hist_peak(&hist, 0, 4, Side::Short), 5.0);
        assert_eq!(
            same_dir_hist_peak(&hist, 0, 0, Side::Long),
            0.0,
            "该 bar 无绿柱"
        );
        assert_eq!(same_dir_hist_peak(&hist, 0, 99, Side::Short), 0.0);
    }

    #[test]
    fn segments_diverge_or_any_single_channel_suffices() {
        // 027:32「只要其中一个符合就可以」：逐通道单测——任一通道衰减即 true，全无衰减 false。
        let hist = vec![4.0, -4.0, 1.0, -1.0]; // A=[0,1] 红柱4/绿柱4；C=[2,3] 红柱1/绿柱1
        let dif = vec![10.0, 12.0, 9.0, 8.0];
        // 三通道全衰减（面积 1<4、柱峰 1<4、dif 峰 9<12）⟹ true。
        assert!(segments_diverge_or(
            &hist,
            &dif,
            Side::Short,
            (0, 1),
            (2, 3)
        ));
        // 混合柱口径对照：混合面积 C=2 < A=8 也 true——但下例展示分离情形。
        assert!(segments_diverge(&hist, (0, 1), (2, 3), Direction::Down));

        // 分离情形①（p113 turn=739707 标本型）：Down 同色 C=2 < A=6 ⟹ 背驰 true；
        // 混合口径 C=7 > A=6 判负——两种口径在此标本上给出相反判定（#988 切换的语义见证）。
        // 「或关系臂」的完整行为见 segments_diverge_or_any_single_channel_suffices。
        let hist2 = vec![-6.0, 1.0, -2.0, 5.0];
        assert!(segments_diverge(&hist2, (0, 1), (2, 3), Direction::Down));
        let dif2 = vec![-9.0, -9.0, -9.0, -9.0]; // dif 峰持平（等值不算衰减）
        assert!(
            segments_diverge_or(&hist2, &dif2, Side::Long, (0, 1), (2, 3)),
            "同色面积 2<6 单通道成立"
        );

        // 分离情形②：面积两口径都不衰减，黄白线峰 C<A ⟹ 单通道成立（026:521）。
        let hist3 = vec![-2.0, -2.0, -3.0, -3.0];
        let dif3 = vec![-8.0, -10.0, -5.0, -6.0]; // A 负峰 10 > C 负峰 6
        assert!(segments_diverge_or(
            &hist3,
            &dif3,
            Side::Long,
            (0, 1),
            (2, 3)
        ));

        // 全无衰减 ⟹ false（033:26 无衰减即无盘背，市场事实边界）。
        let hist4 = vec![-2.0, -2.0, -9.0, -9.0];
        let dif4 = vec![-5.0, -6.0, -8.0, -10.0];
        assert!(!segments_diverge_or(
            &hist4,
            &dif4,
            Side::Long,
            (0, 1),
            (2, 3)
        ));
    }

    #[test]
    fn dif_crosses_zero_touch_or_sign_flip() {
        // 025:761 回拉 0 轴：触 0 或相邻变号；同号区间 false；越界 false。
        assert!(dif_crosses_zero(&[1.0, -0.5, 2.0], 0, 2), "变号");
        assert!(dif_crosses_zero(&[1.0, 0.0, 2.0], 0, 2), "触 0");
        assert!(!dif_crosses_zero(&[1.0, 0.5, 2.0], 0, 2), "同号无回拉");
        assert!(!dif_crosses_zero(&[1.0, 2.0], 0, 99), "越界不可验 ⟹ false");
        // 首 bar 不与区间外 bar 配对（t > lo 才比 t-1）。
        assert!(
            !dif_crosses_zero(&[-1.0, 2.0, 3.0], 1, 2),
            "区间起点不与左邻配对"
        );
    }

    // ── § B. A/B/C 框架层：趋势背驰 A 段定位（locate_trend_seg_a）─────────────────

    #[test]
    fn locate_departure_move_a_covers_whole_interval() {
        // Q5：趋势 τ=Trend(Down)，prev_center end=5，last_center end=12。多段离开走势——
        // I(A) = (首个匹配段起点, 末个匹配段终点) = (6, 11)，覆盖中间反向段 [8,10] 的 bar。
        let prev_c = ctr(300, 400, 290, 410, 5);
        let last_c = ctr(100, 200, 90, 210, 12);
        let segments = vec![
            // start_index 升序。向下段在 [5,12) 区间内（离开走势的组成段）。中间反向段端点 295
            // < prev_c.zd=300——趋势内部正常回撤，未回中枢核心 ⟹ 同一 episode（codex ac4 #1）。
            Segment {
                direction: Direction::Down,
                start_index: 6,
                end_index: 8,
                start_price: 380,
                end_price: 280,
            },
            Segment {
                direction: Direction::Up,
                start_index: 8,
                end_index: 10,
                start_price: 280,
                end_price: 295,
            },
            Segment {
                direction: Direction::Down,
                start_index: 10,
                end_index: 11,
                start_price: 295,
                end_price: 250,
            },
            Segment {
                direction: Direction::Down,
                start_index: 13,
                end_index: 15,
                start_price: 200,
                end_price: 80,
            }, // 在 last_center 之后（C 区，非 A）
        ];
        let seg_a = locate_departure_move_a(
            &segments,
            &self_anchors(&segments),
            &prev_c,
            &last_c,
            Direction::Down,
        );
        assert_eq!(
            seg_a,
            Some((6, 11)),
            "Q5：A = 整个离开走势区间（首匹配段起点..末匹配段终点，含中间反向段）"
        );
    }

    #[test]
    fn locate_departure_move_a_reentry_splits_episodes() {
        // codex ac4 #1 修复见证：失败离开（[6,8]）→ 回中枢段（[8,10] 端点 395 回到 prev core
        // [300,400] 内侧 ≥ zd=300）→ 重新离开（[10,11]）。两个独立 episode 不桥接——
        // A = 最后 episode [10,11]，非旧桥接区间 [6,11]。
        let prev_c = ctr(300, 400, 290, 410, 5);
        let last_c = ctr(100, 200, 90, 210, 12);
        let segments = vec![
            Segment {
                direction: Direction::Down,
                start_index: 6,
                end_index: 8,
                start_price: 380,
                end_price: 280,
            },
            Segment {
                direction: Direction::Up,
                start_index: 8,
                end_index: 10,
                start_price: 280,
                end_price: 395,
            }, // 回中枢：end 395 ≥ zd=300
            Segment {
                direction: Direction::Down,
                start_index: 10,
                end_index: 11,
                start_price: 395,
                end_price: 250,
            },
        ];
        let seg_a = locate_departure_move_a(
            &segments,
            &self_anchors(&segments),
            &prev_c,
            &last_c,
            Direction::Down,
        );
        assert_eq!(
            seg_a,
            Some((10, 11)),
            "回中枢段切开两个 episode ⟹ A = 当前（最后）episode，不桥接"
        );
        // 对照：中间反向段未回核心（end 280 < zd=300）⟹ 同一 episode ⟹ 全区间（covers_whole_interval 语义）。
        let no_reentry = vec![
            Segment {
                direction: Direction::Down,
                start_index: 6,
                end_index: 8,
                start_price: 380,
                end_price: 280,
            },
            Segment {
                direction: Direction::Up,
                start_index: 8,
                end_index: 10,
                start_price: 280,
                end_price: 295,
            },
            Segment {
                direction: Direction::Down,
                start_index: 10,
                end_index: 11,
                start_price: 295,
                end_price: 250,
            },
        ];
        let seg_a2 = locate_departure_move_a(
            &no_reentry,
            &self_anchors(&no_reentry),
            &prev_c,
            &last_c,
            Direction::Down,
        );
        assert_eq!(
            seg_a2,
            Some((6, 11)),
            "反向段未回核心 ⟹ 同一 episode ⟹ 整区间"
        );
    }

    #[test]
    fn departure_move_c_start_reentry_bounds_episode() {
        // codex ac4 #2 修复见证：中枢后失败离开 [6,8] → 回中枢段 [8,10]（end 395 ≥ zd=300）→
        // 重新离开 [10,11]（判破段）。λ_C = 10（当前 episode 起点），非旧口径 6（首个同向段）。
        let c = ctr(300, 400, 290, 410, 5);
        let segments = vec![
            Segment {
                direction: Direction::Down,
                start_index: 6,
                end_index: 8,
                start_price: 380,
                end_price: 280,
            },
            Segment {
                direction: Direction::Up,
                start_index: 8,
                end_index: 10,
                start_price: 280,
                end_price: 395,
            },
            Segment {
                direction: Direction::Down,
                start_index: 10,
                end_index: 11,
                start_price: 395,
                end_price: 250,
            },
        ];
        assert_eq!(
            departure_move_c_start(&segments, &self_anchors(&segments), &c, Direction::Down, 10),
            Some(10),
            "回中枢段之后重新离开 ⟹ λ_C = 当前 episode 首同向段起点"
        );
        // 无回中枢段 ⟹ 整窗口一个 episode ⟹ λ_C = 首个同向段起点（单段兼容口径）。
        assert_eq!(
            departure_move_c_start(
                &segments[..1],
                &self_anchors(&segments[..1]),
                &c,
                Direction::Down,
                6
            ),
            Some(6),
            "无回中枢段 ⟹ λ_C = 中枢后首个同向段起点"
        );
    }

    #[test]
    fn locate_departure_move_a_single_segment_bit_compatible() {
        // Q5 兼容性：恰一个匹配段 ⟹ 返回值与旧单段实现 bit 相同。
        let prev_c = ctr(300, 400, 290, 410, 5);
        let last_c = ctr(100, 200, 90, 210, 12);
        let segments = vec![
            Segment {
                direction: Direction::Down,
                start_index: 6,
                end_index: 8,
                start_price: 380,
                end_price: 280,
            },
            Segment {
                direction: Direction::Up,
                start_index: 8,
                end_index: 10,
                start_price: 280,
                end_price: 295,
            }, // 未回核心（<zd=300）
        ];
        let seg_a = locate_departure_move_a(
            &segments,
            &self_anchors(&segments),
            &prev_c,
            &last_c,
            Direction::Down,
        );
        assert_eq!(
            seg_a,
            Some((6, 8)),
            "单匹配段 ⟹ 与旧单段返回值 bit 相同（兼容）"
        );
    }

    #[test]
    fn locate_departure_move_a_none_when_no_prev_leave() {
        // prev_center 与 last_center 之间无同向离开段 ⟹ A 区间无法定位 ⟹ None（无背驰对照）。
        let prev_c = ctr(300, 400, 290, 410, 5);
        let last_c = ctr(100, 200, 90, 210, 12);
        let segments = vec![
            // [5,12) 内只有向上段，无向下离开段 ⟹ A（向下）无候选。
            Segment {
                direction: Direction::Up,
                start_index: 6,
                end_index: 8,
                start_price: 280,
                end_price: 380,
            },
        ];
        let seg_a = locate_departure_move_a(
            &segments,
            &self_anchors(&segments),
            &prev_c,
            &last_c,
            Direction::Down,
        );
        assert_eq!(seg_a, None, "无 prev_center 同向离开段 ⟹ A 无法定位");
    }

    #[test]
    fn abc_divergence_trend_diverges_via_area() {
        // AbcDivergence 趋势背驰：A 段面积大、C 段面积小 ⟹ 背驰（C<A 力度原语）。
        let hist = vec![5.0, -5.0, 1.0, -1.0]; // A=[0,1] 面积10，C=[2,3] 面积2
        let abc = AbcDivergence {
            seg_a: (0, 1),
            seg_c: (2, 3),
            is_trend: true,
        };
        assert!(
            abc.diverges(&hist, (0, 1), (2, 3), Direction::Down),
            "C段同色面积2 < A段同色面积10 ⟹ 趋势背驰"
        );
        // 反向：C 段面积大 ⟹ 力度延续 ⟹ 非背驰。
        let abc_cont = AbcDivergence {
            seg_a: (2, 3),
            seg_c: (0, 1),
            is_trend: true,
        };
        assert!(
            !abc_cont.diverges(&hist, (2, 3), (0, 1), Direction::Down),
            "C段同色面积10 ≥ A段同色面积2 ⟹ 力度延续=非背驰"
        );
    }

    // ===== § A2. 多力度原语 + Weak_Θ 词典序（P2 §4/§7 改点5，L1 接口正确性）=====

    #[test]
    fn dif_peak_up_takes_positive_max_down_takes_abs_min() {
        // 向上段：黄白线正峰（max）。dif=[1,3,2] ⟹ 峰=3。
        let dif = vec![1.0, 3.0, 2.0, -1.0];
        assert_eq!(segment_dif_peak(&dif, 0, 2, Direction::Up), 3.0);
        // 向下段：黄白线负峰（|min|）。dif=[−1,−4,−2] ⟹ 峰=|−4|=4。
        let dif2 = vec![-1.0, -4.0, -2.0];
        assert_eq!(segment_dif_peak(&dif2, 0, 2, Direction::Down), 4.0);
        // 越界 ⟹ 0。
        assert_eq!(segment_dif_peak(&dif, 0, 10, Direction::Up), 0.0);
        // 向上段但区间全负 ⟹ 正峰 = 0（max(neg,0)=0，无正黄白线）。
        assert_eq!(segment_dif_peak(&dif2, 0, 2, Direction::Up), 0.0);
    }

    #[test]
    fn price_amplitude_and_speed_from_close_endpoints() {
        // 振幅 = |端价差|（整数 tick）。closes[0..=3]=[100,?,?,150] ⟹ |150−100|=50。
        let closes: Vec<Tick> = vec![100, 120, 90, 150];
        assert_eq!(segment_price_amplitude(&closes, 0, 3), 50);
        // 速度 = 振幅 / 跨度 = 50 / 3。
        assert!((segment_price_speed(&closes, 0, 3) - (50.0 / 3.0)).abs() < 1e-12);
        // 越界 ⟹ 0。
        assert_eq!(segment_price_amplitude(&closes, 0, 9), 0);
        assert_eq!(segment_price_speed(&closes, 0, 9), 0.0);
        // TV = 20+30+60 = 110（路径长度 > 端点差 50——折返段被计入）。
    }

    fn ff(area: f64, dif: f64, amp: i64, speed: f64) -> ForceFeatures {
        // #994：tv 维已处决删除。
        ForceFeatures {
            macd_area: area,
            dif_peak: dif,
            price_amplitude: amp,
            price_speed: speed,
        }
    }

    #[test]
    fn weak_theta_each_mode_compares_correct_proxy() {
        // A 段力度大，C 段力度小 ⟹ 各 mode 都判 Weak（背驰=力度衰减）。
        let a = ff(10.0, 8.0, 100, 20.0);
        let c = ff(5.0, 4.0, 50, 10.0);
        assert!(
            weak_theta(WeakThetaMode::MacdArea, &a, &c),
            "C.area<A.area ⟹ Weak"
        );
        assert!(weak_theta(WeakThetaMode::Dif, &a, &c), "C.dif<A.dif ⟹ Weak");
        assert!(
            weak_theta(WeakThetaMode::PriceAmplitude, &a, &c),
            "C.amp<A.amp ⟹ Weak"
        );
        // C 力度 ≥ A ⟹ 各 mode 非 Weak（力度延续）。
        assert!(!weak_theta(WeakThetaMode::MacdArea, &c, &a));
        assert!(!weak_theta(WeakThetaMode::Dif, &c, &a));
    }

    #[test]
    fn force_state_five_dominance_cases() {
        let fp = |a, c| ForceProxies { seg_a: a, seg_c: c };
        let strong = ff(10.0, 8.0, 100, 20.0);
        let weak = ff(5.0, 4.0, 50, 10.0);
        // C 全弱于 A ⟹ Dominated（确定背驰）。
        assert_eq!(fp(strong, weak).force_state(), ForceStateA5::Dominated);
        // C 全强于 A ⟹ Dominates。
        assert_eq!(fp(weak, strong).force_state(), ForceStateA5::Dominates);
        // 全等 ⟹ Tie。
        assert_eq!(fp(strong, strong).force_state(), ForceStateA5::Tie);
        // 口径冲突：C.area 弱但 C.dif 强 ⟹ Incomparable。
        let mixed_a = ff(10.0, 4.0, 100, 20.0);
        let mixed_c = ff(5.0, 8.0, 50, 10.0);
        assert_eq!(
            fp(mixed_a, mixed_c).force_state(),
            ForceStateA5::Incomparable
        );
    }

    /// 三口径 D 判定（A2 #163，prereg-a2-thetadom-oos-20260704 冻结判据的 L1 验证）。
    #[test]
    fn confirm_divergence_three_gauges() {
        let fp = |a, c| ForceProxies { seg_a: a, seg_c: c };
        let strong = ff(10.0, 8.0, 100, 20.0);
        let weak = ff(5.0, 4.0, 50, 10.0);
        let dominated = fp(strong, weak); // C 全弱 ⟹ Dominated
        let mixed = fp(ff(10.0, 4.0, 100, 20.0), ff(5.0, 8.0, 50, 10.0)); // Incomparable
                                                                          // G1 MacdArea：D ≡ macd_c_lt_a（force 不参与，None 也判）。
        assert!(confirm_divergence(DivergenceGauge::MacdArea, true, None));
        assert!(!confirm_divergence(
            DivergenceGauge::MacdArea,
            false,
            Some(&dominated)
        ));
        // G2 ThetaDom：D ≡ Dominated（macd_c_lt_a 不参与）；Incomparable 不作背驰确认。
        assert!(confirm_divergence(
            DivergenceGauge::ThetaDom,
            false,
            Some(&dominated)
        ));
        assert!(!confirm_divergence(
            DivergenceGauge::ThetaDom,
            true,
            Some(&mixed)
        ));
        // G2/G3 force 无源 ⟹ false（诚实不判，不 fallback 回 MACD）。
        assert!(!confirm_divergence(DivergenceGauge::ThetaDom, true, None));
        assert!(!confirm_divergence(
            DivergenceGauge::Conjunction,
            true,
            None
        ));
        // G3 Conjunction：两者同真才确认。
        assert!(confirm_divergence(
            DivergenceGauge::Conjunction,
            true,
            Some(&dominated)
        ));
        assert!(!confirm_divergence(
            DivergenceGauge::Conjunction,
            false,
            Some(&dominated)
        ));
        assert!(!confirm_divergence(
            DivergenceGauge::Conjunction,
            true,
            Some(&mixed)
        ));
        // #990 I-2：默认口径 = ForceL（教义判据 L(C)<L(B)，#873）；MacdArea 降为显式对照档（ADR-0005）。
        assert_eq!(DivergenceGauge::default(), DivergenceGauge::ForceL);

        /// ★#990 ForceL 专项锁：教义判据 `L(C)<L(B)`（Some）生效、无数据（None）不判、
        /// 与面积档可给相反判定（口径切换的语义见证）。
        #[test]
        fn confirm_divergence_forcel_semantics() {
            use crate::theta_v0::parser::segment::{segment_force_l, stroke_velocity};
            // 构造笔：b 首笔速度 10、末笔 2；c 首笔 2、末笔 -1 ⟹ L(b)=-8 < L(c)=-3 ⟹ L(c)>L(b) 不判；
            // 交换后 L(c)<L(b) 判。用反查原语直接验算。
            let mk = |d: Direction, s: usize, e: usize, p0: Tick, p1: Tick| Stroke {
                direction: d,
                start_index: s,
                end_index: e,
                start_price: p0,
                end_price: p1,
            };
            let strokes_b = vec![
                mk(Direction::Up, 0, 9, 0, 100),     // v=+10
                mk(Direction::Down, 9, 19, 100, 80), // v=-2
            ];
            let strokes_c = vec![
                mk(Direction::Up, 20, 29, 0, 20),    // v=+2
                mk(Direction::Down, 30, 39, 20, 10), // v=-1
            ];
            assert_eq!(stroke_velocity(&strokes_b[0]), 10.0);
            // L(b) = v(末)-v(首) = -2-10 = -12；L(c) = -1-2 = -3 ⟹ L(c) > L(b)。
            let lb = segment_force_l(&strokes_b, 0, 19).unwrap();
            let lc = segment_force_l(&strokes_c, 20, 39).unwrap();
            assert!((lb - (-12.0)).abs() < 1e-9);
            assert!((lc - (-3.0)).abs() < 1e-9);
            // gauge 语义：ForceL + L(c)<L(b)=false ⟹ 不判；true ⟹ 判；None ⟹ 不判。
            assert!(!confirm_divergence_l(
                DivergenceGauge::ForceL,
                true,
                None,
                Some(false)
            ));
            assert!(confirm_divergence_l(
                DivergenceGauge::ForceL,
                false,
                None,
                Some(true)
            ));
            assert!(!confirm_divergence_l(
                DivergenceGauge::ForceL,
                true,
                None,
                None
            ));
            // MacdArea 档不受 l 参与影响（对照臂独立性）。
            assert!(confirm_divergence_l(
                DivergenceGauge::MacdArea,
                true,
                None,
                Some(false)
            ));
        }
    }

    /// G4 ThetaLex（Θ_LEX 词典序 D 判定，A3 #164，关于背驰.pdf §9.2）：judge 层 `weak_theta(Lex)`
    /// = Weak(C,A) 词典序（DIF 主 ▷ 面积次）。这是 `weak_theta` 原语的生产消费点（671：judge 非
    /// selector veto）。macd_c_lt_a 不参与（Lex 用 DIF/面积词典序，非纯面积）。
    #[test]
    fn confirm_divergence_theta_lex_gauge() {
        let fp = |a, c| ForceProxies { seg_a: a, seg_c: c };
        // C.dif < A.dif（DIF 主判据衰减）⟹ Weak ⟹ D，**即使 macd_c_lt_a=false**（DIF 压过面积/MACD）。
        let dif_weak = fp(ff(5.0, 8.0, 0, 0.0), ff(10.0, 4.0, 0, 0.0)); // C.dif(4)<A.dif(8) 但 C.area(10)>A.area(5)
        assert!(
            confirm_divergence(DivergenceGauge::ThetaLex, false, Some(&dif_weak)),
            "ThetaLex：C.dif<A.dif ⟹ Weak ⟹ D（DIF 主，macd_c_lt_a 不参与）"
        );
        // 对照：MacdArea 口径同输入 D=false（面积延续）——证 ThetaLex ≠ MacdArea。
        assert!(!confirm_divergence(
            DivergenceGauge::MacdArea,
            false,
            Some(&dif_weak)
        ));
        // DIF 相等（不可判）⟹ 退面积次判据：C.area<A.area ⟹ Weak ⟹ D。
        let dif_tie_area_weak = fp(ff(10.0, 5.0, 0, 0.0), ff(4.0, 5.0, 0, 0.0));
        assert!(
            confirm_divergence(DivergenceGauge::ThetaLex, false, Some(&dif_tie_area_weak)),
            "ThetaLex：DIF 相等 ⟹ 退面积，C.area<A.area ⟹ Weak"
        );
        // C 力度延续（C.dif>A.dif）⟹ 非 Weak ⟹ D=false。
        let dif_strong = fp(ff(5.0, 4.0, 0, 0.0), ff(10.0, 8.0, 0, 0.0));
        assert!(
            !confirm_divergence(DivergenceGauge::ThetaLex, true, Some(&dif_strong)),
            "ThetaLex：C.dif>A.dif ⟹ 力度延续 ⟹ 非背驰（即使 macd_c_lt_a=true）"
        );
        // force 无源 ⟹ false（诚实不判，不 fallback 回 MACD，与 ThetaDom 同纪律）。
        assert!(
            !confirm_divergence(DivergenceGauge::ThetaLex, true, None),
            "ThetaLex force 无源 ⟹ D=false（无 5-proxy 不判，no-workaround）"
        );
    }

    /// Θ_SCORE β_norm + K=3 分箱（prereg 冻结边界 0/0.33 的 L1 验证）。
    #[test]
    fn theta_score_and_bin_frozen_boundaries() {
        let fp = |da: f64, dc: f64| ForceProxies {
            seg_a: ff(0.0, da, 0, 0.0),
            seg_c: ff(0.0, dc, 0, 0.0),
        };
        // β_norm = (m_A−m_C)/(m_A+m_C)：C 弱 ⟹ 正（背驰域）；C 强 ⟹ 负。
        assert!((fp(8.0, 4.0).theta_score() - (4.0 / 12.0)).abs() < 1e-12);
        assert!(fp(4.0, 8.0).theta_score() < 0.0);
        // 双零 ⟹ 0（无力度可比=非背驰，冻结口径）。
        assert_eq!(fp(0.0, 0.0).theta_score(), 0.0);
        // 分箱边界：≤0 非背驰；(0,0.33) 弱；≥0.33 强（边界值 0.33 归 Strong）。
        assert_eq!(theta_score_bin(0.0), ThetaScoreBin::NonDivergent);
        assert_eq!(theta_score_bin(-0.5), ThetaScoreBin::NonDivergent);
        assert_eq!(theta_score_bin(0.1), ThetaScoreBin::Weak);
        assert_eq!(theta_score_bin(0.33), ThetaScoreBin::Strong);
        assert_eq!(theta_score_bin(1.0), ThetaScoreBin::Strong);
        // β_norm=1/3 > 0.33 ⟹ fp(8,4) 落 Strong（冻结边界与归一化差的联动例）。
        assert_eq!(
            theta_score_bin(fp(8.0, 4.0).theta_score()),
            ThetaScoreBin::Strong
        );
    }

    /// ★Lex 词典序核心（第17课「黄白线主 ▷ 面积次」，非 AND/OR）：DIF 可判用 DIF，DIF 相等退面积。
    #[test]
    fn weak_theta_lex_dif_dominates_area_secondary() {
        // (1) DIF 严格可判：C.dif<A.dif ⟹ Weak，**即使面积相反**（DIF 主判据压过面积）。
        let a1 = ff(5.0, 8.0, 0, 0.0); // A: 面积小、DIF 大
        let c1 = ff(10.0, 4.0, 0, 0.0); // C: 面积大、DIF 小
        assert!(
            weak_theta(WeakThetaMode::Lex, &a1, &c1),
            "DIF 主：C.dif(4)<A.dif(8) ⟹ Weak，即使 C.area(10)>A.area(5)（黄白线压过面积）"
        );
        // 对照：纯面积 mode 会判非 Weak（面积延续）——证明 Lex ≠ 纯面积。
        assert!(
            !weak_theta(WeakThetaMode::MacdArea, &a1, &c1),
            "纯面积：C.area(10)≥A.area(5) ⟹ 非 Weak（与 Lex 分歧，证 DIF 主判据生效）"
        );

        // (2) DIF 相等（不可判）⟹ 退面积次判据：C.area<A.area ⟹ Weak。
        let a2 = ff(10.0, 5.0, 0, 0.0);
        let c2 = ff(4.0, 5.0, 0, 0.0); // DIF 相等（5==5）⟹ 退面积
        assert!(
            weak_theta(WeakThetaMode::Lex, &a2, &c2),
            "DIF 相等 ⟹ 退面积次判据：C.area(4)<A.area(10) ⟹ Weak"
        );
        // DIF 相等 + 面积也延续 ⟹ 非 Weak。
        let c3 = ff(20.0, 5.0, 0, 0.0);
        assert!(
            !weak_theta(WeakThetaMode::Lex, &a2, &c3),
            "DIF 相等 + C.area(20)≥A.area(10) ⟹ 非 Weak"
        );
    }

    #[test]
    fn force_features_assembles_all_proxies() {
        // hist=[3,-3,1,-1]（#988 Up 同色：A[0,1]=3，C[2,3]=1），dif=[2,4,1,0.5]，closes=[100,110,105,102]。
        let hist = vec![3.0, -3.0, 1.0, -1.0];
        let dif = vec![2.0, 4.0, 1.0, 0.5];
        let closes: Vec<Tick> = vec![100, 110, 105, 102];
        let a = force_features(&hist, &dif, &closes, 0, 1, Direction::Up);
        assert_eq!(a.macd_area, 3.0);
        assert_eq!(a.dif_peak, 4.0); // up 段 max(dif[0..=1])=max(2,4)=4
        assert_eq!(a.price_amplitude, 10); // |110−100|
                                           // Weak_Θ Lex：A=[0,1] vs C=[2,3]（C.dif_peak=max(1,0.5)=1<A.dif=4 ⟹ Weak）。
        let c = force_features(&hist, &dif, &closes, 2, 3, Direction::Up);
        assert!(
            weak_theta(WeakThetaMode::Lex, &a, &c),
            "C 段 DIF 峰(1)<A 段 DIF 峰(4) ⟹ Lex Weak"
        );
    }

    // ===== 增量 MACD API（231号纯性能，bit-exact 对照全量版）=====

    /// bit-exact 核心：增量逐 bar 输出 == 全量版对应位置（合成数据）。
    #[test]
    fn incremental_macd_bit_exact_synthetic() {
        // 合成 closes：覆盖上升/震荡/下降，长度 > signal 周期使 EMA 充分递推。
        let closes: Vec<f64> = (0..80)
            .map(|i| 100.0 + 10.0 * ((i as f64) * 0.3).sin() + (i as f64) * 0.05)
            .collect();
        let cfg = MacdConfig::default();
        let full = compute_macd(&closes, &cfg);

        // 增量：init 首 bar，逐 bar append，逐位断言。
        let mut state = MacdState::init(closes[0], &cfg);
        // 首 bar 对照。
        let p0 = state.current_point();
        assert!(
            (p0.dif - full.dif[0]).abs() < 1e-12,
            "首 bar DIF 不匹配：增量={} 全量={}",
            p0.dif,
            full.dif[0]
        );
        assert!((p0.dea - full.dea[0]).abs() < 1e-12);
        assert!((p0.hist - full.hist[0]).abs() < 1e-12);

        for i in 1..closes.len() {
            state = compute_macd_append(&state, closes[i]);
            let p = state.current_point();
            assert!(
                (p.dif - full.dif[i]).abs() < 1e-12,
                "bar {} DIF 不匹配：增量={} 全量={}",
                i,
                p.dif,
                full.dif[i]
            );
            assert!(
                (p.dea - full.dea[i]).abs() < 1e-12,
                "bar {} DEA 不匹配：增量={} 全量={}",
                i,
                p.dea,
                full.dea[i]
            );
            assert!(
                (p.hist - full.hist[i]).abs() < 1e-12,
                "bar {} hist 不匹配：增量={} 全量={}",
                i,
                p.hist,
                full.hist[i]
            );
        }
        assert_eq!(state.bars_processed(), closes.len() as u64);
    }

    /// bit-exact 边界：首 bar 确定性（DIF=DEA=hist=0）。
    #[test]
    fn incremental_macd_first_bar_is_zero() {
        let cfg = MacdConfig::default();
        let state = MacdState::init(1234.5, &cfg);
        let p = state.current_point();
        assert_eq!(p.dif, 0.0, "首 bar DIF = close-close = 0");
        assert_eq!(p.dea, 0.0, "首 bar DEA = 首值取首 DIF = 0");
        assert_eq!(p.hist, 0.0, "首 bar hist = DIF-DEA = 0");
        assert_eq!(state.bars_processed(), 1);
    }

    /// bit-exact：macd_state_from_closes 末状态 == 逐 bar append 末状态。
    #[test]
    fn incremental_macd_from_closes_matches_append() {
        let closes: Vec<f64> = (0..30).map(|i| 50.0 + (i as f64)).collect();
        let cfg = MacdConfig::default();
        let from_helper = macd_state_from_closes(&closes, &cfg);
        // 手动逐 bar。
        let mut manual = MacdState::init(closes[0], &cfg);
        for &c in &closes[1..] {
            manual = manual.append(c);
        }
        assert_eq!(from_helper, manual);
    }

    /// bit-exact：跨不同 cfg 参数（fast/slow/signal 非默认）逐位相等。
    #[test]
    fn incremental_macd_bit_exact_custom_cfg() {
        let closes: Vec<f64> = (0..60)
            .map(|i| 200.0 + 5.0 * ((i as f64) * 0.7).cos())
            .collect();
        let cfg = MacdConfig {
            fast: 5,
            slow: 20,
            signal: 5,
        };
        let full = compute_macd(&closes, &cfg);
        let mut state = MacdState::init(closes[0], &cfg);
        for i in 1..closes.len() {
            state = compute_macd_append(&state, closes[i]);
            let p = state.current_point();
            assert!(
                (p.dif - full.dif[i]).abs() < 1e-12,
                "custom cfg bar {} DIF",
                i
            );
            assert!(
                (p.dea - full.dea[i]).abs() < 1e-12,
                "custom cfg bar {} DEA",
                i
            );
            assert!(
                (p.hist - full.hist[i]).abs() < 1e-12,
                "custom cfg bar {} hist",
                i
            );
        }
    }

    /// 标度：增量 append 单次成本应近似常数（exp≈1），相对全量 compute_macd 的 O(n)。
    ///
    /// 用单 bar append 的固定耗时 vs 全量 compute_macd 在增大 n 下的线性增长比，
    /// 断言 append 耗时不随已处理 bar 数增长（O(1) per bar）。
    #[test]
    fn incremental_macd_append_is_o1_scaling() {
        let cfg = MacdConfig::default();
        // 在两个不同规模下测量「再 append 1 bar」的耗时——O(1) 则两者相近。
        let bench_once = |n_pre: usize| -> u128 {
            let closes_pre: Vec<f64> = (0..n_pre)
                .map(|i| 100.0 + ((i as f64) * 0.1).sin())
                .collect();
            let state0 = macd_state_from_closes(&closes_pre, &cfg);
            let new_close = 105.0;
            // 重复 append（丢弃，仅测单次 append 在已处理 n_pre 后的耗时）。
            let start = std::time::Instant::now();
            let iters = 50_000;
            let mut s = state0.clone();
            for _ in 0..iters {
                s = s.append(new_close);
            }
            let _ = s.current_point();
            start.elapsed().as_nanos() / (iters as u128)
        };
        // min-of-3 降噪：CI 共享 runner 单轮抖动只会抬高耗时（cache miss / 频率漂移），
        // 取最小值压回真实成本；真正 O(n) 回归差 ~50x，min-of-3 仍远超 3.0 阈值。
        let bench = |n_pre: usize| -> u128 { (0..3).map(|_| bench_once(n_pre)).min().unwrap() };
        let per_bar_small = bench(100);
        let per_bar_large = bench(5_000);
        // O(1) 判据：大样本 per-bar 耗时不应显著高于小样本。
        // 容忍 3x 噪声（bench 环境抖动），真正 O(n) 会差 ~50x。
        let ratio = per_bar_large as f64 / per_bar_small.max(1) as f64;
        assert!(
            ratio < 3.0,
            "append 非 O(1)：小样本 {} ns/bar，大样本 {} ns/bar，比 {}",
            per_bar_small,
            per_bar_large,
            ratio
        );
    }
}
