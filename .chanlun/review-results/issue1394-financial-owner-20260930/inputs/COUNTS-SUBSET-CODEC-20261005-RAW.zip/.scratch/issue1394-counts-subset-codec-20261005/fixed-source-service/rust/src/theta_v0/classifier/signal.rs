//! 信号端点提取（reference-theta-v0.md:34-36）——confirmed 走势结构 → 买卖点。
//!
//! ## 契约重锚（legacy Formal/BSPLabels + Claim9 → `Origin.BspClassification` + `Origin.CenterStates`）
//!
//! 把 confirmed 中枢 + 线段序列提取为买卖点端点（`BspPoint`）。每个端点的语义状态（对齐
//! `Origin.BspClassification.BspEndpoint` 字段）由走势结构相对中枢的位置（`Origin.CenterStates.
//! classifyPosition`）+ 背驰力度（`Origin.Divergence.IsDivergence`，由已实装 MACD 真算）bit-exact
//! 计算（非臆造）。
//!
//! ## 完整买卖点覆盖（formalization-validity-domain，★关键 L 级边界标注）
//!
//! 本工位提取**第一类 + 第三类**买卖点（confirmed 结构上**严格可判定**的两类）：
//!
//! - **第三类**（B3/S3）：reference:36「上离中枢后次级别回试低点 `>ZG`=3买；下离后回抽高点
//!   `<ZD`=3卖」是**点相对中枢核心区间的位置判据**（`Origin.BspClassification.IsType3Buy/IsType3Sell`
//!   + `Origin.CenterStates.classifyPosition`，已 bit-exact 形式化），只需 confirmed 中枢 + 后续
//!   线段端点价，**纯整数几何 L0**，零经验时序依赖。
//!
//! - **第一类**（B1/S1）：reference:34 + `Origin.BspClassification.IsType1 = brokeCenter ∧
//!   divPair.isTrend = true ∧ IsDivergence(divPair)`。**第一类 = 趋势背驰点**（A/B/C 框架，第24课:22-24 + maimai.md:103-112）。
//!   三分量分层：
//!   · **局部趋势门**（`decompose`+`center_trend_gate`，task #143）：第一类**只由趋势背驰产生**——段所在走势类型块 ≥2 同向中枢
//!     ⟹ Trend(方向)，才产第一类；1 中枢（盘整）/mixed（扩张）**不产**（盘整背驰不产第一类，
//!     beichi #4 + maimai.md:56 已结算）。**L0**（中枢同向外缘关系，纯整数几何）。这是「假背驰=
//!     假买卖点」头号缺口的修复——退化实现跳过 τ 门控，单中枢/任意段都产第一类=噪声。
//!   · **破中枢几何分量**（`brokeCenter`）：C 段端点破**最后一个中枢**核心 `[zd,zg]` 之外（买侧
//!     向下破 `< zd`，卖侧向上破 `> zg`）——纯整数比较，**L0**（608号位置三态，对齐 descend.rs
//!     `sub_broke_below`/`sub_broke_above`）。∧ **037:20 破 b 包络极值分量**（p117，裁定 T3）：
//!     c 端点必破 b（=I(A)）包络极值（下跌 `< b_lo` / 上涨 `> b_hi`，严格超越、等号排除，
//!     `move_range_envelope` 单一来源）——未破者不产第一类候选（061:28 候选资格层，含零 bit
//!     struct_break 候选也不产；rust 领先 Origin `IsType1`，Lean 侧吸收列遗留项 L1）。
//!   · **趋势背驰力度分量**（`IsDivergence`，A/B/C）：C 段（破最后中枢段）相对 **A 段（倒数第二
//!     中枢的离开段，跨相邻中枢配对）** MACD 面积**严格变小**（第24课:24「C 段面积 < A 段面积」）。
//!     ★A/C 跨相邻中枢配对（`locate_trend_seg_a`）替换退化的「任意前同向段」——A 不是序列序任意前
//!     同向段，而是趋势中相邻前一中枢的离开段（第24课:22「同向趋势之间一定有中枢连接」=B 段）。
//!     由已实装 MACD（`divergence::AbcDivergence::diverges`）**真算**（★rust 领先 Origin：Lean
//!     `divPair` 是外部参数 still-MISSING-C 无 Origin MACD 引擎，且 Lean 标 still-MISSING-C 不实装
//!     A/B/C 段结构；rust 实装 A/B/C 框架 + MACD，故背驰分量**真算非占位**，见 descend.rs 模块头）。
//!     认识论：A/C 段配对 + MACD 面积比较确定 = **L1**（管线正确性，对齐 Lean IsType1 结构合取）；
//!     「MACD 趋势背驰预测在真实行情有效」才是 **L2/L3**（否证检验，**不在本工位**，alpha 影响须
//!     统一 L3 验证）。趋势/盘整门控判据（中枢同向关系）= **L0**（纯整数几何，零经验依赖）。
//!
//! ## 第二类（B2/S2）：递归组装层提取入口 `extract_second_signals`（#52 收尾，★no-patch）
//!
//! 第二类买卖点**不在 `extract_signals`（L0 segment 层）产出**——这是诚实的**签名层**边界，
//! 不是遗漏：`IsType2 = afterTypeOne ∧ ¬brokeCenter`，且**买卖点定律一**（§10.2，第14课）：
//! 「任何级别的第二类买卖点都由次级别相应走势的**第一类**构成」。`extract_signals` 入参 `segments`
//! 是 **L0 线段**——线段是递归底（`descend.rs::RMove::Segment` 下钻得空序列），**结构上无次级别
//! 走势对象**。「次级别第一类构成」需要 `descend.rs::RMove::Compose { subs, .. }` 的递归载荷
//! （次级别走势序列）作输入——`extract_signals(centers, segments, ...)` 的签名层**拿不到**它。
//! 在 `extract_signals` 内硬产第二类 = 用本级别 `afterTypeOne` 占位冒充次级别第一类构成 =
//! 声明膨胀（禁止）。`signal_extraction_emits_no_second_class` 锁定 L0 层不产第二类的边界。
//!
//! **#52 消除「递归组装层缺口」标记**：依赖已满足——`rmove_compose.rs::find_second_type_structure`
//! （port `Origin.RMoveCompose.SecondTypeStructure`，#51 已真封）消费 RMove 递归塔，从 `descend parent`
//! 取回的次级别走势序列内识别第二类走势结构（第一类离开 m1 + 回拉段 m2 + i1<i2 时间序；回拉**不问**
//! 新不新低——#816 B-2②，破一类极值由 `retrace_breaks_extreme` 重合标注承载，不作准入分档）。
//! 本模块补**平行的递归组装层提取入口** [`extract_second_signals`]：消费 RMove 递归塔（`parent: &RMove`）
//! + B 口径中枢区间，调 `find_second_type_structure` 产 B2/S2 `BspPoint`。这**不是**在 `extract_signals`
//! 内硬产（那会声明膨胀），而是补上**递归组装层本身**——`extract_signals`（L0）与 `extract_second_signals`
//! （递归组装层）是**两个平行的提取入口**，按输入对象（L0 segment vs RMove 递归塔）分工，零冒充。
//!
//! ⟹ `extract_signals` 多声部产 B1/S1/B3/S3（消解 #5「单声部 L0 第三类」根因）；
//!    `extract_second_signals` 递归组装层产 B2/S2（消解 #5「第二类结构不可产」收尾）。
//! 下游 E5 平仓闭环（trades=0）是 L3 层（不在本工位，见 closed_loop）。
//!
//! ## ★诚实 still-MISSING（B2/S2 递归组装层提取的开口，no-声明膨胀）
//!
//! - **RMove 递归塔生产路径已接入**（still-MISSING-塔已解除，#53 升级）：`mod.rs::classify` 已把递归塔
//!   走势单元从 `UnitRange` 升级为携 subs 的 `RMove::Compose`（`recursive_tower.rs::LeveledMove`+source_index
//!   坐标侧车），`extract_second_signals`/`extract_second_for_level` 零改动真接入生产路径——端到端产 B2
//!   （`mod.rs::tests::end_to_end_second_buy_via_l1_l2_geometric`）。诚实边界（still-MISSING-窗口，codex 裁决）：
//!   B2/S2 只在 L1→L2 几何路径产，L0→L1 三段交替窗口结构上界（可背驰同向段仅位置2，非接入缺陷），
//!   见 `mod.rs::l0_level_emits_no_second_class_window_bound`。
//! - **次级别坐标 `index_of`**（still-MISSING-坐标）：`RMove`（port Lean `Move` μF）是纯结构区间，
//!   **无 source_index**。B2/S2 `BspPoint.source_index`（平局裁决+回溯，reference:16）由 `index_of`
//!   闭包提供（次级别走势→原始 K 序，上游塔构造时填）——与 `center_of`/`divergence_of` 同精神（次级别
//!   坐标/中枢/力度由上游提供，descend.rs 边界）。本模块不冒充自动坐标分配。
//! - **背驰力度引擎**（still-MISSING-C，承接 SubLevelDescent）：第一类离开 m1 的背驰由 `divergence_of`
//!   闭包提供。rust `divergence.rs` 已实装 MACD（领先 Origin），但「次级别走势→MACD 背驰」的自动配对
//!   需 RMove 塔携带各次级别走势的 close 区间——同 still-MISSING-塔，由上游塔构造时接入真 MACD。

use super::super::config::MacdConfig;
use super::super::types::{
    Center, Direction, MoveKind, Segment, Side, Stroke, ThirdClassEntryIdentity, Tick,
};
// Side 已在上行 import（judge_first_cached 用它构造 BspPoint.struct_break_dir，P2-R2）。
use super::super::types::BspBits;
use super::bsp::{endpoint_to_bsp, EndpointSituation};
use super::decompose::{
    center_block_kind, center_block_kind_at, center_block_lift, center_block_lift_at,
    center_own_dir_at, center_trend_gate, decompose, MoveBlock,
};
use super::descend::RMove;
use super::divergence::{
    self, compute_macd, departure_move_c_start, force_features, locate_departure_move_a,
    move_range_envelope, segments_diverge_or, AbcDivergence, DivergenceGauge, ForceProxies,
};
use super::retrace_ledger::{
    PanDivSubtype, RetraceKey, RetraceLedger, RetracePoint, RetraceSide, ShortRetracePortal,
    ShortRetraceRecord,
};
use super::rmove_compose::{find_second_type_structure, m2_broke_center};
use std::cell::RefCell;

/// 买卖点条目（带结构止损价，single source，见 `bsp::BspPoint`）。
pub use super::bsp::BspPoint;
/// owner 归属载体（#218 面 A，见 `bsp::OwnerRef`）。
pub use super::bsp::OwnerRef;

// ── #1176（B01）：三大判据块迁出（纯移动零行为，消费面零改）──────────────────────────
// 第一类结构门 + 一类判定 → `gates`；盘背短差观测通道 → `pan_div_short`；盘整背驰证书 →
// `cert`。此处重导出保 `signal::X` 原路径逐字不变；`extract_*` 入口族留本文件门面。
pub(crate) mod cert;
pub(crate) mod gates;
pub(crate) mod pan_div_short;

pub(crate) use cert::{
    judge_pan_div, judge_pan_div_observation, locate_pan_div_structure, pan_div_structure_extreme,
    PanDivStructure,
};
pub use cert::{PanDivCert, QuasiSecondCert};
pub(crate) use gates::{
    first_structural_gates, judge_first_cached, judge_first_from_gates, FirstStructuralGates,
};
pub(crate) use pan_div_short::{
    drain_pan_div_short_retrace_observations, pan_div_subtype_channel_reason,
    t3_in_c_grade_reason_to_pan_div_subtype, PanDivShortRetraceObservation,
};
// ★P2-R2（codex-review-20260701-2251 护栏7）：`StructBreakFeature` sidecar 已删除。
// 它从未接通生产（mod.rs 全走 `extract_signals(...).0` / `extract_signals_with_hist(...).0` 丢弃
// sidecar，零生产消费者）。macd_c_lt_a（C<A 背驰）信息**完全可从产出 BspPoint 派生**：
//   `struct_break_dir=Some ∧ (bits.buy1 ∨ bits.sell1)` ⟺ macd_c_lt_a=true（破中枢 ∧ 背驰确认）；
//   `struct_break_dir=Some ∧ 六 bit 全零`                ⟺ macd_c_lt_a=false（破中枢 ∧ 未背驰）。
// 删除死 sidecar（no-patch 死代码清除）零信息损失——R2 的 struct_break_dir 直接承载破中枢方向，
// 候选恢复方向进样本不再需要「零 bit 候选 + feature 供 χ 学 MACD」这条从未接通的迂回路径。

/// 线段端点投影（信号候选点：每条线段的终止端点 = 一个潜在买卖点）。
struct SegEnd {
    source_index: usize,
    /// 端点价（线段终止价 = 该端点的极值）。
    price: Tick,
    /// 该线段方向（向上线段端点 = 高点候选，向下 = 低点候选）。
    dir: Direction,
}

fn seg_end(s: &Segment) -> SegEnd {
    SegEnd {
        source_index: s.end_index,
        price: s.end_price,
        dir: s.direction,
    }
}

/// 把段的 `source_index`（原始 K 序）区间映射到 `closes` 序列的下标区间（MACD 段面积坐标系）。
///
/// ★坐标系一致性（formalization-validity-domain，无漂移）：段的 `start_index/end_index` 是
/// `source_index`（原始 K 序，stroke.rs:94 链）；`closes` 是 `ParseLayer.merged_bars` 的 close
/// 序列（classify 唯一可达的 close 来源）。merged_bars 各元素携带 `source_index`（合并保留起始
/// bar 原始号，单调递增）。本函数把段的 source_index 端点映射到 merged_bars **下标**，使 MACD 段
/// 面积区间与 `closes` 同坐标系——**不**跨「原始 bars / merged_bars」两序列混用（那会引入面积错位）。
///
/// `src_to_idx` 是 merged_bars 下标 → source_index 的**升序**映射（`closes[k]` 对应 `src_to_idx[k]`；
/// merged_bars source_index 单调递增，见函数头）。找首个 `>= start` 的下标 lo 与末个 `<= end` 的
/// 下标 hi。区间空（无 bar 落入）⟹ None。
///
/// ★性能（O(logS) 二分，原 O(S) 线性 `position`/`rposition`）：`src_to_idx` 升序 ⟹ 谓词 `s >= start`
/// 与 `s <= end` 都是单调前缀/后缀，用 `partition_point` 二分定位（替代每次调用 O(S) 全扫）。type1
/// 路径每段调本函数 2 次（curr + prev），原 O(S) 线性扫使 type1 退化为 O(S²)——这是 L2 profile 坐实
/// 的真 O(n²) 热点之一（与 type3 前驱重复 O(C·S) 并列）；二分后降为 O(S·logS)。
fn map_src_range_to_close_idx(
    src_to_idx: &[usize],
    start: usize,
    end: usize,
) -> Option<(usize, usize)> {
    if start > end {
        return None;
    }
    // lo = 首个 source_index >= start 的 closes 下标（升序 ⟹ `s < start` 是前缀，二分其长度）。
    let lo = src_to_idx.partition_point(|&s| s < start);
    if lo >= src_to_idx.len() {
        return None; // 无 source_index >= start（全部 < start）。
    }
    // hi = 末个 source_index <= end 的 closes 下标（升序 ⟹ `s <= end` 是前缀，末元素 = 前缀长 - 1）。
    let cnt_le_end = src_to_idx.partition_point(|&s| s <= end);
    if cnt_le_end == 0 {
        return None; // 无 source_index <= end（全部 > end）。
    }
    let hi = cnt_le_end - 1;
    if lo > hi {
        return None;
    }
    Some((lo, hi))
}

/// 某线段归属的「最近已确认中枢」（第18课定理三「该中枢」+ 第49课「当下之前最后一个中枢」）。
///
/// ★中枢归属语义（codex 异质裁决 2026-06-27，原文坐实）：第一/三类买卖点针对的中枢是该端点
/// **刚离开并首次回试的那个中枢**——即该线段在原始 K 序上**之前最后一个已确认中枢**（不是所有
/// 价格阈值更低/更高的前驱中枢）。原文依据：
/// - 第18课定理三（018:64）：「中枢破坏 = 离开**该**中枢后回抽不重新回到**该**中枢内」——单数「该中枢」。
/// - 第20课定理（020:60）：「离开缠中说禅走势中枢...回试...必须是**第一次**」——单数中枢 + 第一次。
/// - 第49课/第29课：「当下之前最后一个中枢」组织买卖点（`bsp.rs:110` BspPoint.center 注「最后中枢」）。
/// - maimai.md:103：第一类「向下跌破**最后一个**中枢」。
/// - Lean `BspClassification.BspEndpoint`（lean:75-84）只带**单一** center，`IsType3Buy/Sell` 相对该
///   **一个** center 判定（lean:117-125）。
///
/// `centers` 按 `end_index` 升序（`detect_centers_with` 非重叠扫描保证，mod.rs:136）。返回 `end_index
/// <= seg_start` 的**最后一个**中枢（该线段离开/回试时「当下之前最后一个中枢」）。无满足者 ⟹ None
/// （线段在所有中枢之前 ⟹ 无可离开/回试的中枢 ⟹ 非第一/三类）。
fn nearest_confirmed_center(centers: &[Center], seg_start: usize) -> Option<&Center> {
    // 升序 centers 上，end_index <= seg_start 的是一个前缀；取该前缀末元素 = 最近中枢。
    let hi = centers.partition_point(|c| c.end_index <= seg_start);
    if hi == 0 {
        None
    } else {
        Some(&centers[hi - 1])
    }
}

/// ★性能工位（#93）：[`nearest_confirmed_center`] 的索引版本——直接返回**最近中枢在 `centers` 中的下标**
/// 而非 `&Center`。
///
/// ★为什么需要（消解 `.position()` O(S·C) 热点）：旧主循环第一类路径在拿到最近中枢 `c` 后，用
/// `centers.iter().position(|x| x.end_index==c.end_index && x.zd==c.zd && x.zg==c.zg)` 线性扫 O(C)
/// **反查** `c` 的下标（为取 `prev_center = centers[pos-1]`）。`nearest_confirmed_center` 内部
/// `partition_point` 已算出 `hi`（前缀长）⟹ 最近中枢下标 = `hi-1`——可直接返回，无需反查。
///
/// 旧路径的 O(S·C)：每段一次 O(C) 反查 ⟹ S 段 = O(S·C)。profile 坐实（`scale_timing_position_hotspot`
/// exp≈1.98）。本索引版直接由 `partition_point` 的 `hi` 推出下标 O(1)，主循环改为本函数 ⟹ O(S·logC)
/// （partition_point 二分 O(logC)）。
///
/// ★bit-exact 不变式（**核心**）：本函数返回 `hi-1`（前缀末下标 = 最近中枢真位置）。旧 `.position()`
/// 三元组首匹配在**重复三元组**下取**更小**下标（首匹配 ≠ 前缀末）⟹ `prev_center` 不同 ⟹ 第一类输出
/// 可能不同。为严格 bit-exact，[`extract_signals`] 在主循环前预建 `first_match_idx:
/// HashMap<(end_index, zd, zg), usize>`（正向扫 `centers_sorted`，仅在 key 不存在时插入 ⟹ 保留首匹配
/// 下标，与 `.position()` 语义逐位一致），主循环用 `first_match_idx.get(&c 三元组)` 取 `pos`（O(1)）。
/// `c`（last_center）仍取 `centers_sorted[c_idx]`（最近中枢语义正确）。`bit_exact_battery_digest`
/// 测试 D（重复三元组）锁定此路径。
pub(crate) fn nearest_confirmed_center_idx(centers: &[Center], seg_start: usize) -> Option<usize> {
    let hi = centers.partition_point(|c| c.end_index <= seg_start);
    if hi == 0 {
        None
    } else {
        Some(hi - 1)
    }
}

// ── #1176（B01）：第一类结构门 + 一类判定已迁至 `signal::gates`（零行为）──────────────────

/// 第三类买卖点判定（契约锚 `Origin.BspClassification.IsType3Buy/IsType3Sell` 点位判据）。
///
/// 对相邻线段对 (leave, retest)（leave 已归属其**最近中枢** `c`，见 [`nearest_confirmed_center`]）
/// 按 reference:36 判第三类：
/// - **3买**：向上 leave 离开 `c` 上方（端点 `> c.zg`）+ 向下 retest 回试低点 `> c.zg`（不触及闭区间
///   中枢）⟹ 该回试低点 = 3 买。
/// - **3卖**：向下 leave 离开 `c` 下方（端点 `< c.zd`）+ 向上 retest 回抽高点 `< c.zd`（不触及闭区间
///   中枢）⟹ 该回抽高点 = 3 卖。
///
/// ★中枢归属（codex 裁决，第18课定理三「该中枢」）：`c` 是 leave 段刚离开的**最近中枢**——同一
/// retest 端点只相对**该一个**中枢判一次，不对所有 `zg < retest` 的前驱中枢重复产出（旧
/// `for c in centers` 的重复 bug 根源）。
///
/// bit-exact 边界：严格口径（`> zg` / `< zd`，等号排除）——retest==zg=单点重叠仍触及闭区间中枢
/// `[ZD,ZG]`（中心定理一：重叠=中枢延伸，非终结）⟹ 非第三类。逐字段对齐 Lean `IsType3Buy`
/// （`zg < retracePrice` 严格，BspClassification.lean:113）。codex 裁决 2026-06-27（中枢终结语义）。
/// ★Q7-#1 裁定C：`leave_anchor` = leave 段的方向锚资格——三类的离开/突破段须有锚（fallback ⟹
/// None ⟹ 非三类结构）。retest 段是几何回试角色（回试不触中枢的区间判据），不设锚门。
/// 第三类离开/回试的结构证书。`point` 继续是既有 BSP 单一输出；两个区间为完整 `c_p`
/// 归属边提供可追溯结构，不另起第二套第三类判据。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct ThirdClassCert {
    pub point: BspPoint,
    pub center: Center,
    pub departure_interval: (usize, usize),
    pub retest_interval: (usize, usize),
}

fn third_class_entry_identity(
    c: &Center,
    leave_seg: &Segment,
    retest_seg: &Segment,
) -> ThirdClassEntryIdentity {
    ThirdClassEntryIdentity {
        center_si: c.start_index,
        center_zd: c.zd,
        center_zg: c.zg,
        leave_interval: (leave_seg.start_index, leave_seg.end_index),
        retest_interval: (retest_seg.start_index, retest_seg.end_index),
    }
}

pub(crate) fn judge_third_cert(
    c: &Center,
    leave_seg: &Segment,
    leave_anchor: Option<Direction>,
    retest_seg: &Segment,
) -> Option<ThirdClassCert> {
    let leave = seg_end(leave_seg);
    let retest = seg_end(retest_seg);
    match (leave_anchor, retest.dir) {
        // 3 买：向上离开（leave 端点 > c.zg）+ 向下回试（retest 低点 > c.zg，不触及闭区间中枢）。
        (Some(Direction::Up), Direction::Down) if leave.price > c.zg && retest.price > c.zg => {
            let situ = EndpointSituation {
                after_first_buy: false,
                is_pullback_end: false,
                left_center: true,         // 离开最近中枢（leave.price > c.zg）
                retrace_not_reenter: true, // 回试不触及闭区间中枢（retest > c.zg，严格）
                below_last_center: false,
                is_sell_side: false,
            };
            let mut bits = endpoint_to_bsp(&situ);
            bits.third_class_entry = Some(third_class_entry_identity(c, leave_seg, retest_seg));
            Some(ThirdClassCert {
                point: make_third_point(retest.source_index, bits, retest.price, c),
                center: *c,
                departure_interval: (leave_seg.start_index, leave_seg.end_index),
                retest_interval: (retest_seg.start_index, retest_seg.end_index),
            })
        }
        // 3 卖：向下离开（leave 端点 < c.zd）+ 向上回抽（retest 高点 < c.zd，不触及闭区间中枢）。
        (Some(Direction::Down), Direction::Up) if leave.price < c.zd && retest.price < c.zd => {
            let situ = EndpointSituation {
                after_first_buy: false,
                is_pullback_end: false,
                left_center: true,
                retrace_not_reenter: true,
                below_last_center: false,
                is_sell_side: true,
            };
            let mut bits = endpoint_to_bsp(&situ);
            bits.third_class_entry = Some(third_class_entry_identity(c, leave_seg, retest_seg));
            Some(ThirdClassCert {
                point: make_third_point(retest.source_index, bits, retest.price, c),
                center: *c,
                departure_interval: (leave_seg.start_index, leave_seg.end_index),
                retest_interval: (retest_seg.start_index, retest_seg.end_index),
            })
        }
        // 同向相邻（无回试）/破中枢方向不符/触及中枢：非第三类结构。
        _ => None,
    }
}

fn judge_third(
    c: &Center,
    leave_seg: &Segment,
    leave_anchor: Option<Direction>,
    retest_seg: &Segment,
) -> Option<BspPoint> {
    judge_third_cert(c, leave_seg, leave_anchor, retest_seg).map(|cert| cert.point)
}

/// ★R1（2026-07-17 代理裁定，p112 实证 + doc-trend §2）：趋势背驰 c 内含对最后中枢 B 的
/// 第三类买卖点（037:18 必要合取项）。判据 = [`judge_third_cert`] 几何**去 anchor 门**
/// （anchor 门是 Q7-#1 工程资格，非教义；p112 §2-T3 同口径）：从 `max(c_start, last.end_index)`
/// 起向未来扫紧邻段对，找首个「leave 同趋势方向且端点破核心（Up: >zg / Down: <zd）∧ retest
/// 反向且端点不重回核心」对，回试段允许落在旧 turn（#105 单腿 seg_c.1）之后——**全离开段口径**
/// （037:22，p112 T3_ext 机械化 `third_class_extended` 同构），两端点以 `as_of` 界（禁前视）。
///
/// 返回首个命中 `(leave.end_index, retest.end_index)`；无命中 ⟹ None（c 未确立，037:18 否则
/// 条款「按盘整背驰处理」的适用域）。
pub(crate) fn trend_third_class_in_c(
    segments: &[Segment],
    last: &Center,
    direction: Direction,
    c_start: usize,
    as_of: usize,
) -> Option<(usize, usize)> {
    let lo = segments.partition_point(|s| s.start_index < c_start.max(last.end_index));
    let hi = segments.partition_point(|s| s.end_index <= as_of);
    let win = &segments[lo..hi];
    for pair in win.windows(2) {
        let (leave, retest) = (&pair[0], &pair[1]);
        if leave.direction != direction || retest.direction == direction {
            continue;
        }
        let hit = match direction {
            Direction::Up => leave.end_price > last.zg && retest.end_price > last.zg,
            Direction::Down => leave.end_price < last.zd && retest.end_price < last.zd,
        };
        if hit {
            return Some((leave.end_index, retest.end_index));
        }
    }
    None
}

/// T3-in-c 固定首对分级器五桶 Missing 原因（#606 S1，ADR 补充十五/十六）。
///
/// ★#885 S4-d：`pub(crate)` → `pub`——否则域记录进 [`super::LevelState`]（pub 字段）后
/// 通道词汇须同级可见，不构成新判据（语义逐字未动）。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum T3InCGradeReason {
    /// 中枢框右边（`start_index >= last_center.end_index`，含等值）无任何段。
    MissingLeave,
    /// leave 之后无紧随段（连续缺口单腿 c）。
    MissingRetest,
    /// leave 与 retest 方向相同（非互反，未构成离开/回试对）。
    SameDirection,
    /// leave 端点未严格破该框 ZG/ZD（未离开核心）。
    LeaveNotOutside,
    /// retest 端点重回该框核心（未能保持在核心之外）。
    RetestReentered,
}

/// #607 S2 D5（counterfactual 反证）：`THETA_T3INC_SKIP` 强制跳过 [`judge_first_cached`] 内
/// T3-in-c 合取——否则域点恢复 #606 前旧行为（仍置一类 bit）。读一次缓存（热路径零 syscall，
/// 同 `classifier::mod::CASCADE_EPROBE` OnceLock 先例）；进程级 env，测试内不跨用例翻转。
static T3_IN_C_SKIP: std::sync::OnceLock<bool> = std::sync::OnceLock::new();

fn t3_in_c_skip_enabled() -> bool {
    *T3_IN_C_SKIP.get_or_init(|| {
        std::env::var(crate::theta_v0::env_registry::THETA_T3INC_SKIP)
            .map(|v| {
                matches!(
                    v.as_str(),
                    "1" | "true" | "TRUE" | "yes" | "YES" | "on" | "ON"
                )
            })
            .unwrap_or(false)
    })
}

/// T3-in-c 固定首对分级判定结果。（★#885 S4-d：可见性随 [`T3InCGradeReason`] 同步放 `pub`。）
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum T3InCGrade {
    /// 固定首对命中：leave/retest 区间（`start_index, end_index`）。
    Present {
        leave_interval: (usize, usize),
        retest_interval: (usize, usize),
    },
    Missing(T3InCGradeReason),
}

/// **T3-in-c 固定首对分级器**（D1，ADR 补充十五「共享枢轴坐标系」+ 补充十六裁定同源）。
///
/// ★#1229 裁定 a（2026-08-25）退役：本函数**不再作生产准入判据**——`judge_first_from_gates`
/// 的 T3-in-c 合取已统一走 [`trend_third_class_in_c`] 全窗后扫（037:18「至少一个」语义）。
/// 本函数与 [`T3InCGrade`]/[`T3InCGradeReason`] 仅保留为**诊断词汇**（对拍退役口径 / 通道
/// 词汇），生产调用方为零。
///
/// 判定锚 = **最后中枢 `last_center` 右边**（`start_index >= last_center.end_index`，含等值即
/// 紧邻）——**不是** `λ_C`/`c_start`。leave = 该锚之后固定第一条段，retest = 紧随一条；方向
/// 互反；价格严格对该框 `ZG`/`ZD`（Up：`leave.end_price > zg ∧ retest.end_price > zg`；Down
/// 镜像 `< zd`）。任一失败即 `Missing`，**不后扫**。
pub(crate) fn t3_in_c_fixed_first_pair(
    segments: &[Segment],
    last_center: &Center,
    direction: Direction,
) -> T3InCGrade {
    let anchor = segments.partition_point(|s| s.start_index < last_center.end_index);
    let Some(leave) = segments.get(anchor) else {
        return T3InCGrade::Missing(T3InCGradeReason::MissingLeave);
    };
    let Some(retest) = segments.get(anchor + 1) else {
        return T3InCGrade::Missing(T3InCGradeReason::MissingRetest);
    };
    if leave.direction == retest.direction {
        return T3InCGrade::Missing(T3InCGradeReason::SameDirection);
    }
    let leave_outside = match direction {
        Direction::Up => leave.end_price > last_center.zg,
        Direction::Down => leave.end_price < last_center.zd,
    };
    if !leave_outside {
        return T3InCGrade::Missing(T3InCGradeReason::LeaveNotOutside);
    }
    let retest_outside = match direction {
        Direction::Up => retest.end_price > last_center.zg,
        Direction::Down => retest.end_price < last_center.zd,
    };
    if !retest_outside {
        return T3InCGrade::Missing(T3InCGradeReason::RetestReentered);
    }
    T3InCGrade::Present {
        leave_interval: (leave.start_index, leave.end_index),
        retest_interval: (retest.start_index, retest.end_index),
    }
}

/// T3-in-c 全窗后扫分级（#1229 裁定 a 统一后，037:18「至少一个」语义）。
///
/// [`trend_third_class_in_c`] 的命中折叠：`Present` = c 全窗 `[c_start, as_of]` 内存在对 B 的
/// 第三类买卖点对（leave/retest 区间）；`Missing` = 全窗无命中（037:18 否则条款域）。不再细分
/// 失败原因——固定首对五桶是已退役判据的诊断词汇（[`T3InCGrade`]），非本分级的一部分。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum T3InCScan {
    /// 全窗后扫命中：leave/retest 区间（`start_index, end_index`）。
    Present {
        leave_interval: (usize, usize),
        retest_interval: (usize, usize),
    },
    /// 全窗后扫无命中（c 未含第三类买卖点，037:18 否则条款域）。
    Missing,
}

/// #1229 裁定 a：把 [`trend_third_class_in_c`] 的后扫结果折成统一 T3-in-c 分级（全窗后扫）。
///
/// `trend_third_class_in_c` 只回 `(leave.end_index, retest.end_index)`；本函数按终点反查真实段
/// 补 `start_index`（段终点在 `segments` 内唯一——段序列共享端点且严格递增）。命中回退成
/// `Missing` 是不可达分支（扫描器只回它亲眼在窗内看到的段终点）。
pub(crate) fn t3_in_c_scan_grade(
    segments: &[Segment],
    last: &Center,
    direction: Direction,
    c_start: usize,
    as_of: usize,
) -> T3InCScan {
    match trend_third_class_in_c(segments, last, direction, c_start, as_of) {
        Some((leave_end, retest_end)) => {
            let leave = segments.iter().find(|s| s.end_index == leave_end);
            let retest = segments.iter().find(|s| s.end_index == retest_end);
            match (leave, retest) {
                (Some(leave), Some(retest)) => T3InCScan::Present {
                    leave_interval: (leave.start_index, leave.end_index),
                    retest_interval: (retest.start_index, retest.end_index),
                },
                _ => {
                    debug_assert!(false, "trend_third_class_in_c 命中必回真实段终点");
                    T3InCScan::Missing
                }
            }
        }
        None => T3InCScan::Missing,
    }
}

/// 一类点 T3-in-c 全窗后扫分级观测记录（#606 S1 第三修复车挂点；#1249 起分级器统一为
/// [`trend_third_class_in_c`] 全窗后扫，037:18「至少一个」语义）。
///
/// 每条记录对应一个当前生产口径下已产出的一类点（`buy1 ∨ sell1`）在 [`t3_in_c_scan_grade`]
/// 下的一次分级（`Present` 与 `Missing` 均记录，非只记否则域）。键唯一：
/// `(level, source_index, side, center_start_index, center_zd, center_zg)`；一一对应：生产
/// `bsp` 中每个 `buy1 ∨ sell1` 点恰产一条本记录（无重复判定、无遗漏）。
///
/// `level` 是**真实调用级别**，非占位：`mod.rs` 逐级循环本就持有 `level_idx`，经
/// [`extract_first_third_resume`] 的 `level: u32` 参数穿透到 [`judge_segment`]，捕获时直接
/// 写入本字段——不再有事后按 `(source_index,side,center)` 反查 `classification.levels[lvl].bsp`
/// 补齐级别的机器（旧版反查在多级巧合同签名时会误配/静默丢记录，见
/// [`crate::theta_v0::backtest::opsem_dump`] 模块头谱系注记）。
///
/// ★#885 S4-d（可见性放 `pub` + level 盖章口径补充）：本记录新增**生产 sink 通道**——
/// [`judge_first_cached`] 按 `diverged` 无条件捕获（不再只落诊断 sidecar），经提取入口一路上
/// 穿进 [`super::LevelState::first_class_grades`]。全量入口（`level=None`）捕获时本字段先落
/// 占位 0，由 `Classification` 装配方（`classify_impl` / 增量塔级别循环）按真实级别盖章——
/// `LevelState` 本身按 Vec 下标即级别，盖章是诚实补齐而非改判。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FirstClassGradeRecord {
    pub level: u32,
    pub source_index: usize,
    pub side: Side,
    /// 中枢身份（判定 `last_center`，取自该点自身 `BspPoint.center`，非重新查找）。
    pub center_start_index: usize,
    pub center_end_index: usize,
    pub center_zd: Tick,
    pub center_zg: Tick,
    pub grade: T3InCScan,
}

thread_local! {
    /// #606 S1 第三修复车：一类点 T3-in-c 分级 sidecar 捕获槽。`None`（默认，生产恒态）⟹
    /// [`judge_segment`] 挂点读一次 `Cell`（`is_none()`）即返回，零成本；`Some` 仅由
    /// [`otherwise_domain_sidecar_begin`]（env 门控，同 opsem sidecar 先例）在诊断复放前打开。
    ///
    /// 纯传递通道（`Vec`，push 序）——每条记录捕获时已携带真实 `level`（调用者传参穿透，见
    /// [`FirstClassGradeRecord`] 文档），无需在此按签名分组或做候选级别分配；跨帧 upsert 折叠
    /// （"保留最新一次判定"）在收尾阶段按完整身份键（含 `level`）进行，见
    /// [`crate::theta_v0::backtest::opsem_dump::OtherwiseDomainSidecarCollector::observe_frame`]。
    static GRADE_SIDECAR: RefCell<Option<Vec<FirstClassGradeRecord>>> = RefCell::new(None);
}

/// 打开一类点分级 sidecar 捕获（诊断专用，调用方负责 env 门控）。
pub(crate) fn otherwise_domain_sidecar_begin() {
    GRADE_SIDECAR.with(|c| *c.borrow_mut() = Some(Vec::new()));
}

/// 关闭并取走已捕获记录（每条记录的 `level` 是捕获时真实调用级别，非占位）。未 `begin` 时
/// 返回空 Vec。
pub(crate) fn otherwise_domain_sidecar_take() -> Vec<FirstClassGradeRecord> {
    GRADE_SIDECAR.with(|c| c.borrow_mut().take().unwrap_or_default())
}

/// ★S2 fix2 F1 回归测试专用：只读探针，是否仍在捕获态（`GRADE_SIDECAR.is_some()`）。
/// 不消费槽内容（不同于 [`otherwise_domain_sidecar_take`]）——纯粹用于断言 `finish()` 后
/// thread_local 是否已正确收回 `None`。
#[cfg(test)]
pub(crate) fn otherwise_domain_sidecar_is_active() -> bool {
    GRADE_SIDECAR.with(|c| c.borrow().is_some())
}

// ── #1176（B01）：盘背短差观测通道已迁至 `signal::pan_div_short`（零行为）──────────────────

/// 构造第一类 BspPoint（结构止损价 = pivot 极值，reference:46——1 类止损用 pivot 非 center.zg/zd）。
///
/// 1/2 类止损取 `pivot_low`(买)/`pivot_high`(卖)（破中枢段端点极值），非 center.zg/zd（那是 3 类）。
/// pivot 按 bit 方向填，另一侧 0。
///
/// ★owner 载体（关③ 补记 2026-07-18 ② 路径 (a) 起构造时填载；#218 面 A 载体形态 =
/// [`OwnerRef::Center`]）：`center = Some(OwnerRef::Center(*c))`，`c` = 判定中枢
///（`judge_first_cached` 的 `last_center`——被破的最后中枢，即本趋势 a+A+b+B+c 的 B
/// 同型对象）。一类归属参照 = 中枢（同级别，与事件 B 同型），教义已对齐（#211 在案）。
/// center 是 Trend 域 owner 判同（核心区间 `(zd,zg)` 带判同，nest.rs `terminal_bits_in_book`
/// Trend 域）的载体与回溯锚，**不进止损判据**（止损仍 pivot，语义不变）。
///
/// ★P2-R2（p2-plan §2）：`struct_break_dir=Some(破中枢方向)`——由 [`judge_first_cached`] 传入
/// （买侧向下破=Long，卖侧向上破=Short），**与 bits 是否置 buy1/sell1 无关**。零 bit 破中枢候选
/// （C≥A 未背驰）靠此字段在 `candidate_dir` 恢复方向进样本（消选择偏差）。pivot 仍按 bit 方向填
/// （零 bit ⟹ 两侧 0，止损源留待背驰确认——未背驰候选不置 buy1，无 1 类 pivot 止损语义）。
fn make_first_point(
    source_index: usize,
    bits: BspBits,
    pivot_price: Tick,
    c: &Center,
    struct_break_dir: Option<Side>,
    force: Option<ForceProxies>,
) -> BspPoint {
    BspPoint {
        source_index,
        bits,
        // 1 买止损源 pivot_low（破中枢低点）；1 卖止损源 pivot_high（破中枢高点）。
        pivot_low: if bits.buy1 { pivot_price } else { 0 },
        pivot_high: if bits.sell1 { pivot_price } else { 0 },
        center: Some(OwnerRef::Center(*c)), // owner 载体（#218 面 A 形态）：被破的最后中枢构造时填载
        struct_break_dir,
        // ★β^div 力度（beta-route #115）：一类趋势背驰候选的 A/C 段 5 proxy（有 dif/closes_tick 输入时
        // Some，否则 None）——单一来源就在此字段，经 Candidate.force 透传（A6 #159）由 selector
        // z_of_candidate 读进 force_state。
        force,
        retrace_breaks_type1: None, // #816 B-2② 重合标注仅二类点有（一/三类 None）
    }
}

/// 构造第三类 BspPoint（结构止损价 single source）。
///
/// 3 类止损取 `center.zg`(买)/`zd`(卖)，故 center 必 `Some`（不变量：含 3 类 bit ⟹ center
/// 有值）。pivot_low/pivot_high 取回试端点价（买点回试低点 = pivot_low，卖点 = pivot_high）。
fn make_third_point(
    source_index: usize,
    bits: BspBits,
    retest_price: Tick,
    c: &Center,
) -> BspPoint {
    BspPoint {
        source_index,
        bits,
        // 买点回试低点 → pivot_low；卖点回抽高点 → pivot_high。按 bit 方向填，另一侧 0。
        pivot_low: if bits.buy3 { retest_price } else { 0 },
        pivot_high: if bits.sell3 { retest_price } else { 0 },
        center: Some(OwnerRef::Center(*c)), // owner 载体（#218 面 A 形态）：所离开回抽的中枢构造时填载
        struct_break_dir: None, // 第三类=离开后回抽，非破中枢结构候选（P2-R2 语义：None）
        force: None,            // 第三类无 A/C 趋势段对 ⟹ 无力度 proxy（诚实 None，231号）
        retrace_breaks_type1: None, // #816 B-2② 重合标注仅二类点有（一/三类 None）
    }
}

/// 构造第二类 BspPoint（结构止损价 = 回拉走势结束点，reference:46 1/2 类止损 = pivot）。
///
/// 第二类止损（reference:46，与第一类同列）：1/2 买止损 = `pivot_low`，1/2 卖止损 = `pivot_high`
/// ——非 `center.zg/zd`（那是第三类）。`second_point` = `SecondTypeStructure.second_point`（回拉走势
/// 结束点：买侧 = 回拉低点 m2.lo / 卖侧 = 回拉高点 m2.hi，§10.1），按 bit 方向填 pivot，另一侧 0。
///
/// ★#218 面 A（spec owner-attribution-fix-20260724 ID-1；#211 路线 B + v2 教义修订）：
/// 归属载体从「次级别中枢 c1」（确认层对象，归属/确认混载 = 级别错配根因）改载
/// **该走势的一类点身份锚**（[`OwnerRef::Type1Anchor`]，`type1_src` = 第一类离开走势 m1 的
/// 终点坐标 = 该走势终点极值点 = 一类点，区间套恰好存在）。二类归属参照只挂该走势一类点
///（★#816 B-2②：归属不问跌破与否——回拉可破一类极值，`101:32`【正文】），与本级别中枢无关；
/// 确认层识别（c1/i1/i2/背驰）一个 bit 不动。
/// 锚 =（极值价, 合并组锚）由 nest 核内经 T1 oracle 判定时解析（本层只载坐标），
/// **不进止损判据**（止损仍 pivot，语义不变）。
///
/// ★#816 B-2② 重合标注：`retrace_breaks_type1: Some(retrace_breaks_type1)`——回拉是否破一类
/// 极值的重合身份标注（「一般都构成盘整背驰」，语义归 #817），**不作准入分档**（判据不得以
/// 「回拉不创新低/新高」为必要条件；硬闸已由 #884 拆）。
fn make_second_point(
    source_index: usize,
    bits: BspBits,
    second_point: Tick,
    type1_src: usize,
    retrace_breaks_type1: bool,
) -> BspPoint {
    BspPoint {
        source_index,
        bits,
        // 2 买止损源 pivot_low（回拉低点）；2 卖止损源 pivot_high（回拉高点）。
        pivot_low: if bits.buy2 { second_point } else { 0 },
        pivot_high: if bits.sell2 { second_point } else { 0 },
        center: Some(OwnerRef::Type1Anchor(type1_src)), // #218 面 A：归属载体 = 该走势一类点锚坐标
        struct_break_dir: None, // 第二类=中枢内部回拉，非破中枢结构候选（P2-R2 语义：None）
        force: None,            // 第二类无 A/C 趋势段对 ⟹ 无力度 proxy（诚实 None，231号）
        retrace_breaks_type1: Some(retrace_breaks_type1), // #816 B-2② 重合标注（不作准入分档）
    }
}

// ── #1176（B01）：盘整背驰证书与判定已迁至 `signal::cert`（零行为）──────────────────

/// 第二类买卖点提取（递归组装层入口，契约锚 `Origin.RMoveCompose.SecondTypeStructure` +
/// `Origin.BspClassification.IsType2`；买卖点定律一 §10.2 + 第14/15课）。
///
/// ★与 `extract_signals`（L0 segment 层）平行的**递归组装层提取入口**：`extract_signals` 入参是
/// L0 线段（递归底，无次级别走势对象 ⟹ 不可产第二类）；本函数入参是 **RMove 递归塔** `parent`
/// （`RMove::Compose`，携 `descend parent` = 次级别走势序列），故**能**产第二类——第二类 =
/// 次级别第一类构成（§10.2「任何级别的第二类由次级别相应走势的第一类构成」，第14课买点定律一）。
///
/// 语义（消费 `find_second_type_structure` 识别的第二类走势结构）：
/// - **B2**（side=Long）：第一类离开走势后，次级别**回拉段**（首个后继走势，**不问**新不新低——
///   #816 B-2②：判据不得以「回拉不创新低/新高」为必要条件，`101:32`【正文】跌破一买「这是完全
///   可以的」）的结束点（§10.1「第一类买点后次级别上涨结束、再次下跌的那个次级别走势的结束点」）。
/// - **S2**（side=Short）：镜像——第一类离开后的回抽段结束点（同样不问新不新高）。
/// - 回拉是否破一类极值 = [`SecondTypeStructure::retrace_breaks_extreme`] → `BspPoint.retrace_breaks_type1`
///   重合标注（「一般都构成盘整背驰」的重合身份，语义归 #817），**不作准入分档**。
/// - 回拉是否再破中枢 = [`m2_broke_center`]（方向敏感：
///   买侧 `m2.lo < c1.zd` / 卖侧 `c1.zg < m2.hi`）→ `EndpointSituation.below_last_center`
///   （= Lean `brokeCenter`，#1291 G5 F-2 从常量 `false` 换真检查）——同款**标注面**，不作准入
///   分档（B-2② 口径一致性：`is_second` 判据不含 `below_last_center`）。
///
/// `find_second_type_structure(parent, side, center_of, divergence_of)` 在 `descend parent` 内识别
/// `SecondTypeStructure { i1, i2, second_point, retrace_breaks_extreme }`（i1=第一类离开，i2=回拉段
/// =首个后继，i1<i2 时间序；second_point=回拉走势结束点）。识别出 ⟹ 产一个 B2/S2 端点
/// （`is_second = after_first_buy ∧ is_pullback_end`，对齐 `IsType2 = afterTypeOne ∧ ¬brokeCenter`
/// 的准入形）；`below_last_center`（= `brokeCenter`）另由方向敏感真检查载真值（#1291 G5 F-2），
/// 作标注面不进准入（见上条）。否则空。
///
/// ★坐标 still-MISSING（见模块头）：`RMove`（port Lean `Move` μF）无 source_index——`BspPoint.source_index`
/// 由 `index_of` 闭包提供（次级别走势 → 原始 K 序，上游塔构造时填，与 `center_of`/`divergence_of` 同
/// 精神）。本函数不冒充自动坐标分配（在 RMove 上硬造 source_index = 声明膨胀）。
///
/// `c1`：第二类的次级别第一类离开走势所破的中枢（B 口径核心区间 [zd,zg]，迁主塔 637 定稿；
/// `center_of` 给次级别每走势配中枢，本入口对识别出的第一类离开走势用 `c1` 统一，同 descend.rs 边界）。
/// **c1 只是确认层判定中枢（识别用）**——#218 面 A 后不再充归属载体：二类点的归属载体 =
/// 该走势一类点身份锚（识别出的 `i1` 第一类离开走势终点坐标，经 `index_of` 供给，零新入参；
/// v2 教义修订：二类归属参照 = 该走势一类点，回拉不破一类极值，与本级别中枢无关）。
/// `divergence_of`：每个次级别走势的 MACD 背驰判定（rust 真算，divergence.rs；力度领先 Origin）。
/// `index_of`：每个次级别走势 → 原始 K 序号（坐标 still-MISSING，上游塔提供）。
pub fn extract_second_signals(
    parent: &RMove,
    side: Side,
    c1: &Center,
    divergence_of: impl Fn(&RMove) -> bool,
    index_of: impl Fn(&RMove) -> usize,
) -> Vec<BspPoint> {
    // 在 RMove 递归塔的次级别走势序列内识别第二类走势结构（第一类离开 + 回拉段 + i1<i2；
    // 回拉**不问**新不新低——#816 B-2②，破极值由 structure.retrace_breaks_extreme 标注）。
    // center_of 对识别用的第一类离开走势统一配 c1（次级别中枢，B 口径核心区间，上游塔提供）。
    let Some(structure) = find_second_type_structure(parent, side, |_m| *c1, &divergence_of) else {
        // 无第二类走势结构（无第一类离开 / 无后继回拉段）⟹ 无 B2/S2（诚实空）。
        return Vec::new();
    };
    let subs = super::descend::descend(parent);
    // 第一类离开走势 m1（结构识别出的 i1 位置）——该走势的一类点 = m1 终点极值点（区间套
    // 恰好存在：该走势终点 = 一类点）；坐标经既有 index_of 供给（#218 面 A 归属载体，零新入参）。
    let m1 = &subs[structure.i1];
    // 回拉走势 m2（结构识别出的 i2 位置）——第二类买卖点 = 其结束点 = structure.second_point。
    let m2 = &subs[structure.i2];
    let is_sell = matches!(side, Side::Short);
    // 第二类端点语义：after_first_buy（第一类离开在前，IsType2 的 afterTypeOne）∧ is_pullback_end
    //（回拉走势结束点，回拉未再破中枢 = IsType2 的 ¬brokeCenter）。
    let situ = EndpointSituation {
        after_first_buy: true, // 第一类离开走势在前（structure.i1 < i2，§10.1「第一类后」）
        is_pullback_end: true, // 回拉走势结束点（#816 B-2②：不问新不新低，破极值走标注）
        left_center: false,    // 第二类是中枢内部回拉，非第三类的离开后回抽
        retrace_not_reenter: false,
        // #1291 G5 F-2：`below_last_center`（= Lean `brokeCenter`）从常量 `false` 换方向敏感
        // 真检查——m2 是否再破第一类离开所破的中枢 c1（买侧跌破下沿 zd / 卖侧升破上沿 zg）。
        // ★不作准入分档（B-2② 口径一致性）：`is_second` 判据不含本字段，回拉再破中枢仍产二类
        // 点；本字段只作破中枢读数（未持久化到 BspPoint，无下游标注消费者），语义归 #817 同族。邻接缺口随票记档。
        below_last_center: m2_broke_center(side, m2, c1),
        is_sell_side: is_sell,
    };
    let bits = endpoint_to_bsp(&situ);
    // source_index 由 index_of 取回拉走势 m2 的原始 K 序（坐标 still-MISSING，上游塔提供）。
    // ★#218 面 A：归属载体改载该走势一类点身份锚（m1 终点坐标 = index_of(m1)）——归属/确认
    // 分层：识别层（c1/i1/i2/背驰）一个 bit 不动，仅归属载体的填载内容换（spec ID-1）。
    vec![make_second_point(
        index_of(m2),
        bits,
        structure.second_point,
        index_of(m1),
        structure.retrace_breaks_extreme, // #816 B-2② 重合标注透传（不作准入分档）
    )]
}

/// 从 confirmed 中枢序列 + 线段序列 + close 序列提取该级别全部买卖点（reference:34-36）。
///
/// 对每个中枢，取其 `end_index` 之后的线段子序列，提取**第一类**（趋势背驰，A/B/C 框架）+
/// **第三类**（离开后回试不破）买卖点。买卖点按 source_index 升序返回（reference:16 平局裁决——
/// 已确认结构不回写，时间序天然升序）。
///
/// ★第一类 = 趋势背驰（A/B/C 框架，第24课:22-24 + maimai.md:103-112，消解 grammar-audit 头号缺口）：
/// 本函数在 L0 层从 `centers` 派生走势类型分解（[`decompose`]，Q1/Q8），**只在段所在块为 Trend 时产第一类**——
/// A 段 = 倒数第二中枢离开段，C 段 = 破最后中枢段，C段面积<A段面积（跨相邻中枢配对，非退化的「任意
/// 前同向段」）。盘整（Consolidation）/退化（mixed/扩张）τ **不产第一类**（盘整背驰不产第一类，
/// beichi #4 + maimai.md:56 已结算）。这是「假背驰=假买卖点」头号缺口的修复点。
///
/// ★第二类（B2/S2）**不在本函数产出**——本函数入参是 L0 线段（递归底，无次级别走势对象 ⟹ 结构
/// 上不可产第二类，签名层边界，见模块头）。B2/S2 由平行的递归组装层入口 [`extract_second_signals`]
/// 产（消费 RMove 递归塔的 `SecondTypeStructure`）——按输入对象分工，非本函数缺口，零冒充。
///
/// `closes`：close 序列（`ParseLayer.merged_bars` 的 close，MACD 算趋势背驰用）。
/// `close_src`：closes 各元素的 source_index（merged_bars 锚点，段区间坐标系转换用）。
/// `macd_cfg`：MACD 参数（fast/slow/signal，从 ThetaConfig.macd 读）。
///
/// ★本函数覆盖：B1/S1（趋势背驰 A/B/C 框架）+ B3/S3（confirmed 结构几何）。
/// B2/S2 见 [`extract_second_signals`]（递归组装层）。
pub fn extract_signals(
    centers: &[Center],
    segments: &[Segment],
    closes: &[f64],
    close_src: &[usize],
    macd_cfg: &MacdConfig,
) -> Vec<BspPoint> {
    // MACD hist（趋势背驰真算，浮点域隔离在 divergence.rs）。空 closes ⟹ 空 hist ⟹ 第一类结构候选
    // 不产（段无法映射 closes 区间 ⟹ 无 C<A 判据），第三类仍正常产（纯整数几何）。
    let hist = compute_macd(closes, macd_cfg).hist;
    // 简易入口传空 dif/closes_tick ⟹ 各点 force=None（此入口不算力度；GOLDEN 电池走此路，force 恒 None
    // ⟹ 结构 bit-exact，仅 Debug 多 `, force: None` 常量，见 digest guard 诚实重算说明）。
    // BspPoint 投影（.0）：PanDiv 证书唯一真值源在 extract_signals_with_hist（生产 classify 直调它
    // 消费 .1；本简易/测试入口只投影结构 bit 点，非第二套真值）。分级记录 sink（#885）在本简易
    // 入口同样只落即弃——生产可查载体走 classify 装配链（`LevelState.first_class_grades`）。
    extract_signals_with_hist(
        centers,
        segments,
        &hist,
        &[],
        &[],
        close_src,
        DivergenceGauge::MacdArea,
        &[],
        &mut Vec::new(),
    )
    .0
}

/// 力度离线入口（force-proxy-survey-20260702.md）：与 [`extract_signals`] 同产 BspPoint，但传真
/// dif/closes_tick ⟹ 一类趋势背驰候选的 `point.force` 算得 `Some`（A/C 段可配对，5 proxy）；第二/
/// 三类无 A/C 对 ⟹ `point.force=None`。供 W-VERIFY(#13) 多 proxy 交叉验证读 `p.force`。
///
/// **认识论 L1**（formalization-validity-domain 231号）：段坐标→proxy 是确定性算术（管线正确性）。
/// **不改 buy1 判据**（class_index 冻结，671 力度=feature 非 veto）：返回的 BspPoint 结构字段（六
/// bit/pivot/center/struct_break_dir）与 [`extract_signals`] 逐字段相同（`PartialEq` 排除 force），
/// force 是旁挂量，不进任何 bit 判定。**与生产热路径同接线**（beta-route #115 后，增量路径亦传真 dif）。
pub fn extract_signals_force(
    centers: &[Center],
    segments: &[Segment],
    closes: &[f64],
    close_src: &[usize],
    macd_cfg: &MacdConfig,
) -> Vec<BspPoint> {
    let series = compute_macd(closes, macd_cfg);
    // closes 是 merged_bars.close(Tick) 的 as f64（mod.rs:217），整值往返 as i64 精确（振幅=tick 差）。
    let closes_tick: Vec<Tick> = closes.iter().map(|&c| c as Tick).collect();
    // BspPoint 投影（.0，同 extract_signals 注）：PanDiv 真值源在 with_hist，生产路径消费 .1。
    // 分级记录 sink（#885）本入口只落即弃（同 extract_signals 注）。
    extract_signals_with_hist(
        centers,
        segments,
        &series.hist,
        &series.dif,
        &closes_tick,
        close_src,
        DivergenceGauge::MacdArea,
        &[],
        &mut Vec::new(),
    )
    .0
}

/// 增量 MACD 接入点（231号纯性能，bit-exact 铁律）：与 [`extract_signals`] 同逻辑，但接受
/// 预计算 `hist`（由调用方增量产出，避免全量 `compute_macd` 重算）。这是**第一/三类买卖点提取的
/// core**（[`extract_signals`] 委托本函数，只差 hist 来源：全量 `compute_macd` vs 增量缓存）。
///
/// `hist` 须与 `compute_macd(closes, macd_cfg).hist` 逐元素 bit-identical（ac75d4b3 已证
/// `MacdState::append` bit-exact）。调用方负责 hist 的增量产出与缓存（见
/// `classify_incremental` 的 `compute_macd_hist_incremental`）。
///
/// ★P2-R2（codex-decide-20260701-2121 → p2-plan §2）：破中枢结构候选（趋势 ∧ 破最后中枢 ∧ A/C 可
/// 配对）全部进样本（消选择偏差），背驰确认（C<A）置 buy1/sell1，未背驰置零 bit + `struct_break_dir`
/// （下游 candidate_dir 恢复方向）。**不再产 StructBreakFeature sidecar**（护栏7 死代码删除，macd_c_lt_a
/// 可从 BspPoint 派生，见模块头）。
pub fn extract_signals_with_hist(
    centers: &[Center],
    segments: &[Segment],
    hist: &[f64],
    dif: &[f64],
    closes_tick: &[Tick],
    close_src: &[usize],
    gauge: DivergenceGauge,
    strokes: &[Stroke],
    grade_sink: &mut Vec<FirstClassGradeRecord>,
) -> (Vec<BspPoint>, Vec<PanDivCert>) {
    // L0 入口：线段有内在缠论方向 ⟹ 锚方向 ≡ 结构方向（域定理）。Q7-#1 裁定C 的锚门只约束
    // 级别-N fallback 单元（经 [`extract_signals_with_hist_anchored`] 传 provenance 派生锚）。
    // p117 后级别-N 第一类路径亦消费结构方向锚（见下函数头注），L0 两口径恒等不受影响。
    extract_signals_with_hist_anchored(
        centers,
        segments,
        None,
        None,
        hist,
        dif,
        closes_tick,
        close_src,
        gauge,
        strokes,
        grade_sink,
    )
}

/// ★ADR 补充十三 / #486 / Spec #485（承接 Q7-#1 裁定C）：`anchor_dirs[i]` 是
/// `segments[i]` 在本入口使用的方向锚。整参 `None` = L0（段结构方向即锚方向）；L≥1 生产调用由
/// `extract_first_third_for_level` 传入单元结构方向。endpoint provenance fallback 只保留在上游
/// 平行数组/诊断中，不再否决 A 段、C 段/破中枢段或三类 leave 段。盘整背驰路径
/// （[`judge_pan_div`]）仍恒用 `anchors_self`。
///
/// ★p117 + #486：[`judge_segment`] 的第一类路径消费 `anchors_self`，三类路径消费 `anchors`；
/// L≥1 生产调用中两者均为单元结构方向，故一/三类处于同级授权层次。判据函数的方向匹配与几何
/// 契约不动；`judge_first_cached` 直调时传 `None` 的拒绝契约另由同模块直测锁定。
pub fn extract_signals_with_hist_anchored(
    centers: &[Center],
    segments: &[Segment],
    anchor_dirs: Option<&[Option<Direction>]>,
    // ★#1028 裁定 A：与 `segments` 平行的 departure 单元终点数组（`departure_ends[i]` =
    // 段 i 的趋势真终点）。`None` = L0（segment 自身即 departure 单元，点锚回退 seg.end_index）。
    departure_ends: Option<&[usize]>,
    hist: &[f64],
    dif: &[f64],
    closes_tick: &[Tick],
    close_src: &[usize],
    gauge: DivergenceGauge,
    // ★#990 I-2：strokes 供 ForceL 教义判据（L 经 #989 反查）；空 ⟹ ForceL 无源不判。
    strokes: &[Stroke],
    // ★#885 S4-d：一类点 T3-in-c 分级记录生产 sink（按 `diverged` 捕获，两域）；本入口
    // `level=None` ⟹ 记录 `level` 字段为占位 0，由 `Classification` 装配方按真实级别盖章。
    grade_sink: &mut Vec<FirstClassGradeRecord>,
) -> (Vec<BspPoint>, Vec<PanDivCert>) {
    // ★线段按 start_index **稳定**升序排一次（生产路径 parser 线段账本本已 start_index 严格单调
    // 递增——流式 push 时 seg_start 单调推进，segment.rs:344-380——故排序对生产路径是恒等）。稳定
    // 排序保证 start_index 相同时保留原序。中枢归属用 start_index，单趟扫描需线段时间序。
    // ★O(1) 优化：检测已有序则直接借用引用（避免 O(k) clone+sort）。生产路径 + 测试合成数据均有序。
    let sorted_owned: Vec<Segment>;
    let anchors_perm: Vec<Option<Direction>>;
    let departure_perm: Vec<usize>;
    let sorted: &[Segment];
    let anchors_in: Option<&[Option<Direction>]>;
    let departure_in: Option<&[usize]>;
    if segments
        .windows(2)
        .all(|w| w[0].start_index <= w[1].start_index)
    {
        sorted = segments;
        anchors_in = anchor_dirs;
        departure_in = departure_ends;
    } else {
        // 稳定排序经下标置换——anchor_dirs/departure_ends 与 segments 平行数组，须同一置换（Q7-#1 裁定C）。
        let mut idx: Vec<usize> = (0..segments.len()).collect();
        idx.sort_by_key(|&i| segments[i].start_index);
        sorted_owned = idx.iter().map(|&i| segments[i].clone()).collect();
        sorted = &sorted_owned;
        anchors_in = match anchor_dirs {
            Some(a) => {
                anchors_perm = idx.iter().map(|&i| a[i]).collect();
                Some(&anchors_perm)
            }
            None => None,
        };
        departure_in = match departure_ends {
            Some(d) => {
                departure_perm = idx.iter().map(|&i| d[i]).collect();
                Some(&departure_perm)
            }
            None => None,
        };
    }
    // 锚资格平行数组（与 `sorted` 等长）：anchors_self = 结构方向（L0 语义 + 盘整背驰路径专用）。
    let anchors_self: Vec<Option<Direction>> = sorted.iter().map(|s| Some(s.direction)).collect();
    let anchors: &[Option<Direction>] = anchors_in.unwrap_or(&anchors_self);
    debug_assert_eq!(
        anchors.len(),
        sorted.len(),
        "anchor_dirs 与 segments 必等长"
    );
    debug_assert!(
        departure_in.is_none_or(|d| d.len() == sorted.len()),
        "departure_ends 与 segments 必等长（#1028 平行数组）"
    );

    // ★中枢归属用 centers 按 end_index 升序（`detect_centers_with` 非重叠扫描已保证，mod.rs:136；
    // 公开函数不假设入参有序 ⟹ 本入口稳定排序，`nearest_confirmed_center` 二分前缀依赖升序）。
    let centers_owned: Vec<Center>;
    let centers_sorted: &[Center] = if centers.windows(2).all(|w| w[0].end_index <= w[1].end_index)
    {
        centers
    } else {
        centers_owned = {
            let mut v = centers.to_vec();
            v.sort_by_key(|c| c.end_index);
            v
        };
        &centers_owned
    };

    // ★局部趋势门（Q1/Q8 裁决，task #143）：τ 从「全历史累积链 AllTrend」（吸收锁死谓词，
    // PDF §2 + 外审漏斗坐实）换为「段当时所在走势类型块」。分解块前缀稳定（decompose.rs 模块头）
    // ⟹ 批式逐段查表 = 因果判定：段的最近已确认中枢 c 在其当时的当前块中恒为尾中枢；
    // gate[pos]=Some(d) ⟺ 该块为 Trend(d) 且 pos>块首（prev=pos-1 同块前驱，A 段所在，PDF §7）。
    // 盘整/扩张 run 内不产第一类（盘整背驰承接路由归 #145；「刚完成趋势块」时限窗口归 #144）。
    let blocks = decompose(centers_sorted);
    let center_gate = center_trend_gate(centers_sorted.len(), &blocks);
    let any_trend = center_gate.iter().any(|g| g.is_some());
    // ★Q4（task #145）：每中枢 ownership 块类别（与趋势门同一 decompose 单一来源，不 fork 第二套
    // 分解）——段的最近中枢落在 Consolidation 块 ⟹ 走盘整背驰证书路径（不产第一类 bit）。
    // #898 起另查 level_lift：只有本级别盘整块（lift==0）放行，扩展高一级块被拦。
    let center_kind = center_block_kind(centers_sorted.len(), &blocks);
    // ★#898（#815 M-1 落地）：盘整背驰是**本级别**盘整的判据——扩展折出的高一级盘整块
    // （level_lift=1，核心分离∧外缘重叠 `020:58`）不得触发本级盘背路由，只放行 lift==0 块
    // （单中枢块 + 中枢延伸块，「延伸的时候只有一个中枢」030:92【答疑】）。级别标注在此被真消费。
    let center_lift = center_block_lift(centers_sorted.len(), &blocks);
    let any_consol = center_kind
        .iter()
        .zip(center_lift.iter())
        .any(|(k, l)| *k == Some(MoveKind::Consolidation) && *l == Some(0));

    // ★单趟扫描（消解旧 `for c in centers` 对前驱中枢重复产出，codex 裁决 2026-06-27）：每个线段端点
    // 只相对其**最近已确认中枢**（"当下之前最后一个中枢"，第18课定理三「该中枢」+ 第49课）判第一/三
    // 类**一次**，不对所有阈值更低/更高的前驱中枢重复认领。
    //
    // ★复杂度 O(S·logC + S·logS)（#93 性能工位修复后，profile 坐实近线性）：
    // - 每段 `nearest_confirmed_center_idx` 二分 O(logC) 定位归属中枢下标 + `first_match_idx` O(1)
    //   查表取首匹配 `pos`（替代旧 `.position()` O(C) 线性反查——热点①，exp≈1.98 已 profile 坐实，
    //   见 `scale_timing_position_hotspot`）。
    // - 第一类 A 段定位（`locate_trend_seg_a`）O(S) 线性扫，但**按 last_center_idx 缓存**——趋势 τ 下
    //   多段共享同一 `(prev_center, last_center)` 对 ⟹ A 段每对至多算一次，替代旧每段重算（热点②，
    //   `scale_timing_breaking_path` exp≈1.99 已 profile 坐实）。
    let mut points = Vec::new();

    // ★首匹配下标表（热点① bit-exact 修复，#93）：旧 `.position(|x| 三元组==c 三元组)` 在重复三元组下
    // 返回**首匹配**（最小下标），非 `nearest_confirmed_center_idx` 给出的前缀末下标。为严格 bit-exact
    // 保留旧语义，正向扫 `centers_sorted`、仅在 key 不存在时插入 ⟹ 保留首匹配下标。主循环 O(1) 查表取
    // `pos`（替代旧 O(C) 线性反查），`c`（last_center）仍取 `centers_sorted[c_idx]`（最近中枢语义正确）。
    // 建表 O(C)。
    // ★B1 性能（algo-opt-plan-20260702 泳道B）：唯一消费点在 :632 `if let Some(dir) = trend_dir` 分支内
    // ⟹ 非趋势 τ（trend_dir=None）永不查表。建表移入 trend_dir.is_some() 守卫——非趋势时略过 O(C) 建表 +
    // 分配（空表从不被 get 查询 ⟹ 逐位恒等 bit-exact；仅趋势 τ 才产第一类，非趋势无第一类路径）。
    let mut first_match_idx: std::collections::HashMap<(usize, Tick, Tick), usize> =
        std::collections::HashMap::new();
    if any_trend {
        first_match_idx.reserve(centers_sorted.len());
        for (idx, c) in centers_sorted.iter().enumerate() {
            // 仅在 key 不存在时插入 ⟹ 首匹配（最小 idx）胜出，与旧 `.position()` 逐位一致。
            first_match_idx
                .entry((c.end_index, c.zd, c.zg))
                .or_insert(idx);
        }
    }

    // ★A 段缓存（热点②修复，#93）：key = last_center_idx（趋势 τ 下 prev_center = centers_sorted[pos-1]
    // 由 c 三元组经 first_match_idx 唯一决定 ⟹ 同 c_idx 下 (pos-1, c_idx) 配对唯一），val =
    // `locate_trend_seg_a` 结果 + 其包络（p117 037:20：b 包络随 I(A) 同槽缓存，每 c_idx 至多算
    // 一次，`move_range_envelope` 单一来源；与 C 段无关，仅依赖 `(segments, prev_center,
    // last_center, trend_dir)`）。
    // 趋势 τ 必 ≥2 同向中枢 ⟹ 所有触发第一类的段的 last_center_idx ∈ [1, C-1]，缓存规模至多 C 条。
    // 每段查缓存 O(1)（HashMap），首次 miss 才调 O(S) 的 `locate_trend_seg_a`——总成本从 O(S²)（每段
    // 重算）降为 O(C·S + S)（每中枢对一次 + 每段查缓存），C ≪ S 时近线性。
    let mut a_seg_cache: std::collections::HashMap<usize, Option<((usize, usize), (Tick, Tick))>> =
        std::collections::HashMap::new();
    // ★Q5 λ_C（codex ac4 #2 修复）：episode 语义下 λ_C 依赖 seg 前的回中枢段集合 ⟹ 不再可按
    // c_idx 缓存（旧 c_start_cache 无 reentry 检测，「失败离开→回中枢→重新离开」时 λ_C 过早污染
    // I(C) 面积）。逐段调 departure_move_c_start：O(窗口)（partition_point 定界 + 窗口线性扫），
    // 窗口 = c 之后至 seg 的段（生产量级中枢均段数 ~3，与 judge_pan_div 同成本类）。
    // ★Q4：盘整背驰证书收集（不产 BspPoint，不置 six-bit——承接路由在 econ 层）。
    let mut pan_divs: Vec<PanDivCert> = Vec::new();

    for (i, seg) in sorted.iter().enumerate() {
        // 该段归属的最近已确认中枢下标（"当下之前最后一个中枢"）。无 ⟹ 该段在所有中枢之前 ⟹ 非第一/三类。
        let Some(c_idx) = nearest_confirmed_center_idx(&centers_sorted, seg.start_index) else {
            continue;
        };
        // 第一类门（趋势方向）：`pos` 由 `first_match_idx` O(1) 查表给出（首匹配下标，bit-exact 等价旧
        // `.position()`）——重复三元组下返回最小下标，prev_center=pos-1、gate=center_gate[pos]。
        let gate_dir = if any_trend {
            first_match_idx
                .get(&{
                    let c = &centers_sorted[c_idx];
                    (c.end_index, c.zd, c.zg)
                })
                .and_then(|&pos| center_gate[pos].map(|d| (pos, d)))
        } else {
            None
        };
        // #898：本级盘背只认本级别盘整块（lift==0）。
        let kind_consol = any_consol
            && center_kind[c_idx] == Some(MoveKind::Consolidation)
            && center_lift[c_idx] == Some(0);
        // ★on2w3-07a：单段判定核（第一/盘整/三类）——full 路径与 resume 路径共享，逐字段等价
        // （gate/kind 由 caller 按 O(C) 数组或 pointwise 查询解析后传入，判定逻辑同一份）。
        // `level: None`——本入口是全量 fallback（也是 `extract_first_third_resume` 内部
        // debug_assert 对拍重算路径），非生产 incremental 逐 bar 调用点，不参与 sidecar 捕获
        // （见 `judge_segment` 文档 `level` 参数说明）。
        judge_segment(
            i,
            seg,
            c_idx,
            gate_dir,
            kind_consol,
            &sorted,
            anchors,
            &anchors_self,
            &centers_sorted,
            &mut a_seg_cache,
            hist,
            dif,
            closes_tick,
            close_src,
            gauge,
            strokes,
            None,
            departure_in,
            &mut points,
            &mut pan_divs,
            grade_sink,
        );
    }
    // 按 source_index 升序（reference:16 平局裁决键的时间序分量）。force 已收进各 BspPoint.force。
    // 分级记录同键排序（#885：一类候选 source_index 在本级提取内唯一，稳定排序 canonical）。
    points.sort_by_key(|p: &BspPoint| p.source_index);
    pan_divs.sort_by_key(|p: &PanDivCert| p.source_index);
    grade_sink.sort_by_key(|g: &FirstClassGradeRecord| g.source_index);
    (points, pan_divs)
}

/// 07a/5b 共用的唯一 e_src 公式（source_index 量纲）。
///
/// `prefix_count < 2`、越界或缺级都返回 0：稳定集为空但本 bar 冷算照常进行。
/// 合法生产调用满足 `prefix_count <= centers.len()`；越界分支只作保守失效护栏。
pub fn freeze_boundary_src(centers: &[Center], prefix_count: usize, dirty_e: usize) -> usize {
    if prefix_count < 2 {
        return 0;
    }
    centers
        .get(prefix_count - 2)
        .map_or(0, |center| center.end_index.min(dirty_e))
}

/// ★on2w3-07a 一/三类 frontier-resume（消 07a O(n²) 主导项，algo-opt-plan B2 泳道）。
///
/// 07a `extract_signals_with_hist{,_anchored}` 每 memo-miss 全量重判全部 S 段（第一/盘整/三类），
/// 跨 N bar 累积 O(S·N)=O(n²)（on2w3 profile 坐实 BTC-1M 4422ms/94% 在逐段判定循环，exp≈2.20）。
/// 但**已 confirmed 的段的点跨 bar 不变**：段 i 的第一类依赖其最近中枢 c 的趋势门（`decompose`
/// 冻结 sealed 关系 R_j, j<m-2）+ A/C 后向窗口 + hist 前缀（append-only）；三类依赖 sorted[i-1..=i]
/// + 各自最近中枢；盘整依赖同一门 + 后向窗口。故**冻结边界 `e_src` 之前的段的点可缓存**，每 bar
/// 只重判 tail `[stable_seg..S)`。
///
/// **锚口径（sound，doc① Q2 handoff 精化）**：段 i 可封 ⟺ `seg[i].end_index < e_src`，其中
/// `e_src = min(centers[prefix_count-2].end_index, dirty_e)`（倒数第二个 confirmed 中枢的终点，
/// 保证 seg[i] 落 confirmed 段前缀 ∧ 其最近中枢 c_idx≤prefix_count-3 门已冻结；cascade `dirty_e`
/// 兜底 frontier 改写）。`prefix_count<2` ⟹ e_src=0（无可复用前缀，退化全判）。
///
/// **bit-exact 铁律**：缓存按 push 序（段 i 序：type1→type3，pan_div 分开）存 confirmed 前缀点，
/// `cache ++ advance[cached..stable] ++ tail[stable..S]` == full 路径 pre-sort `points` 向量逐元素
/// 相等 ⟹ 同一 `sort_by_key(source_index)` 稳定排序逐字段 bit-identical（H1 神谕先例，debug_assert
/// 对拍 full 重算 + `bit_exact_per_bar` always-run 网锁定）。
///
/// **setup 线性化**：`blocks` = caller 已增量产出的 `decompose_resume` 输出（不重 decompose）；门/
/// 类别用 pointwise `center_own_dir_at`/`center_block_kind_at`（O(log C)/段），不 materialize O(C) 数组；
/// `first_match_idx` 冗余删除（中枢 end_index 严格递增 ⟹ 三元组唯一 ⟹ pos==c_idx，on2w3 实测 0/7.17M）。
///
/// `level`：本入口是生产 incremental 重放的**真实调用点**——`mod.rs` 的 `for level_idx in
/// 0..=l_max` 塔循环逐级各调一次，`level_idx` 本就在场（#606 S1 第三修复车：level 传参穿透，
/// 换掉旧版「挂点处不在场 ⟹ sidecar 收尾按身份反查补齐」的反查机器）。原样传给
/// [`judge_segment`]（`Some(level)`），供一类点 T3-in-c 分级 sidecar（若已打开）捕获时直接
/// 打上真实级别标签。
#[allow(clippy::too_many_arguments)]
pub fn extract_first_third_resume(
    cached_pts: &mut Vec<BspPoint>,
    cached_pans: &mut Vec<PanDivCert>,
    // ★#885 S4-d：`cached_pts/cached_pans` 配套的分级记录缓存（同一产出、同一 push 序、同一
    // 冻结边界锚、同一单调守卫 ⟹ 锁步失效）。返回三元组第三元 = 缓存前缀 ++ 本 bar tail 的
    // 完整记录序列（`level` 已由本入口真实级别填载，非占位）。
    cached_grades: &mut Vec<FirstClassGradeRecord>,
    cached_count: &mut usize,
    level: u32,
    centers: &[Center],
    segments: &[Segment],
    anchor_dirs: Option<&[Option<Direction>]>,
    // ★#1028 裁定 A：与 `segments` 平行的 departure 单元终点数组；`None` = L0（点锚回退
    // seg.end_index）。
    departure_ends: Option<&[usize]>,
    blocks: &[MoveBlock],
    prefix_count: usize,
    dirty_e: usize,
    hist: &[f64],
    dif: &[f64],
    closes_tick: &[Tick],
    close_src: &[usize],
    gauge: DivergenceGauge,
    strokes: &[Stroke],
) -> (Vec<BspPoint>, Vec<PanDivCert>, Vec<FirstClassGradeRecord>) {
    // 生产路径 segments/centers 已 start_index/end_index 升序（parser 账本 + 非重叠中枢扫描）；
    // anchors 平行。resume 是热路径专用入口，**假设有序**（debug_assert 守护，release 剥离）——
    // 全量 fallback（乱序入参）走 [`extract_signals_with_hist_anchored`]，本入口不重排。
    debug_assert!(
        segments
            .windows(2)
            .all(|w| w[0].start_index <= w[1].start_index),
        "resume 入口假设 segments 有序（生产路径恒真）"
    );
    debug_assert!(
        centers.windows(2).all(|w| w[0].end_index < w[1].end_index),
        "resume 入口假设 centers end_index 严格递增（非重叠扫描恒真 ⟹ 三元组唯一 ⟹ pos==c_idx）"
    );
    let anchors_self: Vec<Option<Direction>> = segments.iter().map(|s| Some(s.direction)).collect();
    let anchors: &[Option<Direction>] = anchor_dirs.unwrap_or(&anchors_self);
    debug_assert_eq!(
        anchors.len(),
        segments.len(),
        "anchor_dirs 与 segments 必等长"
    );
    debug_assert!(
        departure_ends.is_none_or(|d| d.len() == segments.len()),
        "departure_ends 与 segments 必等长（#1028 平行数组）"
    );

    let any_trend = blocks.iter().any(|b| b.kind == MoveKind::Trend);
    // #898：本级盘背只认本级别盘整块（lift==0）——扩展折出的高一级盘整块不算。
    let any_consol = blocks
        .iter()
        .any(|b| b.kind == MoveKind::Consolidation && b.level_lift == 0);

    // 冻结边界 e_src → 可封段数 stable_seg（segments 按 start 升序 ∧ 非重叠 ⟹ end 亦升序 ⟹
    // partition_point 二分）。公式由 `freeze_boundary_src` 单一持有，供 resume 与 p123 读同源。
    let e_src = freeze_boundary_src(centers, prefix_count, dirty_e);
    let stable_seg = segments.partition_point(|s| s.end_index < e_src);

    // 单调守卫（confirmed 前缀单调非降 ⟹ 正常永不触发；cascade 前缀回缩由 caller 别处 clear +
    // 本守卫兜底）：缓存越过本 bar 冻结边界 ⟹ 保守清空重判。
    if *cached_count > stable_seg {
        cached_pts.clear();
        cached_pans.clear();
        cached_grades.clear(); // #885：分级记录缓存同守卫锁步清空。
        *cached_count = 0;
    }

    // 逐段判定核（advance 与 tail 共享）：pointwise 解析门/类别后调 [`judge_segment`]。
    let mut a_seg_cache: std::collections::HashMap<usize, Option<((usize, usize), (Tick, Tick))>> =
        std::collections::HashMap::new();
    let mut judge_range = |from: usize,
                           to: usize,
                           pts: &mut Vec<BspPoint>,
                           pans: &mut Vec<PanDivCert>,
                           grades: &mut Vec<FirstClassGradeRecord>,
                           a_cache: &mut std::collections::HashMap<
        usize,
        Option<((usize, usize), (Tick, Tick))>,
    >| {
        for i in from..to {
            let seg = &segments[i];
            let Some(c_idx) = nearest_confirmed_center_idx(centers, seg.start_index) else {
                continue;
            };
            // pos==c_idx（end_index 严格递增 ⟹ 三元组唯一）；门 = pointwise ownership 方向。
            let gate_dir = if any_trend {
                center_own_dir_at(blocks, c_idx).map(|d| (c_idx, d))
            } else {
                None
            };
            // #898：本级盘背只认本级别盘整块（lift==0）。
            let kind_consol = any_consol
                && center_block_kind_at(blocks, c_idx) == Some(MoveKind::Consolidation)
                && center_block_lift_at(blocks, c_idx) == Some(0);
            judge_segment(
                i,
                seg,
                c_idx,
                gate_dir,
                kind_consol,
                segments,
                anchors,
                &anchors_self,
                centers,
                a_cache,
                hist,
                dif,
                closes_tick,
                close_src,
                gauge,
                strokes,
                Some(level),
                departure_ends,
                pts,
                pans,
                grades,
            );
        }
    };

    // 推进：新晋 confirmed 的段 [cached_count..stable_seg) 一次性判入缓存（一生一算，push 序）。
    if *cached_count < stable_seg {
        judge_range(
            *cached_count,
            stable_seg,
            cached_pts,
            cached_pans,
            cached_grades,
            &mut a_seg_cache,
        );
        *cached_count = stable_seg;
    }

    // 结果 = confirmed 前缀点（缓存 clone）+ frontier tail 点（每 bar 重判，tail 小）。push 序拼接。
    let mut points = cached_pts.clone();
    let mut pan_divs = cached_pans.clone();
    let mut grades = cached_grades.clone(); // #885：分级记录同口径合并。
                                            // tail 的 a_seg_cache 独立（advance 已消耗，tail 段最近中枢多在 frontier）——新建，与 full
                                            // 路径每调用一份 a_seg_cache 同语义（key=c_idx，命中即复用；跨 advance/tail 不复用不影响 bit）。
    let mut tail_a_cache: std::collections::HashMap<usize, Option<((usize, usize), (Tick, Tick))>> =
        std::collections::HashMap::new();
    judge_range(
        stable_seg,
        segments.len(),
        &mut points,
        &mut pan_divs,
        &mut grades,
        &mut tail_a_cache,
    );

    points.sort_by_key(|p: &BspPoint| p.source_index);
    pan_divs.sort_by_key(|p: &PanDivCert| p.source_index);
    grades.sort_by_key(|g: &FirstClassGradeRecord| g.source_index); // #885：与点同键 canonical。

    debug_assert!(
        {
            let mut full_grades = Vec::new();
            let (full_pts, full_pans) = extract_signals_with_hist_anchored(
                centers, segments, anchor_dirs, departure_ends, hist, dif, closes_tick,
                close_src, gauge, strokes, &mut full_grades,
            );
            // #885：全量对拍入口 level=None ⟹ 记录 level 为占位 0；对拍内容 = 判定本体
            // （坐标/方向/中枢身份/grade），level 由本 resume 入口真实级别统一盖章后比对。
            for g in &mut full_grades {
                g.level = level;
            }
            points == full_pts && pan_divs == full_pans && grades == full_grades
        },
        "07a frontier-resume 破裂：resume 输出 != 全量重判（冻结边界/push 序/pointwise 门不变式被违反）"
    );
    (points, pan_divs, grades)
}

/// ★on2w3-07a 单段判定核（第一/盘整/三类）——[`extract_signals_with_hist_anchored`] full 路径与
/// [`extract_first_third_resume`] 增量路径**共享同一份判定逻辑**（消 07a O(n²)：resume 只对 frozen
/// 边界后的 tail 段调本函数，confirmed 前缀点缓存复用）。
///
/// 判定所需的 gate/kind 由 caller 解析后传入（full 路径读 O(C) `center_gate`/`center_kind` 数组、
/// resume 路径读 pointwise `center_own_dir_at`/`center_block_kind_at`——两者逐点等价，测试锁定），
/// 本函数只做「已知 gate ⟹ 判第一/盘整/三类」的因果判定 ⟹ full/resume 输出逐字段 bit-identical。
///
/// - `gate_dir`：`Some((pos, dir))` = 该段最近中枢落趋势块（pos=首匹配中枢下标，prev=pos-1、
///   dir=趋势方向）；`None` = 非趋势（不产第一类）。
/// - `kind_consol`：该段最近中枢按 ownership 落**本级别** Consolidation 块（lift==0，#898；
///   走盘整背驰证书路径）。
/// - `a_seg_cache`：A 段区间 + 其 b 包络（p117 037:20）按 `last_center_idx=c_idx` 缓存（热点②，
///   趋势 τ 下多段共享 A 段对；包络随 I(A) 同槽，`move_range_envelope` 单一来源）。
/// - `level`：`Some(level_idx)` = 本调用来自 [`extract_first_third_resume`]（生产 incremental
///   重放路径，`mod.rs` 逐级循环真实持有的级别号，#606 S1 第三修复车传参穿透）——一类点
///   T3-in-c 分级 sidecar（若已打开）据此捕获，见下方 `GRADE_SIDECAR` 分支。`None` = 本调用来自
///   [`extract_signals_with_hist_anchored`]（全量 fallback / `extract_first_third_resume` 内部
///   debug_assert 对拍重算）——该路径不是生产逐 bar 重放的调用点，也可能对同一批段重复判定，
///   不参与 sidecar 捕获（避免与真实捕获重复写入或写入无意义级别）。
/// - `grade_sink`（#885 S4-d）：分级记录生产 sink，原样透传 [`judge_first_cached`]——两路径
///   （full/resume）都捕获，与 sidecar 的 `level` 门控无关。
#[allow(clippy::too_many_arguments)]
fn judge_segment(
    i: usize,
    seg: &Segment,
    c_idx: usize,
    gate_dir: Option<(usize, Direction)>,
    kind_consol: bool,
    sorted: &[Segment],
    anchors: &[Option<Direction>],
    anchors_self: &[Option<Direction>],
    centers_sorted: &[Center],
    a_seg_cache: &mut std::collections::HashMap<usize, Option<((usize, usize), (Tick, Tick))>>,
    hist: &[f64],
    dif: &[f64],
    closes_tick: &[Tick],
    close_src: &[usize],
    gauge: DivergenceGauge,
    strokes: &[Stroke],
    level: Option<u32>,
    // ★#1028 裁定 A：与 `sorted` 平行的 departure 单元终点数组（L≥1 由调用方预算）；`None` =
    // L0（segment 自身即 departure 单元，点锚回退 seg.end_index）。
    departure_ends: Option<&[usize]>,
    points: &mut Vec<BspPoint>,
    pan_divs: &mut Vec<PanDivCert>,
    grade_sink: &mut Vec<FirstClassGradeRecord>,
) {
    let c = &centers_sorted[c_idx];
    // ★#1028 裁定 A：本段的 departure 单元终点（调用方预算，索引随 sorted 平行）。
    let departure_end = departure_ends.map(|d| d[i]);
    // 第一类（趋势背驰，A/B/C 框架）：仅段所在趋势块 + 破最后中枢段触发（Q8：「最后一个中枢」=
    // 当前走势类型的最后中枢 = c）；prev_center = pos-1（同块前驱，A 段所在）。
    if let Some((pos, dir)) = gate_dir {
        let prev_center = &centers_sorted[pos - 1];
        // ★p117 + ADR 补充十三 / #486 / Spec #485：L≥1 一/三类均获单元结构方向锚。
        // 第一类在此消费 `anchors_self`。定义域「趋势中」（037:16/027:14）由本分支 τ 门
        // （gate_dir，级别-N decompose Trend 块）承担；行程方向=τ（037:20 单元级对应）
        // 与破核心几何在判据函数内保留——授权非去除，方向匹配检查整体保留。
        // 三消费点同源切换（禁部分修：broke 门/λ_C/A 段是同一「第一类方向锚」语义，部分切换
        // 会使 judge_first_cached「broke ⟹ λ_C 必 Some」契约出现模糊地带）。三类分支读取
        // `anchors[i-1]`；L≥1 生产调用已由上层传入结构锚，与 p117 一类处于同级授权层次。
        // provenance 仅留上游平行数组长度契约/诊断，不再作为一类或三类的方向否决。
        // 热点②修复：A 区间按 last_center_idx=c_idx 缓存（与 C 段 `seg` 无关）。首次 miss 才调
        // `locate_departure_move_a` O(窗口)，后续 hit O(1) 复用——消解每段重算的 O(S²)。
        // ★p117 037:20（裁定 T3）：b 包络（`move_range_envelope`，单一来源）随 I(A) 同槽缓存——
        // 每 c_idx 至多算一次；包络 None 构造性不可能（I(A) 首/末段恒整支落入 span），
        // `and_then` 塌陷为「无 A」处理 = 无参照极值诚实判负（与 None 语义一致）。
        let a_seg_entry = *a_seg_cache.entry(c_idx).or_insert_with(|| {
            locate_departure_move_a(sorted, anchors_self, prev_center, c, dir)
                .and_then(|span| move_range_envelope(sorted, span).map(|env| (span, env)))
        });
        // Q5 λ_C（codex ac4 #2）：当前 episode 首同向段起点（共享 helper，逐段计算）。
        let c_start_entry = departure_move_c_start(sorted, anchors_self, c, dir, seg.start_index);
        if let Some(pf) = judge_first_cached(
            c,
            dir,
            seg,
            anchors_self[i],
            hist,
            dif,
            closes_tick,
            close_src,
            a_seg_entry,
            c_start_entry,
            departure_end,
            gauge,
            strokes,
            sorted,
            level,
            grade_sink,
        ) {
            // ★#607 S2：D4 观测面 sidecar 捕获已挪进 `judge_first_cached` 本体（按 `diverged`
            // 门控在 T3-in-c 二次门控**之前**捕获，避免 D2 切换后仅凭 `pf.bits` 观测漏记否则域
            // 点，见该函数内注记）。此处不再重复捕获。
            points.push(pf);
        }
    }

    // ★Q4 盘整背驰（task #145）：段的最近中枢按 ownership 落在 Consolidation 块 ⟹ 走盘整背驰证书
    // 路径（同一中枢两次同向离开 + 力度或关系 R2）。不产 BspPoint、不置 six-bit——证书由 econ 层承接。
    if kind_consol {
        if let Some(cert) = judge_pan_div(c, seg, sorted, anchors_self, hist, dif, close_src) {
            pan_divs.push(cert);
        }
    }

    // 第三类：当前段作 retest，前一段作 leave。中枢归属 = **leave 段离开的最近中枢**（第18课
    // 「该中枢」），故用 leave 段 start_index 定位中枢，retest 相对**同一**中枢判一次。
    // ★#487 不改这条既有最近归属路径；四边框时间配对只用于接线层额外给出的挂起历史候选。
    if i > 0 {
        let leave_seg = &sorted[i - 1];
        if let Some(c_leave_idx) =
            nearest_confirmed_center_idx(centers_sorted, leave_seg.start_index)
        {
            let c_leave = &centers_sorted[c_leave_idx];
            // ★#816 B-3（020:62【正文】「必须是第一次」= 判据级必要条件，显式名分）：
            // `first_retrace_pair` —— leave 必须是该中枢右边之后的**第一条**段（其前一
            // 段起点在中枢右边之前），retest 为其紧随段；首个配对失败（价格重回）后
            // 出现的远期相邻对**不得**回填（与 #487 historical-bound 配对规则同口径）。
            // 语义锚 = Lean `BspClassification.IsType3Buy/Sell` 的 `firstRetrace` 合取项。
            let first_retrace_pair = i == 1 || sorted[i - 2].start_index < c_leave.end_index;
            // ADR 补充十三 / #486 / Spec #485：leave 段须有方向锚；L≥1 的 `anchors`
            // 已由调用层换成结构方向。retest 段仍只是几何回试角色。
            if first_retrace_pair {
                if let Some(p) = judge_third(c_leave, leave_seg, anchors[i - 1], seg) {
                    points.push(p);
                }
            }
        }
    }
}

/// 一类判据链漏斗计数（#141 外审问题包诊断探针，仅 test 构建）。
///
/// 与 [`extract_signals_with_hist`] **同一批判据函数**逐环计数（675号 meta-rule：探针走生产路径，
/// 不另起坐标系）——nearest_confirmed_center_idx / trend_class / first_match_idx / broke 几何 /
/// locate_trend_seg_a / map_src_range_to_close_idx / AbcDivergence::diverges 全部原函数调用。
/// 尾部 parity 断言：漏斗幸存数须与生产提取输出逐一相等（分叉即 panic，不产生伪计数）。
#[cfg(test)]
pub(crate) struct Type1Funnel {
    /// 分解块统计（task #143：AllTrend τ 已删，改报趋势/盘整块数 + 最长趋势 run 跨中枢数）。
    pub n_trend_blocks: usize,
    pub n_consol_blocks: usize,
    pub longest_trend_run: usize,
    pub n_centers: usize,
    pub n_segments: usize,
    /// 环1：有「最近已确认中枢」的段数（候选评估入口）。
    pub s_with_center: usize,
    /// 环2：last_center 有前驱中枢（pos≥1，即 ≥2 中枢可配 A/B/C）。
    pub s_pos_ge1: usize,
    /// 环3：局部趋势门开（center_gate[pos]=Some，段所在块为 Trend 且 pos>块首）⊆ 环2。
    pub s_gate_open: usize,
    /// 环4：C 段破最后中枢几何成立（方向=趋势方向 ∧ 端点越 zd/zg）。
    pub s_broke: usize,
    /// 环5：A 段可配对（locate_trend_seg_a=Some）。
    pub s_a_paired: usize,
    /// 环5b：037:20 破 b 包络极值（c 端点 `< b_lo` / `> b_hi`，b=I(A) 包络；计数于 A 配对后、
    /// λ_C/映射前——与生产 `judge_first_cached` 同判据同顺序，p117 裁定 T3）。
    pub s_extreme: usize,
    /// 环6：A/C 段均可映射到 closes 坐标（=生产 struct_break 候选数）。
    pub s_mapped: usize,
    /// 环7：MACD 背驰 C<A 成立（=生产 buy1/sell1 数）。
    pub s_diverge: usize,
}

#[cfg(test)]
pub(crate) fn type1_funnel_dx(
    centers: &[Center],
    segments: &[Segment],
    anchor_dirs: Option<&[Option<Direction>]>,
    hist: &[f64],
    dif: &[f64],
    closes_tick: &[Tick],
    close_src: &[usize],
) -> Type1Funnel {
    let blocks = decompose(centers);
    let center_gate = center_trend_gate(centers.len(), &blocks);
    let mut f = Type1Funnel {
        n_trend_blocks: blocks.iter().filter(|b| b.kind == MoveKind::Trend).count(),
        n_consol_blocks: blocks
            .iter()
            .filter(|b| b.kind == MoveKind::Consolidation)
            .count(),
        longest_trend_run: blocks
            .iter()
            .filter(|b| b.kind == MoveKind::Trend)
            .map(|b| b.end_center - b.start_center + 1)
            .max()
            .unwrap_or(0),
        n_centers: centers.len(),
        n_segments: segments.len(),
        s_with_center: 0,
        s_gate_open: 0,
        s_pos_ge1: 0,
        s_broke: 0,
        s_a_paired: 0,
        s_extreme: 0,
        s_mapped: 0,
        s_diverge: 0,
    };
    let mut first_match_idx: std::collections::HashMap<(usize, Tick, Tick), usize> =
        std::collections::HashMap::new();
    for (idx, c) in centers.iter().enumerate() {
        first_match_idx
            .entry((c.end_index, c.zd, c.zg))
            .or_insert(idx);
    }
    let mut a_seg_cache: std::collections::HashMap<usize, Option<((usize, usize), (Tick, Tick))>> =
        std::collections::HashMap::new();
    // Q7-#1 裁定C + 675号（探针走生产路径）：锚与生产同源——L0 传 None（自锚），级别-N 由
    // census 传 `center_own_dir_at` 派生锚（仅用于尾部 parity 对拍调用；生产三类仍消费之）。
    // ★p117 窄域授权镜像：第一类判据环（broke/A 段/λ_C）与生产 `judge_segment` 同步降级为
    // 结构方向锚（`anchors_owned` ≡ 生产 `anchors_self`）—— parity 断言（尾部）对拍的正是
    // 降级后的生产路径，探针不分叉。
    let anchors_owned = super::divergence::self_anchors(segments);
    for (si, seg) in segments.iter().enumerate() {
        let Some(c_idx) = nearest_confirmed_center_idx(centers, seg.start_index) else {
            continue;
        };
        f.s_with_center += 1;
        let c = &centers[c_idx];
        let Some(&pos) = first_match_idx.get(&(c.end_index, c.zd, c.zg)) else {
            continue;
        };
        if pos < 1 {
            continue;
        }
        f.s_pos_ge1 += 1;
        let Some(dir) = center_gate[pos] else {
            continue;
        };
        f.s_gate_open += 1;
        // broke 几何（judge_first_cached 同判据同顺序）。
        let end = seg_end(seg);
        // ★p117 + ADR 补充十三 / #486 / Spec #485：broke 锚门与生产第一类路径同源——
        // 结构方向锚（行程方向=τ 等式 veto）；provenance None 只保留直调判据契约。
        let broke = match (anchors_owned[si], dir) {
            (Some(Direction::Down), Direction::Down) => end.price < c.zd,
            (Some(Direction::Down), Direction::Down) => c.zg < end.price,
            _ => false,
        };
        if !broke {
            continue;
        }
        f.s_broke += 1;
        let prev_center = &centers[pos - 1];
        let a = *a_seg_cache.entry(c_idx).or_insert_with(|| {
            locate_departure_move_a(segments, &anchors_owned, prev_center, c, dir)
                .and_then(|span| move_range_envelope(segments, span).map(|env| (span, env)))
        });
        let Some(((a_start, a_end), (b_lo, b_hi))) = a else {
            continue;
        };
        f.s_a_paired += 1;
        // ★p117 037:20（裁定 T3，与生产 judge_first_cached 同判据同顺序）：c 端点破 b 包络极值
        // （严格超越，等号排除）——未破者不进第一类候选域（061:28），连 struct_break 候选也不计。
        let extreme_037_20 = match dir {
            Direction::Down => end.price < b_lo,
            Direction::Up => end.price > b_hi,
        };
        if !extreme_037_20 {
            continue;
        }
        f.s_extreme += 1;
        // Q5 λ_C（生产同款共享 helper，codex ac4 #2）：I(C)=[λ_C, seg.end]（broke ⟹ 必 Some）。
        let Some(lambda_c) =
            departure_move_c_start(segments, &anchors_owned, c, dir, seg.start_index)
        else {
            continue;
        };
        let (Some(c_i), Some(a_i)) = (
            map_src_range_to_close_idx(close_src, lambda_c, seg.end_index),
            map_src_range_to_close_idx(close_src, a_start, a_end),
        ) else {
            continue;
        };
        f.s_mapped += 1;
        let abc = AbcDivergence {
            seg_a: (a_start, a_end),
            seg_c: (lambda_c, seg.end_index),
            is_trend: true,
        };
        if abc.diverges(hist, a_i, c_i, dir) {
            f.s_diverge += 1;
        }
    }
    // parity 守卫（675号：探针不分叉）——漏斗幸存数须与生产提取逐一相等。漏斗环7 计数 MACD 面积
    // 判据（s_diverge）⟹ parity 对拍用默认 MacdArea 口径（探针语义=对照基线口径的生产路径）。
    let (prod, _pan) = extract_signals_with_hist_anchored(
        centers,
        segments,
        anchor_dirs,
        None,
        hist,
        dif,
        closes_tick,
        close_src,
        DivergenceGauge::MacdArea,
        &[],
        &mut Vec::new(),
    );
    let prod_t1 = prod.iter().filter(|p| p.bits.buy1 || p.bits.sell1).count();
    let prod_sb = prod.iter().filter(|p| p.struct_break_dir.is_some()).count();
    assert_eq!(prod_t1, f.s_diverge, "漏斗环7（背驰）须=生产 buy1/sell1 数");
    assert_eq!(
        prod_sb, f.s_mapped,
        "漏斗环6（mapped 候选）须=生产 struct_break 候选数"
    );
    f
}

#[cfg(test)]
mod tests {
    use super::super::level_view::CoordinateWindow;
    use super::super::retrace_ledger::{
        RetraceInput, RetraceOutcome, RetraceProvenance, ShortRetraceRejection, StrictCompletedPair,
    };
    use super::*;

    fn center(zd: Tick, zg: Tick, end_index: usize) -> Center {
        Center {
            zd,
            zg,
            dd: zd - 5,
            gg: zg + 5,
            start_index: 0,
            end_index,
        }
    }

    fn seg(dir: Direction, si: usize, ei: usize, sp: Tick, ep: Tick) -> Segment {
        Segment {
            direction: dir,
            start_index: si,
            end_index: ei,
            start_price: sp,
            end_price: ep,
        }
    }

    /// closes + close_src 辅助：连续 source_index 0..n（无合并跳跃的简单坐标系）。
    fn closes_seq(vals: &[Tick]) -> (Vec<f64>, Vec<usize>) {
        let c: Vec<f64> = vals.iter().map(|&v| v as f64).collect();
        let src: Vec<usize> = (0..vals.len()).collect();
        (c, src)
    }

    /// 第三类专用入口（无 MACD 依赖——传空 closes，第一类自然不产）。
    fn extract_third_only(centers: &[Center], segs: &[Segment]) -> Vec<BspPoint> {
        extract_signals(centers, segs, &[], &[], &MacdConfig::default())
    }

    // ── 第三类（保留原判据，MACD 无关）────────────────────────────────────────

    #[test]
    fn third_buy_extracted_bit_exact() {
        // 中枢核心 [100,200] end_index=12。后续：向上线段离开（端点 250 > zg=200），
        // 向下回试低点 210 > zg=200（不入中枢）⟹ 3 买。
        let c = center(100, 200, 12);
        let segs = vec![
            seg(Direction::Up, 12, 16, 150, 250),   // 离开：端点 250 > 200
            seg(Direction::Down, 16, 20, 250, 210), // 回试：低点 210 > 200 → 3 买
        ];
        let points = extract_third_only(&[c], &segs);
        assert_eq!(points.len(), 1);
        assert!(points[0].bits.buy3);
        assert_eq!(points[0].source_index, 20); // 回试端点
        assert_eq!(points[0].pivot_low, 210); // 回试低点 = pivot_low
        assert_eq!(
            points[0].center.and_then(|o| match o {
                OwnerRef::Center(c) => Some(c.zg),
                _ => None,
            }),
            Some(200),
        ); // 3 买止损 = zg（#218 面 A 载体形态：Center 变体读出）
    }

    #[test]
    fn third_buy_rejected_when_retest_reenters() {
        // 回试低点 190 < zg=200（重新跌破进入中枢）⟹ 不是 3 买。
        let c = center(100, 200, 12);
        let segs = vec![
            seg(Direction::Up, 12, 16, 150, 250),
            seg(Direction::Down, 16, 20, 250, 190), // 回试 190 < 200 → 入中枢，非 3 买
        ];
        let points = extract_third_only(&[c], &segs);
        assert!(points.is_empty());
    }

    #[test]
    fn third_buy_boundary_retest_eq_zg_not_third() {
        // 回试低点 == zg=200（边界临界点）：严格口径 `> zg` ⟹ 非第三类买点。
        // retest==zg=单点重叠仍触及闭区间中枢 [ZD,ZG]=中枢延伸（中心定理一）=非终结=非第三类。
        // 逐字段对齐 Lean IsType3Buy（zg < retracePrice，严格）。codex 裁决 2026-06-27。
        let c = center(100, 200, 12);
        let segs = vec![
            seg(Direction::Up, 12, 16, 150, 250),
            seg(Direction::Down, 16, 20, 250, 200), // 回试 == zg → 触及中枢 → 非 3 买（严格排除等号）
        ];
        let points = extract_third_only(&[c], &segs);
        assert!(
            points.is_empty(),
            "retest==zg 触及闭区间中枢=非终结=非第三类（严格口径，对齐 Lean）"
        );
    }

    #[test]
    fn third_sell_extracted_bit_exact() {
        // 镜像：向下离开（端点 50 < zd=100），向上回抽高点 90 < zd=100 ⟹ 3 卖。
        let c = center(100, 200, 12);
        let segs = vec![
            seg(Direction::Down, 12, 16, 150, 50), // 离开：端点 50 < 100
            seg(Direction::Up, 16, 20, 50, 90),    // 回抽：高点 90 < 100 → 3 卖
        ];
        let points = extract_third_only(&[c], &segs);
        assert_eq!(points.len(), 1);
        assert!(points[0].bits.sell3);
        assert_eq!(points[0].pivot_high, 90); // 回抽高点 = pivot_high
        assert_eq!(
            points[0].center.and_then(|o| match o {
                OwnerRef::Center(c) => Some(c.zd),
                _ => None,
            }),
            Some(100),
        ); // 3 卖止损 = zd（#218 面 A 载体形态：Center 变体读出）
    }

    #[test]
    fn no_leave_no_third_signal() {
        // 线段未离开中枢（端点 180 < zg=200）⟹ 无第三类（且方向不破中枢，无第一类）。
        let c = center(100, 200, 12);
        let segs = vec![
            seg(Direction::Up, 12, 16, 150, 180),   // 未离开（180 < 200）
            seg(Direction::Down, 16, 20, 180, 160), // 端点 160 ∈ [100,200]，未破中枢下沿
        ];
        let points = extract_third_only(&[c], &segs);
        assert!(points.is_empty());
    }

    #[test]
    fn third_buy_has_center_invariant() {
        // 不变量：含 3 类 bit ⟹ center 必 Some（strategy 3 类止损 unwrap 安全）。
        let c = center(100, 200, 12);
        let segs = vec![
            seg(Direction::Up, 12, 16, 150, 250),
            seg(Direction::Down, 16, 20, 250, 210),
        ];
        let points = extract_third_only(&[c], &segs);
        for p in &points {
            if p.bits.buy3 || p.bits.sell3 {
                assert!(p.center.is_some(), "含 3 类 bit ⟹ center 必 Some");
            }
        }
    }

    #[test]
    fn empty_centers_no_signal() {
        let points = extract_third_only(&[], &[seg(Direction::Up, 0, 4, 0, 10)]);
        assert!(points.is_empty());
    }

    // ★探索性测试（揭示 bug，testing-override 生成态例外）：坐实「同一 retest 端点对所有
    //   zg < retest 的前驱中枢重复产出」的重复机制。修复后此测试断言**唯一归属最近中枢**。
    #[test]
    fn third_buy_belongs_only_to_nearest_center_not_all_predecessors() {
        // 三个前驱中枢，zg 递增：C0[10,20] end=2、C1[30,40] end=14、C2[50,60] end=26。
        // 离开+回试发生在 C2 之后：向上离开（端点 90 > 60），向下回试低点 70 > 60（不入 C2）。
        // bug 语义：retest 端点 70 同时满足 70 > C0.zg=20、70 > C1.zg=40、70 > C2.zg=60 ⟹ 旧码产 3 个 bsp。
        // 正确语义（第18课定理三「该中枢」+ 第49课「当下之前最后一个中枢」）：retest 只归属刚离开的
        //   最近中枢 C2（end=26，离 leave 段最近）⟹ 唯一 1 个 bsp，center=C2。
        let c0 = center(10, 20, 2);
        let c1 = center(30, 40, 14);
        let c2 = center(50, 60, 26);
        let segs = vec![
            seg(Direction::Up, 27, 30, 60, 90), // 离开 C2 上方（端点 90 > 60）
            seg(Direction::Down, 30, 34, 90, 70), // 回试低点 70 > 60（不入 C2）→ 3 买（仅归属 C2）
        ];
        let points = extract_third_only(&[c0, c1, c2], &segs);
        let buy3: Vec<_> = points.iter().filter(|p| p.bits.buy3).collect();
        assert_eq!(
            buy3.len(),
            1,
            "同一 retest 端点只归属刚离开的最近中枢 C2，不对 C0/C1 前驱重复产出（第18课定理三「该中枢」）"
        );
        assert_eq!(buy3[0].source_index, 34, "唯一 bsp 在回试端点");
        assert_eq!(
            buy3[0].center.and_then(|o| match o {
                OwnerRef::Center(c) => Some((c.zd, c.zg)),
                _ => None,
            }),
            Some((50, 60)),
            "归属中枢 = 刚离开的最近中枢 C2[50,60]（第49课「当下之前最后一个中枢」）"
        );
    }

    // ── 第一类（A/B/C 趋势背驰框架：≥2 同向中枢 + A/C 跨相邻中枢 + τ 门控）──────
    //
    // ★语义升级（第24课:22-24 + maimai.md:103-112，消解 grammar-audit 头号缺口）：第一类 = 趋势
    //   背驰点，**前提 ≥2 依次同向中枢**（趋势 τ）。A=前中枢离开段、C=后中枢破中枢段，C<A 力度。
    //   单中枢（盘整）**不产第一类**（盘整背驰，beichi #4）——旧测试用单中枢产第一类是退化语义，
    //   已被 A/B/C 框架正确否决。下列测试构造下跌趋势（两依次向下中枢）的标准 A/B/C 结构。

    /// 下跌趋势中枢辅助：dd/gg 携全（趋势门控用 dd/gg 外缘判 c1.gg < c0.dd）。
    fn dc(zd: Tick, zg: Tick, dd: Tick, gg: Tick, ei: usize) -> Center {
        Center {
            zd,
            zg,
            dd,
            gg,
            start_index: 0,
            end_index: ei,
        }
    }

    #[test]
    fn first_buy_extracted_with_trend_divergence() {
        // ★趋势背驰 1 买（A/B/C 框架）：两依次向下中枢（下跌趋势 τ=Trend(Down)）。
        // - C0[300,400] dd=290 gg=410 end=2（前中枢，A 段所在）。
        // - C1[100,200] dd=90  gg=210 end=8（后中枢，c1.gg=210 < c0.dd=290 ⟹ 下跌延续 ⟹ 趋势）。
        // - A 段 [3,5]：C0 之后向下离开段（端点破 C0 下沿 < 300），MACD 面积大（强势）。
        // - C 段 [9,11]：C1 之后向下破中枢段（端点 80 < C1.zd=100），MACD 面积小（背驰）⟹ 1 买。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250), // A 段：C0 离开段（破 C0 下沿）
            seg(Direction::Up, 5, 7, 250, 280),   // B 段连接（中间反向，构成 C1）
            seg(Direction::Down, 9, 11, 150, 80), // C 段：破 C1 下沿（< 100）∧ 背驰 ⟹ 1 买
            seg(Direction::Up, 11, 13, 80, 90),   // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        // closes（merged_bars 序列，与 segment 抽象端点价解耦——结构判定在 tick 域，MACD 在浮点域，
        // closes 是 merged_bars，segment 端点是抽象极值，两者不必逐 bar 一致）：A 段 bar [3,5] 急跌
        // （hist 面积大=强力度），C 段 bar [9,11] 缓动（hist 面积小=力度衰减=背驰）。手算 A area[3,5]=
        // 23.26 > C area[9,11]=9.09 ⟹ C<A 趋势背驰成立。
        let prices: Vec<Tick> = vec![
            300, 300, 300, // 0..2 C0 区（预热）
            300, 100, 250, // 3..5 A 段：急跌（hist 绝对值大=强力度）
            250, 250, 250, // 6..8 B 段：盘整让 EMA 收敛（hist 回拉 0 轴）
            248, 246, 244, // 9..11 leave：缓动（hist 小=力度衰减）
            242, 240, 238,
            236, // 12..15 retest+bottom：延续缓跌（I(C)=[9,15] 面积仍 < A）
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert_eq!(
            buy1.len(),
            1,
            "下跌趋势 C 段破最后中枢 ∧ C<A 趋势背驰 ⟹ 一个 1 买"
        );
        assert_eq!(
            buy1[0].source_index, 15,
            "1 买端点 = bottom 段（破新低）终止 source_index（#1249 后扫命中 leave+retest）"
        );
        assert_eq!(
            buy1[0].pivot_low, 70,
            "1 买止损源 = pivot_low（bottom 段破新低端点）"
        );
        // ★owner 载体补齐（关③ 补记② 路径 (a)）：一类点构造时填入判定中枢 last_center=c1
        //（被破的最后中枢 = a+A+b+B+c 的 B 同型对象）——名实一致根据：一类点本就由「C 段破
        // last_center ∧ C<A 趋势背驰」相对 c1 判定产出；center 是 owner 载体，止损仍 pivot
        //（pivot_low=80 上条已锁，center 不进 1/2 类止损判据）。
        // （#218 面 A 载体形态机械适配：一/三类载 OwnerRef::Center，语义不动。）
        assert_eq!(
            buy1[0].center,
            Some(OwnerRef::Center(c1)),
            "一类点 center = 判定中枢（owner 载体）；止损仍 pivot 非 center"
        );
    }

    /// ★#607 S2 D2（37:18 分档大闸）+ #1249：`diverged`（MACD C<A 背驰）成立但 c 全窗后扫
    /// `Missing`（否则域，c 内无 leave+retest 对）⟹ 一类 bit **不置**——同
    /// `first_buy_extracted_with_trend_divergence` 逐字段相同的夹具（背驰几何一致），唯一差别是
    /// 本测试**不追加** retest 段，故 T3-in-c 全窗后扫 `Missing`。点仍以零 bit 结构候选继续走
    /// 既有候选流（struct_break_dir 无条件置，P2-R2 先例）——D2「大闸」不改候选集合，只改名分（bit）。
    #[test]
    fn otherwise_domain_missing_t3_in_c_zero_bit_continues_candidate_flow() {
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250), // A 段
            seg(Direction::Up, 5, 7, 250, 280),   // B 段连接
            seg(Direction::Down, 9, 11, 150, 80), // C 段：破 C1 下沿 ∧ 背驰——但 c 内无 retest 段
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "diverged 成立但 c 全窗后扫 Missing（无 leave+retest 对）⟹ 否则域，一类 bit 不置位（#607 D2/#1249）"
        );
        let sb_pt: Vec<_> = points.iter().filter(|p| p.source_index == 11).collect();
        assert_eq!(
            sb_pt.len(),
            1,
            "否则域点仍进 BspPoint 样本（零 bit 结构候选，D2 不改候选集合）"
        );
        assert_eq!(
            sb_pt[0].struct_break_dir,
            Some(Side::Long),
            "零 bit 候选带 struct_break_dir=Some（下游 candidate_dir 恢复方向进样本，P2-R2 消选择偏差）"
        );
        assert_eq!(
            sb_pt[0].bits.class_index(),
            0,
            "否则域 ⟹ 六 bit 全零（class_index=0，未冒充第一类）"
        );
    }

    // ── p117（686 翻转条款第一支窄域授权，终端背书裁定 T2）：第一类路径方向锚降级 ──────
    //
    // 降级 = provenance 锚（anchors，次级别块 ownership 资格）→ 单元结构方向（anchors_self），
    // 限第一类路径、限 τ 门开、限单元行程方向=τ（等式 veto 保留，非去除）。下列测试复用
    // `first_buy_extracted_with_trend_divergence` 的 A/B/C 夹具（C0[300,400]→C1[100,200] 下跌
    // 趋势；A=[3,5] Down 急跌；B=[5,7] Up；C=[9,11] Down 缓动破 zd=100，A 面积 23.26 > C 9.09），
    // 级别-N 输入经 `extract_signals_with_hist_anchored(..., Some(anchor_dirs), ...)` 显式锚数组模拟。

    #[test]
    fn first_buy_fallback_c_unit_rescued_via_structural_direction() {
        // ★S2 救回型：C 单元（破中枢段）fallback（anchor=None）但结构方向 Down=τ——p117 后
        // broke 锚门用单元结构方向 ⟹ 触发（旧口径：provenance None 在几何评估前击杀）。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
            seg(Direction::Up, 11, 13, 80, 90), // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let anchors = [
            Some(Direction::Down),
            Some(Direction::Down),
            None,
            Some(Direction::Down),
            Some(Direction::Down),
        ]; // C 单元 fallback
        let (points, _pan) = extract_signals_with_hist_anchored(
            &[c0, c1],
            &segs,
            Some(&anchors),
            None,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert_eq!(
            buy1.len(),
            1,
            "C 单元 fallback 且结构方向=τ ⟹ p117 后破中枢触发 ∧ C<A 背驰 ⟹ 1 买"
        );
        assert_eq!(
            buy1[0].source_index, 15,
            "1 买端点 = bottom 段终止 source_index"
        );
        assert_eq!(
            buy1[0].pivot_low, 70,
            "1 买止损源 = pivot_low（bottom 段破新低端点）"
        );
        // ★owner 载体补齐（关③ 补记② 路径 (a)）：一类点构造时填入判定中枢 last_center=c1——
        // 名实一致根据同 `first_buy_extracted_with_trend_divergence`（本测试复用其 A/B/C 夹具）；
        // center 是 owner 载体，止损仍 pivot（上条已锁，center 不进 1/2 类止损判据）。
        // （#218 面 A 载体形态机械适配：一/三类载 OwnerRef::Center，语义不动。）
        assert_eq!(
            buy1[0].center,
            Some(OwnerRef::Center(c1)),
            "一类点 center = 判定中枢（owner 载体）；止损仍 pivot 非 center"
        );
    }

    /// #1028 裁定 A 回归锁：一类点点锚 = departure 单元终点。
    ///
    /// 复用 `first_buy_fallback_c_unit_rescued_via_structural_direction` 的 A/B/C 夹具（buy1 原锚
    /// = C 段终点 source_index 11）。传 `departure_ends[2]=7`（趋势真终点）⟹ 点 `source_index` 与
    /// 分级记录 `source_index` 同键迁移到 7；判定链字段（pivot/center/bits）逐字不动——只动锚。
    #[test]
    fn first_buy_point_anchor_migrates_to_departure_unit_end() {
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
            seg(Direction::Up, 11, 13, 80, 90), // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let anchors = [
            Some(Direction::Down),
            Some(Direction::Down),
            None,
            Some(Direction::Down),
            Some(Direction::Down),
        ];
        // bottom 段（下标 4）的 departure 单元终点 = 7（趋势真终点）；其余下标不回读（无点产出）。
        let departure_ends = [0, 0, 0, 0, 7];
        let mut grades = Vec::new();
        let (points, _pan) = extract_signals_with_hist_anchored(
            &[c0, c1],
            &segs,
            Some(&anchors),
            Some(&departure_ends),
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut grades,
        );
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert_eq!(buy1.len(), 1, "夹具应产一个 buy1");
        assert_eq!(
            buy1[0].source_index, 7,
            "点锚 = departure 单元终点（非 bottom 段终点 15，#1028 裁定 A）"
        );
        assert_eq!(
            buy1[0].pivot_low, 70,
            "止损 pivot 仍 = bottom 段端点极值（判定链不动）"
        );
        assert_eq!(
            buy1[0].center,
            Some(OwnerRef::Center(c1)),
            "owner 载体仍 = 判定中枢（判定链不动）"
        );
        assert_eq!(
            grades.len(),
            2,
            "分级记录 = leave + bottom 两 diverged 候选（#885 契约）"
        );
        assert!(
            grades.iter().any(|r| r.source_index == 7),
            "bottom 分级记录 source_index 与点同键迁移到 7（一一对应不脱键）"
        );
    }

    #[test]
    fn first_buy_fallback_c_unit_opposite_travel_still_rejected() {
        // ★行程方向 veto 保留（降级非去除，037:20 单元级对应）：C 单元结构方向 Up ≠ τ=Down，
        // 端点 80 < zd=100 虽越界，仍拒——锁死「τ 继承纯几何」（方案 (ii)，永久拒绝）的误放形态。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Up, 9, 11, 60, 80), // C 单元：结构方向 Up ≠ τ=Down，端点 80 < zd=100 越界
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let anchors = [Some(Direction::Down), Some(Direction::Down), None];
        let (points, _pan) = extract_signals_with_hist_anchored(
            &[c0, c1],
            &segs,
            Some(&anchors),
            None,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "行程方向 ≠τ ⟹ 无 1 买（方向等式 veto 保留）"
        );
        assert!(
            points
                .iter()
                .all(|p| p.source_index != 11 || p.struct_break_dir.is_none()),
            "@11 无 struct_break 候选（含零 bit 候选也不产——τ 继承式误放的负例锁）"
        );
    }

    #[test]
    fn first_buy_fallback_a_window_pairable_via_structural_direction() {
        // ★S4 救回型：A 单元 fallback（anchor=None）但结构方向 Down=τ——p117 后 A 窗筛选用
        // 结构方向 ⟹ A 候选可配（旧口径：`**a == Some(dir)` 过滤全空 ⟹ locate 返回 None）。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
            seg(Direction::Up, 11, 13, 80, 90), // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let anchors = [
            None,
            Some(Direction::Down),
            Some(Direction::Down),
            Some(Direction::Down),
            Some(Direction::Down),
        ]; // A 单元 fallback
        let (points, _pan) = extract_signals_with_hist_anchored(
            &[c0, c1],
            &segs,
            Some(&anchors),
            None,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert_eq!(
            buy1.len(),
            1,
            "A 单元 fallback 且结构方向=τ ⟹ p117 后 A/C 可配对 ⟹ 1 买"
        );
        assert_eq!(buy1[0].source_index, 15);
        assert_eq!(buy1[0].pivot_low, 70);
    }

    #[test]
    fn first_buy_anchored_set_bit_identical_after_downgrade() {
        // ★单调加宽、零误杀的单元级锁（裁定 T2 裁决 3：构造性结论的回归锁）：anchor=Some(d) 与
        // 单元结构方向同源（project_to_units 同一 unwrap 源）⟹ 全 Some 锚（=结构方向）的输入在
        // 降级前后逐字段恒等——无任何现产第一类点因本修消失。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let full = [
            Some(Direction::Down),
            Some(Direction::Down),
            Some(Direction::Down),
        ];
        let (pts_anchor, _) = extract_signals_with_hist_anchored(
            &[c0, c1],
            &segs,
            Some(&full),
            None,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        let (pts_self, _) = extract_signals_with_hist_anchored(
            &[c0, c1],
            &segs,
            None,
            None,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        assert_eq!(
            pts_anchor, pts_self,
            "全 Some 锚（=结构方向）与自锚两跑 Vec<BspPoint> 逐字段相等（降级不改变已合格点）"
        );
    }

    #[test]
    fn judge_first_cached_provenance_gate_preserved_for_direct_callers() {
        // ★p117 直调判据契约锁：ADR 补充十三 / #486 / Spec #485 只改 L≥1 调用层方向源；
        // `judge_first_cached` 语义未动，直接调用方传 provenance None 时仍在几何评估前拒绝。
        let c1 = dc(100, 200, 90, 210, 8);
        let c_seg = seg(Direction::Down, 9, 11, 150, 80);
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let out = judge_first_cached(
            &c1,
            Direction::Down,
            &c_seg,
            None,
            &hist,
            &[],
            &[],
            &src,
            Some(((3, 5), (250, 350))),
            Some(9),
            None,
            DivergenceGauge::MacdArea,
            &[],
            &[c_seg],
            None,
            &mut Vec::new(),
        );
        assert!(
            out.is_none(),
            "直调判据传 provenance None ⟹ None（判据函数语义未动，降级在调用点）"
        );
    }

    #[test]
    fn first_buy_fallback_episode_lambda_c_consistent() {
        // ★λ_C 三消费点同源一致性锁（禁部分修：broke 门/λ_C/A 段同一方向语义）：C 单元前插入
        // 回中枢段（端点重回 c1 核心 [100,200] 内侧 ⟹ episode 边界），fallback C 单元经结构方向
        // 救回时 λ_C 取「结构同向 episode 起点」——与 broke 门/A 段筛选同一 anchors_self 来源。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),  // A 段
            seg(Direction::Up, 5, 7, 250, 280),    // B 段连接
            seg(Direction::Up, 9, 10, 140, 150),   // 回中枢段：端点 150 ∈ [100,200] ⟹ episode 边界
            seg(Direction::Down, 10, 12, 150, 80), // C 段（fallback，结构方向 Down=τ）：破 zd=100
        ];
        let anchors = [
            Some(Direction::Down),
            Some(Direction::Down),
            Some(Direction::Down),
            None,
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 250, 248, 246, 244,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let (points, _pan) = extract_signals_with_hist_anchored(
            &[c0, c1],
            &segs,
            Some(&anchors),
            None,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        // ★#1249（#1229 裁定 a）：c 全窗 [λ_C=10, seg.end=12] 后扫——回中枢段 [9,10]（价 150，
        // 未破 zd=100）落在 λ_C 之前（episode 边界重置 λ_C=10），窗内仅触发段 [10,12] 单段，
        // 无 leave+retest 对 ⟹ 后扫 `Missing` ⟹ 该点落否则域：零一类 bit，继续走候选流
        // （struct_break_dir 无条件置，P2-R2 先例）——λ_C reentry 救回的是「候选資格」
        // （broke 门 + I(C) 面积），T3-in-c 是独立于 λ_C 的另一层几何合取，两者不桥接。
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert!(
            buy1.is_empty(),
            "c 全窗后扫无第三类对（回中枢段在 λ_C 前、触发段无回试）⟹ 否则域，1 买不置位（#1249）"
        );
        let sb_pt: Vec<_> = points.iter().filter(|p| p.source_index == 12).collect();
        assert_eq!(
            sb_pt.len(),
            1,
            "λ_C reentry 救回的候选仍进样本（零 bit struct_break，D2 否则域不改候选集合）"
        );
        assert_eq!(
            sb_pt[0].struct_break_dir,
            Some(Side::Long),
            "零 bit 候选带 struct_break_dir=Some（P2-R2 消选择偏差）"
        );
        assert_eq!(
            sb_pt[0].bits.class_index(),
            0,
            "否则域 ⟹ 六 bit 全零（class_index=0）"
        );
        // 同一共享 helper 的对照锁定：provenance 锚下 λ_C 不可定位（fallback C 单元不作方向锚
        // ⟹ None，旧口径击杀链）；结构方向锚下 = 回中枢段（终点 10）之后首同向段起点 10
        // （「失败离开→回中枢→重新离开」不桥接）。λ_C 计算本身不受 T3-in-c 大闸影响（D1/D2
        // 分属独立合取项，本断言组不改）。
        assert_eq!(
            departure_move_c_start(&segs, &anchors, &c1, Direction::Down, 10),
            None,
            "provenance 锚：fallback C 单元不作方向锚 ⟹ λ_C None（p117 前击杀链）"
        );
        let self_a = super::divergence::self_anchors(&segs);
        assert_eq!(
            departure_move_c_start(&segs, &self_a, &c1, Direction::Down, 10),
            Some(10),
            "结构方向锚：λ_C = episode 首同向段起点 10（生产第一类路径 p117 后消费此源）"
        );
    }

    // ── p117（037:20 破极值补项，终端背书裁定 T3）：c 端点必破 b（=I(A)）包络极值 ──────
    //
    // 插入层面 = 结构候选门（与 broke 同层，061:28 候选资格定性）：未破 b 极值的破核心段不进
    // 第一类候选域——含零 bit struct_break 候选也不产（D1 收缩语义）。「创出」= 严格超越（等号
    // 排除，与 zd/zg 严格口径一致）。夹具关键几何：A 腿终点压到 zd 之下（b_lo=90 < zd=100）使
    // 新门**可绑定**（区别于 canonical 夹具 b_lo=250 > zd=100 的不绑定几何，§5.4 回归面）。

    #[test]
    fn first_class_requires_b_envelope_break_03720() {
        // ★T1 杀伪（负例）：C 端点 95 破核心（< zd=100）但未破 b 包络极值（b_lo=90）⟹ 连零 bit
        // struct_break 候选也不产。反事实（旧口径）：95<100 ⟹ 该坐标曾是 struct_break 候选。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 90), // A 腿：b_lo=90 < zd=100（门可绑定几何）
            seg(Direction::Up, 5, 7, 90, 95),    // B 连接
            seg(Direction::Down, 9, 11, 150, 95), // C：95 < zd=100 破核心 ✓，95 ≥ b_lo=90 破极值 ✗
        ];
        // closes 取 canonical 急跌-缓动型——若放行则 C<A 成立，把变量隔离到 037:20 一项。
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "未破 b 极值 ⟹ 无 1 买（037:20 必要合取）"
        );
        assert!(
            points.iter().all(|p| p.struct_break_dir.is_none()),
            "破核心但未破 b 极值 ⟹ 连零 bit struct_break 候选也不产（D1 候选门收缩；旧口径下 @11 = 候选 95<100）"
        );
    }

    #[test]
    fn first_class_point_deferred_to_envelope_breaking_leg_03720() {
        // ★T2 同 episode 递延（正例核心）：C 腿1 破核心未破极值（被杀）；C 内反向段未回核心
        // ⟹ 同一 episode（λ_C=9）；C 腿2 端点 85 < b_lo=90 破极值 = 因果触发段——点在腿2 端点
        // （@15），非破核心腿（@11）。坐实「不改变点的因果语义，只在同一触发点加严」。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 90),  // A：b_lo=90
            seg(Direction::Up, 5, 7, 90, 95),     // B
            seg(Direction::Down, 9, 11, 150, 95), // C 腿1：破核心 ✓ 未破极值 ✗（旧口径候选坐标）
            seg(Direction::Up, 11, 13, 95, 98),   // C 内反向段：98 < zd=100 未回核心 ⟹ 同一 episode
            seg(Direction::Down, 13, 15, 98, 85), // C 腿2：85 < b_lo=90 破极值 ✓ = 因果触发段
        ];
        // closes：I(A)=[3,5] 急跌（面积大）、I(C)=[9,15] 缓动（面积小 ⟹ C<A 成立）。
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 249, 248, 247, 246, 245, 244, 243,
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert_eq!(
            buy1.len(),
            1,
            "破极值腿端点破核心 ∧ C<A ⟹ 一个 1 买（递延到因果触发段）"
        );
        assert_eq!(
            buy1[0].source_index, 15,
            "点在破极值腿端点 @15，非破核心腿 @11"
        );
        assert_eq!(buy1[0].pivot_low, 85, "pivot_low = 破极值腿端点极值 85");
        assert!(
            points.iter().all(|p| p.source_index != 11),
            "@11（破核心未破极值腿）零产出——旧口径下该坐标有 struct_break 候选"
        );
    }

    #[test]
    fn first_class_envelope_equality_is_not_a_break_03720() {
        // ★T3 等号非创出：C 端点 == b_lo（90 == 90）——「创出」= 严格超越，等号排除（与中枢
        // zd/zg 严格不等式口径一致）⟹ 无候选。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 90),  // A：b_lo=90
            seg(Direction::Up, 5, 7, 90, 95),     // B
            seg(Direction::Down, 9, 11, 150, 90), // C：90 < zd=100 破核心 ✓，90 == b_lo 等号 ✗
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        assert!(points.iter().all(|p| !p.bits.buy1), "等号非创出 ⟹ 无 1 买");
        assert!(
            points.iter().all(|p| p.struct_break_dir.is_none()),
            "等号 ⟹ 连零 bit struct_break 候选也不产（严格超越口径）"
        );
    }

    #[test]
    fn first_sell_requires_b_envelope_break_03720() {
        // ★T4 上涨镜像：c1.dd=290 > c0.gg=210 ⟹ Trend(Up)；b_hi=410 > zg=400（门可绑定几何）。
        // 单腿变体：C 端点 405 破核心（> zg=400）未破极值（≤ b_hi=410）⟹ 杀；
        // 双腿变体：第二腿 415 > b_hi=410 ⟹ sell1 于破极值腿端点 @15。
        let c0 = dc(100, 200, 90, 210, 2);
        let c1 = dc(300, 400, 290, 410, 8);
        let leg_a = seg(Direction::Up, 3, 5, 150, 410); // A：b_hi=410 > zg=400
        let leg_b = seg(Direction::Down, 5, 7, 410, 405); // B
        let leg_c1 = seg(Direction::Up, 9, 11, 390, 405); // C 腿1：405 > zg=400 ✓，405 ≤ 410 ✗
                                                          // 单腿变体（杀伪镜像）：无 1 卖且无 struct_break 候选。
        let prices1: Vec<Tick> = vec![200, 200, 200, 200, 400, 300, 300, 300, 300, 301, 302, 303];
        let (closes1, src1) = closes_seq(&prices1);
        let segs1 = vec![leg_a, leg_b, leg_c1];
        let points1 = extract_signals(&[c0, c1], &segs1, &closes1, &src1, &MacdConfig::default());
        assert!(
            points1.iter().all(|p| !p.bits.sell1),
            "未破 b 极值 ⟹ 无 1 卖（037:20 镜像）"
        );
        assert!(
            points1.iter().all(|p| p.struct_break_dir.is_none()),
            "破核心未破 b 极值 ⟹ 连零 bit struct_break 候选也不产（镜像 D1 收缩）"
        );
        // 双腿变体（递延镜像）：C 内反向段未回核心 ⟹ 同一 episode；腿2 破极值触发。
        let leg_rev = seg(Direction::Down, 11, 13, 405, 402); // 402 > zg=400 未回核心 ⟹ 同 episode
        let leg_c2 = seg(Direction::Up, 13, 15, 402, 415); // C 腿2：415 > b_hi=410 ✓ 触发
                                                           // closes：I(A)=[3,5] 急涨（面积大）、I(C)=[9,15] 缓动平底（面积小 ⟹ C<A 成立）——
                                                           // 与买侧 T2「I(A) 急跌 / I(C) 缓动」镜像；初版 C 段 301→305 缓升使 dif 持续走高、
                                                           // C 面积反超 A（macd_c_lt_a=false ⟹ @15 仅 struct_break_dir=Some(Short) 无 bit），
                                                           // 属夹具几何错误，非门实装错误（结构链已实证全通）。
        let prices2: Vec<Tick> = vec![
            200, 200, 200, 200, 500, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250, 250,
        ];
        let (closes2, src2) = closes_seq(&prices2);
        let segs2 = vec![leg_a, leg_b, leg_c1, leg_rev, leg_c2];
        let points2 = extract_signals(&[c0, c1], &segs2, &closes2, &src2, &MacdConfig::default());
        let sell1: Vec<_> = points2.iter().filter(|p| p.bits.sell1).collect();
        assert_eq!(
            sell1.len(),
            1,
            "破极值腿端点破核心 ∧ C<A ⟹ 一个 1 卖（递延到因果触发段）"
        );
        assert_eq!(sell1[0].source_index, 15, "点在破极值腿端点 @15");
        assert_eq!(
            sell1[0].pivot_high, 415,
            "pivot_high = 破极值腿端点极值 415"
        );
    }

    #[test]
    fn force_proxies_juxtaposed_on_first_class_candidate() {
        // ★Step1/2 力度并置（force-proxy-survey-20260702.md）：extract_signals_force 与 extract_signals
        // 同产 BspPoint，且一类趋势背驰候选并置 A/C 段 5 proxy。复用上测 fixture（C<A 背驰成立）。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
            seg(Direction::Up, 11, 13, 80, 90), // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let pts = extract_signals_force(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());

        // BspPoint 结构字段与 extract_signals 逐字段一致（PartialEq 排除 force ⟹ Some/None 不改相等）。
        let plain = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        assert_eq!(
            pts, plain,
            "extract_signals_force 的 BspPoint 结构字段与 extract_signals 相同（force 旁挂）"
        );

        // 一类候选（buy1）的 point.force = Some(ForceProxies)，且 C<A（背驰=力度衰减，第24课:24）。
        let b1 = pts
            .iter()
            .find(|p| p.bits.buy1)
            .expect("fixture 产一个 1 买");
        let force = b1
            .force
            .expect("一类趋势背驰候选 point.force = Some（A/C 段可配对）");
        assert_eq!(b1.source_index, 15);
        assert!(
            force.seg_c.macd_area < force.seg_a.macd_area,
            "C 段面积 < A 段面积（趋势背驰）"
        );
        assert!(
            force.seg_a.dif_peak > 0.0 || force.seg_c.dif_peak > 0.0,
            "DIF 峰 proxy 已填充"
        );
        assert!(
            force.seg_a.price_amplitude > 0,
            "A 段价格振幅 proxy 已填充（tick 域）"
        );

        // 填充率报告（force 填充率 = Some / 一类候选数；三类候选 force=None 是诚实缺省非漏填）。
        let first_class = pts.iter().filter(|p| p.bits.buy1 || p.bits.sell1).count();
        let filled = pts
            .iter()
            .filter(|p| (p.bits.buy1 || p.bits.sell1) && p.force.is_some())
            .count();
        eprintln!(
            "[force 填充率] 候选总数={} 一类={} force填充={} 填充率={:.0}%",
            pts.len(),
            first_class,
            filled,
            if first_class > 0 {
                100.0 * filled as f64 / first_class as f64
            } else {
                0.0
            }
        );
        assert_eq!(
            filled, first_class,
            "所有一类趋势背驰候选（A/C 可配对）point.force 均 Some"
        );
    }

    /// #606 S1 抛光车（终审 F-低2）：钉死「`level=None` 全量 fallback 路径不写 `GRADE_SIDECAR`」——
    /// 只有 `extract_first_third_resume`（生产 incremental 重放）传 `Some(level)` 才触达捕获分支
    /// （`judge_segment` 文档已述该契约，本测试补一条直接单测锁）。复用上一测试 fixture（保证产
    /// 一个 buy1，否则测试空转）。
    #[test]
    fn fallback_full_recompute_does_not_capture_grade_sidecar() {
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
            seg(Direction::Up, 11, 13, 80, 90), // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let series = compute_macd(&closes, &MacdConfig::default());
        let closes_tick: Vec<Tick> = closes.iter().map(|&c| c as Tick).collect();

        otherwise_domain_sidecar_begin();
        let (points, _pans) = extract_signals_with_hist_anchored(
            &[c0, c1],
            &segs,
            None,
            None,
            &series.hist,
            &series.dif,
            &closes_tick,
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        assert!(
            points.iter().any(|p| p.bits.buy1),
            "fixture 仍需产一个 buy1（否则测试空转）"
        );
        let captured = otherwise_domain_sidecar_take();
        assert!(
            captured.is_empty(),
            "level=None 全量 fallback 路径不应写入 GRADE_SIDECAR（只有 incremental resume 传 \
             Some(level) 才捕获，见 judge_segment 文档 level 参数说明）"
        );
    }

    /// ★#885 S4-d（验收锁之一）+ #1249：分级记录**生产 sink** 捕获——Present 与否则域（Missing）
    /// 两域均按 `diverged` 落 sink（不再只落 env 门控的 thread_local sidecar），`level=None` 全量
    /// 入口同样捕获（`level` 字段占位 0，由 Classification 装配方盖章，见
    /// [`FirstClassGradeRecord`] 文档）。#1249 起分级器统一为全窗后扫：Present fixture 仍产 buy1
    /// （bottom 段后扫命中 leave+retest），否则域 fixture 仍零一类 bit（D2 否则域语义不变）。
    #[test]
    fn first_class_grade_sink_captures_present_and_otherwise_domain() {
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        // Present fixture（与上一测试同款：后扫 leave+retest 对，retest 端点 90 < zd=100）。
        let segs_present = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
            seg(Direction::Up, 11, 13, 80, 90), // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        // 否则域 fixture：仅 retest 端点改为 105（≥ zd=100，重回核心）⟹ 无第三类对 ⟹ 后扫
        // Missing；closes/结构门/diverged 与 Present fixture 逐字相同。
        let segs_missing = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
            seg(Direction::Up, 11, 13, 80, 105), // retest：重回核心（≥ zd=100）⟹ 无第三类对
            seg(Direction::Down, 13, 15, 90, 70), // bottom：破新低但 c 无第三类对 ⟹ Missing
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let series = compute_macd(&closes, &MacdConfig::default());
        let closes_tick: Vec<Tick> = closes.iter().map(|&c| c as Tick).collect();

        // ── Present：sink 2 条（leave Missing + bottom Present），字段逐位锁定 ──
        let mut sink = Vec::new();
        let (points, _pans) = extract_signals_with_hist(
            &[c0, c1],
            &segs_present,
            &series.hist,
            &series.dif,
            &closes_tick,
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut sink,
        );
        assert!(
            points.iter().any(|p| p.bits.buy1 && p.source_index == 15),
            "Present fixture 仍产 buy1（bottom 段后扫命中 leave+retest，#1249 判据统一）"
        );
        // #1249：c 全窗内 leave（[9,11]）与 bottom（[13,15]）两个 diverged 候选均落 sink——
        // leave 的 as_of=11 尚未含 retest ⟹ Missing；bottom 的 as_of=15 含 leave+retest ⟹ Present。
        assert_eq!(
            sink.len(),
            2,
            "两个 diverged 一类候选 ⟹ 两条分级记录（Missing+Present）"
        );
        let rec = sink
            .iter()
            .find(|r| r.source_index == 15)
            .expect("bottom 分级记录按坐标可查");
        assert_eq!(rec.side, Side::Long);
        assert_eq!(
            (
                rec.center_start_index,
                rec.center_end_index,
                rec.center_zd,
                rec.center_zg
            ),
            (c1.start_index, c1.end_index, c1.zd, c1.zg),
            "中枢身份 = 判定中枢 c1（取自该点自身，非重新查找）"
        );
        assert_eq!(
            rec.grade,
            T3InCScan::Present {
                leave_interval: (9, 11),
                retest_interval: (11, 13)
            }
        );
        assert!(sink
            .iter()
            .any(|r| r.source_index == 11 && r.grade == T3InCScan::Missing));

        // ── 否则域：sink 2 条 Missing（leave 与 bottom 两 diverged 候选），点仍零一类 bit ──
        let mut sink = Vec::new();
        let (points, _pans) = extract_signals_with_hist(
            &[c0, c1],
            &segs_missing,
            &series.hist,
            &series.dif,
            &closes_tick,
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut sink,
        );
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "否则域点仍零一类 bit（#607 D2 语义不变，本票只建可查性）"
        );
        assert!(
            points
                .iter()
                .any(|p| p.source_index == 11 && p.struct_break_dir == Some(Side::Long)),
            "否则域点仍进 BspPoint 样本（零 bit 结构候选，D2 不改候选集合）"
        );
        assert_eq!(sink.len(), 2, "否则域两条记录均落 sink（此前按坐标查不到）");
        assert!(sink.iter().all(|r| r.grade == T3InCScan::Missing));
        assert!(sink.iter().any(|r| r.source_index == 11));
        assert!(sink.iter().any(|r| r.source_index == 15));
        // sidecar 未打开 ⟹ 生产 sink 捕获与 sidecar 无耦合（take 返回空）。
        assert!(otherwise_domain_sidecar_take().is_empty());
    }

    /// 三口径 D 判定接线（A2 #163）：同一 fixture 下 gauge 切换只改 buy1/sell1 置位，不改候选集合
    /// （struct_break_dir 无条件置——未背驰候选进样本，消选择偏差语义在三口径下保持）。
    #[test]
    fn divergence_gauge_switches_first_class_bit_not_candidate_set() {
        // 复用 force_proxies_juxtaposed fixture（MacdArea 口径 C<A 背驰成立 ⟹ buy1）。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
            seg(Direction::Up, 11, 13, 80, 90), // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let series = compute_macd(&closes, &MacdConfig::default());
        let closes_tick: Vec<Tick> = closes.iter().map(|&c| c as Tick).collect();
        let run = |g: DivergenceGauge| {
            extract_signals_with_hist(
                &[c0, c1],
                &segs,
                &series.hist,
                &series.dif,
                &closes_tick,
                &src,
                g,
                &[],
                &mut Vec::new(),
            )
            .0
        };
        let (base, dom, conj) = (
            run(DivergenceGauge::MacdArea),
            run(DivergenceGauge::ThetaDom),
            run(DivergenceGauge::Conjunction),
        );
        // 候选集合不变：破中枢结构候选（struct_break_dir=Some）三口径逐点同数同位。
        let sb = |v: &[BspPoint]| {
            v.iter()
                .filter(|p| p.struct_break_dir.is_some())
                .map(|p| p.source_index)
                .collect::<Vec<_>>()
        };
        assert_eq!(sb(&base), sb(&dom), "gauge 只改 D 置位，不改破中枢候选集合");
        assert_eq!(sb(&base), sb(&conj));
        // 基线口径产 buy1（fixture 保证 C<A）。
        let b1 = |v: &[BspPoint]| v.iter().filter(|p| p.bits.buy1).count();
        assert_eq!(b1(&base), 1, "MacdArea 口径 fixture 产 1 买");
        // 口径语义一致性：产出 BspPoint 携带的 force 就是判定输入（单一来源）——ThetaDom 口径的
        // buy1 置位 ⟺ force_state==Dominated；Conjunction ⟺ MACD ∧ Dominated（逐点可验）。
        let cand = base.iter().find(|p| p.bits.buy1).unwrap();
        let dominated = cand.force.expect("一类候选 force=Some").force_state()
            == super::super::divergence::ForceStateA5::Dominated;
        assert_eq!(b1(&dom) == 1, dominated, "ThetaDom 口径 buy1 ⟺ Dominated");
        assert_eq!(
            b1(&conj) == 1,
            dominated,
            "Conjunction = MACD(true) ∧ Dominated"
        );
    }

    #[test]
    fn first_buy_rejected_in_consolidation_tau_gate() {
        // ★τ 门控核心否决（消解假背驰=假买卖点）：**单中枢（盘整 τ=Consolidation）不产第一类**。
        // 同样的破中枢段 + 力度衰减，但只有 1 个中枢 ⟹ 盘整背驰（非趋势背驰）⟹ 第一类不产
        // （beichi #4 + maimai.md:56「盘整背驰不产第一类」已结算）。这正是退化实现的假买卖点来源。
        let c = dc(100, 200, 90, 210, 2);
        let segs = vec![
            seg(Direction::Down, 3, 5, 150, 90), // 破中枢段（前）
            seg(Direction::Down, 6, 8, 120, 80), // 破中枢段（后，面积更小）
        ];
        let prices: Vec<Tick> = vec![100, 100, 100, 100, 60, 140, 100, 95, 105];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c], &segs, &closes, &src, &MacdConfig::default());
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "单中枢=盘整 τ ⟹ 第一类不产（盘整背驰非趋势背驰，beichi #4）——τ 门控否决假买卖点"
        );
    }

    #[test]
    fn first_buy_rejected_when_segment_in_consolidation_block() {
        // ★局部趋势门（Q1/Q8，task #144）：段所在块为 **Consolidation**（链尾扩张关系）⟹ 第一类
        // 不产。链 = [Trend(Up) 0..1, Consolidation 1..2]——早期趋势块不为后续盘整块内的段开门
        // （门作用域=段当时所在块，非任意历史块；盘整背驰承接路由归 #145/Q4）。
        let c0 = dc(100, 200, 90, 210, 2);
        let c1 = dc(300, 400, 290, 410, 5); // c0→c1 上涨
        let c2 = dc(350, 450, 250, 460, 8); // c1→c2 扩张 ⟹ c2 落在盘整块（gate[2]=None）
        let segs = vec![
            seg(Direction::Down, 9, 11, 150, 80), // 破 c2，但段所在块=Consolidation ⟹ 门关
        ];
        let prices: Vec<Tick> = vec![100, 100, 100, 100, 60, 140, 100, 95, 105, 150, 145, 80];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1, c2], &segs, &closes, &src, &MacdConfig::default());
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "段的最近中枢落在盘整块 ⟹ 局部趋势门关 ⟹ 第一类不产"
        );
    }

    #[test]
    fn first_buy_fires_after_early_overlap_no_global_lock_in() {
        // ★§10 不锁死性质（PDF §10，task #144 机器验证）：早期 overlap 关系 + 后续局部同向块
        // ⟹ 门开、第一类照产。旧 AllTrend 谓词下本链 ∃r_j=Overlap ⟹ 永久 Degenerate ⟹ 0
        // （吸收锁死，外审坐实 BTC 全历史第 1-17 天锁死 8.8 年）；分解门下早期历史不传导。
        let c_pre = dc(280, 420, 270, 430, 1); // 与 c0 overlap（非 GG/DD 完全分离）
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8); // c0→c1 Down（GG=210 < DD(c0)=290）
        let centers = [c_pre, c0, c1];
        // §10 前件断言：链首关系确为 overlap（产盘整块），尾部为局部同向趋势块。
        let blocks = decompose(&centers);
        assert_eq!(
            blocks.iter().map(|b| b.kind).collect::<Vec<_>>(),
            vec![MoveKind::Consolidation, MoveKind::Trend],
            "前件：早期 overlap ⟹ 首块盘整；后续同向 ⟹ 尾块 Trend"
        );
        // fixture 同 force 测试的 buy1 见证：A 段深 V 大力度，C 段缓降破 zd(c1)=100 ⟹ 背驰。
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
            seg(Direction::Up, 11, 13, 80, 90), // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, 250, 250, 250, 248, 246, 244, 242, 240, 238, 236,
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&centers, &segs, &closes, &src, &MacdConfig::default());
        assert!(
            points.iter().any(|p| p.bits.buy1 && p.source_index == 15),
            "§10：早期 overlap 不锁死——尾部局部趋势块内破中枢背驰段照产第一类"
        );
    }

    #[test]
    fn first_buy_rejected_without_divergence() {
        // ★P2 语义纪律（codex-decide-20260701-2121）：MACD C<A 从 gate 降为 feature。趋势中破最后
        //   中枢但 **C 段力度未衰减**（C 段面积 ≥ A 段 ⟹ macd_c_lt_a==false）——不再被 MACD 预删，
        //   而是作为 **struct_break 候选进样本**（消选择偏差，下游 χ 可检验），但**不置 buy1**（buy1
        //   保严格「趋势背驰」语义，未背驰的破中枢不冒充第一类）。feature `macd_c_lt_a` 记 sidecar，
        //   **不进 BspPoint**（bit-exact 隔离，codex 风险2）。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250), // A 段
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80), // C 段：破中枢但力度延续
        ];
        // A 段小幅、C 段大幅 ⟹ C 面积 > A ⟹ 力度延续（非背驰）。
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 295, 305, // 3..5 A 段：小幅（hist 小）
            250, 280, 260, 150, 60,
            240, // 9..11 C 段：大幅（hist 大 ⟹ 力度延续 ⟹ 非背驰）
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        // buy1 保严格语义：未背驰 ⟹ 不置 buy1（不冒充第一类）。
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "C 段力度延续 ⟹ 非趋势背驰 ⟹ buy1 不置位（保严格语义）"
        );
        // 破中枢结构候选**仍产出**（进样本，消选择偏差）——source_index=11（C 段破中枢端点）。
        let sb_pt: Vec<_> = points.iter().filter(|p| p.source_index == 11).collect();
        assert_eq!(sb_pt.len(), 1,
            "struct_break 候选进 BspPoint 样本（零 buy1=Flat 候选，assemble_gamma 归 𝒦 不冒充第一类）"
        );
        // ★P2-R2（p2-plan §2）：该零 bit 候选带 struct_break_dir=Some(Long)——下游 candidate_dir 用它
        // 恢复 Long 方向进 μ 样本（消选择偏差）。买侧向下破 ⟹ Long。bit-vector 仍全零（class_index=0）。
        assert_eq!(sb_pt[0].struct_break_dir, Some(Side::Long),
            "零 bit 破中枢候选带 struct_break_dir=Some(Long)（下游 candidate_dir 恢复方向进样本，消选择偏差）");
        assert_eq!(sb_pt[0].bits.class_index(), 0,
            "六 bit 全零（未背驰不置 buy1）⟹ class_index=0——struct_break_dir 不进桶键（bit-exact 冻结）");
    }

    #[test]
    fn diverging_break_sets_buy1_and_struct_break_dir() {
        // ★P2-R2 对偶（背驰确认路径）：C 段力度衰减（C<A）⟹ 严格第一类（置 buy1）∧ struct_break_dir
        //   =Some(Long)。macd_c_lt_a=true 从产出派生（bits.buy1=true ⟺ C<A，护栏7 删 sidecar 后的等价）。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80), // C 段：破 C1 下沿 ∧ 背驰 ⟹ 1 买
            seg(Direction::Up, 11, 13, 80, 90),   // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 100, 250, // A 段急跌（强力度）
            250, 250, 250, 248, 246, 244, // leave 缓动（弱力度=背驰）
            242, 240, 238, 236, // 12..15 retest+bottom：延续缓跌
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        // 背驰 ⟹ 置 buy1（严格第一类）。macd_c_lt_a=true 从 bits.buy1=true 派生（护栏7 删 sidecar 等价）。
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert_eq!(
            buy1.len(),
            1,
            "C<A 趋势背驰 ⟹ 一个严格第一类 1 买（buy1 置位 ⟺ macd_c_lt_a=true）"
        );
        assert_eq!(buy1[0].source_index, 15);
        // ★P2-R2：背驰确认的破中枢点也带 struct_break_dir=Some(Long)——**无条件置**（不管背驰）。
        // 此点有 buy1 六 bit ⟹ candidate_dir 走 root_sel=Long，struct_break_dir 与之一致（不改结果，护栏1）。
        assert_eq!(
            buy1[0].struct_break_dir,
            Some(Side::Long),
            "破中枢方向无条件置（背驰确认路径同样 Some(Long)）——与 buy1 的 root_sel 方向一致"
        );
    }

    /// ★P2-R2 验收（判据「|结构候选域|>|MACD-veto候选域|」的可机器验证形式）：同一 C≥A 破中枢输入下，
    /// 结构版 `extract_signals`（无 veto，破中枢候选全进样本）产出的候选**严格多于** MACD-veto oracle
    /// `extract_signals_orig`（`judge_first_orig` 的 `!diverges ⟹ return None`，pre-P2-R2 面积门语义）。
    /// 差集恰是被 MACD C≥A 预删、经 `struct_break_dir` 恢复的零 bit 破中枢候选（下游 χ 可否证 MACD）。
    #[test]
    fn struct_candidate_domain_strictly_supersets_macd_veto_domain() {
        let cfg = MacdConfig::default();
        // first_buy_rejected_without_divergence 的输入：趋势 ∧ 破最后中枢 ∧ C≥A（力度延续，非背驰）。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 80),
        ];
        let prices: Vec<Tick> = vec![300, 300, 300, 300, 295, 305, 250, 280, 260, 150, 60, 240];
        let (closes, src) = closes_seq(&prices);
        let structural = extract_signals(&[c0, c1], &segs, &closes, &src, &cfg);
        let veto = extract_signals_orig(&[c0, c1], &segs, &closes, &src, &cfg);
        // C≥A 破中枢候选：veto oracle 预删，结构版恢复进样本 ⟹ 结构候选域严格 ⊋ veto 候选域。
        assert!(
            structural.len() > veto.len(),
            "结构候选域 |{}| 须严格 > MACD-veto 候选域 |{}|（C≥A 破中枢候选被 veto 预删，结构版恢复进样本）",
            structural.len(),
            veto.len()
        );
        // 差集载体：带 struct_break_dir=Some ∧ 零 bit（class_index=0，未冒充第一类）的破中枢候选。
        let recovered: Vec<_> = structural
            .iter()
            .filter(|p| p.struct_break_dir.is_some() && p.bits.class_index() == 0)
            .collect();
        assert!(
            !recovered.is_empty(),
            "被恢复的候选带 struct_break_dir=Some ∧ 零 bit（未冒充第一类，class_index=0）"
        );
    }

    #[test]
    fn first_buy_rejected_without_broke_center() {
        // 趋势中 C 段未破最后中枢下沿（端点 120 ∈ [100,200]）⟹ 非第一类（几何不足）。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 150, 120), // 端点 120 >= zd=100，未破最后中枢
        ];
        let prices: Vec<Tick> = vec![300, 300, 300, 300, 200, 400, 250, 280, 260, 150, 145, 120];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "C 段未破最后中枢 ⟹ 非第一类（几何分量不足）"
        );
    }

    #[test]
    fn first_buy_rejected_without_prev_center_leave_segment() {
        // 趋势中无 A 段（前中枢 C0 与后中枢 C1 之间无向下离开段）⟹ A/C 无法配对 ⟹ 非第一类。
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            // C0(end=2) 与 C1(end=8) 之间只有向上段，无向下离开段 ⟹ A 段（向下）无候选。
            seg(Direction::Up, 3, 5, 250, 350),
            seg(Direction::Down, 9, 11, 150, 80), // C 段：破最后中枢但无 A 段对照
        ];
        let prices: Vec<Tick> = vec![300, 300, 300, 250, 300, 350, 250, 280, 260, 150, 145, 80];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "无前中枢离开段（A 段无法定位）⟹ 非第一类"
        );
    }

    #[test]
    fn first_sell_mirror_with_trend_divergence() {
        // ★趋势背驰 1 卖镜像：两依次向上中枢（上涨趋势 τ=Trend(Up)）。
        // - C0[100,200] dd=90  gg=210 end=2（前中枢，A 段所在）。
        // - C1[300,400] dd=290 gg=410 end=8（后中枢，c1.dd=290 > c0.gg=210 ⟹ 上涨延续 ⟹ 趋势）。
        // - A 段 [3,5]：C0 之后向上离开段（端点 > C0.zg=200），面积大。
        // - C 段 [9,11]：C1 之后向上破中枢段（端点 420 > C1.zg=400），面积小（顶背驰）⟹ 1 卖。
        let c0 = dc(100, 200, 90, 210, 2);
        let c1 = dc(300, 400, 290, 410, 8);
        let segs = vec![
            seg(Direction::Up, 3, 5, 150, 250), // A 段：C0 离开段（破 C0 上沿）
            seg(Direction::Down, 5, 7, 250, 280), // B 段连接
            seg(Direction::Up, 9, 11, 350, 420), // leave：三买离开，破 C1 上沿（> 400）
            seg(Direction::Down, 11, 13, 420, 410), // retest：三买回试，不重回（> zg）
            seg(Direction::Up, 13, 15, 410, 430), // top：一卖破新高（后扫命中 leave+retest）
        ];
        // closes 镜像（A 段急涨强力度、C 段缓动弱力度=顶背驰）：A area[3,5]=23.26 > C area[9,11]=9.09。
        let prices: Vec<Tick> = vec![
            200, 200, 200, 200, 400, 250, // 3..5 A 段：急涨（hist 大=强力度）
            250, 250, 250, // 6..8 B 段：盘整收敛 EMA
            252, 254, 256, // 9..11 leave：缓动（hist 小=顶背驰）
            258, 260, 262,
            264, // 12..15 retest+top：延续缓涨（I(C)=[9,15] 面积仍 < A）
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        let sell1: Vec<_> = points.iter().filter(|p| p.bits.sell1).collect();
        assert_eq!(
            sell1.len(),
            1,
            "上涨趋势 C 段破最后中枢上沿 ∧ 顶背驰 ⟹ 一个 1 卖"
        );
        assert_eq!(
            sell1[0].source_index, 15,
            "1 卖端点 = 破新高 top 段终止 source_index"
        );
        assert_eq!(
            sell1[0].pivot_high, 430,
            "1 卖止损源 = pivot_high（破新高 top 段端点）"
        );
        // ★owner 载体补齐（关③ 补记② 路径 (a)）：一类点构造时填入判定中枢 last_center=c1
        //（上涨趋势镜像，被破的最后中枢）——名实一致根据同一类买侧；center 是 owner 载体，
        // 止损仍 pivot（pivot_high=420 上条已锁，center 不进 1/2 类止损判据）。
        // （#218 面 A 载体形态机械适配：一/三类载 OwnerRef::Center，语义不动。）
        assert_eq!(
            sell1[0].center,
            Some(OwnerRef::Center(c1)),
            "一类点 center = 判定中枢（owner 载体）；止损仍 pivot 非 center"
        );
    }

    // ── Q5（task #145）：A/C 从单段升级为次级别走势区间——多段 departure 语义真变 ────

    /// Q5 A 侧语义变更见证：A 由 2 个同向段构成（中间夹反向段）。旧单段口径（A=末个匹配段
    /// [7,9]）不判背驰（C 面积 ≥ 旧 A 面积）；新区间口径（I(A)=[3,9] 覆盖全离开走势）判背驰
    /// ⟹ buy1 置位。前置条件在测试内用同一 `segment_macd_area` 自证（fixture 不靠魔数）。
    #[test]
    fn q5_multi_segment_departure_a_interval_flips_divergence() {
        use super::super::divergence::segment_macd_area;
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250),  // A 腿1（深）
            seg(Direction::Up, 5, 7, 250, 280),    // A 内部反向段
            seg(Direction::Down, 7, 9, 280, 240),  // A 腿2（浅，旧口径的"末段 A"）
            seg(Direction::Down, 13, 15, 150, 80), // leave：三卖离开，破 c1.zd=100
            seg(Direction::Up, 15, 17, 80, 90),    // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 17, 19, 90, 70),  // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 200, 260, 262, 264, 263, 262, 262, 262, 262, 240, 215, 190, 230,
            240, 250, 260,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        // 前置自证：area(旧A=[7,9]) < area(C=[13,15]) < area(新A=[3,9])——旧口径不背驰、新口径背驰。
        let (a_old, c_area, a_new) = (
            segment_macd_area(&hist, 7, 9, Direction::Down),
            segment_macd_area(&hist, 13, 15, Direction::Down),
            segment_macd_area(&hist, 3, 9, Direction::Down),
        );
        assert!(
            a_old < c_area,
            "前置：旧单段 A 面积({a_old:.3}) < C 面积({c_area:.3})（旧口径不判背驰）"
        );
        assert!(
            c_area < a_new,
            "前置：C 面积({c_area:.3}) < 新区间 A 面积({a_new:.3})（新口径判背驰）"
        );
        // 生产输出：新区间口径 ⟹ 背驰成立 ⟹ buy1（旧口径下此点是零 bit struct_break 候选）。
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert_eq!(
            buy1.len(),
            1,
            "Q5：I(A) 覆盖全离开走势区间 ⟹ 背驰成立 ⟹ buy1（语义真变，非兼容重构）"
        );
        assert_eq!(buy1[0].source_index, 19);
    }

    /// Q5 C 侧语义变更见证（反向）：C 由 2 个同向段构成。旧单段口径（C=破中枢段 [18,20]）判
    /// 背驰；新区间口径（I(C)=[λ_C=13, 20] 覆盖全离开走势）不判 ⟹ 零 bit struct_break 候选。
    #[test]
    fn q5_multi_segment_departure_c_interval_flips_divergence() {
        use super::super::divergence::segment_macd_area;
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250), // A（单段）
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 13, 15, 180, 90), // C 腿1：破 zd=100（候选点，episode 起点 λ_C=13）
            seg(Direction::Up, 16, 17, 90, 96), // C 内部反向段（end 96 < zd=100 未回核心 ⟹ 同一 episode）
            seg(Direction::Down, 18, 20, 96, 80), // C 腿2：再破（因果触发段，I(C)=[13,20]）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 262, 250, 265, 275, 280, 282, 283, 284, 284, 250, 200, 150, 230,
            280, 279, 278, 277,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        // 前置自证：area(旧C=[18,20]) < area(A=[3,5]) < area(新C 腿1=[13,15] ≤ [13,20])——
        // 旧口径在 20 判背驰、新区间口径两个候选点（15/20）都不判。
        let (c_old, a_area, c_leg1) = (
            segment_macd_area(&hist, 18, 20, Direction::Down),
            segment_macd_area(&hist, 3, 5, Direction::Down),
            segment_macd_area(&hist, 13, 15, Direction::Down),
        );
        assert!(
            c_old < a_area,
            "前置：旧单段 C 面积({c_old:.3}) < A 面积({a_area:.3})（旧口径判背驰）"
        );
        assert!(
            a_area < c_leg1,
            "前置：A 面积({a_area:.3}) < 新区间 C 面积下界({c_leg1:.3})（新口径不判背驰）"
        );
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        assert!(
            points.iter().all(|p| !p.bits.buy1),
            "Q5：I(C) 覆盖全离开走势区间 ⟹ 力度未衰减 ⟹ buy1 不置位（语义真变）"
        );
        // 破中枢结构候选仍进样本（P2-R2 消选择偏差）：零 bit + struct_break_dir=Some(Long)。
        let sb: Vec<_> = points
            .iter()
            .filter(|p| p.source_index == 20 && p.struct_break_dir == Some(Side::Long))
            .collect();
        assert_eq!(sb.len(), 1, "未背驰破中枢候选仍产零 bit struct_break 点");
        assert_eq!(sb[0].bits.class_index(), 0);
    }

    /// codex ac4 #2 修复见证（C 侧 reentry）：失败离开 [9,11]（未破 zd=100）→ 回中枢段 [11,13]
    /// （端点 150 回到核心内侧 ≥ zd）→ 重新离开 [13,15] 破中枢。λ_C = 当前 episode 起点 13（非旧
    /// 口径 9）——I(C)=[13,15] 面积 < A < 桥接区间 [9,15] 面积 ⟹ episode 口径判背驰 buy1；桥接
    /// 口径不判（前置在测试内自证）。
    #[test]
    fn q5_c_side_reentry_episode_bounds_lambda_c() {
        use super::super::divergence::{departure_move_c_start, segment_macd_area};
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250), // A
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 190, 120), // 失败离开（end 120 > zd=100 未破）
            seg(Direction::Up, 11, 13, 120, 150),  // 回中枢段（end 150 ≥ zd=100）
            seg(Direction::Down, 13, 15, 150, 80), // 重新离开：破 zd（因果触发段）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 220, 200, 230, 260, 265, 250, 235, 240, 265, 266, 265, 264,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        // λ_C 直接锁定（共享 helper 单一来源）。
        assert_eq!(
            departure_move_c_start(
                &segs,
                &super::super::divergence::self_anchors(&segs),
                &c1,
                Direction::Down,
                13
            ),
            Some(13),
            "回中枢段之后 ⟹ λ_C = 当前 episode 首同向段起点"
        );
        // 前置自证：episode I(C) < A < 桥接 [9,15]——修复前后布尔翻转的见证条件。
        let (c_ep, a_area, c_bridged) = (
            segment_macd_area(&hist, 13, 15, Direction::Down),
            segment_macd_area(&hist, 3, 5, Direction::Down),
            segment_macd_area(&hist, 9, 15, Direction::Down),
        );
        assert!(
            c_ep < a_area,
            "前置：episode C 面积({c_ep:.3}) < A 面积({a_area:.3})"
        );
        // #988 同色口径下该前提方向翻转（Down 绿柱主导：桥接 C ≤ A）——
        // 「旧桥接口径不判背驰」的见证改为：episode 口径 C < A 判背驰、桥接口径不比 episode 更强。
        // 生产断言（buy1 空）不受影响：λ_C 取 episode 边界，非桥接。
        assert!(
            c_bridged >= c_ep,
            "前置：桥接 C 面积({c_bridged:.3}) ≥ episode C 面积({c_ep:.3})"
        );
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        // ★#1249（#1229 裁定 a）：c 全窗 [λ_C=13, seg.end=15] 后扫——失败离开段 [9,11]（价 120，
        // 未破 zd=100）与回中枢段 [11,13]（价 150 回核心）都落在 λ_C 之前（episode 边界重置
        // λ_C=13），窗内仅重新离开段 [13,15] 单段（可作 leave 但无紧随 retest）⟹ 后扫 `Missing`
        // ⟹ 否则域：零一类 bit，继续走候选流（struct_break_dir 无条件置，P2-R2 先例）。λ_C reentry
        // 修复的是「候选資格」（broke 门 + I(C) 面积衰减，上方前置断言不变）；T3-in-c 是独立于
        // λ_C 的另一层几何合取，两者不桥接。
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert!(
            buy1.is_empty(),
            "c 全窗后扫无第三类对（失败离开与回中枢段在 λ_C 前、重离开段无回试）⟹ 否则域，1 买不置位（#1249）"
        );
        let sb_pt: Vec<_> = points.iter().filter(|p| p.source_index == 15).collect();
        assert_eq!(
            sb_pt.len(),
            1,
            "λ_C reentry 修复的候选仍进样本（零 bit struct_break，D2 否则域不改候选集合）"
        );
        assert_eq!(
            sb_pt[0].struct_break_dir,
            Some(Side::Long),
            "零 bit 候选带 struct_break_dir=Some（P2-R2 消选择偏差）"
        );
        assert_eq!(
            sb_pt[0].bits.class_index(),
            0,
            "否则域 ⟹ 六 bit 全零（class_index=0）"
        );
    }

    /// codex ac4 #3：C 侧单段兼容独立锁定——中枢后恰一个同向离开段（无回中枢段）⟹ λ_C =
    /// seg.start_index ⟹ I(C) = 旧单段区间，行为与旧口径 bit 相同（不依赖「全局第一个匹配段」
    /// 之外的隐式前提——本 fixture 中该段即首匹配段，且 helper 输出被显式锁定）。
    #[test]
    fn q5_c_side_single_segment_bit_compatible() {
        use super::super::divergence::{departure_move_c_start, segment_macd_area};
        let c0 = dc(300, 400, 290, 410, 2);
        let c1 = dc(100, 200, 90, 210, 8);
        let segs = vec![
            seg(Direction::Down, 3, 5, 350, 250), // A（单段）
            seg(Direction::Up, 5, 7, 250, 280),
            seg(Direction::Down, 9, 11, 280, 80), // C：唯一离开段，破 zd=100
            seg(Direction::Up, 11, 13, 80, 90),   // retest：三卖回试，不重回（< zd）
            seg(Direction::Down, 13, 15, 90, 70), // bottom：一买破新低（后扫命中 leave+retest）
        ];
        let prices: Vec<Tick> = vec![
            300, 300, 300, 300, 180, 170, 250, 300, 300, 298, 296, 294, 292, 290, 288, 286,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        assert_eq!(
            departure_move_c_start(
                &segs,
                &super::super::divergence::self_anchors(&segs),
                &c1,
                Direction::Down,
                9
            ),
            Some(9),
            "单段离开 ⟹ λ_C = seg.start_index（与旧单段口径 bit 相同）"
        );
        let (c_area, a_area) = (
            segment_macd_area(&hist, 9, 11, Direction::Down),
            segment_macd_area(&hist, 3, 5, Direction::Down),
        );
        assert!(
            c_area < a_area,
            "前置：C 面积({c_area:.3}) < A 面积({a_area:.3})（背驰成立）"
        );
        let points = extract_signals(&[c0, c1], &segs, &closes, &src, &MacdConfig::default());
        let buy1: Vec<_> = points.iter().filter(|p| p.bits.buy1).collect();
        assert_eq!(
            buy1.len(),
            1,
            "单段 C + bottom：与旧口径同判 buy1（#1249 后扫命中 leave+retest）"
        );
        assert_eq!(buy1[0].source_index, 15);
    }

    // ── Q4（task #145）：盘整背驰证书（PanDivCert）——盘整块内破中枢+背驰，零一类 bit ────

    /// #69 5b / T1：e_src 公式必须只有一个 source_index 量纲来源；等于边界的段仍属可变尾。
    #[test]
    fn freeze_boundary_src_grid_and_strict_segment_gate() {
        let centers = [
            dc(100, 200, 90, 210, 10),
            dc(300, 400, 290, 410, 20),
            dc(500, 600, 490, 610, 30),
        ];
        assert_eq!(freeze_boundary_src(&centers, 0, usize::MAX), 0);
        assert_eq!(freeze_boundary_src(&centers, 1, usize::MAX), 0);
        assert_eq!(freeze_boundary_src(&centers, 2, usize::MAX), 10);
        assert_eq!(freeze_boundary_src(&centers, 3, usize::MAX), 20);
        assert_eq!(freeze_boundary_src(&centers, 3, 17), 17);

        let segments = [
            seg(Direction::Down, 1, 16, 200, 100),
            seg(Direction::Up, 16, 17, 100, 180),
            seg(Direction::Down, 17, 18, 180, 90),
        ];
        let e_src = freeze_boundary_src(&centers, 3, 17);
        assert_eq!(
            segments.partition_point(|segment| segment.end_index < e_src),
            1,
            "segment.end_index == e_src 必须留在冷算尾部"
        );
    }

    /// Q4 正例：段的最近中枢落在 Consolidation 块（沿用 first_buy_rejected_when_segment_in_
    /// consolidation_block 的中枢链）+ 同一中枢两次同向离开（A 破核心 → 回中枢段 → C 破核心）
    /// + C<A 背驰 ⟹ 产 PanDivCert；**零 BspPoint 一类 bit**（盘整背驰不冒充 B1/S1）。
    #[test]
    fn pan_div_cert_emitted_in_consolidation_block_zero_first_class_bits() {
        use super::super::divergence::segment_macd_area;
        let c0 = dc(100, 200, 90, 210, 2);
        let c1 = dc(300, 400, 290, 410, 5); // c0→c1 上涨（趋势块）
        let c2 = dc(350, 450, 250, 460, 8); // c1→c2 扩张 ⟹ c2 按 ownership 落盘整块
        let segs = vec![
            seg(Direction::Down, 9, 11, 460, 330), // A：第一次离开（端点 330 < c2.zd=350 破核心）
            seg(Direction::Up, 11, 13, 330, 380),  // 回中枢段（端点 380 ≥ 350 回到核心内侧）
            seg(Direction::Down, 13, 15, 380, 300), // C：第二次离开（端点 300 < 350 破核心）
        ];
        let prices: Vec<Tick> = vec![
            100, 100, 100, 100, 60, 140, 100, 95, 105, 105, 60, 90, 95, 93, 91, 89,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        // 前置自证：C 面积 < A 面积（盘整背驰 Weak 成立）。
        let (a_area, c_area) = (
            segment_macd_area(&hist, 9, 11, Direction::Down),
            segment_macd_area(&hist, 13, 15, Direction::Down),
        );
        assert!(
            c_area < a_area,
            "前置：C 面积({c_area:.3}) < A 面积({a_area:.3})"
        );
        let (points, pan) = extract_signals_with_hist(
            &[c0, c1, c2],
            &segs,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        // 零一类 bit（盘整块内不产第一类——门关；盘整背驰不冒充 B1/S1）。
        assert!(
            points.iter().all(|p| !p.bits.buy1 && !p.bits.sell1),
            "盘整块内零 buy1/sell1（盘整背驰不冒充同级第一类）"
        );
        // 恰一张证书，字段逐一锁定。
        assert_eq!(
            pan.len(),
            1,
            "同一中枢两次同向离开 + C<A ⟹ 恰一张 PanDivCert"
        );
        let cert = &pan[0];
        assert_eq!(cert.source_index, 15, "因果触发点 = 破中枢段端点");
        assert_eq!(cert.side, Side::Long, "向下破 ⟹ Long 候选");
        assert_eq!(
            (cert.center.zd, cert.center.zg),
            (350, 450),
            "证书携同一中枢（两次离开的 B）"
        );
        assert_eq!(cert.seg_a, (9, 11), "A = 前一次同向离开末段");
        assert_eq!(
            cert.seg_c,
            (13, 15),
            "I(C) = 当前离开走势区间（Q5 同款区间语义）"
        );
    }

    /// #483 正例（24 课第二支）：C 端点仍在中枢核心内，但同色 MACD 柱面积严格 C<A，
    /// 只产 PanDivCert 形状的观测证书；不产任何 BspPoint，也不进入生产 PanDiv 承接。
    #[test]
    fn pan_div_unbroken_core_area_divergence_emits_observation_only() {
        use super::super::divergence::same_color_area;
        let c0 = dc(100, 200, 90, 210, 2);
        let c1 = dc(300, 400, 290, 410, 5);
        let c2 = dc(350, 450, 250, 460, 8);
        let segs = vec![
            seg(Direction::Down, 9, 11, 460, 330),
            seg(Direction::Up, 11, 13, 330, 380),
            seg(Direction::Down, 13, 15, 380, 360), // C：360 ∈ (zd=350, zg=450)
        ];
        let mut hist = vec![0.0; 16];
        hist[9..=11].copy_from_slice(&[-4.0, -3.0, -2.0]);
        hist[13..=15].copy_from_slice(&[-1.0, -1.0, -1.0]);
        let src: Vec<usize> = (0..hist.len()).collect();
        assert!(
            same_color_area(&hist, 13, 15, Side::Long) < same_color_area(&hist, 9, 11, Side::Long),
            "前置：24 课面积判据严格 C<A"
        );

        let anchors = super::super::divergence::self_anchors(&segs);
        let observation =
            judge_pan_div_observation(&c2, &segs[2], &segs, &anchors, &hist, &[], &src);
        let (points, production_pan) = extract_signals_with_hist(
            &[c0, c1, c2],
            &segs,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );

        assert!(points.is_empty(), "不破核心盘背只进观测层，不产 BspPoint");
        assert!(
            production_pan.is_empty(),
            "不破核心盘背不得进入既有生产 PanDiv 承接路径"
        );
        assert_eq!(
            observation,
            Some(PanDivCert {
                source_index: 15,
                side: Side::Long,
                center: c2,
                seg_a: (9, 11),
                seg_c: (13, 15),
            })
        );
    }

    /// #483 高危反例：Down C 端点反向越过核心上沿时，不属于「C 不破核心」授权范围。
    #[test]
    fn pan_div_unbroken_core_down_above_zg_is_rejected() {
        let c2 = dc(350, 450, 250, 500, 8);
        let segs = vec![
            seg(Direction::Down, 9, 11, 460, 330),
            seg(Direction::Up, 11, 13, 330, 380),
            seg(Direction::Down, 13, 15, 380, 500), // C：500 > zg=450，反向越界
        ];
        let mut hist = vec![0.0; 16];
        hist[9..=11].copy_from_slice(&[-4.0, -3.0, -2.0]);
        hist[13..=15].copy_from_slice(&[-1.0, -1.0, -1.0]);
        let src: Vec<usize> = (0..hist.len()).collect();
        let anchors = super::super::divergence::self_anchors(&segs);

        assert!(
            judge_pan_div_observation(&c2, &segs[2], &segs, &anchors, &hist, &[], &src).is_none(),
            "Down C 端点反向越过 zg 不得识别为 C 不破核心盘背"
        );
    }

    /// #483 高危反例：Up C 端点反向越过核心下沿时，D-3 取段也必须拒绝。
    #[test]
    fn pan_div_unbroken_core_up_below_zd_is_rejected() {
        let c2 = Center {
            zd: 350,
            zg: 450,
            dd: 300,
            gg: 500,
            start_index: 4,
            end_index: 8,
        };
        let segs = vec![
            seg(Direction::Up, 1, 3, 340, 460), // A：中枢前最近同向段（进入段）
            seg(Direction::Up, 9, 11, 380, 300), // C：300 < zd=350，反向越界
        ];
        let mut hist = vec![0.0; 12];
        hist[1..=3].copy_from_slice(&[4.0, 3.0, 2.0]);
        hist[9..=11].copy_from_slice(&[1.0, 1.0, 1.0]);
        let src: Vec<usize> = (0..hist.len()).collect();
        let anchors = super::super::divergence::self_anchors(&segs);

        assert!(
            judge_pan_div_observation(&c2, &segs[1], &segs, &anchors, &hist, &[], &src).is_none(),
            "Up C 端点反向越过 zd 不得经 D-3 取段识别为 C 不破核心盘背"
        );
    }

    /// #483 反例锁：C 不破核心时，24 课只授权同色柱面积严格 C<A；即使既有 OR 判据的
    /// DIF 峰衰减成立，只要面积不背驰，也不得识别。
    #[test]
    fn pan_div_unbroken_core_without_area_divergence_is_rejected() {
        use super::super::divergence::{same_color_area, segments_diverge_or};
        let c0 = dc(100, 200, 90, 210, 2);
        let c1 = dc(300, 400, 290, 410, 5);
        let c2 = dc(350, 450, 250, 460, 8);
        let segs = vec![
            seg(Direction::Down, 9, 11, 460, 330),
            seg(Direction::Up, 11, 13, 330, 380),
            seg(Direction::Down, 13, 15, 380, 360),
        ];
        let mut hist = vec![0.0; 16];
        hist[9..=11].copy_from_slice(&[-1.0, -1.0, -1.0]);
        hist[13..=15].copy_from_slice(&[-2.0, -2.0, -2.0]);
        let mut dif = vec![0.0; 16];
        dif[9..=11].copy_from_slice(&[-4.0, -4.0, -4.0]);
        dif[13..=15].copy_from_slice(&[-1.0, -1.0, -1.0]);
        let src: Vec<usize> = (0..hist.len()).collect();
        assert!(
            same_color_area(&hist, 13, 15, Side::Long) >= same_color_area(&hist, 9, 11, Side::Long),
            "前置：面积没有 C<A"
        );
        assert!(
            segments_diverge_or(&hist, &dif, Side::Long, (9, 11), (13, 15)),
            "反例隔离：既有 OR 判据仅由 DIF 峰衰减成立"
        );

        let anchors = super::super::divergence::self_anchors(&segs);
        let observation =
            judge_pan_div_observation(&c2, &segs[2], &segs, &anchors, &hist, &dif, &src);
        let (points, production_pan) = extract_signals_with_hist(
            &[c0, c1, c2],
            &segs,
            &hist,
            &dif,
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );

        assert!(points.is_empty(), "反例不得产 BspPoint");
        assert!(
            production_pan.is_empty(),
            "反例不得进入生产 PanDiv 承接路径"
        );
        assert!(observation.is_none(), "C 不破核心且面积不背驰不得识别");
    }

    /// #483 反例锁：C 破核心支继续走既有“力度或关系”路径，完整证书字段与买卖点集合逐位不变。
    #[test]
    fn pan_div_broken_core_branch_remains_bit_exact() {
        let c0 = dc(100, 200, 90, 210, 2);
        let c1 = dc(300, 400, 290, 410, 5);
        let c2 = dc(350, 450, 250, 460, 8);
        let segs = vec![
            seg(Direction::Down, 9, 11, 460, 330),
            seg(Direction::Up, 11, 13, 330, 380),
            seg(Direction::Down, 13, 15, 380, 300), // 300 < zd=350
        ];
        let mut hist = vec![0.0; 16];
        hist[9..=11].copy_from_slice(&[-4.0, -3.0, -2.0]);
        hist[13..=15].copy_from_slice(&[-1.0, -1.0, -1.0]);
        let src: Vec<usize> = (0..hist.len()).collect();

        let (points, pan) = extract_signals_with_hist(
            &[c0, c1, c2],
            &segs,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );

        assert!(points.is_empty(), "既有 fixture 的买卖点集合保持空集");
        assert_eq!(
            pan,
            vec![PanDivCert {
                source_index: 15,
                side: Side::Long,
                center: c2,
                seg_a: (9, 11),
                seg_c: (13, 15),
            }],
            "破核心支证书逐字段不变"
        );
    }

    // ── R1/R2/R3（2026-07-17 代理裁定）：三买几何 / 力度或关系 / D-3 取段（#1265） ─────────

    /// R1 三买几何（037:18，judge_third 去 anchor 门同构）：离开破核心 + 回试不重回 ⟹ 命中；
    /// 回试重回核心 ⟹ 首个离开不算，后续延迟三买仍可命中；as_of 截断 ⟹ None（禁前视）。
    #[test]
    fn trend_third_class_in_c_geometry() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 5,
        };
        // Up：leave 端点 260 > zg=200 破核心，retest 端点 220 > 200 不重回 ⟹ 三买 @10。
        let segs = vec![
            seg(Direction::Up, 6, 8, 210, 260),
            seg(Direction::Down, 8, 10, 260, 220),
        ];
        assert_eq!(
            trend_third_class_in_c(&segs, &last, Direction::Up, 6, 10),
            Some((8, 10)),
            "离开破核心 + 回试不重回 ⟹ 立即三买"
        );
        // 回试重回（190 ≤ 200）⟹ 首次离开不算；延迟三买（二次离开 + 回试 205 > 200）@14。
        let delayed = vec![
            seg(Direction::Up, 6, 8, 210, 260),
            seg(Direction::Down, 8, 10, 260, 190),
            seg(Direction::Up, 10, 12, 190, 270),
            seg(Direction::Down, 12, 14, 270, 205),
        ];
        assert_eq!(
            trend_third_class_in_c(&delayed, &last, Direction::Up, 6, 14),
            Some((12, 14)),
            "延迟三买（p112 70 案型）在全离开段口径下存在"
        );
        // 禁前视：as_of=12 截断延迟回试 ⟹ None。
        assert_eq!(
            trend_third_class_in_c(&delayed, &last, Direction::Up, 6, 12),
            None
        );
        // Down 对称：leave 端点 90 < zd=100 破核心，retest 端点 95 < 100 不重回。
        let down = vec![
            seg(Direction::Down, 6, 8, 190, 90),
            seg(Direction::Up, 8, 10, 90, 95),
        ];
        assert_eq!(
            trend_third_class_in_c(&down, &last, Direction::Down, 6, 10),
            Some((8, 10))
        );
        // 无回试（单腿窗口）⟹ None——p112 构造性恒假的机械显形（#105 单腿口径）。
        let single = vec![seg(Direction::Up, 6, 8, 210, 260)];
        assert_eq!(
            trend_third_class_in_c(&single, &last, Direction::Up, 6, 10),
            None
        );
    }

    /// ★#1249（#1229 裁定 a）对拍锁（#804 ① 同输入同输出）：统一后的分级器
    /// [`t3_in_c_scan_grade`] 与 [`trend_third_class_in_c`] 对同一输入逐位一致——`Present` ⟺
    /// 扫描器命中且区间 = 命中段区间；`Missing` ⟺ 扫描器 `None`。锁住「大闸消费后扫结果」，
    /// 防止未来再另起一套判据（生产级同锁由 s2_mirror_capture 的
    /// `run_first_production_diagnostics` 走 `judge_first_from_gates` 覆盖）。
    #[test]
    fn t3_in_c_scan_grade_parity_with_back_scan() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 5,
        };
        let segs = vec![
            seg(Direction::Up, 6, 8, 210, 260),
            seg(Direction::Down, 8, 10, 260, 220),
        ];
        let scan = trend_third_class_in_c(&segs, &last, Direction::Up, 6, 10);
        let grade = t3_in_c_scan_grade(&segs, &last, Direction::Up, 6, 10);
        match scan {
            Some((leave_end, retest_end)) => {
                let leave = segs.iter().find(|s| s.end_index == leave_end).unwrap();
                let retest = segs.iter().find(|s| s.end_index == retest_end).unwrap();
                assert_eq!(
                    grade,
                    T3InCScan::Present {
                        leave_interval: (leave.start_index, leave.end_index),
                        retest_interval: (retest.start_index, retest.end_index),
                    }
                );
            }
            None => assert_eq!(grade, T3InCScan::Missing),
        }
        // Down 对称：命中对的区间逐位一致。
        let down = vec![
            seg(Direction::Down, 6, 8, 190, 90),
            seg(Direction::Up, 8, 10, 90, 95),
        ];
        assert_eq!(
            t3_in_c_scan_grade(&down, &last, Direction::Down, 6, 10),
            T3InCScan::Present {
                leave_interval: (6, 8),
                retest_interval: (8, 10)
            }
        );
        // 无命中 ⟹ Missing。
        let single = vec![seg(Direction::Up, 6, 8, 210, 260)];
        assert_eq!(
            t3_in_c_scan_grade(&single, &last, Direction::Up, 6, 10),
            T3InCScan::Missing
        );
    }

    // ── T3-in-c 固定首对分级器（D1，#606 S1）：五桶全盖 + 与扫描器行为对照 ─────────

    /// Present：leave/retest 紧邻固定首对，方向互反、价格严格破该框 ZG/ZD。
    #[test]
    fn t3_in_c_fixed_first_pair_present() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 5,
        };
        let segs = vec![
            seg(Direction::Up, 5, 8, 210, 260),
            seg(Direction::Down, 8, 10, 260, 220),
        ];
        assert_eq!(
            t3_in_c_fixed_first_pair(&segs, &last, Direction::Up),
            T3InCGrade::Present {
                leave_interval: (5, 8),
                retest_interval: (8, 10)
            },
            "固定首对紧邻锚 last_center.end_index=5（含等值）命中"
        );
        // Down 镜像。
        let down = vec![
            seg(Direction::Down, 5, 8, 190, 90),
            seg(Direction::Up, 8, 10, 90, 95),
        ];
        assert_eq!(
            t3_in_c_fixed_first_pair(&down, &last, Direction::Down),
            T3InCGrade::Present {
                leave_interval: (5, 8),
                retest_interval: (8, 10)
            }
        );
    }

    /// 桶①missing_leave：中枢框右边（`start_index >= end_index`）无任何段。
    #[test]
    fn t3_in_c_fixed_first_pair_missing_leave() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 20,
        };
        // 唯一段落在锚之前（start_index=5 < end_index=20）⟹ 锚右边无段。
        let segs = vec![seg(Direction::Up, 5, 8, 210, 260)];
        assert_eq!(
            t3_in_c_fixed_first_pair(&segs, &last, Direction::Up),
            T3InCGrade::Missing(T3InCGradeReason::MissingLeave)
        );
        // 空段列同样落此桶。
        assert_eq!(
            t3_in_c_fixed_first_pair(&[], &last, Direction::Up),
            T3InCGrade::Missing(T3InCGradeReason::MissingLeave)
        );
    }

    /// 桶②missing_retest：连续缺口单腿 c——leave 存在但无紧随段。
    #[test]
    fn t3_in_c_fixed_first_pair_missing_retest() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 5,
        };
        let single = vec![seg(Direction::Up, 5, 8, 210, 260)];
        assert_eq!(
            t3_in_c_fixed_first_pair(&single, &last, Direction::Up),
            T3InCGrade::Missing(T3InCGradeReason::MissingRetest),
            "单腿窗口（连续缺口）⟹ missing_retest，非 missing_leave"
        );
    }

    /// 桶③same_direction：leave 与 retest 方向相同（同向续行，非离开/回试对）。
    #[test]
    fn t3_in_c_fixed_first_pair_same_direction() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 5,
        };
        let segs = vec![
            seg(Direction::Up, 5, 8, 210, 230),
            seg(Direction::Up, 8, 10, 230, 260), // 同向续行（非回试）
        ];
        assert_eq!(
            t3_in_c_fixed_first_pair(&segs, &last, Direction::Up),
            T3InCGrade::Missing(T3InCGradeReason::SameDirection)
        );
    }

    /// 桶④leave_not_outside：leave 端点未严格破该框 ZG/ZD（未离开核心）。
    #[test]
    fn t3_in_c_fixed_first_pair_leave_not_outside() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 5,
        };
        let segs = vec![
            seg(Direction::Up, 5, 8, 150, 200), // 端点 200 未严格 > zg=200
            seg(Direction::Down, 8, 10, 200, 180),
        ];
        assert_eq!(
            t3_in_c_fixed_first_pair(&segs, &last, Direction::Up),
            T3InCGrade::Missing(T3InCGradeReason::LeaveNotOutside)
        );
    }

    /// 桶⑤retest_reentered：leave 严格破核心，但 retest 端点重回闭区间核心。
    #[test]
    fn t3_in_c_fixed_first_pair_retest_reentered() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 5,
        };
        let segs = vec![
            seg(Direction::Up, 5, 8, 210, 260),
            seg(Direction::Down, 8, 10, 260, 190), // 190 <= zg=200，重回核心
        ];
        assert_eq!(
            t3_in_c_fixed_first_pair(&segs, &last, Direction::Up),
            T3InCGrade::Missing(T3InCGradeReason::RetestReentered)
        );
    }

    /// 首对失败远对不认领：与 [`trend_third_class_in_c`] 对照——扫描器在首对失败（同向续行）
    /// 后继续后扫，找到延迟三买（p112 70 案型）；固定首对分级器**不后扫**，首对失败即 Missing，
    /// 不认领后面本会成功的远对（补充十五「不得越过同向续行后扫替代配对」）。
    #[test]
    fn t3_in_c_fixed_first_pair_does_not_rescan_past_first_pair_failure() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 6,
        };
        // 首对：leave(6,8) Up 破核心 260>200，retest(8,10) Down 190<=200 重回核心 ⟹ retest_reentered。
        // 远对：leave(10,12) Up 再次破核心 270>200，retest(12,14) Down 205>200 不重回 ⟹ 若后扫会命中。
        let delayed = vec![
            seg(Direction::Up, 6, 8, 210, 260),
            seg(Direction::Down, 8, 10, 260, 190),
            seg(Direction::Up, 10, 12, 190, 270),
            seg(Direction::Down, 12, 14, 270, 205),
        ];
        assert_eq!(
            t3_in_c_fixed_first_pair(&delayed, &last, Direction::Up),
            T3InCGrade::Missing(T3InCGradeReason::RetestReentered),
            "固定首对分级器不后扫：首对失败即 Missing，不认领延迟三买远对"
        );
        // 对照：既有扫描器在同一段列上会后扫命中延迟三买（c_start=6, as_of=14）。
        assert_eq!(
            trend_third_class_in_c(&delayed, &last, Direction::Up, 6, 14),
            Some((12, 14)),
            "扫描器口径下同一段列会认领远对——两谓词不是同一判据（#586 在案）"
        );
    }

    /// 固定首对锚非 λ_C/c_start 坐标案例：锚 = `last_center.end_index`（B 右边），不是
    /// `λ_C`/`c_start`。当 λ_C 晚于 `last_center.end_index`（B 右边与 c 的次级别离开起点之间
    /// 还有一段未被 λ_C 覆盖的段）时，固定首对分级器仍以 B 右边第一条为 leave——与「从 λ_C 起
    /// 扫」的口径可能给出不同的 leave/retest 对（判定锚差异的机械显形）。
    #[test]
    fn t3_in_c_fixed_first_pair_anchor_is_b_right_edge_not_lambda_c() {
        let last = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 5,
        };
        // B 右边（end_index=5）之后第一条段 start_index=5（等值即紧邻）已是 leave；
        // 假设某扫描口径的 λ_C/c_start 误锚在 8（下一段起点），会跳过 (5,8) 这一段，
        // 直接从 (8,10) 起扫——那样会漏掉本对象在锚 5 处即已 Missing 的判定（此处仍破核心+
        // 不重回 ⟹ Present，用于反证「锚必须是 B 右边」：若锚误用 8，只看得到 retest 段
        // 本身找不到紧随段 ⟹ 会误判 missing_retest，而固定首对（锚=5）给出 Present）。
        let segs = vec![
            seg(Direction::Up, 5, 8, 210, 260),
            seg(Direction::Down, 8, 10, 260, 220),
        ];
        assert_eq!(
            t3_in_c_fixed_first_pair(&segs, &last, Direction::Up),
            T3InCGrade::Present {
                leave_interval: (5, 8),
                retest_interval: (8, 10)
            },
            "锚=B 右边 end_index=5 ⟹ Present"
        );
        // 若误把锚坐标设为 λ_C=8（跳过 leave 段直接从 retest 段起找），
        // 该段列在锚 8 处只剩 (8,10) 一条 ⟹ missing_retest——与正确锚（Present）判异，
        // 机械证明锚坐标选择改变判定结果。
        let wrong_anchor_center = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 8,
        };
        assert_eq!(
            t3_in_c_fixed_first_pair(&segs, &wrong_anchor_center, Direction::Up),
            T3InCGrade::Missing(T3InCGradeReason::MissingRetest),
            "误锚 λ_C=8 ⟹ missing_retest，与正确锚 B 右边=5 的 Present 判异"
        );
    }

    /// ★#1265 D-3 统一取段（首次离开 = 进入段；061:26 正文「只要是围绕一中枢的两段走势都可以
    /// 比较力度」）：中枢后无前次同向破核心段时，A = 中枢前最近同向段；R2 力度或关系：混合
    /// 面积 C≥A 但同色面积 C<A ⟹ 仍产证。
    #[test]
    fn pan_div_entry_anchor_rescue_and_or_relation_weak() {
        use super::super::divergence::{segments_diverge, self_anchors};
        let c2 = Center {
            zd: 350,
            zg: 450,
            dd: 250,
            gg: 460,
            start_index: 4,
            end_index: 8,
        };
        let segs = vec![
            seg(Direction::Down, 1, 3, 460, 360), // 进入段：中枢前同向段（end=3 ≤ c2.start=4）
            seg(Direction::Down, 9, 11, 380, 300), // C：破核心（300 < zd=350）；中枢后无回中枢段
        ];
        let anchors = self_anchors(&segs);
        let src: Vec<usize> = (0..12).collect();
        // hist：进入段绿柱 −5×3=15；C 绿柱 −1−1=2 但夹红柱 +20 ⟹ 混合面积 C=22 > A=15（旧口径判负），
        // 同色面积 2<15 且绿柱峰 1<5 ⟹ 或关系两通道成立（027:32）。
        let mut hist = vec![0.0; 12];
        hist[1] = -5.0;
        hist[2] = -5.0;
        hist[3] = -5.0;
        hist[9] = -1.0;
        hist[10] = 20.0;
        hist[11] = -1.0;
        let dif = vec![0.0; 12];
        assert!(
            segments_diverge(&hist, (1, 3), (9, 11), Direction::Down),
            "前置自证：Down 同色面积单通道即判背驰——绿 C=2 < A=15（红柱 20 不再污染，#988）"
        );
        let cert = judge_pan_div(&c2, &segs[1], &segs, &anchors, &hist, &dif, &src)
            .expect("D-3 取段命中进入段 + 力度或关系成立 ⟹ 产证");
        assert_eq!(cert.side, Side::Long);
        assert_eq!(cert.seg_a, (1, 3), "进入段 = 中枢前最近同向段（061:26）");
        assert_eq!(cert.seg_c, (9, 11), "I(C) = 当前离开 episode");
        assert_eq!(cert.source_index, 11);
    }

    /// R2 边界（033:26）：各 proxy 全无衰减 ⟹ 市场事实，不产证（不放宽）。
    #[test]
    fn pan_div_or_relation_all_channels_fail_rejects() {
        use super::super::divergence::self_anchors;
        let c2 = Center {
            zd: 350,
            zg: 450,
            dd: 250,
            gg: 460,
            start_index: 4,
            end_index: 8,
        };
        let segs = vec![
            seg(Direction::Down, 1, 3, 460, 360),
            seg(Direction::Down, 9, 11, 380, 300),
        ];
        let anchors = self_anchors(&segs);
        let src: Vec<usize> = (0..12).collect();
        // C 绿柱面积/柱峰/dif 峰全面放大 ⟹ 或关系全假。
        let mut hist = vec![0.0; 12];
        hist[1] = -2.0;
        hist[2] = -2.0;
        hist[3] = -2.0;
        hist[9] = -9.0;
        hist[10] = -9.0;
        hist[11] = -9.0;
        let dif = vec![0.0; 12];
        assert!(
            judge_pan_div(&c2, &segs[1], &segs, &anchors, &hist, &dif, &src).is_none(),
            "各 proxy 全无衰减 ⟹ 市场事实（033:26）⟹ 不产证"
        );
    }

    /// Q4×Q5 对称（codex ac4-r2）：前一次离开为**多段 episode**（破核心腿 + 未回核心的中间反向
    /// 段 + 再破更深腿）⟹ I(A) = 整个 episode 区间 [λ_A, ρ_A]，非仅末段锚。
    #[test]
    fn pan_div_a_side_multi_segment_episode_interval() {
        use super::super::divergence::segment_macd_area;
        let c0 = dc(100, 200, 90, 210, 2);
        let c1 = dc(300, 400, 290, 410, 5);
        let c2 = dc(350, 450, 250, 460, 8); // 扩张 ⟹ ownership 盘整块
        let segs = vec![
            seg(Direction::Down, 9, 11, 460, 330), // A 腿1：破核心（330 < zd=350）
            seg(Direction::Up, 11, 12, 330, 340), // A 内部反向段（340 < 350 未回核心 ⟹ 同 episode）
            seg(Direction::Down, 12, 13, 340, 300), // A 腿2：再破（episode 锚）
            seg(Direction::Up, 13, 15, 300, 380), // 回中枢段（380 ≥ 350，A/C 分隔）
            seg(Direction::Down, 15, 17, 380, 295), // C：第二次离开破核心
        ];
        let prices: Vec<Tick> = vec![
            100, 100, 100, 100, 60, 140, 100, 95, 105, 40, 45, 35, 30, 25, 60, 90, 88, 86,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let (a_area, c_area) = (
            segment_macd_area(&hist, 9, 13, Direction::Down),
            segment_macd_area(&hist, 15, 17, Direction::Down),
        );
        assert!(
            c_area < a_area,
            "前置：C 面积({c_area:.3}) < A episode 面积({a_area:.3})"
        );
        let (_points, pan) = extract_signals_with_hist(
            &[c0, c1, c2],
            &segs,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        assert_eq!(
            pan.len(),
            1,
            "多段前次离开 + 回中枢 + 再破 + C<A ⟹ 恰一张证书"
        );
        assert_eq!(
            pan[0].seg_a,
            (9, 13),
            "I(A) = 前次离开整个 episode 区间（λ_A=腿1起点, ρ_A=腿2终点）"
        );
        assert_eq!(pan[0].seg_c, (15, 17), "I(C) = 当前离开区间");
    }

    /// Q4 负例：无回中枢段（两 Down 段之间的反向段未回到核心内侧）⟹ 同一次离开 ⟹ 无 A/C
    /// 两次离开结构 ⟹ 不产证书（诚实不产，非放宽判据）。
    #[test]
    fn pan_div_rejected_without_reentry_between_departures() {
        let c0 = dc(100, 200, 90, 210, 2);
        let c1 = dc(300, 400, 290, 410, 5);
        let c2 = dc(350, 450, 250, 460, 8);
        let segs = vec![
            seg(Direction::Down, 9, 11, 460, 330),
            seg(Direction::Up, 11, 13, 330, 340), // 反弹端点 340 < c2.zd=350：未回中枢
            seg(Direction::Down, 13, 15, 340, 300),
        ];
        let prices: Vec<Tick> = vec![
            100, 100, 100, 100, 60, 140, 100, 95, 105, 105, 60, 90, 95, 93, 91, 89,
        ];
        let (closes, src) = closes_seq(&prices);
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let (_points, pan) = extract_signals_with_hist(
            &[c0, c1, c2],
            &segs,
            &hist,
            &[],
            &[],
            &src,
            DivergenceGauge::MacdArea,
            &[],
            &mut Vec::new(),
        );
        assert!(pan.is_empty(), "无回中枢段 ⟹ 同一次离开 ⟹ 无盘整背驰证书");
    }

    // ── 第二类 L0 签名层边界（extract_signals 不产；B2 由递归组装层入口产）──────

    #[test]
    fn signal_extraction_emits_no_second_class() {
        // ★L0 签名层边界（编码为可执行断言，formalization-validity-domain）：extract_signals 对任意
        // L0 segment 输入**永不产第二类**——第二类=次级别第一类构成（买卖点定律一），需 RMove 递归
        // 结构（descend.rs），L0 segment 是递归底（descend 得空）⟹ 结构上不可在本签名层产出。
        // 此断言锁定边界：B2/S2 由平行的递归组装层入口 `extract_second_signals` 产（消费 RMove 塔），
        // 非 extract_signals 缺口——按输入对象分工（L0 segment vs RMove 递归塔），见模块头。
        let c = center(100, 200, 2);
        let segs = vec![
            seg(Direction::Down, 3, 5, 150, 90),
            seg(Direction::Down, 6, 8, 120, 80),
            seg(Direction::Up, 9, 11, 80, 250),
            seg(Direction::Down, 12, 14, 250, 210),
        ];
        let prices: Vec<Tick> = vec![
            100, 100, 100, 100, 60, 140, 100, 95, 105, 100, 175, 250, 250, 230, 210,
        ];
        let (closes, src) = closes_seq(&prices);
        let points = extract_signals(&[c], &segs, &closes, &src, &MacdConfig::default());
        for p in &points {
            assert!(
                !p.bits.buy2,
                "extract_signals（L0 层）不产第二类买点——B2 由 extract_second_signals 递归组装层产"
            );
            assert!(
                !p.bits.sell2,
                "extract_signals（L0 层）不产第二类卖点——S2 由 extract_second_signals 递归组装层产"
            );
        }
    }

    // ── 第二类递归组装层提取（extract_second_signals 消费 RMove 塔产 B2/S2）────────

    use super::super::descend::RMove;
    use super::super::rmove_compose::compose_move;

    /// 第二类结构的次级别中枢（B 口径核心区间 [zd,zg]=[0,4]，对齐 rmove_compose 见证 c1_wit）。
    fn second_center() -> Center {
        Center {
            zd: 0,
            zg: 4,
            dd: -2,
            gg: 6,
            start_index: 0,
            end_index: 0,
        }
    }

    /// 第一类离开走势（向下破中枢，区间 [-10,-2]，lo=-10 < zd=0 ⟹ 破中枢；对齐 rmove_compose m1_wit）。
    fn m1_break() -> RMove {
        RMove::Segment {
            direction: Direction::Down,
            lo: -10,
            hi: -2,
        }
    }

    /// 回拉走势（未破一类极值，区间 [-8,3]，lo=-8 ≥ m1.lo=-10 ⟹ 重合标注 Some(false)；对齐 m2_wit）。
    fn m2_pullback() -> RMove {
        RMove::Segment {
            direction: Direction::Up,
            lo: -8,
            hi: 3,
        }
    }

    /// 收尾走势（凑满 ≥3 段；对齐 m3_wit）。
    fn m3_tail() -> RMove {
        RMove::Segment {
            direction: Direction::Up,
            lo: 1,
            hi: 5,
        }
    }

    /// 本级别走势塔：RMove::Compose 组装第一类离开 + 回拉 + 收尾。
    fn parent_tower() -> RMove {
        compose_move(
            vec![m1_break(), m2_pullback(), m3_tail()],
            vec![second_center()],
            1,
        )
    }

    #[test]
    fn second_buy_extracted_from_rmove_tower() {
        // ★递归组装层 B2 提取：RMove 塔含第一类离开（破中枢 ∧ 背驰）+ 回拉段 ⟹ 一个 B2。
        // 回拉未破一类极值（m2.lo=-8 ≥ m1.lo=-10）⟹ 重合标注 retrace_breaks_type1=Some(false)。
        // divergence_of：仅第一类离开 m1（lo=-10）背驰，回拉/收尾不背驰（rust MACD 真算的占位见证）。
        // index_of：回拉走势 m2 → 原始 K 序 42（坐标 still-MISSING，上游塔提供）。
        let parent = parent_tower();
        let points = extract_second_signals(
            &parent,
            Side::Long,
            &second_center(),
            |m| m.lo() == -10, // 仅第一类离开背驰
            |m| {
                if m.lo() == -8 {
                    42
                } else if m.lo() == -10 {
                    30
                } else {
                    0
                }
            }, // m2 → 42；m1 → 30
        );
        assert_eq!(points.len(), 1, "RMove 塔（第一类离开 ∧ 回拉段）⟹ 一个 B2");
        assert!(points[0].bits.buy2, "递归组装层产第二类买点（buy2 置位）");
        assert!(
            !points[0].bits.buy1 && !points[0].bits.buy3,
            "第二类端点不置 1/3 类（互斥语义）"
        );
        assert_eq!(
            points[0].source_index, 42,
            "B2 source_index = 回拉走势 m2 的原始 K 序（index_of）"
        );
        assert_eq!(
            points[0].pivot_low, -8,
            "B2 止损源 = 回拉低点（second_point = m2.lo）"
        );
        // ★#218 面 A（spec owner-attribution-fix-20260724 ID-1，机械改写归因：载体形态变化）：
        // 二类点归属载体从 c1（次级别中枢，确认层对象）改载该走势一类点身份锚（m1 终点坐标 30）；
        // 止损仍 pivot（上条已锁，语义不变）。★#816 B-2②：归属不问跌破与否（锚不变）。
        assert_eq!(
            points[0].center,
            Some(OwnerRef::Type1Anchor(30)),
            "二类点归属载体 = 该走势一类点锚（m1 终点坐标）；止损仍 pivot 非 center"
        );
        assert_eq!(
            points[0].retrace_breaks_type1,
            Some(false),
            "回拉未破一类极值 ⟹ 重合标注 Some(false)（第15课「未创新低」常规形态）"
        );
    }

    /// ★#816 B-2② 拆闸验收（实施 #884）：回拉**跌破**一类（lo=-12 < m1.lo=-10）**仍产 B2**——
    /// `101:32`【正文】「第二类买点跌破第一类买点……这是完全可以的」；重合身份（二类 × 盘整
    /// 背驰）由 `retrace_breaks_type1=Some(true)` 标注，**不作准入分档**（语义归 #817）。
    /// 旧 `no_new_low` 硬闸下此输入产 0 个 B2——本测试即「跌破一买」类二类点 0→有 的见证级对照。
    #[test]
    fn second_buy_produced_when_retrace_makes_new_low() {
        let m2_break = RMove::Segment {
            direction: Direction::Up,
            lo: -12,
            hi: 3,
        };
        let parent = compose_move(vec![m1_break(), m2_break], vec![second_center()], 1);
        let points = extract_second_signals(
            &parent,
            Side::Long,
            &second_center(),
            |m| m.lo() == -10,
            |_m| 0,
        );
        assert_eq!(
            points.len(),
            1,
            "回拉跌破一类 ⟹ 仍是合法二类点（#816 B-2②，101:32「这是完全可以的」）"
        );
        assert!(points[0].bits.buy2, "跌破一买的二类点 buy2 置位");
        assert_eq!(
            points[0].pivot_low, -12,
            "B2 止损源 = 回拉低点（跌破一类后的新低 -12）"
        );
        assert_eq!(
            points[0].retrace_breaks_type1,
            Some(true),
            "跌破一类 ⟹ 重合标注 Some(true)（「一般都构成盘整背驰」，语义归 #817，不作闸）"
        );
    }

    #[test]
    fn second_buy_rejected_without_divergence() {
        // 第一类离开破中枢但**不背驰**（divergence_of 全 false）⟹ 无完整第一类 ⟹ 无第二类结构。
        let parent = parent_tower();
        let points = extract_second_signals(
            &parent,
            Side::Long,
            &second_center(),
            |_m| false, // 力度全 false：无背驰
            |_m| 0,
        );
        assert!(
            points.is_empty(),
            "破中枢但不背驰 ⟹ 非次级别第一类 ⟹ 无第二类"
        );
    }

    #[test]
    fn second_sell_mirror_from_rmove_tower() {
        // S2 镜像：第一类向上离开探顶（破中枢上沿）+ 回抽段 ⟹ 一个 S2（止损 = 回抽高点）。
        // 第一类离开 [2,10]（hi=10 > zg=4 ⟹ 向上破中枢），回抽 [1,8]（hi=8 ≤ m1.hi=10 ⟹ 未创新高
        // ⟹ 重合标注 Some(false)）。
        let m1_sell = RMove::Segment {
            direction: Direction::Up,
            lo: 2,
            hi: 10,
        };
        let m2_sell = RMove::Segment {
            direction: Direction::Down,
            lo: 1,
            hi: 8,
        };
        let m3_sell = RMove::Segment {
            direction: Direction::Down,
            lo: 0,
            hi: 6,
        };
        let parent = compose_move(vec![m1_sell, m2_sell, m3_sell], vec![second_center()], 1);
        let points = extract_second_signals(
            &parent,
            Side::Short,
            &second_center(),
            |m| m.hi() == 10, // 仅第一类离开背驰
            |m| {
                if m.hi() == 8 {
                    17
                } else if m.hi() == 10 {
                    11
                } else {
                    0
                }
            }, // m2 → 17；m1 → 11
        );
        assert_eq!(points.len(), 1, "S2：第一类离开 ∧ 回抽段 ⟹ 一个 S2");
        assert!(points[0].bits.sell2, "递归组装层产第二类卖点（sell2 置位）");
        assert!(!points[0].bits.buy2, "卖侧 ⟹ buy2 不置位");
        assert_eq!(
            points[0].source_index, 17,
            "S2 source_index = 回抽走势的原始 K 序"
        );
        assert_eq!(
            points[0].pivot_high, 8,
            "S2 止损源 = 回抽高点（second_point = m2.hi）"
        );
        // ★#218 面 A（机械改写归因：载体形态变化，同买侧）：S2 归属载体改载该走势一类点
        // 身份锚（m1 终点坐标 11）；止损仍 pivot（pivot_high=8 上条已锁）。
        assert_eq!(
            points[0].center,
            Some(OwnerRef::Type1Anchor(11)),
            "S2 归属载体 = 该走势一类点锚（m1 终点坐标）；止损仍 pivot 非 center"
        );
        assert_eq!(
            points[0].retrace_breaks_type1,
            Some(false),
            "回抽未破一类极值 ⟹ 重合标注 Some(false)（第15课「未创新高」常规形态）"
        );
    }

    /// ★#816 B-2② 卖侧镜像（实施 #884）：回抽**升破**一类（hi=12 > m1.hi=10）**仍产 S2**；
    /// 重合标注 `retrace_breaks_type1=Some(true)`，不作准入分档。
    #[test]
    fn second_sell_produced_when_retrace_makes_new_high() {
        let m1_sell = RMove::Segment {
            direction: Direction::Up,
            lo: 2,
            hi: 10,
        };
        let m2_break = RMove::Segment {
            direction: Direction::Down,
            lo: 1,
            hi: 12, // 升破一类高点 10
        };
        let parent = compose_move(vec![m1_sell, m2_break], vec![second_center()], 1);
        let points = extract_second_signals(
            &parent,
            Side::Short,
            &second_center(),
            |m| m.hi() == 10,
            |_m| 0,
        );
        assert_eq!(
            points.len(),
            1,
            "回抽升破一类 ⟹ 仍是合法二类卖点（#816 B-2② 镜像，判据不得以「回拉不创新高」为必要条件）"
        );
        assert!(points[0].bits.sell2, "升破一类的二类点 sell2 置位");
        assert_eq!(
            points[0].pivot_high, 12,
            "S2 止损源 = 回抽高点（升破一类后的新高 12）"
        );
        assert_eq!(
            points[0].retrace_breaks_type1,
            Some(true),
            "升破一类 ⟹ 重合标注 Some(true)（语义归 #817，不作闸）"
        );
    }

    // ── #218 面 A：二类归属载体修填（spec owner-attribution-fix-20260724 ID-1，#211 路线 B
    //    + v2 教义修订：二类归属参照 = 该走势一类点，非中枢）──────────────────────────

    /// 面 A 验收（#218 票体）：二类点归属载体 = 该走势一类点身份锚——`find_second_type_structure`
    /// 识别出的 i1（第一类离开走势）的**终点**坐标（该走势终点极值点 = 一类点，区间套恰好存在；
    /// 坐标经既有 `index_of` 供给，零新入参）。识别层零改动：c1 判定中枢、i1/i2 时间序、
    /// second_point 取法、bits、背驰判定逐字一致。
    #[test]
    fn second_buy_owner_carrier_is_type1_anchor() {
        let parent = parent_tower();
        let points = extract_second_signals(
            &parent,
            Side::Long,
            &second_center(),
            |m| m.lo() == -10, // 仅第一类离开背驰（识别层口径一个 bit 不动）
            // 坐标：回拉 m2 → 42；第一类离开 m1 → 30（一类点 = m1 终点 = 该走势终点极值点）。
            |m| {
                if m.lo() == -8 {
                    42
                } else if m.lo() == -10 {
                    30
                } else {
                    0
                }
            },
        );
        assert_eq!(points.len(), 1);
        assert!(points[0].bits.buy2 && !points[0].bits.buy1 && !points[0].bits.buy3);
        assert_eq!(
            points[0].source_index, 42,
            "识别不变：B2 坐标 = 回拉走势 m2 终点（index_of）"
        );
        assert_eq!(
            points[0].pivot_low, -8,
            "识别不变：止损源 = 回拉低点（second_point = m2.lo）"
        );
        assert_eq!(
            points[0].center,
            Some(OwnerRef::Type1Anchor(30)),
            "#218 面 A：归属载体 = 该走势一类点锚（m1 终点坐标 30）；不再载 c1（次级别中枢，级别错配根因）"
        );
    }

    /// 面 A 卖侧镜像：S2 归属载体同为该走势一类点锚（第一类离开走势 m1 终点坐标）。
    #[test]
    fn second_sell_owner_carrier_is_type1_anchor() {
        let m1_sell = RMove::Segment {
            direction: Direction::Up,
            lo: 2,
            hi: 10,
        };
        let m2_sell = RMove::Segment {
            direction: Direction::Down,
            lo: 1,
            hi: 8,
        };
        let m3_sell = RMove::Segment {
            direction: Direction::Down,
            lo: 0,
            hi: 6,
        };
        let parent = compose_move(vec![m1_sell, m2_sell, m3_sell], vec![second_center()], 1);
        let points = extract_second_signals(
            &parent,
            Side::Short,
            &second_center(),
            |m| m.hi() == 10, // 仅第一类离开背驰
            |m| {
                if m.hi() == 8 {
                    17
                } else if m.hi() == 10 {
                    11
                } else {
                    0
                }
            },
        );
        assert_eq!(points.len(), 1);
        assert!(points[0].bits.sell2 && !points[0].bits.buy2);
        assert_eq!(
            points[0].source_index, 17,
            "识别不变：S2 坐标 = 回抽走势 m2 终点"
        );
        assert_eq!(
            points[0].pivot_high, 8,
            "识别不变：止损源 = 回抽高点（second_point = m2.hi）"
        );
        assert_eq!(
            points[0].center,
            Some(OwnerRef::Type1Anchor(11)),
            "#218 面 A：S2 归属载体 = 该走势一类点锚（m1 终点坐标 11）"
        );
    }

    /// 面 A 归属/确认分层证据（US-04）：c1 只是确认层判定中枢（识别用），不进归属载体——
    /// 换一个 m1 同样下破的判定中枢 c1′（zd=-5：m1.lo=-10 < -5 下破成立），识别结果与
    /// 归属载体逐值不变（锚坐标只由 m1 终点给出，与 c1 无关）。
    #[test]
    fn second_owner_carrier_independent_of_judge_center_c1() {
        let c1_alt = Center {
            zd: -5,
            zg: -3,
            dd: -6,
            gg: -2,
            start_index: 0,
            end_index: 0,
        };
        let parent = parent_tower();
        let points = extract_second_signals(
            &parent,
            Side::Long,
            &c1_alt,
            |m| m.lo() == -10,
            |m| {
                if m.lo() == -8 {
                    42
                } else if m.lo() == -10 {
                    30
                } else {
                    0
                }
            },
        );
        assert_eq!(
            points.len(),
            1,
            "c1′ 仍被 m1 下破 ⟹ 识别结果不变（确认层同一判定）"
        );
        assert_eq!(
            points[0].center,
            Some(OwnerRef::Type1Anchor(30)),
            "归属载体与 c1 无关：换判定中枢锚坐标不变（归属层只挂该走势一类点）"
        );
    }

    #[test]
    fn second_signals_empty_for_l0_segment() {
        // 递归底：RMove::Segment（L0 线段）descend 得空 ⟹ 无次级别走势 ⟹ 无第二类（对齐
        // rmove_compose segment_no_second_type）。递归组装层入口在递归底诚实空，非崩溃。
        let seg = RMove::Segment {
            direction: Direction::Down,
            lo: -10,
            hi: -2,
        };
        let points = extract_second_signals(&seg, Side::Long, &second_center(), |_m| true, |_m| 0);
        assert!(points.is_empty(), "L0 线段（递归底）⟹ 无第二类结构 ⟹ 无 B2");
    }

    // ── 坐标系映射（source_index → closes 下标）─────────────────────────────

    #[test]
    fn src_range_maps_with_merged_bar_gaps() {
        // merged_bars 有合并跳跃：source_index = [0,2,5,9]（下标 0..3）。
        // 段 source_index [2,9] 应映射到 closes 下标 [1,3]（src=2 在下标1，src=9 在下标3）。
        let src_to_idx = vec![0usize, 2, 5, 9];
        assert_eq!(map_src_range_to_close_idx(&src_to_idx, 2, 9), Some((1, 3)));
        // 段 [3,6]：首个 >=3 是 src=5（下标2），末个 <=6 是 src=5（下标2）⟹ (2,2)。
        assert_eq!(map_src_range_to_close_idx(&src_to_idx, 3, 6), Some((2, 2)));
        // 段 [10,20]：无 source_index 落入 ⟹ None。
        assert_eq!(map_src_range_to_close_idx(&src_to_idx, 10, 20), None);
    }

    // ── 中枢归属语义（codex 裁决：唯一归属最近中枢）+ 复杂度标度证据 ─────────────

    /// 确定性合成数据：n_seg 条升序线段（对齐生产路径 parser 线段账本 start_index 严格单调）+
    /// n_center 个中枢 + closes/close_src。无 RNG（确定性，可复现），价格用确定性正弦式震荡造背驰差。
    fn synth_scale_input(
        n_seg: usize,
        n_center: usize,
    ) -> (Vec<Center>, Vec<Segment>, Vec<f64>, Vec<usize>) {
        // 段：方向交替，start_index 严格升序（0,2,4,...），价格在中枢上下震荡（造破中枢 + 背驰对照）。
        let mut segments = Vec::with_capacity(n_seg);
        for k in 0..n_seg {
            let dir = if k % 2 == 0 {
                Direction::Down
            } else {
                Direction::Up
            };
            let si = k * 2;
            let ei = k * 2 + 1;
            // 端点在 [40,260] 区间确定性摆动（破中枢核心 [100,200]：部分段端点 <100 或 >200）。
            let phase = (k as i64 * 37) % 220;
            let ep: Tick = 40 + phase; // 40..260
            let sp: Tick = 150;
            segments.push(Segment {
                direction: dir,
                start_index: si,
                end_index: ei,
                start_price: sp,
                end_price: ep,
            });
        }
        // 中枢：核心 [100,200]，end_index 散布（造不同二分定位起点）。
        let mut centers = Vec::with_capacity(n_center);
        for j in 0..n_center {
            let ei = (j * n_seg / n_center.max(1)) * 2; // 散布在段序列各处
            centers.push(Center {
                zd: 100,
                zg: 200,
                dd: 50,
                gg: 250,
                start_index: 0,
                end_index: ei,
            });
        }
        // closes/close_src：覆盖全段区间，确定性震荡（MACD hist 有非平凡面积 → 背驰判定真触发）。
        let n_close = n_seg * 2 + 2;
        let mut closes = Vec::with_capacity(n_close);
        let mut close_src = Vec::with_capacity(n_close);
        for t in 0..n_close {
            let osc = (((t as i64 * 53) % 80) - 40) as f64; // -40..40 确定性震荡
            closes.push(150.0 + osc);
            close_src.push(t);
        }
        (centers, segments, closes, close_src)
    }

    #[test]
    fn each_retest_endpoint_belongs_to_unique_nearest_center() {
        // ★conformance 测试（codex 明确要求，锁正确语义，替代锚定 bug 产出的旧 bit-exact oracle）：
        // 多中枢散布输入下，每个 retest 端点（source_index）只产**一个** bsp——唯一归属其最近中枢，
        // 不对所有前驱中枢重复（第18课定理三「该中枢」+ 第49课「当下之前最后一个中枢」）。
        //
        // 旧 `for c in centers` 对同一 source_index 重复产出 O(C) 次（98.9% 重复）；修复后单趟扫描
        // 每端点唯一归属 ⟹ 同一 source_index 至多一个第一类 + 至多一个第三类（互斥语义不同 bit）。
        for &(n_seg, n_center) in &[(200usize, 8usize), (1000, 16), (3000, 24)] {
            let (centers, segments, closes, close_src) = synth_scale_input(n_seg, n_center);
            let cfg = MacdConfig::default();
            let points = extract_signals(&centers, &segments, &closes, &close_src, &cfg);

            // 每个 source_index 的第三类买卖点至多一个（唯一归属最近中枢，无前驱重复）。
            use std::collections::HashMap;
            let mut third_per_src: HashMap<usize, usize> = HashMap::new();
            let mut first_per_src: HashMap<usize, usize> = HashMap::new();
            for p in &points {
                if p.bits.buy3 || p.bits.sell3 {
                    *third_per_src.entry(p.source_index).or_insert(0) += 1;
                }
                if p.bits.buy1 || p.bits.sell1 {
                    *first_per_src.entry(p.source_index).or_insert(0) += 1;
                }
            }
            for (&src, &cnt) in &third_per_src {
                assert_eq!(
                    cnt, 1,
                    "标度 ({n_seg} seg, {n_center} center)：source_index={src} 的第三类买卖点必须唯一\
                     （归属最近中枢，不对前驱重复，第18课定理三「该中枢」）"
                );
            }
            for (&src, &cnt) in &first_per_src {
                assert_eq!(
                    cnt, 1,
                    "标度 ({n_seg} seg, {n_center} center)：source_index={src} 的第一类买卖点必须唯一\
                     （归属最后中枢，不对前驱重复，maimai.md:103「最后一个中枢」）"
                );
            }
            // 含 3 类 bit 的 bsp 的 center 必 Some 且 = 某真实输入中枢（归属正确，非零占位）。
            for p in &points {
                if p.bits.buy3 || p.bits.sell3 {
                    // （#218 面 A 载体形态机械适配：三类点恒 Center 载体。）
                    let c = match p.center.expect("含 3 类 bit ⟹ center 必 Some") {
                        OwnerRef::Center(c) => c,
                        other => panic!("三类点载体恒 Center，实际={other:?}"),
                    };
                    assert!(
                        centers.iter().any(|ic| ic.zd == c.zd
                            && ic.zg == c.zg
                            && ic.end_index == c.end_index),
                        "归属中枢必是真实输入中枢之一（最近中枢，非臆造）"
                    );
                }
            }
        }
    }

    #[test]
    fn extract_signals_handles_unsorted_input_via_stable_sort() {
        // 严格性（零假设）：extract_signals 入口稳定排序 ⟹ 即使输入乱序（非生产路径，但公开函数
        // 不能假设升序），结果 = 按 start_index 升序处理的确定性输出。验证排序后切片二分定位正确：
        // 乱序输入与其升序版本产相同 bsp（排序消除输入顺序依赖）。
        let c = center(100, 200, 2);
        let asc = vec![
            seg(Direction::Down, 3, 5, 150, 90),
            seg(Direction::Down, 6, 8, 120, 80),
        ];
        let desc = vec![
            seg(Direction::Down, 6, 8, 120, 80),
            seg(Direction::Down, 3, 5, 150, 90),
        ];
        let prices: Vec<Tick> = vec![100, 100, 100, 100, 60, 140, 100, 95, 105];
        let (closes, src) = closes_seq(&prices);
        let cfg = MacdConfig::default();
        let from_asc = extract_signals(&[c], &asc, &closes, &src, &cfg);
        let from_desc = extract_signals(&[c], &desc, &closes, &src, &cfg);
        assert_eq!(
            from_asc, from_desc,
            "稳定排序消除输入顺序依赖 ⟹ 乱序与升序输入产相同 bsp"
        );
    }

    /// 多中枢散布的合成数据（隔离单趟扫描的 O(S·logC) 标度——大量中枢 + 大量线段）。
    ///
    /// ★为什么需要：旧 `for c in centers` 主循环对每 center 全扫线段后缀 = O(C·S)，且第一/三类对
    /// 前驱中枢**重复产出** O(C) 份/端点（98.9% 重复 + O(n²) 全窗瓶颈双重根源）。本档造 n_center 个
    /// 中枢散布在段序列各处 + 段端点剧烈摆动（破中枢 + 离开/回试），复现旧码 C·S 主循环成本。修复后
    /// 单趟扫描每段 O(logC) 二分定位归属中枢 ⟹ 总 O(S·logC)，无 C·S 全扫 + 无前驱重复。
    fn synth_many_center_input(
        n_seg: usize,
        n_center: usize,
    ) -> (Vec<Center>, Vec<Segment>, Vec<f64>, Vec<usize>) {
        // 方向交替段，start_index 升序，端点剧烈摆动（破中枢 + 离开/回试，最大化产出路径触发）。
        let mut segments = Vec::with_capacity(n_seg);
        for k in 0..n_seg {
            let dir = if k % 2 == 0 {
                Direction::Down
            } else {
                Direction::Up
            };
            let si = k * 2;
            let ei = k * 2 + 1;
            let phase = (k as i64 * 37) % 220;
            let ep: Tick = 40 + phase; // 40..260（破中枢核心 [100,200] + 离开/回试）
            segments.push(Segment {
                direction: dir,
                start_index: si,
                end_index: ei,
                start_price: 150,
                end_price: ep,
            });
        }
        // n_center 个中枢，end_index 散布在段序列各处（每段二分定位不同归属中枢，复现 C 维成本）。
        let mut centers = Vec::with_capacity(n_center);
        for j in 0..n_center {
            let ei = (j * n_seg / n_center.max(1)) * 2;
            centers.push(Center {
                zd: 100,
                zg: 200,
                dd: 50,
                gg: 250,
                start_index: 0,
                end_index: ei,
            });
        }
        let n_close = n_seg * 2 + 2;
        let mut closes = Vec::with_capacity(n_close);
        let mut close_src = Vec::with_capacity(n_close);
        for t in 0..n_close {
            let osc = (((t as i64 * 53) % 80) - 40) as f64;
            closes.push(150.0 + osc);
            close_src.push(t);
        }
        (centers, segments, closes, close_src)
    }

    /// 标度计时（`--ignored` 显式触发，不拖累常规测试）：修复后单趟扫描 `extract_signals` 在
    /// 多中枢散布输入上耗时。验证 O(S·logC) 标度（线性 × log）——段数 ×N、中枢数 ×N 时耗时近线性增长，
    /// 非旧 O(C·S)/O(n²) 的二次/平方爆炸。L2 profile 坐实旧热点 = `extract_signals` O(n²)（前驱重复 +
    /// 每 center 全扫），本档复现规模并展示修复后近线性耗时（无 oracle 对照——旧 oracle 锚定 bug 产出
    /// 已删，no-patch）。
    #[test]
    #[ignore = "标度计时，--ignored 显式触发"]
    fn scale_timing_single_pass() {
        use std::time::Instant;
        let cfg = MacdConfig::default();
        // 段数与中枢数同步放大（旧 O(C·S) 会二次爆炸；修复后 O(S·logC) 近线性）。
        for &(n_seg, n_center) in &[(4000usize, 32usize), (16000, 64), (64000, 128)] {
            let (centers, segments, closes, close_src) = synth_many_center_input(n_seg, n_center);
            let t0 = Instant::now();
            let points = extract_signals(&centers, &segments, &closes, &close_src, &cfg);
            let dt = t0.elapsed();
            println!(
                "[单趟扫描 S={n_seg} C={n_center}] 耗时={:?} bsp={}（O(S·logC) 近线性，无前驱重复）",
                dt, points.len()
            );
        }
    }
    #[test]
    fn diag_first_buy() {
        use super::super::decompose::decompose;
        use super::super::divergence::{compute_macd, locate_departure_move_a, segment_macd_area};
        let c0 = Center {
            zd: 300,
            zg: 400,
            dd: 290,
            gg: 410,
            start_index: 0,
            end_index: 2,
        };
        let c1 = Center {
            zd: 100,
            zg: 200,
            dd: 90,
            gg: 210,
            start_index: 0,
            end_index: 8,
        };
        println!("blocks = {:?}", decompose(&[c0, c1]));
        let prices: Vec<Tick> = vec![300, 300, 300, 300, 200, 400, 250, 280, 260, 150, 145, 155];
        let closes: Vec<f64> = prices.iter().map(|&v| v as f64).collect();
        let src: Vec<usize> = (0..prices.len()).collect();
        let hist = compute_macd(&closes, &MacdConfig::default()).hist;
        let segs = vec![
            Segment {
                direction: Direction::Down,
                start_index: 3,
                end_index: 5,
                start_price: 350,
                end_price: 250,
            },
            Segment {
                direction: Direction::Up,
                start_index: 5,
                end_index: 7,
                start_price: 250,
                end_price: 280,
            },
            Segment {
                direction: Direction::Down,
                start_index: 9,
                end_index: 11,
                start_price: 150,
                end_price: 80,
            },
        ];
        let a = locate_departure_move_a(
            &segs,
            &super::super::divergence::self_anchors(&segs),
            &c0,
            &c1,
            Direction::Down,
        );
        println!("A seg = {:?}", a);
        println!(
            "A area [3,5] = {}",
            segment_macd_area(&hist, 3, 5, Direction::Down)
        );
        println!(
            "C area [9,11] = {}",
            segment_macd_area(&hist, 9, 11, Direction::Down)
        );
        println!(
            "hist = {:?}",
            hist.iter()
                .map(|h| (h * 100.0).round() / 100.0)
                .collect::<Vec<_>>()
        );
    }

    // ── ★性能工位（#93）：O(n²) 双热点 profile + bit-exact 前后对拍 ────────────────────
    //
    // 守卫 signal.rs 两独立 O(n²) 热点（memory signal-on2-two-independent-hotspots）：
    // ① type3 前驱重复（已由单趟扫描 + nearest_confirmed_center 二分在前序修复解决）；
    // ② `.position()` O(S·C) 反查（热点①，map 线性扫）+ `locate_trend_seg_a` 每段重算 O(S²)（热点②）。
    // 本节实测标度（exp 修复前≈2，修复后≈1）+ bit-exact 前后对拍（FNV 摘要逐元素相等）。

    /// FNV-1a over Debug 串（bit-exact 前后对拍的确定性摘要，覆盖 BspPoint 全字段）。
    fn fnv1a(s: &str) -> u64 {
        let mut h: u64 = 0xcbf2_9ce4_8422_2325;
        for b in s.as_bytes() {
            h ^= *b as u64;
            h = h.wrapping_mul(0x0000_0100_0000_01b3);
        }
        h
    }

    /// 严格下跌趋势的 n 个中枢（全链 DownContinuation：next.gg < prev.dd ⟹ trend_class=Trend(Down)
    /// ⟹ trend_dir=Some ⟹ 主循环 `.position()` 触发）。
    fn down_trend_centers(n: usize) -> Vec<Center> {
        (0..n)
            .map(|j| {
                let dd = ((n - j) as Tick) * 100;
                Center {
                    zd: dd + 10,
                    zg: dd + 50,
                    dd,
                    gg: dd + 60,
                    start_index: 0,
                    end_index: 2 * j,
                }
            })
            .collect()
    }

    /// n_seg 条向上线段，start_index 全在所有中枢 end_index 之后（每段最近中枢=最后一个 ⟹ 旧
    /// `.position()` 全扫 C 元素 ⟹ O(S·C)）。向上段在下跌趋势中 broke=false ⟹ judge_first 早退
    /// （不触 locate_trend_seg_a），隔离 `.position()` 为唯一非平凡成本。
    fn up_segs_after(n_seg: usize, n_center: usize) -> Vec<Segment> {
        let base = 2 * n_center;
        (0..n_seg)
            .map(|k| Segment {
                direction: Direction::Up,
                start_index: base + 2 * k,
                end_index: base + 2 * k + 1,
                start_price: 500,
                end_price: 600,
            })
            .collect()
    }

    /// 确定性 LCG 中枢+线段+closes（趋势/破中枢/type3 概率覆盖，bit-exact 电池用）。
    fn lcg_signal_input(
        n_seg: usize,
        n_center: usize,
        seed: u64,
    ) -> (Vec<Center>, Vec<Segment>, Vec<f64>, Vec<usize>) {
        let mut st = seed ^ 0x9E37_79B9_7F4A_7C15;
        let mut nxt = || {
            st = st
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            (st >> 33) as i64
        };
        let mut centers = Vec::with_capacity(n_center);
        let mut base: i64 = 200;
        for j in 0..n_center {
            base += (nxt() % 80) - 40;
            let zd = base;
            let zg = base + 30 + (nxt() % 40);
            centers.push(Center {
                zd,
                zg,
                dd: zd - 20,
                gg: zg + 20,
                start_index: 0,
                end_index: 2 * j,
            });
        }
        let mut segments = Vec::with_capacity(n_seg);
        for k in 0..n_seg {
            let dir = if k % 2 == 0 {
                Direction::Down
            } else {
                Direction::Up
            };
            let ep = 100 + (nxt() % 200);
            segments.push(Segment {
                direction: dir,
                start_index: 2 * k,
                end_index: 2 * k + 1,
                start_price: 200,
                end_price: ep,
            });
        }
        let n_close = n_seg * 2 + 2;
        let mut closes = Vec::with_capacity(n_close);
        let mut cs = Vec::with_capacity(n_close);
        let mut p = 200.0_f64;
        for t in 0..n_close {
            p += ((nxt() % 100) - 50) as f64 * 0.1;
            closes.push(p);
            cs.push(t);
        }
        (centers, segments, closes, cs)
    }

    /// ★仅测试用：`extract_signals` 的**朴素无缓存参考实现**（#93 bit-exact 对拍的 oracle）。
    /// 结构承自 git HEAD b8667b968f（旧 `.position()` O(C) 反查 + 每段重算 A 定位），A/C 判据与
    /// 生产同步升级为 Q5 区间语义（`locate_departure_move_a` + 每段朴素重扫 λ_C，无缓存）——oracle
    /// 的职责是守卫 first_match_idx/a_seg_cache 两缓存优化的透明性（同 #143 换局部
    /// 趋势门先例：oracle 门与生产同步，非语义快照）。
    fn judge_first_orig(
        prev_center: &Center,
        last_center: &Center,
        trend_dir: Direction,
        seg: &Segment,
        segments: &[Segment],
        hist: &[f64],
        src_to_idx: &[usize],
    ) -> Option<BspPoint> {
        let end = seg_end(seg);
        let (broke, is_sell) = match (end.dir, trend_dir) {
            (Direction::Down, Direction::Down) if end.price < last_center.zd => (true, false),
            (Direction::Up, Direction::Down) if last_center.zg < end.price => (true, true),
            _ => (false, false),
        };
        if !broke {
            return None;
        }
        let Some((a_start, a_end)) = locate_departure_move_a(
            segments,
            &super::super::divergence::self_anchors(segments),
            prev_center,
            last_center,
            trend_dir,
        ) else {
            return None;
        };
        // ★p117 037:20 同步（oracle 与生产同一判据，非语义快照——#143 换门同步先例）：c 端点破
        // b 包络极值（包络 = `move_range_envelope` 同一原语同区间语义；oracle 无缓存逐段重算，
        // 与其朴素风格一致）。同步后 `extract_signals_bit_exact_vs_orig_per_case` 逐 case 对拍
        // 保持（两侧同失被 037:20 杀掉的点）。
        let Some((b_lo, b_hi)) = move_range_envelope(segments, (a_start, a_end)) else {
            return None;
        };
        let extreme_037_20 = match trend_dir {
            Direction::Down => end.price < b_lo,
            Direction::Up => end.price > b_hi,
        };
        if !extreme_037_20 {
            return None;
        }
        // Q5 λ_C（oracle 与生产同一共享 helper——codex ac4 #4：无平行实现 ⟹ 无坐标 fork）。
        let Some(lambda_c) = departure_move_c_start(
            segments,
            &super::super::divergence::self_anchors(segments),
            last_center,
            trend_dir,
            seg.start_index,
        ) else {
            return None;
        };
        let (Some(c_idx), Some(a_idx)) = (
            map_src_range_to_close_idx(src_to_idx, lambda_c, seg.end_index),
            map_src_range_to_close_idx(src_to_idx, a_start, a_end),
        ) else {
            return None;
        };
        let abc = AbcDivergence {
            seg_a: (a_start, a_end),
            seg_c: (lambda_c, seg.end_index),
            is_trend: true,
        };
        if !abc.diverges(hist, a_idx, c_idx, trend_dir) {
            return None;
        }
        let situ = EndpointSituation {
            after_first_buy: false,
            is_pullback_end: false,
            left_center: false,
            retrace_not_reenter: false,
            below_last_center: true,
            is_sell_side: is_sell,
        };
        let bits = endpoint_to_bsp(&situ);
        // oracle 是 veto 语义（只产背驰确认第一类）——这些点必破中枢，struct_break_dir 同新版逻辑。
        let struct_break_dir = Some(if is_sell { Side::Short } else { Side::Long });
        // oracle 不算力度（前 force 时代实现）⟹ force=None，与优化版空-dif 电池路径逐字段相等。
        // ★owner 载体补齐（关③ 补记② 路径 (a)）：oracle 同步填载判定中枢 last_center——沿用
        // 本头注「oracle 与生产同步，非语义快照」先例（同 Q5/p117 037:20 两次同步），per-case
        // 逐字段对拍继续锁定（center 在 PartialEq 内，bsp.rs:170）。
        Some(make_first_point(
            end.source_index,
            bits,
            end.price,
            last_center,
            struct_break_dir,
            None,
        ))
    }

    /// ★仅测试用：优化前 `extract_signals`（oracle，逐字从 git HEAD 复制）。
    fn extract_signals_orig(
        centers: &[Center],
        segments: &[Segment],
        closes: &[f64],
        close_src: &[usize],
        macd_cfg: &MacdConfig,
    ) -> Vec<BspPoint> {
        let hist = compute_macd(closes, macd_cfg).hist;
        let mut sorted: Vec<Segment> = segments.to_vec();
        sorted.sort_by_key(|s| s.start_index);
        let mut centers_sorted: Vec<Center> = centers.to_vec();
        centers_sorted.sort_by_key(|c| c.end_index);
        // task #143：oracle 门与生产同步换局部趋势门（本 oracle 守卫热点①②的 O(n) 优化等价性，
        // 非门语义快照——保留 naive .position() 反查与每段 locate_trend_seg_a 重算）。
        let blocks = decompose(&centers_sorted);
        let center_gate = center_trend_gate(centers_sorted.len(), &blocks);
        let any_trend = center_gate.iter().any(|g| g.is_some());
        let mut points = Vec::new();
        for (i, seg) in sorted.iter().enumerate() {
            let center_for_seg = nearest_confirmed_center(&centers_sorted, seg.start_index);
            if let Some(c) = center_for_seg {
                if any_trend {
                    let last_pos = centers_sorted
                        .iter()
                        .position(|x| x.end_index == c.end_index && x.zd == c.zd && x.zg == c.zg);
                    if let Some(pos) = last_pos {
                        if let Some(dir) = center_gate[pos] {
                            let prev_center = &centers_sorted[pos - 1];
                            if let Some(p) = judge_first_orig(
                                prev_center,
                                c,
                                dir,
                                seg,
                                &sorted,
                                &hist,
                                close_src,
                            ) {
                                points.push(p);
                            }
                        }
                    }
                }
                if i > 0 {
                    let leave_seg = &sorted[i - 1];
                    if let Some(c_leave) =
                        nearest_confirmed_center(&centers_sorted, leave_seg.start_index)
                    {
                        // oracle 同步填载（#905 / #816 B-3「必须是第一次」显式化，与生产版同条件）。
                        let first_retrace_pair =
                            i == 1 || sorted[i - 2].start_index < c_leave.end_index;
                        if first_retrace_pair {
                            if let Some(p) =
                                judge_third(c_leave, leave_seg, Some(leave_seg.direction), seg)
                            {
                                points.push(p);
                            }
                        }
                    }
                }
            }
        }
        points.sort_by_key(|p| p.source_index);
        points
    }

    /// bit-exact 前后对拍电池（#93，no-patch）：固定多类输入 ⟹ extract_signals 全字段 FNV 摘要。
    fn bit_exact_battery_digest() -> u64 {
        let cfg = MacdConfig::default();
        let mut acc = String::new();
        // (a) 趋势 `.position()` 路径：下跌趋势 + 向上非破段（隔离 `.position()`）。
        for &(c, s) in &[(8usize, 16usize), (20, 40), (12, 60)] {
            let pts = extract_signals(&down_trend_centers(c), &up_segs_after(s, c), &[], &[], &cfg);
            acc.push_str(&format!("A{c}_{s}:{pts:?}\n"));
        }
        // (b) 多中枢散布合成电池（type3 路径，无趋势）。
        for &(s, c) in &[(50usize, 4usize), (200, 8), (500, 16)] {
            let (ce, se, cl, cs) = synth_many_center_input(s, c);
            let pts = extract_signals(&ce, &se, &cl, &cs, &cfg);
            acc.push_str(&format!("B{s}_{c}:{pts:?}\n"));
        }
        // (c) LCG 随机中枢+线段+closes（趋势/破中枢/type3 概率覆盖）。
        for &seed in &[1u64, 42, 0xDEAD_BEEF] {
            for &(s, c) in &[(60usize, 6usize), (180, 12)] {
                let (ce, se, cl, cs) = lcg_signal_input(s, c, seed);
                let pts = extract_signals(&ce, &se, &cl, &cs, &cfg);
                acc.push_str(&format!("C{seed}_{s}_{c}:{pts:?}\n"));
            }
        }
        // (d) 重复 (end_index,zd,zg) 三元组中枢（stress `.position()` 首匹配语义）。
        let dup = vec![
            center(100, 200, 4),
            center(100, 200, 4),
            center(50, 80, 4),
            center(100, 200, 10),
            center(30, 60, 16),
        ];
        let dsegs = vec![
            seg(Direction::Up, 5, 8, 60, 250),
            seg(Direction::Down, 8, 12, 250, 210),
            seg(Direction::Down, 17, 20, 60, 20),
            seg(Direction::Up, 20, 24, 20, 55),
        ];
        let (dcl, dcs) = closes_seq(&[
            100, 100, 100, 100, 100, 100, 100, 100, 90, 80, 70, 60, 50, 40, 30, 20, 210, 205, 200,
            195, 55, 50, 45, 40,
        ]);
        let pts = extract_signals(&dup, &dsegs, &dcl, &dcs, &cfg);
        acc.push_str(&format!("D:{pts:?}\n"));
        fnv1a(&acc)
    }

    #[test]
    fn extract_signals_bit_exact_digest_guard() {
        // bit-exact 前后对拍（#93）：优化（`.position()` → first_match_idx HashMap + locate_trend_seg_a
        // 缓存）后摘要必须 = 优化前 oracle（git HEAD b8667b968f `extract_signals`）在同电池上的输出。
        //
        // ★GOLDEN 校准（no-patch）：本 GOLDEN = oracle `extract_signals_orig`（从 git HEAD 逐字复制的
        // 优化前实现）在同电池上的 FNV 摘要。`extract_signals_bit_exact_vs_orig_per_case` 逐 case 坐实
        // 优化版与 oracle **逐字段**相等（含新增 struct_break_dir 字段）⟹ 此 GOLDEN 同等于优化版输出。
        //
        // ★P2-R2 诚实更新（codex-review-20260701-2251 护栏4 方案A）：`BspPoint` 新增 `struct_break_dir:
        // Option<Side>` 字段（p2-plan §2 破中枢方向源，消选择偏差）进入 `#[derive(Debug)]` ⟹ FNV 对
        // `{pts:?}` 的摘要必然翻转（新字段改变 Debug 字符串）。这是**诚实的、可证的**代价——**不**通过
        // 自定义 Debug 隐藏 struct_break_dir 假装 digest 不变（那是声明膨胀，护栏4 禁止）。六 bit
        // （buy1/2/3+sell1/2/3）逐字段不变由 `extract_signals_bit_exact_vs_orig_per_case`（逐 case
        // assert_eq 全字段比较）锁定——GOLDEN 翻转**仅**因新增字段，非六 bit 语义变化。
        //
        // ★beta-route #115 诚实更新（force_state 生产热路由）：`BspPoint` 再新增 `force: Option<ForceProxies>`
        // 字段（β^div 力度 proxy）进入 `#[derive(Debug)]` ⟹ 每点 Debug 尾多 `, force: None`（本电池经
        // `extract_signals` 传**空 dif/closes_tick** ⟹ force 恒 None，非力度值差）⟹ FNV 摘要再翻转。同
        // struct_break_dir 先例：**诚实、可证、均匀**（全 None 常量），**不**自定义 Debug 隐藏 force。六 bit
        // + pivot + center + struct_break_dir 逐字段不变仍由 per-case（PartialEq 排除 force，本电池 force
        // 恒 None 无差可漏）锁定——翻转**仅**因新增 `, force: None` 常量串。
        // ★owner 载体补齐（关③ 补记 2026-07-18 ②，编排者路径 (a)）：`make_first_point`/
        // `make_second_point` 构造时 `center: None→Some(判定中枢)`（一/二类点 owner 载体），center 在
        // `#[derive(Debug)]` 内——本 GOLDEN **实测未翻转**（仍 0x90c7_9ee6_17e1_1392），根因经探针逐
        // case 落账：电池 14 case 共产 247 点**全为三类**（buy3+sell3，center 本已 Some），一/二类
        // 路径点零产出（A 组 broke=false 早退；B/C/D 组 τ 门未开 ⟹ `judge_first_cached` 零产出；
        // 二类由 `extract_second_signals` 产，不在本电池输入域）⟹ **点集合与摘要双零变化**。
        // per-case 对拍（oracle 同步填载，「同步非快照」先例）继续逐字段锁定（center 在 PartialEq 内，
        // bsp.rs:170）。若未来电池纳入一/二类路径点致摘要翻转，按上方先例诚实重算并更新本段。
        // ★#110/#218 诚实更新（kimi-nest-mainline-20260717 三方合并浮出，同 struct_break_dir/force
        // 先例）：`BspPoint` 新增 `u32` 级别身份标签字段（#110 塔级别下标标注，字段名从略——
        // 该字段已在 #455 删除，详见下条）且 `center` 载体 `Option<Center>` 升为 `Option<OwnerRef>`
        // （#218 OwnerRef 包装）——二者均在 `#[derive(Debug)]` 内 ⟹ 每点 Debug 串多一枚该字段的默认值
        // 串且 Some(Center{..}) 变 Some(Center(Center{..})) ⟹ FNV 摘要翻转。**不**自定义 Debug
        // 隐藏新字段（护栏4 禁止）。六 bit + pivot + center + struct_break_dir 逐字段语义不变由
        // `extract_signals_bit_exact_vs_orig_per_case`（oracle 同步填载，PartialEq 含该字段/
        // OwnerRef 新口径）继续锁定——翻转**仅**因 Debug 形态变化，非语义变化。
        // ★#455 诚实更新（#434 grilling 交棒件）：上条引入的塔级别下标标注字段**删除**——全仓 62 处
        // 硬编码常值 0、classify_impl/classify_with_tower_incremental 从未写过，正主
        // `LevelProjectionLayer.identity.level` 已实填，同信息两份拷贝其一恒空——删除零损失，见
        // SPEC #455 D1。字段退出 `#[derive(Debug)]` ⟹ 每点 Debug 串少一枚该字段的默认值串 ⟹ FNV
        // 摘要再翻转。同上方先例：**诚实、可证**（PartialEq 同步摘掉该分量，
        // `extract_signals_bit_exact_vs_orig_per_case` 逐 case 对拍口径同步收窄，六 bit + pivot +
        // center + struct_break_dir 仍逐字段锁定），**不**自定义 Debug 补回假字段掩盖翻转。
        // 历史值：`0xe6a2_63e3_43e4_3845`（该字段删除前，#455 之前最后一版）；
        //         `0x90c7_9ee6_17e1_1392`（该字段/OwnerRef 引入前）；
        //         `0x56ed_dd65_1c59_5733`（force 引入前，struct_break_dir 后）；
        //         `0x37d2_45a7_cdc5_505a`（P2-R2 前，struct_break_dir 引入前）；
        //         `0x06b3_7c2f_3a5e_9d41`（更早，与 git HEAD oracle 不一致的历史电池状态）。
        //
        // ★#614 并线并入 kimi 线 #610 的归因取证（2026-07-29）：上表 `0x90c7_9ee6_17e1_1392`
        // → `0xe6a2_63e3_43e4_3845` 这一跳的引入提交经 git bisect 定为 `bbbd8f89fa`
        // （2026-07-24「P1→#214→#218 证书索引口径三部曲」，合法口径演进）——该提交对
        // `BspPoint` 做了两处同时进入 `#[derive(Debug)]` 的改动：新增 `level_origin: u32`
        // （恒 0，#110 面）+ `center: Option<Center>` → `Option<OwnerRef>`（#218 面 A，二类点
        // 值本身也变为 `OwnerRef::Type1Anchor` 坐标，非仅包裹形态）。GOLDEN 未随该提交同步
        // 重锚，致 guard 自 `bbbd8f89fa` 起在 kimi 线持续红（#491 发现）。归因证据：
        // `chanlun/review-results/issue610-digest-guard-attribution-20260728.md`（bisect +
        // 逐行 diff）+ `issue610-id65-supplement-20260729.md`（level_origin 面补记）。
        // ⚠本合并树取 **#455 之后**口径（`level_origin` 已删，见 `bsp.rs` 无该字段），
        // 故现行值为下方 main 侧值，kimi 线的 `0xe6a2…` 即上表「该字段删除前」那一版。
        // ★#905（#816 B-3 落地，2026-08-16）：三类「必须是第一次」显式化（`first_retrace_pair`
        // 谓词，020:62【正文】）——B 组多中枢散布电池的旧输出含同中枢重复三类（第二/三次回试
        // 回填，教义禁止），新输出每中枢仅首对一回；摘要翻转是**语义修正**（教义条件补齐），
        // 非形态变化。oracle（extract_signals_orig）同步填载同条件。历史值：`0xe371_3897_d9bf_978c`
        // （#905 前）。
        // ★#884（#816 B-2② 落地，重合标注字段，2026-08-17）：`BspPoint` 新增
        // `retrace_breaks_type1: Option<bool>`（二类点回拉破一类极值的重合身份标注，`101:32`
        // 【正文】，不作准入分档，语义归 #817）进入 `#[derive(Debug)]` ⟹ 每点 Debug 串多
        // `retrace_breaks_type1: None` 常量（本电池经 `extract_signals` L0 入口产一/三类点，
        // 无二类点 ⟹ 恒 None，均匀）⟹ FNV 摘要翻转。同 struct_break_dir/force 先例：**诚实、
        // 可证、均匀**（全 None 常量），**不**自定义 Debug 隐藏该字段。二类点的标注取值由
        // `extract_second_signals` 路径单测锁定（`second_buy_produced_when_retrace_makes_new_low`
        // 等），本电池无二类点无差可漏——翻转**仅**因新增 `, retrace_breaks_type1: None` 常量串。
        // 历史值：`0xcb91_2871_4985_4dd5`（#884 前）。
        const GOLDEN: u64 = 0xa822_b80d_c37e_b1c7;
        let digest = bit_exact_battery_digest();
        assert_eq!(
            digest, GOLDEN,
            "bit-exact 摘要={digest:#018x}（优化版须 = git HEAD oracle 摘要；`diag_compare_vs_orig` 锁定逐字段相等）"
        );
    }

    /// ★bit-exact 逐 case 对拍（#93，no-patch 锁）：优化版 `extract_signals` 须与 git HEAD oracle
    /// （`extract_signals_orig`，逐字复制的优化前实现）在**每个 case** 上逐字段相等。这比 FNV 摘要
    /// 更强——摘要碰撞理论上可能，逐 case `assert_eq` 零碰撞风险。覆盖趋势 `.position()` 路径、多中枢
    /// 散布 type3 路径、LCG 随机趋势/破中枢/type3、重复三元组 stress（14 case）。
    #[test]
    fn extract_signals_bit_exact_vs_orig_per_case() {
        let cfg = MacdConfig::default();
        let mut cases: Vec<(String, Vec<Center>, Vec<Segment>, Vec<f64>, Vec<usize>)> = Vec::new();
        for &(c, s) in &[(8usize, 16usize), (20, 40), (12, 60)] {
            cases.push((
                format!("A{c}_{s}"),
                down_trend_centers(c),
                up_segs_after(s, c),
                vec![],
                vec![],
            ));
        }
        for &(s, c) in &[(50usize, 4usize), (200, 8), (500, 16)] {
            let (ce, se, cl, cs) = synth_many_center_input(s, c);
            cases.push((format!("B{s}_{c}"), ce, se, cl, cs));
        }
        for &seed in &[1u64, 42, 0xDEAD_BEEF] {
            for &(s, c) in &[(60usize, 6usize), (180, 12)] {
                let (ce, se, cl, cs) = lcg_signal_input(s, c, seed);
                cases.push((format!("C{seed}_{s}_{c}"), ce, se, cl, cs));
            }
        }
        let dup = vec![
            center(100, 200, 4),
            center(100, 200, 4),
            center(50, 80, 4),
            center(100, 200, 10),
            center(30, 60, 16),
        ];
        let dsegs = vec![
            seg(Direction::Up, 5, 8, 60, 250),
            seg(Direction::Down, 8, 12, 250, 210),
            seg(Direction::Down, 17, 20, 60, 20),
            seg(Direction::Up, 20, 24, 20, 55),
        ];
        let (dcl, dcs) = closes_seq(&[
            100, 100, 100, 100, 100, 100, 100, 100, 90, 80, 70, 60, 50, 40, 30, 20, 210, 205, 200,
            195, 55, 50, 45, 40,
        ]);
        cases.push(("D".to_string(), dup, dsegs, dcl, dcs));
        for (name, ce, se, cl, cs) in &cases {
            let opt = extract_signals(ce, se, cl, cs, &cfg);
            let ori = extract_signals_orig(ce, se, cl, cs, &cfg);
            assert_eq!(
                opt, ori,
                "case {name}：优化版须与 git HEAD oracle 逐字段相等（bit-exact）"
            );
        }
    }

    #[test]
    #[ignore = "标度计时（map 线性扫 `.position()` 热点），--ignored 显式触发"]
    fn scale_timing_position_hotspot() {
        use std::time::Instant;
        let cfg = MacdConfig::default();
        let mut prev: Option<(usize, f64)> = None;
        for &n in &[1000usize, 2000, 4000, 8000] {
            let centers = down_trend_centers(n);
            let segs = up_segs_after(n, n);
            let mut best = f64::INFINITY;
            let mut len = 0;
            for _ in 0..3 {
                let t0 = Instant::now();
                let pts = extract_signals(&centers, &segs, &[], &[], &cfg);
                let dt = t0.elapsed().as_secs_f64();
                best = best.min(dt);
                len = pts.len();
            }
            match prev {
                Some((pn, pt)) => {
                    let exp = (best / pt).ln() / (n as f64 / pn as f64).ln();
                    println!("[.position() S=C={n}] t={best:.6}s bsp={len} exp_vs_prev={exp:.3}");
                }
                None => println!("[.position() S=C={n}] t={best:.6}s bsp={len}（基准点）"),
            }
            prev = Some((n, best));
        }
    }

    #[test]
    #[ignore = "标度计时（破中枢路径，含 locate_trend_seg_a 残留），--ignored 显式触发"]
    fn scale_timing_breaking_path() {
        use std::time::Instant;
        let cfg = MacdConfig::default();
        let mut prev: Option<(usize, f64)> = None;
        for &n in &[1000usize, 2000, 4000, 8000] {
            let centers = down_trend_centers(n);
            let base = 2 * n;
            let segs: Vec<Segment> = (0..n)
                .map(|k| Segment {
                    direction: Direction::Down,
                    start_index: base + 2 * k,
                    end_index: base + 2 * k + 1,
                    start_price: 50,
                    end_price: 5,
                })
                .collect();
            let nc = base + 2 * n + 2;
            let closes: Vec<f64> = (0..nc).map(|t| 200.0 + ((t % 7) as f64) - 3.0).collect();
            let csrc: Vec<usize> = (0..nc).collect();
            let mut best = f64::INFINITY;
            let mut len = 0;
            for _ in 0..3 {
                let t0 = Instant::now();
                let pts = extract_signals(&centers, &segs, &closes, &csrc, &cfg);
                best = best.min(t0.elapsed().as_secs_f64());
                len = pts.len();
            }
            match prev {
                Some((pn, pt)) => {
                    let exp = (best / pt).ln() / (n as f64 / pn as f64).ln();
                    println!("[破中枢 S=C={n}] t={best:.6}s bsp={len} exp_vs_prev={exp:.3}");
                }
                None => println!("[破中枢 S=C={n}] t={best:.6}s bsp={len}（基准点）"),
            }
            prev = Some((n, best));
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // 短差档→盘背观测通道消费入口测试（票 #639；#575 消费方接线 3/3）
    // ═══════════════════════════════════════════════════════════════════════

    fn pan_div_wiring_provenance() -> RetraceProvenance {
        RetraceProvenance {
            level: 3,
            window: CoordinateWindow {
                start: 0,
                end: 9_999,
            },
            data_basis: "signal-pan-div-wiring-test".to_owned(),
        }
    }

    fn pan_div_wiring_frame(end_index: usize) -> super::super::retrace_ledger::CenterFrame {
        super::super::retrace_ledger::CenterFrame {
            zd: 100,
            zg: 200,
            start_index: 1_000,
            end_index,
        }
    }

    /// 一条合法的「向上离开」原始观察（三类买点候选），同
    /// `retrace_ledger/tests/mod.rs::up_input` 构造口径（判败靶向驱动，不走全窗 replay——
    /// 编排者 2026-07-29 裁定 B：驱动链归 #575 后续票，本票端到端验收用靶向驱动）。
    fn pan_div_wiring_up_input(
        center: super::super::retrace_ledger::CenterFrame,
        departure: usize,
        outcome: Option<RetraceOutcome>,
        as_of: usize,
    ) -> RetraceInput {
        RetraceInput {
            center,
            pair: StrictCompletedPair {
                leave_move_index: departure,
                retest_move_index: departure + 1,
            },
            leave_direction: Direction::Up,
            retest_direction: Direction::Down,
            leave_end: RetracePoint {
                index: center.end_index + 10,
                price: 250,
            },
            retest_end: outcome.map(|_| RetracePoint {
                index: center.end_index + 20,
                price: 210,
            }),
            outcome,
            as_of,
        }
    }

    /// 端到端：判败事件 → 短差档 → `drain_pan_div_short_retrace_observations` → 盘背观测通道
    /// 可见（亚型签 + 通道映射 + 三锁全过，票面验收①）。
    #[test]
    fn drain_pan_div_short_retrace_observations_end_to_end() {
        let mut ledger = RetraceLedger::new(pan_div_wiring_provenance());
        let center = pan_div_wiring_frame(1_200);
        ledger
            .observe(&pan_div_wiring_up_input(center, 3, None, 500))
            .unwrap();
        ledger
            .observe(&pan_div_wiring_up_input(
                center,
                3,
                Some(RetraceOutcome::RetestReenters),
                640,
            ))
            .unwrap();

        let mut portal = ShortRetracePortal::new();
        let observations = drain_pan_div_short_retrace_observations(&ledger, &mut portal);

        assert_eq!(observations.len(), 1, "一条判败 ⟹ 一条通道观测");
        let obs = observations[0];
        assert_eq!(
            obs.identity,
            RetraceKey {
                frame: center,
                departure_move_index: 3
            }
        );
        assert_eq!(obs.side, RetraceSide::Buy);
        assert_eq!(obs.subtype, PanDivSubtype::RetestReentered, "亚型签固定");
        assert_eq!(
            obs.channel_reason,
            T3InCGradeReason::RetestReentered,
            "亚型签对拍：账本 RetestReentered → 通道 RetestReentered（同名非同谓词，固定映射）"
        );
        assert_eq!(
            obs.retest_end.index, 1_220,
            "判败位置=回抽笔终点，投影不丢失"
        );
        assert_eq!(obs.judged_as_of, 640, "落锤知情时透传");
        assert!(
            portal.balances_with(&ledger),
            "消费后门户仍与账本账平（consume 不删记录）"
        );
        ledger.assert_invariants();
    }

    /// 重复消费幂等在接线面复验（票面验收②）：同一账本/门户对上二次调用，观测集合不重复增长。
    #[test]
    fn drain_pan_div_short_retrace_observations_is_idempotent_on_repeat_call() {
        let mut ledger = RetraceLedger::new(pan_div_wiring_provenance());
        let center = pan_div_wiring_frame(1_200);
        ledger
            .observe(&pan_div_wiring_up_input(center, 3, None, 500))
            .unwrap();
        ledger
            .observe(&pan_div_wiring_up_input(
                center,
                3,
                Some(RetraceOutcome::RetestReenters),
                640,
            ))
            .unwrap();

        let mut portal = ShortRetracePortal::new();
        let first = drain_pan_div_short_retrace_observations(&ledger, &mut portal);
        assert_eq!(first.len(), 1, "首次消费返回该条判败观测");

        let second = drain_pan_div_short_retrace_observations(&ledger, &mut portal);
        assert!(second.is_empty(), "重复消费幂等：同一身份不重复产出观测");

        // 账本新增第二条判败身份后，第三次调用只新增这一条——不重放已消费的第一条。
        let other = pan_div_wiring_frame(9_300);
        ledger
            .observe(&pan_div_wiring_up_input(other, 11, None, 700))
            .unwrap();
        ledger
            .observe(&pan_div_wiring_up_input(
                other,
                11,
                Some(RetraceOutcome::RetestReenters),
                760,
            ))
            .unwrap();
        let third = drain_pan_div_short_retrace_observations(&ledger, &mut portal);
        assert_eq!(
            third.len(),
            1,
            "只新增账本新判败身份对应的一条，不重放旧身份"
        );
        assert_eq!(
            third[0].identity,
            RetraceKey {
                frame: other,
                departure_move_index: 11
            }
        );
        ledger.assert_invariants();
    }

    /// 键冲突拒绝在接线面复验（票面验收②）：`drain` 走 `sync`/`consume`，不绕过
    /// [`ShortRetracePortal::admit`] 的键唯一锁——同一身份对 `admit` 显式二次登记仍被拒。
    #[test]
    fn admit_duplicate_identity_still_rejected_alongside_drain_wiring() {
        let mut ledger = RetraceLedger::new(pan_div_wiring_provenance());
        let center = pan_div_wiring_frame(1_200);
        ledger
            .observe(&pan_div_wiring_up_input(center, 3, None, 500))
            .unwrap();
        ledger
            .observe(&pan_div_wiring_up_input(
                center,
                3,
                Some(RetraceOutcome::RetestReenters),
                640,
            ))
            .unwrap();
        let record = ledger.short_retrace_records()[0];

        let mut portal = ShortRetracePortal::new();
        let _ = drain_pan_div_short_retrace_observations(&ledger, &mut portal);
        assert_eq!(
            portal.admit(record),
            Err(ShortRetraceRejection::DuplicateIdentity(record.identity)),
            "drain 已用 sync 把该身份写入门户；admit 的键唯一锁在接线面照样生效"
        );
        ledger.assert_invariants();
    }

    /// 亚型签对拍映射表：完全穷尽 [`T3InCGradeReason`] 五桶，只有 `RetestReentered` 有对应
    /// [`PanDivSubtype`]，其余四桶（固定首对压根未构成）无对应——不造伪对应。
    #[test]
    fn t3_in_c_grade_reason_to_pan_div_subtype_covers_all_five_buckets() {
        assert_eq!(
            t3_in_c_grade_reason_to_pan_div_subtype(T3InCGradeReason::RetestReentered),
            Some(PanDivSubtype::RetestReentered),
            "唯一天然对应点"
        );
        for unmapped in [
            T3InCGradeReason::MissingLeave,
            T3InCGradeReason::MissingRetest,
            T3InCGradeReason::SameDirection,
            T3InCGradeReason::LeaveNotOutside,
        ] {
            assert_eq!(
                t3_in_c_grade_reason_to_pan_div_subtype(unmapped),
                None,
                "{unmapped:?}：通道侧固定首对未构成，账本侧无对应判案"
            );
        }
        // 反向投影与正向表在唯一对应点上一致（互为部分逆）。
        assert_eq!(
            pan_div_subtype_channel_reason(PanDivSubtype::RetestReentered),
            T3InCGradeReason::RetestReentered
        );
    }

    /// `success`/`Provisional` 不产短差档记录 ⟹ `drain` 天然不折入通道（沿用
    /// `retrace_ledger/tests/short_retrace.rs::success_and_pending_never_enter_short_retrace_portal`
    /// 同一账本侧不变量，接线面复验：通道观测只见判败一族）。测试名 `..._and_success` 名实相符：
    /// `pending`（Provisional，未观测 outcome）与 `succeeded`（Confirmed，`RetraceOutcome::Success`）
    /// 两个独立候选各占一个中枢锚，drain 后均不产观测。
    #[test]
    fn drain_pan_div_short_retrace_observations_ignores_pending_and_success() {
        let mut ledger = RetraceLedger::new(pan_div_wiring_provenance());
        let pending = pan_div_wiring_frame(1_200);
        ledger
            .observe(&pan_div_wiring_up_input(pending, 3, None, 500))
            .unwrap();

        // 不同锚（`start_index` 不同）：`pending` 悬而未决时，同锚不许挂第二个候选
        // （裁定二），故 `succeeded` 必须换一个中枢锚，不能只换 `end_index`。
        let succeeded = super::super::retrace_ledger::CenterFrame {
            zd: 100,
            zg: 200,
            start_index: 3_000,
            end_index: 3_400,
        };
        ledger
            .observe(&pan_div_wiring_up_input(succeeded, 5, None, 800))
            .unwrap();
        ledger
            .observe(&pan_div_wiring_up_input(
                succeeded,
                5,
                Some(RetraceOutcome::Success),
                860,
            ))
            .unwrap();

        let mut portal = ShortRetracePortal::new();
        let observations = drain_pan_div_short_retrace_observations(&ledger, &mut portal);
        assert!(
            observations.is_empty(),
            "Provisional 候选与 Success 判胜候选均不进短差档，通道观测应为空"
        );
        ledger.assert_invariants();
    }

    /// 时序覆盖（缺口，影子评审 MEDIUM-4）：同一身份「先 drain（未登记，空集合）→ 后判败落地
    /// → 再 drain（见该条观测）」——`drain` 结构上先 `sync` 后 `consume`，对尚未登记的身份调用
    /// `consume` 不会写 `consumed`（[`ShortRetracePortal::consume`] 文档），故不会像 #623 HIGH-1
    /// 修复前那样被永久毒化；本测试把这条结构性保证钉进接线面。
    #[test]
    fn drain_pan_div_short_retrace_observations_sees_identity_registered_after_first_empty_drain() {
        let mut ledger = RetraceLedger::new(pan_div_wiring_provenance());
        let center = pan_div_wiring_frame(1_200);
        ledger
            .observe(&pan_div_wiring_up_input(center, 3, None, 500))
            .unwrap();

        let mut portal = ShortRetracePortal::new();
        let first = drain_pan_div_short_retrace_observations(&ledger, &mut portal);
        assert!(first.is_empty(), "身份尚未判败，首次 drain 见空集合");

        ledger
            .observe(&pan_div_wiring_up_input(
                center,
                3,
                Some(RetraceOutcome::RetestReenters),
                640,
            ))
            .unwrap();
        let second = drain_pan_div_short_retrace_observations(&ledger, &mut portal);
        assert_eq!(
            second.len(),
            1,
            "判败落地后再次 drain 见该条观测（首次空读未毒化该身份）"
        );
        assert_eq!(
            second[0].identity,
            RetraceKey {
                frame: center,
                departure_move_index: 3
            }
        );
        ledger.assert_invariants();
    }
}
