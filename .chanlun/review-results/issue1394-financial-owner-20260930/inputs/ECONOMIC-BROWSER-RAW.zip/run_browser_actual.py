#!/usr/bin/env python3
"""#1394 新客户端真实浏览器；只启动四个冻结服务与本次 Chrome。"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import sqlite3
import subprocess
import time

ROOT = Path("/Users/silencehan/Projects/NewChanlun-1394-content-v3")
BASE = Path(__file__).resolve().parent
CASE = ROOT / ".scratch/issue1394-economic-observer-actual-20260930/case-2"
PREPARED = json.loads((BASE / "BROWSER-ENV-PREPARED.json").read_bytes())
PREFLIGHT = json.loads((BASE / "BROWSER-RUN-PREFLIGHT.json").read_bytes())
MOUNTED = json.loads((BASE / "MOUNTED-COPIES.json").read_bytes())
MANIFEST = json.loads((CASE / "evidence/manifest.json").read_bytes())
SOCKET_ROOT = Path("/tmp/nc1394-eo-31")
OUT = BASE / "browser-run-1"
PROCESSES = []
CHROME_PID = None
STARTED_AT = datetime.datetime.now(datetime.timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def semantic_state():
    result = {}
    for owner in ("e", "alpha", "beta"):
        db = CASE / "mounts" / owner / f"{owner}.db"
        conn = sqlite3.connect(f"file:{db}?mode=ro&immutable=1", uri=True)
        conn.execute("PRAGMA query_only=ON")
        seq, root, ns = conn.execute(
            "SELECT seq,root,commit_ns FROM commits ORDER BY seq DESC LIMIT 1").fetchone()
        result[owner] = {"seq": seq, "root": root, "commit_ns": ns,
                         "receipts": conn.execute("SELECT count(*) FROM receipts").fetchone()[0],
                         "published_nodes": conn.execute("SELECT count(*) FROM content_nodes").fetchone()[0],
                         "staging_nodes": conn.execute("SELECT count(*) FROM content_staging").fetchone()[0],
                         "writer_epoch": conn.execute("SELECT v FROM meta WHERE k='writer_epoch'").fetchone()[0],
                         "manifest_hash": conn.execute("SELECT v FROM meta WHERE k='manifest_hash'").fetchone()[0]}
        conn.close()
    return result


def save(name, value):
    path = BASE / name
    with path.open("xb") as stream:
        stream.write(canonical(value))


def start(label, argv):
    stdout = BASE / f"{label}.stdout"
    stderr = BASE / f"{label}.stderr"
    with stdout.open("xb") as out, stderr.open("xb") as err:
        proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
    entry = {"label": label, "pid": proc.pid, "argv": argv, "stdout": str(stdout),
             "stderr": str(stderr), "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
             "ready": False, "ready_utc": None}
    PROCESSES.append((entry, proc))
    save(f"PROCESS-START-{label}.json", entry)
    return entry, proc


def wait_socket(label, proc, path):
    deadline = time.monotonic() + 20
    while not path.exists():
        if proc.poll() is not None:
            raise RuntimeError(f"{label} exited before socket: {proc.returncode}")
        if time.monotonic() >= deadline:
            raise TimeoutError(f"{label} socket deadline")
        time.sleep(0.01)
    entry = next(row for row, p in PROCESSES if p is proc)
    entry["ready"] = True
    entry["ready_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    entry["readiness"] = {"kind": "unix_socket_exists", "path": str(path)}
    save(f"PROCESS-READY-{label}.json", entry)


def wait_port(label, proc, port):
    deadline = time.monotonic() + 20
    while True:
        if proc.poll() is not None:
            raise RuntimeError(f"{label} exited before TCP readiness: {proc.returncode}")
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                break
        except OSError:
            if time.monotonic() >= deadline:
                raise TimeoutError(f"{label} TCP deadline")
            time.sleep(0.02)
    entry = next(row for row, p in PROCESSES if p is proc)
    entry["ready"] = True
    entry["ready_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    entry["readiness"] = {"kind": "tcp_connect_only", "host": "127.0.0.1", "port": port,
                          "claim": "socket acceptance only; no Q3 or economic readiness claim"}
    save(f"PROCESS-READY-{label}.json", entry)


def child_chrome_pid(parent_pid):
    output = subprocess.check_output(["ps", "-axo", "pid=,ppid=,command="], text=True)
    for line in output.splitlines():
        fields = line.split(None, 2)
        if len(fields) != 3:
            continue
        pid, ppid, command = fields
        if (int(ppid) == parent_pid and "Google Chrome" in command and
                "--user-data-dir=" + str(OUT / "profile") in command):
            return int(pid)
    return None


def stop_own_processes():
    result = []
    for entry, proc in reversed(PROCESSES):
        existing = proc.poll()
        if existing is None:
            proc.terminate()
            entry["stop_signal_sent"] = "SIGTERM"
        else:
            entry["stop_signal_sent"] = None
        try:
            status = proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            entry["stop_signal_sent"] = "SIGTERM then SIGKILL after 10s"
            status = proc.wait(timeout=10)
        entry["exit_code"] = status
        entry["reaped"] = True
        entry["stopped_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result.append(entry)
    save("BACKEND-PROCESSES-FINAL.json", {"processes": result, "all_reaped": len(result) == 4})


def detach_only_our_copies():
    hdi = subprocess.check_output(["hdiutil", "info"], text=True)
    rows = []
    for entry in reversed(MOUNTED):
        assert entry["copy_path"] in hdi and entry["source_archive_path"] not in hdi
        result = subprocess.run(["hdiutil", "detach", entry["device"]], capture_output=True, text=True)
        rows.append({"owner": entry["owner"], "device": entry["device"],
                     "copy_path": entry["copy_path"], "archive_path": entry["source_archive_path"],
                     "detach_exit": result.returncode, "detach_stdout": result.stdout.strip(),
                     "detach_stderr": result.stderr.strip()})
    save("COPY-DETACH-FINAL.json", {"copies": rows, "all_detached": all(r["detach_exit"] == 0 for r in rows)})
    return all(r["detach_exit"] == 0 for r in rows)


def clean_only_our_sockets():
    assert SOCKET_ROOT.is_dir() and not SOCKET_ROOT.is_symlink()
    paths = [SOCKET_ROOT / f"{owner}.sock" for owner in ("e", "alpha", "beta")]
    for path in paths:
        if path.exists():
            assert path.is_socket()
            path.unlink()
    assert not list(SOCKET_ROOT.iterdir())
    SOCKET_ROOT.rmdir()
    save("SOCKET-CLEANUP.json", {"paths": [str(p) for p in paths], "short_dir_removed": True})


def main():
    global CHROME_PID
    assert not OUT.exists()
    assert sha(BASE / "BROWSER-RUN-PREFLIGHT.json") == "8d77756398c7a3b3b59d4b09c58609e88bec1cf7fa532204f8cab85472056efc"
    assert SOCKET_ROOT.is_dir() and not SOCKET_ROOT.is_symlink() and not list(SOCKET_ROOT.iterdir())
    before = semantic_state()
    before_db = {owner: sha(CASE / "mounts" / owner / f"{owner}.db") for owner in before}
    archive_sha = {row["owner"]: sha(row["source_archive_path"]) for row in MOUNTED}
    save("BROWSER-STATE-BEFORE.json", {"logical": before, "db_sha256": before_db,
                                       "archive_image_sha256": archive_sha})
    browser_status = None
    error = None
    try:
        for owner in ("e", "alpha", "beta"):
            argv = PREPARED["future_backends"][owner]
            entry, proc = start(owner, argv)
            path = Path(MANIFEST["e"]["socket"] if owner == "e" else next(
                x["socket"] for x in MANIFEST["chongs"] if x["chong_id"] == owner))
            wait_socket(owner, proc, path)
        argv = PREPARED["future_backends"]["q-http"]
        entry, proc = start("q-http", argv)
        wait_port("q-http", proc, 38794)
        browser_argv = list(PREPARED["future_browser"]["runner_argv"])
        assert browser_argv[0] == "node"
        assert browser_argv[browser_argv.index("--output") + 1] == str(OUT)
        assert browser_argv[browser_argv.index("--as-known") + 1] == "85"
        save("BROWSER-COMMAND.json", {"argv": browser_argv, "runner_sha256": sha(browser_argv[1]),
                                      "chrome_sha256": sha(browser_argv[browser_argv.index("--chrome") + 1]),
                                      "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()})
        stdout = BASE / "browser-runner.stdout"
        stderr = BASE / "browser-runner.stderr"
        with stdout.open("xb") as out, stderr.open("xb") as err:
            runner = subprocess.Popen(browser_argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
        save("BROWSER-PROCESS-START.json", {"pid": runner.pid, "argv": browser_argv,
                                             "stdout": str(stdout), "stderr": str(stderr)})
        deadline = time.monotonic() + 240
        while runner.poll() is None:
            if CHROME_PID is None:
                CHROME_PID = child_chrome_pid(runner.pid)
                if CHROME_PID is not None:
                    save("CHROME-PROCESS-START.json", {"pid": CHROME_PID, "parent_runner_pid": runner.pid,
                                                       "profile": str(OUT / "profile")})
            if time.monotonic() >= deadline:
                error = "browser runner deadline 240s; no restart"
                runner.terminate()
                try:
                    runner.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    runner.kill()
                    runner.wait(timeout=10)
                break
            time.sleep(0.05)
        browser_status = runner.wait(timeout=1)
        save("BROWSER-PROCESS-FINAL.json", {"runner_pid": runner.pid, "runner_exit_code": browser_status,
                                             "runner_reaped": True, "chrome_pid_observed": CHROME_PID,
                                             "chrome_profile": str(OUT / "profile"),
                                             "browser_result_exists": (OUT / "result.json").exists(),
                                             "browser_failure_exists": (OUT / "failure.json").exists(),
                                             "deadline_error": error})
        if browser_status != 0:
            raise RuntimeError(error or f"browser runner exit={browser_status}; inspect browser-run-1/failure.json")
        if not (OUT / "result.json").exists():
            raise RuntimeError("browser runner exited zero without result.json")
    except Exception as exc:
        error = str(exc)
        save("BROWSER-ORCHESTRATOR-FAILURE.json", {"error": error, "started_utc": STARTED_AT,
                                                   "phase": "startup or Chrome CDP run",
                                                   "no_retry_same_handle": True})
    finally:
        stop_own_processes()
        after = semantic_state()
        after_db = {owner: sha(CASE / "mounts" / owner / f"{owner}.db") for owner in after}
        archive_after = {row["owner"]: sha(row["source_archive_path"]) for row in MOUNTED}
        save("BROWSER-STATE-AFTER.json", {"logical": after, "db_sha256": after_db,
                                          "archive_image_sha256": archive_after,
                                          "logical_same_as_before": after == before,
                                          "db_bytes_same_as_before": after_db == before_db,
                                          "archive_images_same_as_before": archive_after == archive_sha})
        detached = detach_only_our_copies()
        clean_only_our_sockets()
        save("BROWSER-ORCHESTRATOR-FINAL.json", {"browser_runner_exit": browser_status,
                                                 "error": error, "backend_count": 4,
                                                 "owner_logical_same": after == before,
                                                 "archive_unchanged": archive_after == archive_sha,
                                                 "copies_detached": detached,
                                                 "short_socket_cleaned": True,
                                                 "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()})
    if error or not (after == before and archive_after == archive_sha and detached):
        raise RuntimeError(error or "browser finished but logical/cleanup acceptance failed")
    print(json.dumps({"status": "BROWSER_RUNNER_OK", "runner_exit": browser_status,
                      "owner_logical_same": True, "copies_detached": True,
                      "archive_images_unchanged": True}))


if __name__ == "__main__":
    main()
