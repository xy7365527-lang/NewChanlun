# 代码审查报告

归属：#1394 后台验收客户端 /2 兼容，非 #1460 产品前端。固定基线 `976702750dfd7e89706223216ae8e0e19f2b9c87`；**唯一受评候选 `b0517f442530e0681a22f3a29d931c73f9a4b3f7`**。

范围仅四文件：`s_session/browser/{tb03a-client.js,economic.html}`、`s_session/tests/{test_tb03a_voice_client.cjs,tb03b_browser.cjs}`，736+/55-。起终 HEAD 一致；起始 staged/unstaged 产品差异为空。报告收尾时，实施者已经开始后续返修，`test_tb03a_voice_client.cjs` 出现未提交变化，本报告不审该后续变化；最终 11 个反例从固定 git show 源码加载。本轮仅写本报告与相邻 JSON，未改产品/原件/旧报告/main/root pack，不回退他人编辑。

## 概念层质询结果（Spec）

**FAIL / BLOCK。** 原 HIGH-1 至 HIGH-4 已关闭；剩余 HIGH 两项、MEDIUM 一项，全部为现有可见输入及原记录的关联，非新增政策或不可见权威验证。

### 已关闭与合法路径复核

- 原 HIGH-1：/1 作用域错误修复；非空旧 Prepare/Reserve/Commit 与旧七字段 Evidence 红绿成立。
- 原 HIGH-2：两版三个明确 Evidence 位置以及 peer image/current_image 统一绑定 discovery 的会话与化身；S epoch 仅核其规范正整数，没有假等同 Q epoch。
- 原 HIGH-3：报告的 Q/最坏量、Voice、Prepare 时间/seq、权利来源、决定/权利双向覆盖及 Abort 历史七种反例，在两版均补锁；原 cut 数量按先前已应用事实核，未无条件同最新量相等。
- 原 HIGH-4：报告的 Reserve 当前 epoch/state/seq、E grant plan/attempt/generation/单位/E epoch、请求身份、Commit captured E slot/closed 范围十一种反例，在两版均补锁；共享 grantBinding 保持两消费位置一致。
- 额外 16 种同族负控与上述 18 种，合计 68 个两版负控已读红绿向量和实现；没有只看通过计数。`association-final-green.stdout` 为 164 pass/0 fail/0 skip，SHA256 `dbeff6444c41ccc557d3317eb56411849cfb399e464986ef69319a24e0dd87bc`。
- 实际旧 Rust Abort/Closed 与 AwaitingAllocationPolicy 正例已核：Abort 保留私有锁与原 E 责任，后来 Close 不改先前捕获；不足 cap 时原 grant 为空并保持 #1349 等待。数据是两个已有固定 Rust 单项的本地 durable unit seam，不是 HTTP/browser 验收。

### HIGH-5：原财务 policy 的期限、量纲及已有支持范围未校验

位置：`tb03a-client.js:157–186`、`:204–221`。inputWitness 只核版本/Kind/集合，preparedBinding 核原账与 Prepared 的单位相等，但未与原 policy 配对；所有普通财务事件没有 policy.valid_through_ns 与原 commit_ns 的关联。

从实际 /2 HTTP 原 Prepare 切面出发，仅分别修改该 Prepare 的 witness.input_raw 中一个 policy 字段、保持计划/权利/Prepared/原事件/其他域不变，重新 canonical input_raw 并签外层 image_hash/token，**七个负控均被固定候选接受**：

| 字段 | 负控值 | 应有的现有关系 |
|---|---|---|
| valid_through_ns | `1` | Prepare 原 commit_ns=`72`；原共同界已过期 |
| currency | OTHER-CASH | 原 book/Prepared/right 为 TEST-CASH |
| money_unit | OTHER-MONEY | 原 book/Prepared 为 TEST-CASH 单位 |
| quantity_unit | OTHER-QUANTITY | 原 book/Prepared 为 TEST-UNIT |
| model | UnsupportedMarginModel | 原支持域只能 TestOnlyUnleveragedCashBuy |
| quantum | `2` | 原支持量化只能 `1` |
| allocation_policy_id | UnsupportedChooseWinner | 原支持域只能 #1349/unresolved-common-cap-allocation |

依据：已批准 §5.7 保持现有经济合同、§5.8 保持未决资金政策和普通状态语义、§5.9(5) 保持现有三阶段/知识时钟。实际原输入正本实现 `finance.rs:222–230` 拒不支持的 model/quantum/allocation_policy_id，`:807–811` 配对原账与 policy 三个量纲字段，`:832–835` 对 Import/Prepare/Reserve/Commit 的期限采用 `commit_ns ≤ valid_through_ns` 的**闭区间**；Abort/Close 明确豁免这道期限门。

影响：浏览器把过期或不属于本模型/量纲域的原输入标为普通财务阶段已核。不是要求重新认证 input_sha256 或原目录；字段及业务时刻已经在当前 image 中。

修复应保留原支持枚举及闭区间语义，在同一原输入/事件核心核期限，并将 Prepare 原 policy 量纲与实际原账配对。不要添加资金选择、排序规则、Q/S epoch 等式或新的政策。

置信度 >99%。

### HIGH-6：ImportResponsibility.original 未完整按原 baseline 公式生成

位置：`tb03a-client.js:176–177`、`:234–236`、`:338–340`。当前只核 request id=record 外层 id、original.source=baseline、original.policy=policy，以及 finance 中原记录同值覆盖；未核 original.amount/owner/责任身份与该 baseline 的原派生关系。

基于真实 /1 SQLite oracle 的 E seq=3 原 Import 切面，三个独立一致篡改均被接受：

1. finance.responsibilities[0].amount 和原 Import.record.original.amount 一致改 `0`，original.source.amount 仍是原 baseline 的 `20`。
2. 两处 original.owner 一致改 `OTHER:owner`，原源不动。
3. 原请求 responsibility_id 与记录外层 responsibility_id 一致改 `other-id`，重签 payload_hash；original.responsibility_id 及 source.responsibility_id 仍为原 baseline 身份。

依据：`finance.rs:840–850` 的明确原公式：request id=baseline.responsibility_id；original 是 `{responsibility_id: baseline.responsibility_id, owner: "E:baseline", amount: baseline.amount, source: baseline, policy: policy}`。本票明确全额责任与原回执关联义务，§5.9(5) 保持公共责任先增与原身份。

影响：已核公共责任可显示为零，或归到不属于原 E baseline 的 owner/身份，尽管公开来源原件仍声明金额 20。只需完整比较现有生成式，不需要来源目录、节点 API 或新资金模型。

置信度 >99%。

### MEDIUM-1：CloseApplicants 每次请求内没有 owner 唯一性

位置：`tb03a-client.js:178–184`。当前逐项核申请是否出现在原计划集合，但未核同一请求内 owner 唯一。

基于实际 /1 Abort/Closed oracle，将一个原 closed 项重复一次，同时同步 request.closed、record.closed 和当前 finance.closed_applicants，重签 payload_hash/image_hash/token；固定候选接受。

`finance.rs:1153–1164` 用 owners 集合拒同一次 Close 中重复 owner，直接源语义可核。应只补本次请求内唯一性；**不要求名单排序，不禁止不同历史请求的合法重复关闭**。

置信度 >99%；本项不产生退款或执行资格，但接受了原生产转换明确拒绝的关闭记录。

## 实际限定检查及可复现负控原件

本轮复用已跑的 164 项，不重复全仓、24 矩阵或 HTTP 检查。独立执行了以上负控，并最后从 `git show b0517f...:s_session/browser/tb03a-client.js` 在 vm 中加载**固定源码**，再次一次性重放 11 个反例，全部 accepted；不依赖随后可能发生的工作树改动。

相邻 JSON 保存每个负控的确切修改位置/值、固定 SHA、结果和原件路径/Hash，可据此重放：

- /2 原件：content-v3 工位 `case-2/http-actual/snapshot-current.response.json`，SHA256 `9f26648e3bbea9b0bd7eb636e5c256800cd2b8c87ba92445b27e1a73ba881384`。
- /1 Import 原件：本工位 `v1-native/oracle.json`，SHA256 `0b069fcb0b938fd847ade178b77508cee3c301c1d47fc99f8bbcc8dd5d424dc0`；各域取实际 seq=3，原 image/cut 不由 /2 改头。
- /1 Closed 原件：`association-native/oracle.json` cases["abort-closed"]，SHA256 `b8829f5ed60c4fd1dc3e52208b4edf189cf0e499d0e58562558aa539f27f06a1`；各域取最后实际 commit。

Prepare 切面构造沿既有合法独立域切面测试：B 取原 Prepared receipt.cut/原 Prepare commit_ns/原 record，history 截至原 seq，E 保持其自己的 cut。修改原输入文本时只重新 canonical 该文本；原计划等派生字段不改。Import/Close 仅同步明确同值副本及该请求 payload_hash，最后统一签 outer image_hash/token。反例均为合成负控，不冒充原生非法提交或浏览器验收。

已核：原 SCOPE 报告 SHA `f13e2f327f7514e3e74ea85c8727d09619ff5547a15dea4519b87e7bbcad306a` 未变；ASSOCIATION-ARTIFACTS 列出的全部 21 件文件摘要一致；完整补丁逐字等于固定 git diff，SHA256 `d8d80e8eec8fd342d27adb43fc512fca0d1f864ea8f3607dffb097cca666ae5d`。

## 推论、谱系与范围

完整四文件及调用上下文已经读完；本次新增原输入/配对核心仍没有完整体现同一个已批准消费者域。Hash 与副本同值不能替代生成式中的金额、单位、期限及集合约束。上述关联均由现有公开字段给出。

没有把 `.chanlun/definitions/` 的缠论结构教义改写为金融模型；CONTEXT 的重/Voice 名分、原资金未决政策和无场所资格继续有效。此前谱系查询未发现本具体问题；属 036 声明能力缺口、090 严格性原则的同构，不新增谱系、票或外部评论。

不要求重新认证原 financial input 权威：discovery 没有 input_sha256/完整来源目录。不要求重算没有 previous_root 的顶层经济 root；有前根的 peer/recorded E proof 才核原配方。不要求下载内容节点以独立证明 FinancialBasis 闭包/七字段正文绑定；不假加全局原子域切面或 S epoch=Q epoch。

## 工程层审查（Standards）

**未进入正式工程结论：概念层仍有合同矛盾。** 根据本任务“概念层发现矛盾则停止工程层”的规则，不列工程零缺陷表或 PASS。四文件周边阅读和原件摘要核对用于完整概念盘点，不冒充通过工程层。

实际 browser 尚未启动。164 项、实际 Rust unit seam、HTTP 原件和本报告都不能替代后续页面 AsKnown/Watch/全部原件按钮及真实回复/截图验收。

结论：**FAIL / BLOCK**。本轮完整剩余发现已集中，供下一次同核心整组返修；旧 HIGH-1..4 的关闭不能解除以上三个剩余发现。
