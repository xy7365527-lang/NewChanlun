# #1394 可见原输入返修（固定 a67）

候选 a67bad583ad5ed59e219c54c3ada0e70e1f4f7b3，父 b0517f442530e0681a22f3a29d931c73f9a4b3f7。HIGH5/6/MEDIUM1集中11反例与同族原输入解析一批处理，仅原两文件，原四文件总体不扩大。

- input-binding-red：24条全 Missing expected rejection，覆盖两版11项及期限commit/first-known差异。
- input-parse-red：固定git show b051，49条全红，覆盖完整可见输入shape/type/唯一性/归属/完整集合及原16MiB。
- input-final-green：256/256、零失败、零跳过。合法commit期限闭边界、三量纲/导入、Abort/Close过期豁免、合法Abort保锁/Closed/Awaiting、无排序关闭集合及不同请求同owner复用均通过。
- 两修改JS node --check及git diff --check通过；不重跑无关全仓，不新增Rust/服务/browser。

Rust input:172–423全部可见条件和reduce使用关联列于INPUT-CHECKLIST.json。冻结input_sha256及授权目录不可见，不冒充重新认证来源。S epoch不借Q epoch；不新增节点API/政策/资源配置。

/2 E3导入原件来自已有watch-from-init.response.json，SHA256=6915432369584c9f88df1e187348fc33eb9c2544558efeecbac99b6980d68a97，未改文件。/1来源仍为实际Rust durable unit seam。期限边界、/2 Close与第二Close请求为明标协议派生向量，不冒称额外原生运行。

INPUT-PATCH.diff/INPUT-FULL-PATCH.diff与原a67 SHA原样保留；最后Close.reason类型小增补另绑定9f923候选，见DELIVERY-RESULTS.md。
