# 代码审查报告

归属 #1394，既有后台验收客户端兼容 /2；非 #1460 产品前端。
固定基线 `976702750dfd7e89706223216ae8e0e19f2b9c87`；固定候选 `4f77188ebeefb422c012cc64fdbae58d186b48ff`。只审四文件 `s_session/browser/{tb03a-client.js,economic.html}`、`s_session/tests/{test_tb03a_voice_client.cjs,tb03b_browser.cjs}`。

本次集中完成固定差异的概念余项检查。两个旧报告和失败/通过原日志保留，不覆盖。本轮不修改代码、原件、main、root pack 或外部状态。

## 概念层质询结果（Spec）

**FAIL / BLOCK：剩余两组 HIGH 关联缺陷。** 以下为同族缺陷集中报告，不要求逐项拆票或增加接口。

### 已关闭的发现

1. 初版 HIGH-1：旧 /1 的 `discovery` ReferenceError 已消除；真实 Rust /1 Prepare/Reserve/Commit 的红绿日志和 85/85 合并日志已核。旧 oracle 为实际持久 SQLite 数据，仅公开包裹由 Node 签 outer image/token；不声称旧 HTTP/browser 验收。
2. HIGH-2：Evidence 可见 session_id/session_generation 现在通过同一 discovery 明确绑定。所有三个明确持久位置及递归 peer image/current_image 调用同一核心。已读 8 个一致改头负控红→绿、相关 13 pass/0 fail/0 skip；不拿 Q epoch 冒充 S epoch。两版合法非空阶段保持可读。

### HIGH-3：私有决定、原 Prepare 与历史之间缺少可见关联

位置：`tb03a-client.js:173–184`、`:208–214`、`:249–257`。

当前 `decision` 检查 Prepared 与 Prepare 记录副本相等、单个数值合法，但没有把这些副本与实际原账/原绑定/原事件关联；反向也不要求已存在 Prepare 历史继续有该决定和权利。

**实际限定负控，固定候选全部接受：**

| 一致改写内容 | 原件可见的矛盾 |
|---|---|
| B:alpha Prepared 的 fixed_q、worst_quantity 均改 `987`，finance 与原 Prepare 副本一致 | 实际 book.fixed_q=`12`；原最坏量=`6`。检查只用同一个被改写的 Prepared.fixed_q 当上界，Q 越界被展示为已核 |
| Prepared.voice.instrument 改 `OTHER.INSTRUMENT`，binding_id 保留 | 实际原 BindVoice/账簿同 binding 对应另一标的，`:178` 只比 binding_id，未核完整原绑定记录 |
| prepared_ns 改 `71` | 原 Prepare 事件 commit_ns=`72`；`:177` 只核不晚于外层 view，未核与原提交相等 |
| Prepared 的 plan.expected_book_version/book_version_before/book_version_after 改 `1/1/2`，重算对应 plan/payload Hash | 实际 Prepare 事件 seq=`3`；`:176` 只核相邻 +1，没有核 book_version_after 等于其原 Prepare seq |
| Prepared.right_source.amount 改 `987`，保留 owner/right_id | image.finance.rights 原权利 amount=`40`，但只检查伪来源金额覆盖锁，没有与实际原权利的不可变字段配对 |
| 删除 finance.decisions 与 finance.rights 的记录，数组保留，Prepare 历史不动 | `financeImage` 仍遍历并核该 Prepare Evidence，但无反向关联；这个丢失全部已发生私有锁/决定的 image 被接受 |
| 将 finance 当前决定独立复制后改为 AbortedBeforeCommit、abort_ns=`71`，原 Prepare 保持 Prepared | 无 AbortDecision 历史，且中止时间早于 Prepare；`:184` 只核 abort_ns≤view，仍接受 |

**依据与修复边界：** 已批准 §5.7 要求 Prepare 首版同一证据、实际经济 image 和原派生关系保持，§5.8 保持 Abort/Commit 原语义，§5.9(5) 保持三阶段、原身份及所有知识时钟。本次范围也明确要求原计划/全额锁/固定 Q/Voice/时钟/cut 关联。

实际生产原公式可定位：`finance.rs:761–770` 查实际非空 book 与原 Voice，`:792–814` 以实际 book 的量/Q/单位和原权利构造 Prepared，`:814` 明定 prepared_ns=提交 ns、book_version_after=该 seq；`:1115–1143` Abort 由原 Prepared 生成并写历史，保留私有锁。`BindVoice` 原记录已在完整 history 中可见。比较上述成对原件是已有字段校验，不需要内容节点或新 API。

建议将 Prepare 的身份/版本/时间、原 BindVoice、不可变 Q/单位与原权利字段，以及 finance 决定/权利与历史记录的双向覆盖核进同一核心；Abort 要有同身份、同 Prepared 的实际历史记录及匹配时间。**不得把历史 Prepared.actual_quantity 无条件同最新 book.actual_quantity 比较**：应使用其原 cut 的可见原账上下文，防止合法后续事实改变数量时误杀。固定 Q、原 Voice 和事件 seq/ns 可直接从已有不变记录关联。

置信度 >95%；这组不是字形风格或单纯多打日志问题，直接改变了“已核私有决定/责任”的显示含义。

### HIGH-4：Reserve/Commit 的原 grant 与捕获证明缺少状态、代际及计划字段关联

位置：`tb03a-client.js:135–148`、`:150–155`、`:190–200`、`:231–242`、`:254`。

通用 `proof` 只核 current_epoch 为正数、current_cut 不早于 receipt 和两个实际 image/root；E `verifyFinance` 只把 grant 的 amount/plan_hash/quantity/时间序号与 Prepared 配对。B Committed 核了部分计划字段，但 E Reserved 的同一个 grant 判断未共享这些绑定；Commit 也未确认所捕获的 E 当前 slot/申请者范围有效。

**实际限定负控，固定候选全部接受：**

| 一致改写内容 | 已有原件可见的矛盾 |
|---|---|
| Reserve 捕获 B:alpha proof.current_epoch=`2` | 原 plan.applicant_epoch=`1`，本次新授信应拒已换代申请 |
| 该 proof.current_image 当前决定改为 AbortedBeforeCommit，重算 current root | 原 Prepared 已失效，仍被 E Reserved 使用 |
| 该 proof.current_cut.commit_seq=`4`，重算 current root | 原 Prepared seq=`3`，最新版本已不等于 expected_book_version+1 |
| E 的 slot、Reserve 历史记录与 responsibility 中同 grant 的 plan_id 一致改 `other-plan` | 原 Prepared plan_id 未变，plan_hash 仍绑定原 plan，E 分支未核此 grant 字段 |
| 上述 grant.applicant_epoch 一致改 `2` | 捕获的原 plan 与 current epoch 都为 `1`，但只核该字段为正数 |
| 上述 grant.e_epoch 一致改 `2` | 原 Reserve request.payload.writer_epoch 未变，为 `1` |
| 上述 grant.units.quantity.unit 一致改 `OTHER-UNIT` | 捕获 Prepared.units 是 TEST-UNIT；E 分支未核 grant 与原 Prepared 量纲相等 |
| Prepare request.payload.decision_id 改为其他身份，重签 payload_hash | 事件记录/原计划仍是 alpha；只核 op 与 payload_hash，没有核请求业务身份与记录一致 |
| Reserve request.payload.slot_id 改为 other-slot，重签 payload_hash | 原 slot_id 未变；同样未核该业务身份配对 |
| Commit 的 grant_proof.current_image 删除当前 finance.slots，重算 current root | receipt 中原 Reserved slot 仍在，但本次当前 image 不再有该 slot，B Committed 仍通过 |
| 同 current_image 增加匹配 slot/owner/applicant_epoch/generation 的 closed_applicants，重算 current root | captured 当前范围已关闭该申请，责任还在并不能构成首次 Commit 的有效范围 |

后三类 current proof 负控均使用原 previous_root/commit_ns 和实际 image Hash 重算该 current_cut.root_hash，**不是依靠故意漏签的摘要失败或放宽节点闭包**。正例仍逐字来自原机器输出；负控不称为原生经济事实。

**依据与修复边界：** §5.7 明确原 plan、grant、receipt 与经济 proof 保持，§5.9(5) 保持三阶段与原身份/知识时钟；本票要求实际 grant/cut/量关联。

原实际 Reserve 门见 `finance.rs:965–995`：current.state=Prepared、current.prepared=original.prepared、current_epoch=plan.applicant_epoch、current seq=expected_book_version+1。grant 原公式 `:996` 的 plan_id/attempt_id/applicant_epoch/generation/units 来自同一个原 Prepared，e_epoch 来自 Reserve 的 writer_epoch。原 Commit 门 `:1043–1095` 要求所捕获的 E current_slot 等于原 Reserved slot，并拒已关闭申请者；责任保留是另一条件，不能接管范围校验。事件/receipt 原公式 `:1180–1191` 用原请求身份生成唯一收据。

建议为 E、B 两处 grant 判断共享同一个明确原 plan/Prepared/Reserve 上下文，逐项核全部已有绑定字段；Reserve 核捕获的当前 Prepared 状态/相同原件/本地版本/申请者 epoch；Commit 核 captured E current slot 与关闭范围；历史请求的 op/业务身份/plan_hash/grant_id 等和对应记录配对。不要将当前顶层 E 的后来关闭倒灌到过去 Commit：应仅校验该 Commit **原捕获的 current_image**。本报告不要求拿 discovery 的 Q epoch 校验 E/S epoch，不新增公共资金分配政策。

置信度 >95%。已换代/已中止申请者仍能在浏览器成为“已核 Reserved”，以及不属于原计划的 grant 字段被接受，均是合同关联缺口。

## 反例方法与结果

所有反例从现有固定 /2 HTTP oracle `case-2/http-actual/snapshot-current.response.json` 开始。需要 Prepared 切面时，沿已有合法独立域切面测试取各 B 的原 Prepared receipt.cut、原事件时间及原 record，裁 history 到原 seq，E 保持自己的固定 cut。不伪加全局原子性。

分别修改上述明确已有 schema 字段并保持需要相等的副本同值；计划变动重算 plan/payload Hash，current proof image 变动重算其 native current root，所有负控重签 outer image_hash/token。没有改原文件、原件或生产状态。当前阶段单个负控在约毫秒到亚秒运行，未跑已有全套测试。

实际命令输出的 probe/result 均为 accepted，覆盖表内全部案例。另一个对照将本地 commit receipt.book_version_before 改错，明确以“提交版本或先增责时序不同”拒绝，证明不是跳过整个 verifier；旧 header 同域错误的 8 个现有负控也已以专门绑定错误拒绝。

## 定义、推论与谱系

这四文件没有新增缠论结构定义；金融合同的正本是本票批准 §5.7/5.8/5.9。CONTEXT 的重/Voice 名分、风控教义和 fixed Q 不因 TestOnlyCashBuy 改写；Prepared/Reserved/Committed 仍无场所调用资格。上述问题来自可见原件配对遗漏，不主张重新裁定缠论语义或给生产代码教义发言权。

推论：单个 native Hash 公式与 image_hash 校验通过，不能推出计划/事件/状态/epoch 的关联成立；这些成对字段已经在回复中，必须以同一严格判据关联。E grant 与 B grant 是同一 grant 的两个消费位置，不能只有一侧严格绑定原计划。

检索 `.chanlun/genealogy/` 未定位本批具体缺陷的登记；与 036 声明能力缺口、090 严格性规则同构。未新建谱系/票或发布评论。

## 工程层审查（Standards）

**未进入正式结论。** 虽已读四文件周边调用以完成完整概念差异盘点，按“概念层发现矛盾则停止工程层”规则，不给工程层零缺陷或 PASS 背书。根任务须在上述关联闭合后，以新固定 SHA 局部复核并完成工程轴。

## 交付及边界

初版 FAIL 与 b2ac FAIL 原件保持不变。当前有效源码快照是 4f771；已有 85 与本次 13 项结果按适用范围复用，未将未覆盖的关联负例归入它们。

浏览器尚未运行。本报告不代表实际 AsKnown→Watch、全部原件按钮、HTTP 回复保存与截图路径验收完成；根任务应在审查通过后执行。无内容节点 API，因此仍不独立证明 FinancialBasis 节点完整闭包/七字段正文绑定；顶层缺 previous_root，不声称重算顶层经济 root。

结论：**FAIL / BLOCK（概念层两组剩余合同关联矛盾）**。已关闭 HIGH-1/HIGH-2，不以两项关闭或 85+13 项通过宣称本候选整体通过。
