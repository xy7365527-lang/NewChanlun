#!/usr/bin/env python3
"""#1394 私有只读 owner 测量；不启动 Q HTTP，不发有权限的写请求。"""
import hashlib
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import time

BASE = Path(__file__).resolve().parent / "case-1"
OUT = BASE / "owner-probe-attempt2"
OUT.mkdir(exist_ok=True)
MANIFEST_PATH = BASE / "evidence" / "manifest.json"
BINDING_PATH = BASE / "binding.json"
MANIFEST_RAW = MANIFEST_PATH.read_bytes()
MANIFEST = json.loads(MANIFEST_RAW)
BINDING = json.loads(BINDING_PATH.read_bytes())
assert hashlib.sha256(MANIFEST_RAW).hexdigest() == "8699548e817781aa1c85292e8d498803925525d4ad0b5ef0b1d6634036656ebf"
SOURCE = BINDING["query_source"]


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def semantic_state():
    result = {}
    for owner in ("e", "alpha", "beta"):
        path = BASE / "mounts" / owner / f"{owner}.db"
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        seq, root, commit_ns = conn.execute(
            "SELECT seq,root,commit_ns FROM commits ORDER BY seq DESC LIMIT 1"
        ).fetchone()
        result[owner] = {"seq": seq, "root": root, "commit_ns": commit_ns,
                         "receipts": conn.execute("SELECT count(*) FROM receipts").fetchone()[0],
                         "stage_rows": conn.execute("SELECT count(*) FROM content_staging").fetchone()[0]}
        conn.close()
    return result


PROCESSES = []


def start(owner):
    binary = BINDING["cli"]["e" if owner == "e" else "b"]["path"]
    assert hashlib.sha256(Path(binary).read_bytes()).hexdigest() == BINDING["cli"]["e" if owner == "e" else "b"]["sha256"]
    argv = [binary, "serve", "--manifest", str(MANIFEST_PATH), "--db",
            str(BASE / "mounts" / owner / f"{owner}.db")]
    if owner != "e":
        argv += ["--chong", owner]
    argv += ["--epoch", "1"]
    if owner != "e":
        argv += ["--e-epoch", "1"]
    sock = Path(MANIFEST["e"]["socket"] if owner == "e" else next(
        item["socket"] for item in MANIFEST["chongs"] if item["chong_id"] == owner))
    assert sock.parent == Path(BINDING["socket_root"])
    # The prior formally reaped server leaves only its Unix filesystem entry.
    # A new serve must bind its own inode; never accept old `exists()` as readiness.
    if sock.exists():
        assert sock.is_socket()
        sock.unlink()
    stdout_path, stderr_path = OUT / f"{owner}.stdout", OUT / f"{owner}.stderr"
    stdout, stderr = stdout_path.open("xb"), stderr_path.open("xb")
    proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
    stdout.close(); stderr.close()
    PROCESSES.append((owner, proc, argv, str(stdout_path), str(stderr_path)))
    deadline = time.monotonic() + 20
    while not sock.exists():
        if proc.poll() is not None:
            raise RuntimeError(f"{owner} serve exited {proc.returncode}: {stderr_path.read_text()}")
        if time.monotonic() >= deadline:
            raise TimeoutError(f"{owner} socket not ready")
        time.sleep(0.01)
    return sock


def send(owner, sock, label, payload):
    request = {"schema_revision": "economic-session/2", "session_id": MANIFEST["session_id"],
               "session_generation": MANIFEST["session_generation"], **SOURCE,
               "message_id": "observer-measure-" + label, "payload_hash": digest(payload),
               "causal_refs": [], "payload": payload}
    started = time.monotonic_ns()
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as stream:
        stream.settimeout(90)
        stream.connect(str(sock))
        stream.sendall(canonical(request) + b"\n")
        stream.shutdown(socket.SHUT_WR)
        parts = []
        while True:
            part = stream.recv(65536)
            if not part:
                break
            parts.append(part)
    elapsed_ms = (time.monotonic_ns() - started) / 1e6
    raw = b"".join(parts)
    assert raw.endswith(b"\n") and raw.count(b"\n") == 1
    reply = json.loads(raw[:-1])
    assert reply["payload_hash"] == digest(reply["payload"])
    path = OUT / f"{label}.reply.json"
    path.write_bytes(raw[:-1])
    return reply["payload"], {"owner": owner, "op": payload["op"], "label": label,
                              "elapsed_ms": round(elapsed_ms, 3), "reply_bytes": len(raw),
                              "kind": reply["payload"].get("kind"), "reply_path": str(path),
                              "reply_sha256": hashlib.sha256(raw[:-1]).hexdigest()}


def main():
    before = semantic_state()
    sockets = {}
    rows = []
    payloads = {}
    try:
        for owner in ("e", "alpha", "beta"):
            sockets[owner] = start(owner)
        for owner in ("e", "alpha", "beta"):
            result, row = send(owner, sockets[owner], f"view-{owner}",
                               {"op": "ReadView", "cut": None, "as_known_ns": None})
            assert result["kind"] == "EconomicView"
            payloads[f"view-{owner}"] = result
            rows.append(row)
        for owner in ("e", "alpha", "beta"):
            result, row = send(owner, sockets[owner], f"watch-all-{owner}",
                               {"op": "Watch", "after_cut": None})
            assert result["kind"] == "EconomicChanges"
            row["changes"] = len(result["changes"])
            payloads[f"watch-all-{owner}"] = result
            rows.append(row)
        for owner in ("alpha", "beta"):
            result, row = send(owner, sockets[owner], f"decision-{owner}",
                               {"op": "QueryDecision", "decision_id": owner,
                                "cut": None, "as_known_ns": None})
            assert result["kind"] == "EconomicDecision"
            rows.append(row)
        formal = json.loads((BASE / "evidence" / "observer-cli-results.json").read_bytes())
        grant_id = formal["reserve"]["record"]["grants"][0]["grant_id"]
        result, row = send("e", sockets["e"], "grant-e", {"op": "QueryGrant",
                           "grant_id": grant_id, "cut": None, "as_known_ns": None})
        assert result["kind"] == "EconomicGrant"
        rows.append(row)
        conn = sqlite3.connect(f"file:{BASE / 'mounts/e/e.db'}?mode=ro", uri=True)
        fact_key = conn.execute("SELECT k FROM facts ORDER BY k LIMIT 1").fetchone()[0]
        conn.close()
        for owner, label, payload, kind in [
            ("e", "fact-e", {"op": "QueryFact", "fact_key": fact_key}, "EconomicFact"),
            ("alpha", "allocation-alpha", {"op": "QueryAllocation", "allocation_id": "allocation-alpha"}, "EconomicAllocation"),
            ("alpha", "voice-alpha", {"op": "QueryVoice", "binding_id": "voice-alpha"}, "EconomicVoice"),
        ]:
            result, row = send(owner, sockets[owner], label, payload)
            assert result["kind"] == kind
            rows.append(row)
        denied, row = send("alpha", sockets["alpha"], "q-write-denied",
                           {"op": "PrepareDecision"})
        assert denied["kind"] == "Error" and "未获准" in denied["error"]
        rows.append(row)
        after = semantic_state()
        assert after == before, "read-only Q requests altered durable semantic state"
        views = [payloads[f"view-{o}"] for o in ("e", "alpha", "beta")]
        watches = [payloads[f"watch-all-{o}"] for o in ("e", "alpha", "beta")]
        evidence = {"schema_revision": "testonly-1394-economic-owner-measurement/1",
                    "manifest_sha256": hashlib.sha256(MANIFEST_RAW).hexdigest(),
                    "binding_sha256": hashlib.sha256(BINDING_PATH.read_bytes()).hexdigest(),
                    "before": before, "after": after, "queries": rows,
                    "max_owner_view_bytes": max(len(canonical(x)) for x in views),
                    "sum_owner_view_bytes": sum(len(canonical(x)) for x in views),
                    "max_owner_watch_bytes": max(len(canonical(x)) for x in watches),
                    "sum_owner_watch_bytes": sum(len(canonical(x)) for x in watches),
                    "max_owner_elapsed_ms": max(row["elapsed_ms"] for row in rows if row["kind"] != "Error"),
                    "max_owner_changes": max(row.get("changes", 0) for row in rows),
                    "q_write_denied": denied["error"],
                    "scope": "Q principal through formal E/B Unix serve; no Python economic HTTP invoked"}
        (OUT / "measurement.json").write_bytes(canonical(evidence))
        print(json.dumps({k: evidence[k] for k in (
            "sum_owner_view_bytes", "sum_owner_watch_bytes", "max_owner_elapsed_ms",
            "max_owner_changes", "q_write_denied")}, ensure_ascii=False))
    finally:
        process_rows = []
        for owner, proc, argv, stdout, stderr in reversed(PROCESSES):
            was_running = proc.poll() is None
            if was_running:
                proc.terminate()
            try:
                status = proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                status = proc.wait(timeout=10)
            process_rows.append({"owner": owner, "pid": proc.pid, "argv": argv,
                                 "stdout": stdout, "stderr": stderr,
                                 "was_running": was_running, "exit_code": status,
                                 "reaped": True})
        (OUT / "processes.json").write_bytes(canonical({"processes": process_rows}))


if __name__ == "__main__":
    main()
