#!/usr/bin/env python3
"""#1394 新 auth/new HFS 的官方经济 HTTP 实测；仅操作冻结只读路由。"""
import hashlib
import http.client
import json
from pathlib import Path
import socket
import sqlite3
import subprocess
import time

ROOT = Path("/Users/silencehan/Projects/NewChanlun-1394-content-v3")
BASE = Path(__file__).resolve().parent
CASE = BASE / "case-2"
OUT = CASE / "http-actual"
OUT.mkdir(exist_ok=False)
MANIFEST_PATH = CASE / "evidence/manifest.json"
MANIFEST = json.loads(MANIFEST_PATH.read_bytes())
BINDING = json.loads((CASE / "binding.json").read_bytes())
RATIONALE = json.loads((CASE / "resource-rationale.json").read_bytes())
PLAN = json.loads((CASE / "http-plan.json").read_bytes())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert file_sha(MANIFEST_PATH) == RATIONALE["case_manifest_sha256"]
assert file_sha(CASE / "economic-config.json") == RATIONALE["economic_config_sha256"]
assert file_sha(CASE / "http-plan.json") == "37ebd1e1eba885e96b838de72e2655c1a89cd9d4e05436a4c5cba7ed969327c6"
assert file_sha(CASE / "evidence/s.sqlite") == "08c9d59456cc3eeede74650fad8597ad2743b5acbdf198c7b0b43b64537ec4ad"
for name, expected in RATIONALE["python_files"].items():
    assert file_sha(ROOT / "s_session" / name) == expected["sha256"]
assert file_sha(BASE / "q19-resource-frozen.json") == RATIONALE["q19_resource_sha256"]
assert BINDING["query_source"]["producer_id"] == "Q:issue1394-economic-observer"
assert len(MANIFEST["authorized_sources"]) == 2

PROCESSES = []


def semantic_state():
    state = {}
    for owner in ("e", "alpha", "beta"):
        path = CASE / "mounts" / owner / f"{owner}.db"
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        seq, root, commit_ns = conn.execute(
            "SELECT seq,root,commit_ns FROM commits ORDER BY seq DESC LIMIT 1").fetchone()
        state[owner] = {"seq": seq, "root": root, "commit_ns": commit_ns,
                        "receipts": conn.execute("SELECT count(*) FROM receipts").fetchone()[0],
                        "stage_rows": conn.execute("SELECT count(*) FROM content_staging").fetchone()[0]}
        conn.close()
    return state


def start_owners():
    for owner in ("e", "alpha", "beta"):
        binary = BINDING["cli"]["e" if owner == "e" else "b"]["path"]
        assert file_sha(binary) == BINDING["cli"]["e" if owner == "e" else "b"]["sha256"]
        socket_path = Path(MANIFEST["e"]["socket"] if owner == "e" else next(
            route["socket"] for route in MANIFEST["chongs"] if route["chong_id"] == owner))
        assert socket_path.parent == Path(BINDING["socket_root"])
        if socket_path.exists():
            assert socket_path.is_socket()
            socket_path.unlink()  # this case's already-reaped prior serve left the pathname
        argv = [binary, "serve", "--manifest", str(MANIFEST_PATH), "--db",
                str(CASE / "mounts" / owner / f"{owner}.db")]
        if owner != "e":
            argv += ["--chong", owner]
        argv += ["--epoch", "1"]
        if owner != "e":
            argv += ["--e-epoch", "1"]
        start_process(owner, argv)
        until = time.monotonic() + 20
        while not socket_path.exists():
            if PROCESSES[-1][1].poll() is not None:
                raise RuntimeError(f"{owner} serve exited before socket")
            if time.monotonic() >= until:
                raise TimeoutError(f"{owner} Unix socket deadline")
            time.sleep(0.01)


def start_process(label, argv):
    stdout = OUT / f"{label}.stdout"
    stderr = OUT / f"{label}.stderr"
    with stdout.open("xb") as out, stderr.open("xb") as err:
        proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
    PROCESSES.append((label, proc, argv, stdout, stderr))


def start_q():
    argv = RATIONALE["http_argv"]
    assert argv[1] == str(ROOT / "s_session/s_readonly_server.py")
    assert "--economic-config" in argv and argv[argv.index("--economic-config") + 1] == str(CASE / "economic-config.json")
    port = int(argv[argv.index("--port") + 1])
    start_process("q-http", argv)
    until = time.monotonic() + 20
    while True:
        if PROCESSES[-1][1].poll() is not None:
            raise RuntimeError("Q HTTP exited before port became available")
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                return port
        except OSError:
            if time.monotonic() >= until:
                raise TimeoutError("Q HTTP port deadline")
            time.sleep(0.02)


def response_identity(request, reply):
    header = {"schema_revision", "session_id", "session_generation", "source_namespace",
              "source_epoch", "producer_id", "producer_epoch", "message_id", "payload_hash",
              "causal_refs", "payload"}
    assert set(reply) == header
    assert reply["schema_revision"] == "economic-session/2"
    assert reply["session_id"] == request["session_id"] == MANIFEST["session_id"]
    assert reply["session_generation"] == request["session_generation"] == "1"
    assert reply["source_namespace"] == "economic-observe/replies"
    assert reply["producer_id"] == "Q:" + MANIFEST["session_id"]
    assert reply["source_epoch"] == reply["producer_epoch"] == "1"
    assert reply["payload_hash"] == digest(reply["payload"])
    cause = {k: request[k] for k in ("source_namespace", "source_epoch", "message_id", "payload_hash")}
    assert reply["causal_refs"] == [cause]
    assert reply["message_id"] == "reply-" + digest([
        request["source_namespace"], request["source_epoch"], request["message_id"],
        reply["payload_hash"]])


def post(port, label, route, request):
    assert route in ("/api/economic/snapshot", "/api/economic/watch", "/api/economic/original")
    assert request["payload_hash"] == digest(request["payload"])
    body = canonical(request)
    req_path = OUT / f"{label}.request.json"
    req_path.write_bytes(body)
    started = time.monotonic_ns()
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=45)
    try:
        conn.request("POST", route, body=body, headers={"Content-Type": "application/json",
                                                     "Content-Length": str(len(body))})
        response = conn.getresponse()
        status = response.status
        raw = response.read()
    finally:
        conn.close()
    elapsed_ms = (time.monotonic_ns() - started) / 1e6
    response_path = OUT / f"{label}.response.json"
    response_path.write_bytes(raw)
    reply = json.loads(raw)
    observation = {"label": label, "route": route, "http_status": status,
                   "elapsed_ms": round(elapsed_ms, 3), "request_bytes": len(body),
                   "response_bytes": len(raw), "request_path": str(req_path),
                   "request_sha256": file_sha(req_path), "response_path": str(response_path),
                   "response_sha256": file_sha(response_path)}
    assert status == 200, f"{label}: status={status}, body={reply}"
    response_identity(request, reply)
    return reply["payload"], observation


def as_request(label):
    return PLAN["requests"][label]["request"]


def check_finance_snapshot(snapshot):
    assert snapshot["kind"] == "EconomicSnapshot"
    assert snapshot["completeness"] == "CompleteVector"
    assert snapshot["manifest_hash"] == RATIONALE["case_manifest_sha256"]
    assert snapshot["session_id"] == MANIFEST["session_id"]
    assert snapshot["session_generation"] == "1"
    assert set(snapshot["domains"]) == {"E", "B:alpha", "B:beta"}
    for domain, view in snapshot["domains"].items():
        assert view["status"] == "Available"
        assert view["cut"] == PLAN["expected_latest_cuts"][domain]
        assert view["image_hash"] == digest(view["image"])
        assert view["image"]["finance"]["schema_revision"] == "tb03b-finance/2"
    responsibilities = snapshot["domains"]["E"]["image"]["finance"]["responsibilities"]
    assert sum(int(r["amount"]) for r in responsibilities) == 90
    for owner, locked in (("alpha", "30"), ("beta", "40")):
        decisions = snapshot["domains"]["B:" + owner]["image"]["finance"]["decisions"]
        selected = next(d for d in decisions if d["decision_id"] == owner)
        assert selected["state"] == "Committed"
        assert selected["prepared"]["locked_amount"] == locked
        assert selected["execution_eligibility"] == "None"


def main():
    observations = []
    before = semantic_state()
    try:
        start_owners()
        port = start_q()
        current, row = post(port, "snapshot-current", "/api/economic/snapshot", as_request("snapshot-current"))
        observations.append(row)
        check_finance_snapshot(current)
        assert current["mode"] == "Current"

        replay_request = dict(as_request("snapshot-current"))
        replay_payload = {"op": "snapshot", "cuts": None, "as_known_ns": None,
                          "snapshot_token": current["snapshot_token"]}
        replay_request["message_id"] = "http-snapshot-token-replay"
        replay_request["payload"] = replay_payload
        replay_request["payload_hash"] = digest(replay_payload)
        replay, row = post(port, "snapshot-token-replay", "/api/economic/snapshot", replay_request)
        observations.append(row)
        assert replay == current

        fixed, row = post(port, "snapshot-fixed-latest", "/api/economic/snapshot",
                          as_request("snapshot-fixed-latest"))
        observations.append(row)
        check_finance_snapshot(fixed)
        assert fixed["mode"] == "AsKnown"
        for domain in current["domains"]:
            assert fixed["domains"][domain] == current["domains"][domain]

        watch, row = post(port, "watch-from-init", "/api/economic/watch", as_request("watch-from-init"))
        observations.append(row)
        assert watch["kind"] == "EconomicWatch"
        assert watch["manifest_hash"] == RATIONALE["case_manifest_sha256"]
        for domain, response in watch["domains"].items():
            assert response["status"] == "Available"
            assert response["base_cut"] == PLAN["initial_cuts_for_nonempty_watch"][domain]
            assert response["next_cut"] == PLAN["expected_latest_cuts"][domain]
            assert len(response["changes"]) == 4
            assert response["changes"][-1]["image"] == current["domains"][domain]["image"]

        formal = json.loads((CASE / "evidence/observer-cli-results.json").read_bytes())
        for label, native in (("original-decision-alpha", formal["query_decisions"][0]),
                              ("original-grant-e", formal["query_grants"][0])):
            original, row = post(port, label, "/api/economic/original", as_request(label))
            observations.append(row)
            assert original["kind"] == "EconomicOriginal"
            assert original["cuts"] == PLAN["expected_latest_cuts"]
            assert original["original"] == native, f"{label}: not identical to native Unix original"

        after = semantic_state()
        assert after == before, "Q HTTP changed owner semantic state"

        # No economic write is accepted or sent by this HTTP probe.
        result = {"schema_revision": "testonly-1394-economic-http-result/1", "status": "PASS",
                  "case_manifest_sha256": RATIONALE["case_manifest_sha256"],
                  "economic_config_sha256": RATIONALE["economic_config_sha256"],
                  "q19_resource_sha256": RATIONALE["q19_resource_sha256"],
                  "observations": observations, "snapshot_token": current["snapshot_token"],
                  "three_latest_cuts": PLAN["expected_latest_cuts"],
                  "finance_revision": "tb03b-finance/2", "responsibility_total": "90",
                  "locked_amounts": {"alpha": "30", "beta": "40"},
                  "execution_eligibility": "None", "originals_match_native_unix": True,
                  "structure_api_called": False, "browser_asset_called": False,
                  "owner_semantic_before": before, "owner_semantic_after": after}
        (OUT / "http-result.json").write_bytes(canonical(result))
        print(json.dumps({"status": "PASS", "routes": len(observations),
                          "max_elapsed_ms": max(x["elapsed_ms"] for x in observations)}, ensure_ascii=False))
    finally:
        rows = []
        for label, proc, argv, stdout, stderr in reversed(PROCESSES):
            was_running = proc.poll() is None
            if was_running:
                proc.terminate()
            try:
                status = proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                status = proc.wait(timeout=10)
            rows.append({"label": label, "pid": proc.pid, "argv": argv,
                         "stdout": str(stdout), "stderr": str(stderr),
                         "was_running": was_running, "exit_code": status, "reaped": True})
        (OUT / "processes.json").write_bytes(canonical({"processes": rows}))


if __name__ == "__main__":
    main()
