# #1394 当前 HEAD 财务小域重验准备

本文件是 #1394 工作草稿。根工位批准了 Python/Popen 复用方案，本工位仅准备脚本、配置和原件清单，等待统一 freeze、构建、独立 Python 复核与根明确执行消息。当前未运行 cargo、SQLite、S/E/B/Q 服务、hdiutil 或浏览器。

工作树为 `/Users/silencehan/.codex/worktrees/issue1394-audit-prefix/NewChanlun`。准备开始时 HEAD 为 `7c3e87e965210efc06d89856b5d72154ea5c86be`；S 审计 worker 的补丁完成后，以根冻结清单为最终来源，不沿用这个 SHA 充作最终产品。

## 已准备原件

`INPUT-REUSE-INVENTORY.json` 记录 28 个 bytes-copy 原件的原路径、bytes、SHA 与 mtime。它们包括旧完整 `FAULT-private.rs`、`FORMAL-CLI-private.rs`、HTTP runner、manifest、finance-input、reader resources、Q19、Q 的八项经济资源、具名 S primary/空 WAL/SHM、1307 个已发布 cache、两 authority 和各五类 artifact。未 SQLite-open 任何封存 DB。

finance-input 的原 SHA 为 `56189b58672b1b458fc2ec933d117c3cf1721bedc031bd86c11742ea27400566`，reader resources 的原 SHA 为 `f8e9e3ca737b3c232c0c62bf748f524badeed575646c53338dca35b1804953dc`。1307 个 cache 的 F 摘要已由独立 Python 按 `SHA256(D || tag || U64BE(len) || body)` 全部核对，digest 无重复。这是缓存原件复核，不是生产 resource 验收。

唯一复用 policy 为 `TestOnly-cash-cap-100` / `TestOnlyUnleveragedCashBuy` / `TestOnly-no-leverage-no-venue`。cap100、baseline20、私权40/50、固定 Q12/20，alpha `2×14+2=30`、beta `3×12+4=40`，总责任90。#1349 未决的公共分配政策没有被替换；没有场所权限。

## 根构建与输入格式

三个正式 bin 都在 `rust/Cargo.toml` 要求 `s_session`。只需要根的统一构建：

```sh
cargo build --offline --release --features s_session --bin s_structure_session --bin e_economic_session --bin b_chong_session
```

不启用 `s_capture_native_testonly`、`s_allocation_sqlite_testonly`、`s_allocation_json_testonly` 或任何 cfg(test) fixture；此处没有执行构建。

根将实际 path/SHA、最终 frozen_head、冻结 source 清单的 path/SHA、当前 Python/JS消费者源 SHA、当前 runner 独评 receipt 写入 `config/ARTIFACTS.json`，格式见 `config/ARTIFACTS.example.json`。例子含占位值，不能执行。consumer_source_sha256 应覆盖经济 HTTP/Q、共同 socket、readonly server、现有浏览器三个资产；路径以本工作树为根。runner 独评必须绑定最终脚本 SHA，并明写覆盖 `authority_path_rebinding`。

## 单次 runner 顺序与 oracle

`scripts/run_current.py` 没有默认执行入口；需要 `--execute --artifacts <根清单>`。每个原件 SHA、三 bin SHA、当前 git HEAD 与消费者 SHA 必须一致，旧原件再次复核，然后才创建 `run-1`。同一 run-1 不重用，不在首次失败后补发请求。

1. 为三个 owner 各新建本任务 24MiB UDRW HFS+ image，并核固定容量25124864B、三个不同 st_dev、空目录、实际短 canonical Unix 路径。只接受本任务全新 image 的 create 和该 image 登记的 device 的普通 detach，绝不格式化用户磁盘。
2. 将 S primary/sidecars bytes-copy 到本任务 S-carrier，再绑定根的当前 S bin。新 manifest 在任何 E/B init 前落盘，保留 policy、finance-input hash、时钟、原授权及全部资源值。唯一改动为新 carrier/socket/binary 的路径和 SHA、authority 路径封包与新 manifest 身份；不改 ID 语义。旧 bundle/review 原 bytes/SHA 保留，`AUTHORITY-PATH-REBINDING-EVIDENCE.json` 独核新旧仅 artifact 路径和 review 的 bundle hash 变化，scope 保持 unit trust fixture only。本轮独评覆盖重绑定算法与差异锁，旧独评没有审过新 bytes。
3. 当前普通 `financial-basis-ref` 用旧具名命令读取本任务 S 副本，保持30秒。比对旧 S session/generation/epoch/commit12 和 basis/snapshot refs。此 reader 是普通 `state::audit(tx)`，不会取得 Native/全资源/9011 资格。
4. 用当前非 test E/B 正式 init 建新 owner。唯一直接 SQL 前置是每 owner 精确预装旧1307条 content_nodes，并逐 F 核对；插入后经济 seq0、messages0、receipts0 必须不变。禁止手造 Prepared、grant、Committed。
5. 三个正式 serve 顺序完成 Capture alpha/beta、Apply alpha/beta、BindVoice alpha/beta、ImportResponsibility existing20。每条请求和实际回执保留。authority/cache 的受控 TestOnly 性质保留，不因用了正式入口变成真实场所。
6. 复用完整旧正式 oracle：Prepare alpha/beta→E Reserve→Commit alpha/beta，锁30/40、最坏量6/18、grant30/40、责任90、Committed/None、原 Book 不变、具名 Commit 重复幂等、三 ReadView、两 QueryDecision、两 QueryGrant、三 Watch。逐独立重算请求/reply Hash、replyID/因果、grant ID的原REV公式以及每个owner从genesis到latest的全部经济root链；不硬比旧root。
7. 当前 Q 八项经济资源与原 Q19 不变。HTTP只bind127.0.0.1，实际 current/token replay/fixed latest/as-known85/Watch/两decision及两grant Original。要求三域 CompleteVector、85双Prepared/无local_commit_receipt/责任20、Watch精确三域与逐条四个独立DB历史image/cut相同、四Original完整对象与正式Unix结果相同，逻辑状态前后不变。HTTP使用同一30秒绝对期限、独立dup transport可shutdown、显式response.close，覆盖HTTP/1.0把response从conn解耦的路径。
8. 带 `--browser-handoff` 时写 `run-1/BROWSER-READY.json`，含真实 `/economic.html` URL、四个仍存活 Popen、控件、HTTP paths、原件 ID、旧完整 oracle 的本轮值。runner持续poll并等待根 `run-1/BROWSER-DONE.json`，默认240秒只约束交棒时间，不延长任何产品限额。PASS后核本轮owner完整逻辑和primary DB SHA未变；FAIL/超时首停、同句柄cleanup。
9. 正式服务全部停止并 wait/reap 后，只将本任务 S 副本/binary改名离线。三个鲜正式 recover进程必须epoch2、stage0、seq/root/image/receipts/messages/published不变、manifest字节不变。载体创建/attach前先登记仅本任务全新image意图；attach超时或plist解析失败时仍由hdiutil info的精确image路径定位实际自有device并普通detach。每个卷独立回收并累计失败，finally始终落FINAL-RESULT；未附着只记录确认，回收未完记FAILED_CLEANUP。每个实际Popen记录PID/reap，封存来源SHA重核。

E/B response60000ms、reader request45000ms、S默认30秒和Q单RPC10000ms/操作30000ms均为旧具名值，不扩容、不延期。其它已通过故障矩阵不重跑。

超时或失去可信回包的首例记 `UNKNOWN_OUTCOME`，明确先前财务请求可能已提交，不重发。Committed 表示本地实际提交和保留锁额，不能解释为 Received 或任何外效资格。

## 浏览器根工位验收

根使用实际浏览器工具打开 BROWSER-READY 中的URL。页面会自动读取当前，可再次按 `#current`；`#known-at`填85、`#as-known`按时间回看；`#watch`回current；四个 `button[data-original-kind][data-original-domain][data-original-id]`取得两decision/两grant。`#status`不得出现error或部分域，current显示双Committed，85显示双Prepared，固定Q12/20和实际持量4/15一直不变。

根须保留实际HTTP、DOM/截图、四Original与本轮 FORMAL-UNIX-RESULT 的比对和独立Hash证据，再写以下标记。FAIL也必须写，runner据此收回句柄，不把Ready或等候当作完成。

```json
{"status":"PASS","manifest_sha256":"<BROWSER-READY中的SHA>","evidence":"<根实际浏览器证据路径>"}
```

## 当前真实待办

等待S审计补丁完成后的统一源码freeze与三个非test bin、根ARTIFACTS清单及独立Python复核；尚未执行新reader、金融/HTTP/浏览器或recover。没有修改生产源码、旧scratch、goal、issue/comments，没有#1460/六Destination/9011/全资源闭包验收主张。
