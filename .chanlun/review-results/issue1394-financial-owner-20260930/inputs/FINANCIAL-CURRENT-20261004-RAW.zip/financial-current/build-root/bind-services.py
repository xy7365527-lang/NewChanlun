import hashlib,json,pathlib,shlex,shutil,subprocess
root=pathlib.Path.cwd();out=pathlib.Path(__file__).resolve().parent
names={'s_structure_session','e_economic_session','b_chong_session'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
man=json.loads((out/'SOURCE.json').read_text());listed={r['path']:r['sha256'] for r in man['entries']}
assert all(sha(root/p)==h for p,h in listed.items())
rows=[json.loads(l) for l in (out/'BUILD-services.jsonl').read_text().splitlines()]
assert rows[-1]['reason']=='build-finished' and rows[-1]['success']
arts=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('package_id','').startswith('path+file:')]
selected=[r for r in arts if r.get('executable') and r['target']['name'] in names and r['target']['kind']==['bin']]
assert len(selected)==3 and {r['target']['name'] for r in selected}==names
assert all(not r['profile']['test'] and set(r['features'])=={'default','s_session'} for r in selected)
fixed=out/'fixed-source';fixed.mkdir(exist_ok=False)
for p in listed:
 dst=fixed/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/p,dst);assert sha(dst)==listed[p]
bins={};deps=[];uncovered=[];libraries=[]
for art in arts:
 for filename in art['filenames']:
  src=pathlib.Path(filename)
  if src.name.startswith('libnewchan_rust') and src.suffix in ('.rlib','.dylib'):
   libraries.append({'path':str(src),'sha256':sha(src)})
  if src.name.startswith('libnewchan_rust') and src.suffix=='.rlib': dep=src.with_name(src.stem[3:]+'.d')
  elif art.get('executable')==filename and art['target']['name'] in names: dep=src.with_suffix('.d')
  else:continue
  assert dep.exists(),str(dep)
  text=dep.read_text();copy=out/('dep-'+dep.name);copy.write_text(text)
  records=[]
  for name in shlex.split(text.splitlines()[0].split(': ',1)[1]):
   srcfile=pathlib.Path(name)
   if not srcfile.is_absolute():srcfile=root/'rust'/srcfile
   srcfile=srcfile.resolve()
   if not srcfile.is_file():continue
   if srcfile.is_relative_to(root):
    rel=str(srcfile.relative_to(root));actual=sha(srcfile)
    if rel not in listed:uncovered.append(rel)
    else:assert actual==listed[rel]
    records.append({'path':rel,'sha256':actual})
   else:records.append({'path':str(srcfile),'sha256':sha(srcfile)})
  deps.append({'original_path':str(dep),'copy':str(copy),'sha256':sha(dep),'source_files':records,'env_dep_lines':[l for l in text.splitlines() if l.startswith('# env-dep:')]})
assert libraries and not uncovered,uncovered
for art in selected:
 name=art['target']['name'];dst=out/name;shutil.copy2(art['executable'],dst);dst.chmod(0o555)
 bins[name]={'path':str(dst),'sha256':sha(dst),'compiler_profile_test':art['profile']['test'],'compiler_features':art['features'],'compiler_executable':art['executable']}
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_manifest':str(out/'SOURCE.json'),'source_manifest_sha256':sha(out/'SOURCE.json'),'source_aggregate_sha256':man['aggregate_sha256'],'fixed_source':str(fixed),'build_log_sha256':sha(out/'BUILD-services.jsonl'),'profile':{'release_opt_level':3,'release_debug':0,'incremental':0,'jobs':2},'binaries':bins,'dep_info':deps,'library_artifacts':libraries,'testonly_features':[]}
assert result['head']==man['head']
(out/'BINARY-BINDINGS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'head':result['head'],'source':man['aggregate_sha256'],'binaries':bins},indent=2))
