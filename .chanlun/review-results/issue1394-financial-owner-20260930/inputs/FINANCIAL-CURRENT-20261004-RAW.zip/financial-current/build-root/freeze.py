import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path.cwd()
files=set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','rust','s_session'],text=True).splitlines())
files.add('rust/src/bin/s_session_v3/request_audit.rs')
files.add('rust/src/bin/s_session_v2/staged_nodes.rs')
entries=[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest(),'bytes':(root/p).stat().st_size} for p in sorted(files) if (root/p).is_file()]
body={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'entries':entries,'scope':'all git-enumerated rust and s_session files plus new request_audit module; postbuild dep-info separately checked'}
body['aggregate_sha256']=hashlib.sha256(json.dumps(entries,sort_keys=True,separators=(',',':')).encode()).hexdigest()
pathlib.Path(sys.argv[1]).write_text(json.dumps(body,indent=2))
print(body['aggregate_sha256'],len(entries))
