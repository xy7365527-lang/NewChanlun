# run-3 入口与 EOF 核对

这是执行前只读核对。当前三个 binary、Rust/消费者源码、原28份输入、policy/时钟/资源值没有改动。本次仅修独立 S 预核的缺失 stdin；未运行 S/E/B/Q、SQLite、hdiutil 或新请求。

| 脚本调用 | 当前入口契约与旧 runner 对照 | 结论 |
|---|---|---|
| S `financial-basis-ref` | `rust/src/bin/s_session_v3/financial_reader.rs:68` exact argv 为 binary、command、`--protocol-revision s-session/3`、`--db`，合计6项；`:117–155` 先开本任务普通 DB 的 readonly连接，再 `stdin.read_to_end`、strict JSON、读事务与普通 audit，最后stdout JSON+LF。旧 small 的 argv 没显示 stdin，但 `INPUTS.request_sha256` 指定 `request-empty.json` | run2漏了151B stdin而读到空EOF。R3复制原151B/SHA，`PIPE`+同Popen communicate送原bytes并关闭EOF；保持30秒绝对期限，不增加flags或资源值，不调用封存DB |
| E `init` / `recover` | `rust/src/economic_session/service.rs:745–778` 只认 `--manifest/--db/--chong/--epoch/--e-epoch`；E禁止chong。init/recover不读stdin，在共用独占锁内处理DB，stdout单JSON。runner E argv仅command、manifest、db，stdin DEVNULL | 匹配；全新manifest先冻结，init不得覆盖既有库；recover只处理本run已停止/reap的owner，S只将本任务副本离线 |
| B `init` / `recover` | 同入口，B要求 `--chong alpha/beta` 并核manifest路由。本脚本这两种command不传epoch/e-epoch，参数与当前入口相符，stdin不参与 | 匹配；原writer换代由正式recover完成，未手写epoch |
| 三个 `serve` | 当前入口`:779–829`要求epoch；B额外要求e-epoch。旧 `FORMAL-CLI-private.rs:34–89` E/B同flags、stdin `Stdio::null()`。runner E epoch1、B epoch1/e-epoch1，manifest中的真实短socket与owner路由一致 | 匹配；serve进程stdin DEVNULL正确，请求通过Unix socket，不能把CLI stdin当请求通道 |
| Unix帧 | 当前 `rust/src/session_transport.rs:390–442` 一直读到真实EOF，再要求单LF终止、无内嵌LF。旧正式runner`:153–181` canonical JSON+LF、SHUT_WR、读到EOF。现runner `send`沿同协议，并按冻结frame界限读回单LF | 匹配；所有写/查询共用同一完整信封与EOF发送器，不把LF或超时当EOF |
| Capture/Apply/BindVoice/baseline | `service.rs:89` Capture exact5字段、`:300` Apply exact4字段；voice开局/authority按既有模板；`finance.rs:512–535` ImportResponsibility exact op/responsibility_id/writer_epoch。旧 `FAULT-private.rs` V2Fixture前置的原doc、binding与message/clock逐项沿用。R3没有更改这些payload | 字段、身份、原语及收据kind匹配。Authority/cache仍TestOnly，不能推成真实场所或形式化gamma |
| Prepare/Reserve/Commit | `finance.rs:512–535` exact字段分别为 op/decision_id/plan_hash/writer_epoch；op/slot_id/request_set_hash/writer_epoch；op/decision_id/plan_hash/grant_id/writer_epoch。grant来自实际Reserve回执。本脚本与旧正式runner的五写顺序、原message/clock、Commit幂等原ID保持 | 匹配；不手造grant/Committed，不在未知/超时后重发 |
| Unix只读 | `service.rs:588–593` ReadView exact op/cut/as_known_ns、Watch exact op/after_cut；`finance.rs:1651–1670` QueryDecision/QueryGrant exact对应object ID加cut/as_known_ns。本脚本全部通过同一单LF+EOF发送器 | 匹配；JSON公头/Hash/因果、每owner SQL独立根与实际Unix/HTTP同值锁保留 |
| Q HTTP服务 argv | `s_session/s_readonly_server.py:1190–1196` 接受db、port、browser、host、resource-config、producer-epoch、economic-config，均由当前run冻结路径提供。旧 `run_economic_http_case2.py` 与当前这些flags相同；默认stdin无人读取 | 匹配；只bind127.0.0.1，Q19及八项经济资源原样 |
| HTTP请求 | `s_session/economic_http.py:14–35` exact公共头/Hash/会话；`:69`起读取Content-Length，并且路径仅snapshot/watch/original。本脚本提供唯一Content-Length与canonical bytes，无Transfer-Encoding；snapshot payload exact四字段，token不混cuts/as_known，固定cut不混85。HTTP请求无需Unix LF/SHUT_WR，其EOF由HTTP/1.0正文/显式response.close处理 | 匹配；独立dup transport保持绝对30秒shutdown，Timer与response/dup/conn均收回。四Original及Watch全历史oracle没有改变 |
| hdiutil | run2已实际证明 `24576k/HFS+/-type UDIF` 默认布局，三个capacity25124864，不同st_dev并普通detach0。R3未变这些argv或硬容量门 | 不重跑前置单独探针，不新增layout猜测 |

原151B请求为 `s-financial-query/1`，原session/generation1/epoch1、`object_ids=[]`，其原SHA `96fe6fb67f6804833304d66e39ff30157ac3e537b5e247296ebfb0e3dd7f6162` 与旧 INPUTS 完全相同。`repair-r3/STDIN-INPUT-BINDING.json`记录bytes-copy来源及新副本；原28输入清单不动。

R3 helper只在指定stdin时选PIPE；全部原E/B/Q/hdiutil调用继续DEVNULL。communicate使用启动前算出的同一30秒截止剩余量，超时对同一Popen kill、communicate回收并关闭pipe，不再次发请求。实际EOF闭合及stdin bytes/SHA进入该child的最终记录。无stdin的其它command路径及所有oracle保持。

本审查未发现其它 argv/stdin/EOF 的纯编排缺口，但尚未实际执行run-3。当前reader走普通 `state::audit(tx)`；本次仍不提供Native、9011、全资源或完整经营init资格。run1工具参数失败和run2缺stdin失败原件均保留。
