#!/usr/bin/env python3
"""具名小域重验。必须由根明确授权并提供统一 freeze 后的三 binary。"""
import argparse
import copy
import hashlib
import http.client
import json
import os
from pathlib import Path
import plistlib
import re
import socket
import stat
import subprocess
import sys
import threading
import time
import traceback
from typing import Any

BASE = Path(__file__).resolve().parents[1]
ROOT = BASE.parents[1]
INPUT = BASE / 'inputs'
OWNERS = ('e', 'alpha', 'beta')
DOMAINS = {'e': 'E', 'alpha': 'B:alpha', 'beta': 'B:beta'}
HEADER = {'schema_revision', 'session_id', 'session_generation', 'source_namespace',
          'source_epoch', 'producer_id', 'producer_epoch', 'message_id', 'payload_hash',
          'causal_refs', 'payload'}


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode()


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1 << 20), b''):
            h.update(part)
    return h.hexdigest()


def load(path: str | Path) -> Any:
    return json.loads(Path(path).read_bytes())


def save(path: str | Path, value: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(canonical(value))


def byte_copy(source: str | Path, target: str | Path) -> None:
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    with Path(source).open('rb') as src, target.open('xb') as dst:
        for part in iter(lambda: src.read(1 << 20), b''):
            dst.write(part)
    assert sha(source) == sha(target)


class Run:
    def __init__(self, artifacts: dict[str, Any], run_name: str) -> None:
        self.artifacts = artifacts
        assert re.fullmatch(r'run-[1-9][0-9]*', run_name)
        self.out = BASE / run_name
        # check_artifacts已原子创建此新目录并回收唯一preflight进程；不接续旧run。
        assert self.out.is_dir()
        assert {p.name for p in self.out.iterdir()} == {'PREFLIGHT-GIT-HEAD.json'}
        self.processes = []
        self.mounts = []
        self.trace = []
        self.unix = []
        self.http = []
        self.manifest = None
        self.unknown_outcome = False
        self.histories = {}
        self.socket_root = Path('/private/tmp') / ('nc1394-fc-' + str(os.getpid()))
        self.socket_root.mkdir(exist_ok=False)
        self.manifest_path = self.out / 'manifest.json'
        self.db = {}

    def start(self, label: str, argv: list[str], pipe_stdin: bool = False) -> tuple[subprocess.Popen[bytes], dict[str, Any]]:
        paths = [self.out / (label + suffix) for suffix in ('.stdout', '.stderr')]
        with paths[0].open('xb') as out, paths[1].open('xb') as err:
            proc = subprocess.Popen(argv, stdin=subprocess.PIPE if pipe_stdin else subprocess.DEVNULL, stdout=out, stderr=err,
                                    cwd=ROOT)
        row = {'label': label, 'pid': proc.pid, 'argv': list(argv),
               'stdout': str(paths[0]), 'stderr': str(paths[1]), 'started_ns': time.time_ns(),
               'reaped': False, 'stdin_kind': 'PIPE' if pipe_stdin else 'DEVNULL'}
        self.processes.append((row, proc))
        save(self.out / ('PROCESS-START-' + label + '.json'), row)
        return proc, row

    def command(self, label: str, argv: list[str], timeout: float = 30,
                stdin_bytes: bytes | None = None) -> bytes:
        deadline = time.monotonic() + timeout
        proc, row = self.start(label, argv, pipe_stdin=stdin_bytes is not None)
        try:
            if stdin_bytes is None:
                code = proc.wait(timeout=timeout)
            else:
                row['stdin_bytes'] = len(stdin_bytes)
                row['stdin_sha256'] = hashlib.sha256(stdin_bytes).hexdigest()
                row['absolute_timeout_seconds'] = timeout
                # 同一Popen送完整原件并关闭stdin取得EOF，不另启动child或续期限。
                proc.communicate(input=stdin_bytes, timeout=max(0, deadline - time.monotonic()))
                row['stdin_eof_closed'] = proc.stdin is not None and proc.stdin.closed
                code = proc.returncode
        except subprocess.TimeoutExpired:
            self.unknown_outcome = True
            proc.kill()
            if stdin_bytes is None:
                proc.wait(timeout=10)
            else:
                proc.communicate(timeout=10)  # kill后仍由同一Popen收回并关闭stdin pipe。
            row.update(reaped=True, exit_code=proc.returncode, failure='first timeout; no retry')
            raise
        row.update(reaped=True, exit_code=code)
        raw = Path(row['stdout']).read_bytes()
        if stdin_bytes is not None and time.monotonic() >= deadline:
            self.unknown_outcome = True
            row['failure'] = 'absolute stdin-command deadline reached; no retry'
            raise TimeoutError(row['failure'])
        assert code == 0, (label, code, row['stderr'])
        return raw

    def stop_services(self) -> list[dict[str, str]]:
        errors = []
        for row, proc in reversed(self.processes):
            if row['reaped']:
                continue
            try:
                running = proc.poll() is None
                if running:
                    proc.terminate()
                try:
                    code = proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    code = proc.wait(timeout=10)
                    row['forced_kill_after_term'] = True
                row.update(reaped=True, exit_code=code, was_running_at_stop=running,
                           stop_ns=time.time_ns())
            except Exception:
                row['cleanup_error'] = traceback.format_exc()
                errors.append({'label': row['label'], 'error': row['cleanup_error']})
        return errors

    def provision(self) -> None:
        # 全新专属 image，绝不接受 device 或已有 image 作 create 参数。
        for owner in OWNERS:
            image = self.out / ('carrier-' + owner + '.dmg')
            mount = self.out / 'mounts' / owner
            assert not image.exists()
            mount.mkdir(parents=True, exist_ok=False)
            row = {'owner': owner, 'image': str(image), 'mount': str(mount),
                   'device': None, 'dev': None, 'capacity': None,
                   'fresh_image_absent_before_create': True, 'registered_before_attach': True}
            self.mounts.append(row)
            save(self.out / ('CARRIER-INTENT-' + owner + '.json'), row)
            self.command('create-' + owner,
                         ['hdiutil', 'create', '-size', '24576k', '-fs', 'HFS+',
                          '-type', 'UDIF', '-volname', 'nc1394-fc-' + owner, str(image)])
            raw = self.command('attach-' + owner,
                               ['hdiutil', 'attach', '-plist', '-nobrowse',
                                '-mountpoint', str(mount), str(image)])
            info = plistlib.loads(raw)
            target = next(e for e in info['system-entities'] if e.get('mount-point') == str(mount))
            row.update(device=target['dev-entry'], dev=mount.stat().st_dev,
                       capacity=os.statvfs(mount).f_blocks * os.statvfs(mount).f_frsize)
            assert mount.resolve() == mount
            assert row['capacity'] == 25124864, ('named carrier capacity changed', row)
            assert len({m['dev'] for m in self.mounts}) == len(self.mounts)
            assert {p.name for p in mount.iterdir()} <= {'.fseventsd'}
            self.db[owner] = mount / (owner + '.db')
        save(self.out / 'CARRIERS.json', self.mounts)

    def freeze(self) -> None:
        manifest = load(INPUT / 'old-manifest.json')
        m = copy.deepcopy(manifest)
        # 源库原件只复制；真正调用 reader 的 path 是新本任务 runtime 副本。
        s_dir = self.out / 'S-carrier'
        s_dir.mkdir()
        for p in (INPUT / 'sealed-S').iterdir():
            byte_copy(p, s_dir / p.name)
        s_bin = s_dir / 's_structure_session'
        byte_copy(self.artifacts['binaries']['s_structure_session']['path'], s_bin)
        s_bin.chmod(0o555)
        m['finance']['structure']['binary'] = str(s_bin)
        m['finance']['structure']['binary_sha256'] = sha(s_bin)
        m['finance']['structure']['db'] = str(s_dir / 's.sqlite')
        m['finance']['input_path'] = str(INPUT / 'finance-input.json')
        assert m['finance']['input_sha256'] == sha(INPUT / 'finance-input.json')
        # 原resource文件带终止LF，bytes/SHA逐字保留；manifest内对象按原对象比较，
        # 不把文件LF误当资源字段，不改任何numeric-text值。
        assert sha(INPUT / 'reader-resources.json') == 'f8e9e3ca737b3c232c0c62bf748f524badeed575646c53338dca35b1804953dc'
        assert m['finance']['structure']['reader_resources'] == load(INPUT / 'reader-resources.json')
        assert canonical(m['finance']['structure']['reader_resources']) == canonical(manifest['finance']['structure']['reader_resources'])
        for owner in OWNERS:
            route = m['e'] if owner == 'e' else next(x for x in m['chongs'] if x['chong_id'] == owner)
            route['db'] = str(self.db[owner])
            route['socket'] = str(self.socket_root / (owner + '.sock'))
            assert len(str(Path(route['socket']).resolve()).encode()) < 104
        m['test_only_fault']['marker_path'] = str(self.out / 'fault-marker.json')
        # 原artifact逐字复制；只有authority载体的路径与相应封包hash更新。
        rebindings = []
        for authority in m['voice_binding']['authorities']:
            owner = authority['authority_id']
            old_bundle_path = INPUT / 'authorities' / Path(authority['bundle_path']).name
            old_review_path = INPUT / 'authorities' / Path(authority['verification_path']).name
            old_bundle, old_review = load(old_bundle_path), load(old_review_path)
            bundle, review = copy.deepcopy(old_bundle), copy.deepcopy(old_review)
            changed_paths = []
            for artifact in bundle['artifacts']:
                before_path = artifact['path']
                artifact['path'] = str(INPUT / 'authorities' / Path(artifact['path']).name)
                changed_paths.append({'before': before_path, 'after': artifact['path']})
                assert sha(artifact['path']) == artifact['sha256']
            bundle_path = self.out / 'authorities' / (owner + '-authority.json')
            save(bundle_path, bundle)
            review['artifacts'] = bundle['artifacts']
            review['bundle_sha256'] = sha(bundle_path)
            review_path = self.out / 'authorities' / (owner + '-unit-review.json')
            save(review_path, review)
            expected_bundle = copy.deepcopy(old_bundle)
            expected_review = copy.deepcopy(old_review)
            for artifact in expected_bundle['artifacts']:
                artifact['path'] = str(INPUT / 'authorities' / Path(artifact['path']).name)
            for artifact in expected_review['artifacts']:
                artifact['path'] = str(INPUT / 'authorities' / Path(artifact['path']).name)
            expected_review['bundle_sha256'] = sha(bundle_path)
            assert bundle == expected_bundle and review == expected_review
            assert review['scope'] == old_review['scope'] == 'unit trust fixture only; no independent acceptance'
            rebindings.append({'owner': owner, 'old_bundle_path': str(old_bundle_path),
                'old_bundle_sha256': sha(old_bundle_path), 'old_review_path': str(old_review_path),
                'old_review_sha256': sha(old_review_path), 'new_bundle_path': str(bundle_path),
                'new_bundle_sha256': sha(bundle_path), 'new_review_path': str(review_path),
                'new_review_sha256': sha(review_path), 'changed_artifact_paths': changed_paths,
                'only_allowed_delta': ['artifacts[].path', 'review.bundle_sha256'],
                'all_other_fields_equal': True, 'old_independent_review_covers_new_bytes': False,
                'current_runner_independent_review': self.artifacts['runner_independent_review']})
            authority.update(bundle_path=str(bundle_path), bundle_sha256=sha(bundle_path),
                             verification_path=str(review_path), verification_sha256=sha(review_path))
        assert m['clock'] == manifest['clock']
        assert m['resources'] == manifest['resources']
        assert m['authorized_sources'] == manifest['authorized_sources']
        save(self.manifest_path, m)
        save(self.out / 'AUTHORITY-PATH-REBINDING-EVIDENCE.json', rebindings)
        self.manifest = m
        self.manifest_sha = sha(self.manifest_path)
        q = load(INPUT / 'old-economic-config.json')
        q['manifest'] = str(self.manifest_path)
        q['manifest_hash'] = digest(m)
        save(self.out / 'economic-config.json', q)
        save(self.out / 'FREEZE-BEFORE-INIT.json',
             {'manifest_path': str(self.manifest_path), 'manifest_sha256': self.manifest_sha,
              'artifacts': self.artifacts, 'finance_input_sha256': sha(INPUT / 'finance-input.json'),
              'reader_resources_sha256': sha(INPUT / 'reader-resources.json'),
              'clock_hash': digest(m['clock']), 'resources_hash': digest(m['resources']),
              'testonly_prefix': '精确旧1307 cache及受控authority；不是真实场所/形式化gamma',
              'all_owner_db_absent': all(not p.exists() for p in self.db.values())})
        assert all(not p.exists() for p in self.db.values())

    def owner_argv(self, owner: str, command: str) -> list[str]:
        binary = 'e_economic_session' if owner == 'e' else 'b_chong_session'
        entry = self.artifacts['binaries'][binary]
        assert sha(entry['path']) == entry['sha256']
        argv = [entry['path'], command, '--manifest', str(self.manifest_path),
                '--db', str(self.db[owner])]
        if owner != 'e':
            argv += ['--chong', owner]
        if command == 'serve':
            argv += ['--epoch', '1']
            if owner != 'e':
                argv += ['--e-epoch', '1']
        return argv

    def s_basis_preflight(self) -> None:
        structure = self.manifest['finance']['structure']
        request_path = BASE / 'repair-r3/request-empty.json'
        request = request_path.read_bytes()
        assert hashlib.sha256(request).hexdigest() == '96fe6fb67f6804833304d66e39ff30157ac3e537b5e247296ebfb0e3dd7f6162'
        assert hashlib.sha256(request).hexdigest() == load(INPUT / 'old-S-INPUTS.json')['request_sha256']
        # 复用旧small INPUTS已具名CLI命令，30s保持；只读本任务S副本。
        value = json.loads(self.command('S-current-financial-basis-ref',
            [structure['binary'], 'financial-basis-ref', '--protocol-revision', 's-session/3',
             '--db', structure['db']], timeout=30, stdin_bytes=request))
        old = load(INPUT / 'old-S-INPUTS.json')
        assert value['kind'] == 'FinancialBasisRef'
        assert value['session_id'] == old['session_id'] and value['session_generation'] == '1'
        assert value['writer_epoch'] == '1' and value['commit_ns'] == '12'
        assert value['basis_ref'] == old['basis_ref'] and value['snapshot_ref'] == old['snapshot_ref']
        save(self.out / 'S-CURRENT-BASIS-PREFLIGHT.json',
             {'response': value, 'binary_sha256': sha(structure['binary']),
              'scope': '当前普通state::audit(tx) financial reader；不是Native capture/全资源/9011',
              'only_own_db': structure['db'], 'default_30s_not_extended': True})

    def owned_connection(self, owner: str) -> Any:
        import sqlite3
        path = self.db[owner]
        assert path.parent == self.out / 'mounts' / owner
        assert path.parent.stat().st_dev == next(m['dev'] for m in self.mounts if m['owner'] == owner)
        return sqlite3.connect(path)

    def independent_state(self) -> dict[str, Any]:
        result = {}
        for owner in OWNERS:
            conn = self.owned_connection(owner)
            try:
                conn.execute('PRAGMA query_only=ON')
                rows = conn.execute('SELECT seq,prev_root,root,commit_ns,image FROM commits ORDER BY seq').fetchall()
                previous = ''
                history = []
                for expected_seq, (seq, prev, root, ns, encoded) in enumerate(rows):
                    assert seq == expected_seq
                    assert prev == previous
                    image = json.loads(encoded)
                    expect = digest({'domain_id': DOMAINS[owner],
                                     'session_id': self.manifest['session_id'],
                                     'session_generation': '1', 'commit_seq': str(seq),
                                     'previous_root': prev, 'commit_ns': ns, 'image_hash': digest(image)})
                    assert root == expect, (owner, seq, 'independent economic root')
                    history.append({'cut': {'domain_id': DOMAINS[owner], 'commit_seq': str(seq),
                                           'root_hash': root}, 'commit_ns': ns,
                                    'image': image, 'image_hash': digest(image)})
                    previous = root
                self.histories[owner] = history
                meta = dict(conn.execute('SELECT k,v FROM meta'))
                assert meta['manifest_hash'] == digest(self.manifest)
                latest = rows[-1]
                result[owner] = {'seq': latest[0], 'root': latest[2], 'commit_ns': latest[3],
                                 'image': json.loads(latest[4]), 'writer_epoch': meta['writer_epoch'],
                                 'receipts': conn.execute('SELECT count(*) FROM receipts').fetchone()[0],
                                 'messages': conn.execute('SELECT count(*) FROM messages').fetchone()[0],
                                 'staging': conn.execute('SELECT count(*) FROM content_staging').fetchone()[0],
                                 'published': conn.execute('SELECT count(*) FROM content_nodes').fetchone()[0],
                                 'all_commit_roots_recomputed': len(rows),
                                 'independent_history_cuts': [r['cut'] for r in history]}
            finally:
                conn.close()
        return result

    def init_and_cache(self) -> None:
        cache = load(INPUT / 'published-cache.json')
        assert len(cache['nodes']) == 1307
        for owner in OWNERS:
            value = json.loads(self.command('init-' + owner, self.owner_argv(owner, 'init')))
            assert value['kind'] == 'Initialized' and value['writer_epoch'] == '1'
            save(self.out / ('INIT-' + owner + '.json'), value)
            conn = self.owned_connection(owner)
            try:
                assert conn.execute('SELECT count(*) FROM content_nodes').fetchone()[0] == 0
                conn.execute('PRAGMA synchronous=FULL')
                conn.execute('PRAGMA fullfsync=ON')
                with conn:
                    for n in cache['nodes']:
                        body = bytes.fromhex(n['body'])
                        framed = b'NewChanlun/SContent/1\x00' + bytes([n['tag']]) + len(body).to_bytes(8, 'big') + body
                        assert hashlib.sha256(framed).hexdigest() == n['digest']
                        conn.execute('INSERT INTO content_nodes(digest,tag,body) VALUES(?,?,?)',
                                     (bytes.fromhex(n['digest']), n['tag'], body))
                conn.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchall()
                assert conn.execute('SELECT count(*) FROM content_nodes').fetchone()[0] == 1307
                # 只插缓存表；economic seq、receipts/messages 保持正式 genesis。
                assert conn.execute('SELECT max(seq) FROM commits').fetchone()[0] == 0
                assert conn.execute('SELECT count(*) FROM receipts').fetchone()[0] == 0
                assert conn.execute('SELECT count(*) FROM messages').fetchone()[0] == 0
            finally:
                conn.close()
        save(self.out / 'TESTONLY-CACHE-PREFIX.json',
             {'cache_sha256': sha(INPUT / 'published-cache.json'), 'nodes_per_owner': 1307,
              'only_sql_insert_target': 'content_nodes', 'economic_state_writes': False,
              'same_rows_as_old_v2fixture': True, 'independent_frame_checks': 3909})
        self.initial = self.independent_state()
        save(self.out / 'INITIAL-STATE.json', self.initial)

    def start_owners(self) -> None:
        for owner in OWNERS:
            sock = self.socket_root / (owner + '.sock')
            assert not sock.exists(), 'fresh socket only'
            proc, row = self.start('serve-' + owner, self.owner_argv(owner, 'serve'))
            end = time.monotonic() + 20
            while not sock.exists():
                assert proc.poll() is None, (owner, 'first startup failure')
                assert time.monotonic() < end, (owner, 'first readiness timeout')
                time.sleep(0.01)
            assert stat.S_ISSOCK(sock.stat().st_mode)
            row['ready'] = {'path': str(sock), 'inode': sock.stat().st_ino}

    def envelope(self, message: str, payload: dict[str, Any], source: dict[str, str] | None = None) -> dict[str, Any]:
        source = source or {'source_namespace': 'test', 'source_epoch': 'one',
                            'producer_id': 'unit', 'producer_epoch': '1'}
        return {'schema_revision': 'economic-session/2', 'session_id': self.manifest['session_id'],
                'session_generation': '1', **source, 'message_id': message,
                'payload_hash': digest(payload), 'causal_refs': [], 'payload': payload}

    def check_identity(self, request: dict[str, Any], reply: dict[str, Any], namespace: str, producer: str, epoch: str = '1') -> None:
        assert set(reply) == HEADER
        assert reply['schema_revision'] == request['schema_revision'] == 'economic-session/2'
        assert reply['session_id'] == request['session_id'] == self.manifest['session_id']
        assert reply['session_generation'] == request['session_generation'] == '1'
        assert reply['source_namespace'] == namespace and reply['producer_id'] == producer
        assert reply['source_epoch'] == reply['producer_epoch'] == epoch
        assert reply['payload_hash'] == digest(reply['payload'])
        assert reply['causal_refs'] == [{k: request[k] for k in
            ('source_namespace', 'source_epoch', 'message_id', 'payload_hash')}]
        assert reply['message_id'] == 'reply-' + digest([
            request['source_namespace'], request['source_epoch'], request['message_id'], reply['payload_hash']])

    def send(self, owner: str, label: str, request: dict[str, Any], kind: str) -> dict[str, Any]:
        assert request['payload_hash'] == digest(request['payload'])
        raw_request = canonical(request) + b'\n'
        limit = int(self.manifest['resources']['max_frame_bytes'])
        assert len(raw_request) <= limit
        req_path = self.out / 'unix' / (label + '.request.json')
        save(req_path, request)
        started = time.monotonic_ns()
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as stream:
                deadline = time.monotonic() + int(self.manifest['resources']['response_timeout_ms']) / 1000
                stream.settimeout(max(0.001, deadline - time.monotonic()))
                stream.connect(str(self.socket_root / (owner + '.sock')))
                stream.sendall(raw_request)
                stream.shutdown(socket.SHUT_WR)
                parts, total = [], 0
                while True:
                    stream.settimeout(max(0.001, deadline - time.monotonic()))
                    assert time.monotonic() < deadline, 'absolute Unix consumer deadline; no retry'
                    part = stream.recv(min(65536, limit + 1 - total))
                    if not part:
                        break
                    parts.append(part)
                    total += len(part)
                    assert total <= limit
            raw = b''.join(parts)
            path = self.out / 'unix' / (label + '.response.raw')
            with path.open('xb') as f:
                f.write(raw)
            assert raw.endswith(b'\n') and raw.count(b'\n') == 1
            reply = json.loads(raw[:-1])
            self.check_identity(request, reply, 'economic-session/replies',
                                DOMAINS[owner] + ':' + self.manifest['session_id'])
            self.unix.append({'label': label, 'owner': owner, 'elapsed_ms': (time.monotonic_ns()-started)/1e6,
                              'request': str(req_path), 'reply': str(path), 'reply_sha256': sha(path)})
            assert reply['payload']['kind'] == kind, (label, reply['payload'])
            return reply['payload']
        except Exception:
            self.unknown_outcome = True
            save(self.out / (label + '-FIRST-FAILURE.json'),
                 {'label': label, 'request_path': str(req_path), 'no_retry': True,
                  'operation_outcome': 'Unknown; may have committed before reply loss',
                  'error': traceback.format_exc()})
            raise

    def prefix(self) -> None:
        receipts = []
        for owner in ('alpha', 'beta'):
            bundle = load(self.out / 'authorities' / (owner + '-authority.json'))
            raw_doc = load(INPUT / 'authorities' / (owner + '-opening_raw.json'))
            binding = bundle['bindings'][0]
            request = self.envelope('capture-' + owner, {'op': 'CaptureExternal',
                'raw_utf8': canonical(raw_doc).decode(), 'json_pointer': '/events/0',
                'token': 'token-' + owner, 'source_event_time': None})
            captured = self.send('e', 'capture-' + owner, request, 'Recorded')
            assert captured['fact_key'] == binding['opening_source']['fact_key']
            assert captured['fact_hash'] == binding['opening_source']['fact_hash']
            receipts.append(captured)
            applied = self.send(owner, 'apply-' + owner, self.envelope('apply-' + owner,
                {'op': 'ApplyAllocation', 'fact_key': captured['fact_key'],
                 'allocation_id': 'allocation-' + owner, 'expected_fact_hash': captured['fact_hash']}), 'Applied')
            receipts.append(applied)
            payload = {'op': 'BindVoice', 'binding_id': 'voice-' + owner, 'evidence_id': owner,
                       'carrier_ref': binding['carrier_ref'], 'gamma_ref': binding['gamma_ref'],
                       'parent_voice_id': None, 'sigma': 'Long', 'n': '0',
                       'opening_basis': {'fact_key': captured['fact_key'],
                           'expected_fact_hash': captured['fact_hash'], 'allocation_id': 'allocation-' + owner}}
            receipts.append(self.send(owner, 'bind-' + owner,
                                      self.envelope('bind-' + owner, payload), 'VoiceBound'))
        receipts.append(self.send('e', 'baseline-existing20',
            self.envelope('ImportResponsibility-existing20', {'op': 'ImportResponsibility',
                'writer_epoch': '1', 'responsibility_id': 'existing20'}), 'ResponsibilityImportedReceipt'))
        state = self.independent_state()
        self.prefix_state = state
        assert sum(int(r['amount']) for r in state['e']['image']['finance']['responsibilities']) == 20
        for owner in ('alpha', 'beta'):
            assert any(x['binding_id'] == 'voice-' + owner
                       for x in state[owner]['image']['book']['voice']['records'])
        save(self.out / 'PREFIX-RECEIPTS.json', {'receipts': receipts,
            'scope': '正式init/serve实际步骤；cache和authority仍明确TestOnly，非真实场所'})

    def financial(self) -> None:
        data = load(INPUT / 'finance-input.json')
        plans = {p['decision_id']: p for p in data['plans']}
        requests, prepared, committed = {}, [], []
        for owner, locked, worst in [('alpha', '30', '6'), ('beta', '40', '18')]:
            requests['prepare-' + owner] = self.envelope('PrepareDecision-' + owner,
                {'op': 'PrepareDecision', 'decision_id': owner, 'plan_hash': digest(plans[owner]), 'writer_epoch': '1'})
            receipt = self.send(owner, 'prepare-' + owner, requests['prepare-' + owner], 'PreparedReceipt')
            assert receipt['record']['prepared']['locked_amount'] == locked
            assert receipt['record']['prepared']['worst_quantity'] == worst
            assert receipt['record']['prepared']['plan_hash'] == digest(plans[owner])
            evidence = receipt['record']['structure_evidence']
            assert evidence['kind'] == 'FinancialBasisEvidence' and evidence['commit_ns'] == '12'
            assert evidence['basis_ref'] == load(INPUT / 'old-S-INPUTS.json')['basis_ref']
            assert evidence['session_id'] == self.manifest['session_id']
            prepared.append(receipt)
        requests['reserve'] = self.envelope('Reserve-slot', {'op': 'Reserve', 'writer_epoch': '1',
            'slot_id': 'slot', 'request_set_hash': digest(data['slots'][0]['applicants'])})
        reserve = self.send('e', 'reserve', requests['reserve'], 'ReserveReceipt')
        assert reserve['record']['retained_total'] == '90'
        grants = reserve['record']['grants']
        assert len(grants) == 2 and [g['amount'] for g in grants] == ['30', '40']
        for g in grants:
            owner = g['decision_id']
            # 旧 grant 身份公式的 REV 仍 /1；这是原已裁边界，禁改为 /2。
            assert g['grant_id'] == digest(['tb03b-finance/1', self.manifest['session_id'],
                '1', 'slot', owner, digest(plans[owner])])
            assert g['owner'] == DOMAINS[owner] and g['execution_eligibility'] == 'None'
            assert g['policy'] == data['policy'] and g['plan_hash'] == digest(plans[owner])
            requests['commit-' + owner] = self.envelope('CommitDecision-' + owner,
                {'op': 'CommitDecision', 'decision_id': owner, 'plan_hash': digest(plans[owner]),
                 'writer_epoch': '1', 'grant_id': g['grant_id']})
            receipt = self.send(owner, 'commit-' + owner, requests['commit-' + owner], 'LocalCommitReceipt')
            assert receipt['record']['state'] == 'Committed'
            assert receipt['record']['execution_eligibility'] == 'None'
            committed.append(receipt)
        # 仅明确具名的重复幂等验收；超时/失败不触发任何重发。
        for owner, original in zip(('alpha', 'beta'), committed):
            duplicate = self.send(owner, 'idempotent-commit-' + owner,
                                  requests['commit-' + owner], 'LocalCommitReceipt')
            assert duplicate == original
        views, decisions, grant_queries, watches = [], [], [], []
        for owner in OWNERS:
            views.append(self.send(owner, 'formal-read-' + owner,
                self.envelope('formal-read-' + owner, {'op': 'ReadView', 'cut': None, 'as_known_ns': None}), 'EconomicView'))
        assert sum(int(r['amount']) for r in views[0]['image']['finance']['responsibilities']) == 90
        for owner, locked, qty, q in [('alpha', '30', '4', '12'), ('beta', '40', '15', '20')]:
            view = views[OWNERS.index(owner)]
            d = view['image']['finance']['decisions'][0]
            assert d['state'] == 'Committed' and d['prepared']['locked_amount'] == locked
            assert d['execution_eligibility'] == 'None'
            assert view['image']['book']['actual_quantity'] == qty and view['image']['book']['fixed_q'] == q
            assert view['image']['book'] == self.prefix_state[owner]['image']['book']
            decision = self.send(owner, 'formal-decision-' + owner,
                self.envelope('formal-decision-' + owner, {'op': 'QueryDecision', 'decision_id': owner,
                    'cut': None, 'as_known_ns': None}), 'EconomicDecision')
            assert decision['decision']['state'] == 'Committed'
            assert committed[('alpha', 'beta').index(owner)] in decision['receipts']
            decisions.append(decision)
        for grant in grants:
            gid = grant['grant_id']
            gq = self.send('e', 'formal-grant-' + grant['decision_id'],
                self.envelope('formal-grant-' + gid, {'op': 'QueryGrant', 'grant_id': gid,
                    'cut': None, 'as_known_ns': None}), 'EconomicGrant')
            assert gq['grant'] == grant and gq['receipt'] == reserve
            grant_queries.append(gq)
        for owner, view in zip(OWNERS, views):
            watch = self.send(owner, 'formal-watch-' + owner,
                self.envelope('formal-watch-' + owner, {'op': 'Watch', 'after_cut': None}), 'EconomicChanges')
            assert watch['cut'] == view['cut']
            assert watch['changes'][-1]['image'] == view['image']
            watches.append(watch)
        assert not (self.out / 'fault-marker.json').exists()
        self.formal = {'prepare': prepared, 'reserve': reserve, 'commit': committed,
                       'read_views': views, 'query_decisions': decisions,
                       'query_grants': grant_queries, 'watches': watches}
        save(self.out / 'FORMAL-UNIX-RESULT.json', self.formal)
        self.final_before_q = self.independent_state()
        for owner, row in self.final_before_q.items():
            assert row['seq'] == 4
            view = views[OWNERS.index(owner)]
            assert view['cut'] == self.histories[owner][-1]['cut']
            assert view['image'] == row['image'] and view['image_hash'] == digest(row['image'])
            assert view['commit_ns'] == row['commit_ns']
            assert watches[OWNERS.index(owner)]['changes'] == self.histories[owner]
        save(self.out / 'PRE-Q-STATE.json', self.final_before_q)

    def start_q(self, port: int) -> None:
        argv = [sys.executable, str(ROOT / 's_session/s_readonly_server.py'), '--db',
                self.manifest['finance']['structure']['db'], '--host', '127.0.0.1', '--port', str(port),
                '--browser', str(ROOT / 's_session/browser/economic.html'), '--resource-config',
                str(INPUT / 'q19-resource-frozen.json'), '--producer-epoch', '1',
                '--economic-config', str(self.out / 'economic-config.json')]
        proc, row = self.start('q-http', argv)
        end = time.monotonic() + 20
        while True:
            assert proc.poll() is None, 'first Q startup failure'
            try:
                with socket.create_connection(('127.0.0.1', port), timeout=0.2):
                    break
            except OSError:
                assert time.monotonic() < end, 'first Q readiness timeout'
                time.sleep(0.02)
        row['ready'] = {'host': '127.0.0.1', 'port': port, 'kind': 'TCP accepts'}
        self.port = port

    def post(self, label: str, route: str, payload: dict[str, Any]) -> dict[str, Any]:
        source = {'source_namespace': 'testonly.economic-http-consumer', 'source_epoch': '1',
                  'producer_id': '1394-http-observer-test', 'producer_epoch': '1'}
        request = self.envelope('http-' + label, payload, source)
        save(self.out / 'http' / (label + '.request.json'), request)
        conn = http.client.HTTPConnection('127.0.0.1', self.port, timeout=30)
        started = time.monotonic_ns()
        deadline = time.monotonic() + 30
        timed_out = threading.Event()
        # HTTP/1.0 getresponse会令conn.sock=None；保留独立dup传输句柄，
        # shutdown作用于同一TCP连接，正文fp即便已与HTTPConnection解耦仍会被中断。
        transport: list[socket.socket | None] = [None]
        response: http.client.HTTPResponse | None = None
        def expire() -> None:
            timed_out.set()
            self.unknown_outcome = True
            live_socket = transport[0] if transport[0] is not None else conn.sock
            if live_socket is not None:
                try:
                    live_socket.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
            conn.close()
        watchdog = threading.Timer(max(0, deadline - time.monotonic()), expire)
        watchdog.start()
        try:
            conn.timeout = max(0.001, deadline - time.monotonic())
            conn.connect()
            if timed_out.is_set() or time.monotonic() >= deadline:
                raise TimeoutError('absolute HTTP consumer connect deadline30s; no retry')
            assert conn.sock is not None
            transport[0] = conn.sock.dup()
            body = canonical(request)
            conn.request('POST', route, body=body, headers={'Content-Type': 'application/json',
                                                         'Content-Length': str(len(body))})
            response = conn.getresponse()
            raw = response.read(2097153)
        except Exception as exc:
            if timed_out.is_set() or time.monotonic() >= deadline:
                self.unknown_outcome = True
                raise TimeoutError('absolute HTTP consumer deadline30s; transport interrupted; no retry') from exc
            raise
        finally:
            watchdog.cancel()
            watchdog.join()
            try:
                if response is not None:
                    response.close()
            finally:
                if transport[0] is not None:
                    transport[0].close()
                conn.close()
        if timed_out.is_set() or time.monotonic() >= deadline:
            self.unknown_outcome = True
            raise TimeoutError('absolute HTTP consumer deadline 30s; no retry')
        path = self.out / 'http' / (label + '.response.raw')
        with path.open('xb') as stream:
            stream.write(raw)
        row = {'label': label, 'route': route, 'status': response.status,
               'elapsed_ms': (time.monotonic_ns()-started)/1e6, 'reply_bytes': len(raw),
               'path': str(path), 'sha256': sha(path)}
        self.http.append(row)
        assert response.status == 200 and len(raw) <= 2097152, row
        reply = json.loads(raw)
        self.check_identity(request, reply, 'economic-observe/replies',
                            'Q:' + self.manifest['session_id'])
        return reply['payload']

    def check_snapshot(self, value: dict[str, Any], prepared: bool = False) -> None:
        assert value['kind'] == 'EconomicSnapshot' and value['completeness'] == 'CompleteVector'
        assert value['manifest_hash'] == digest(self.manifest)
        assert value['session_id'] == self.manifest['session_id'] and value['session_generation'] == '1'
        assert set(value['domains']) == set(DOMAINS.values())
        without_token = {k: v for k, v in value.items() if k != 'snapshot_token'}
        assert value['snapshot_token'] == 'economic-snapshot-' + digest(without_token)
        for owner, domain in DOMAINS.items():
            view = value['domains'][domain]
            assert view['status'] == 'Available' and view['image_hash'] == digest(view['image'])
            assert view['image']['finance']['schema_revision'] == 'tb03b-finance/2'
            if not prepared:
                assert view['cut'] == self.formal['read_views'][OWNERS.index(owner)]['cut']
                assert view['image'] == self.formal['read_views'][OWNERS.index(owner)]['image']
                assert view['cut'] == self.histories[owner][-1]['cut']
                assert view['image'] == self.final_before_q[owner]['image']
            elif owner != 'e':
                decision = view['image']['finance']['decisions'][0]
                assert decision['state'] == 'Prepared' and decision['local_commit_receipt'] is None
                assert view['commit_ns'] in ('72', '82') and view['cut']['commit_seq'] == '3'
                assert view['cut'] == self.histories[owner][3]['cut']
                assert view['image'] == self.histories[owner][3]['image']
        e_view = value['domains']['E']
        assert sum(int(r['amount']) for r in e_view['image']['finance']['responsibilities']) == (20 if prepared else 90)
        if prepared:
            assert e_view['commit_ns'] == '65' and e_view['cut']['commit_seq'] == '3'
            assert e_view['cut'] == self.histories['e'][3]['cut']
            assert e_view['image'] == self.histories['e'][3]['image']

    def http_oracles(self) -> None:
        self.current = self.post('snapshot-current', '/api/economic/snapshot',
            {'op': 'snapshot', 'cuts': None, 'as_known_ns': None, 'snapshot_token': None})
        self.check_snapshot(self.current)
        assert self.current['mode'] == 'Current'
        replay = self.post('snapshot-token-replay', '/api/economic/snapshot',
            {'op': 'snapshot', 'cuts': None, 'as_known_ns': None, 'snapshot_token': self.current['snapshot_token']})
        assert replay == self.current
        self.current_cuts = {k: v['cut'] for k, v in self.current['domains'].items()}
        fixed = self.post('snapshot-fixed-latest', '/api/economic/snapshot',
            {'op': 'snapshot', 'cuts': self.current_cuts, 'as_known_ns': None, 'snapshot_token': None})
        self.check_snapshot(fixed)
        assert fixed['mode'] == 'AsKnown'
        for domain in self.current['domains']:
            assert fixed['domains'][domain] == self.current['domains'][domain]
        historical = self.post('snapshot-as-known85', '/api/economic/snapshot',
            {'op': 'snapshot', 'cuts': None, 'as_known_ns': '85', 'snapshot_token': None})
        self.check_snapshot(historical, prepared=True)
        assert historical['mode'] == 'AsKnown'
        initial_cuts = {DOMAINS[o]: {'domain_id': DOMAINS[o], 'commit_seq': '0',
                                   'root_hash': self.initial[o]['root']} for o in OWNERS}
        watch = self.post('watch-from-init', '/api/economic/watch', {'op': 'watch', 'cuts': initial_cuts})
        assert watch['kind'] == 'EconomicWatch' and watch['manifest_hash'] == digest(self.manifest)
        assert set(watch['domains']) == set(DOMAINS.values())
        for domain, changes in watch['domains'].items():
            assert changes['status'] == 'Available' and changes['base_cut'] == initial_cuts[domain]
            assert changes['next_cut'] == self.current_cuts[domain]
            assert len(changes['changes']) == 4
            assert changes['changes'][-1]['image'] == self.current['domains'][domain]['image']
            owner = next(o for o, d in DOMAINS.items() if d == domain)
            assert changes['changes'] == self.histories[owner][1:]
            for change in changes['changes']:
                assert change['image_hash'] == digest(change['image'])
        originals = []
        for owner, native in zip(('alpha', 'beta'), self.formal['query_decisions']):
            originals.append(('original-decision-' + owner, DOMAINS[owner], 'decision', owner, native))
        for grant, native in zip(self.formal['reserve']['record']['grants'], self.formal['query_grants']):
            originals.append(('original-grant-' + grant['decision_id'], 'E', 'grant', grant['grant_id'], native))
        for label, domain, kind, oid, native in originals:
            original = self.post(label, '/api/economic/original', {'op': 'original',
                'cuts': self.current_cuts, 'domain_id': domain, 'kind': kind, 'object_id': oid})
            assert original['kind'] == 'EconomicOriginal' and original['cuts'] == self.current_cuts
            assert original['original'] == native, ('full original differs from actual Unix', label)
        assert self.independent_state() == self.final_before_q
        save(self.out / 'HTTP-RESULT.json', {'status': 'PASS', 'observations': self.http,
            'current_cuts': self.current_cuts, 'historical_as_known_ns': '85',
            'originals_full_object_equal': 4, 'independent_reply_token_image_hashes': True,
            'owner_logical_unchanged': True, 'browser_executed': False})

    def browser_handoff(self, wait_seconds: int) -> None:
        assert 0 < wait_seconds <= 240, 'browser handoff may not extend original240s'
        byte_before = {o: sha(self.db[o]) for o in OWNERS}
        save(self.out / 'BROWSER-OWNER-BYTES-BEFORE.json', byte_before)
        live = [{**row, 'poll_at_handoff': proc.poll()}
                for row, proc in self.processes if not row['reaped']]
        assert len(live) == 4 and all(row['poll_at_handoff'] is None for row in live)
        ready = {'status': 'READY_FOR_ROOT_BROWSER', 'url': f'http://127.0.0.1:{self.port}/economic.html',
                 'discovery_url': f'http://127.0.0.1:{self.port}/api/economic/ready',
                 'manifest_sha256': self.manifest_sha, 'expected_current_cuts': self.current_cuts,
                 'current_snapshot_token': self.current['snapshot_token'], 'knowledge_cutoff': '85',
                 'expected': {'current': '双Committed/None/锁30和40/责任90',
                              'as_known85': '双Prepared、无local_commit_receipt、责任20',
                              'watch': '逐域回current', 'originals': '两decision+两grant完整原件'},
                 'original_grant_ids': [g['grant_id'] for g in self.formal['reserve']['record']['grants']],
                 'formal_oracle': str(self.out / 'FORMAL-UNIX-RESULT.json'),
                 'live_popen': live,
                 'controls': {'current': '#current', 'watch': '#watch', 'known_at': '#known-at',
                              'as_known': '#as-known', 'status': '#status', 'books': '#books',
                              'history': '#history', 'revisit': '#revisit',
                              'originals': 'button[data-original-kind][data-original-domain][data-original-id]'},
                 'http_paths': ['/api/economic/ready', '/api/economic/snapshot',
                                '/api/economic/watch', '/api/economic/original'],
                 'finish_marker': str(self.out / 'BROWSER-DONE.json'),
                 'instruction': '仅根实际浏览器工具操作；runner不启浏览器。根保存原始HTTP/DOM并独核后写done。'}
        save(self.out / 'BROWSER-READY.json', ready)
        print(json.dumps(ready, ensure_ascii=False), flush=True)
        deadline = time.monotonic() + wait_seconds
        marker = self.out / 'BROWSER-DONE.json'
        while not marker.exists():
            assert all(proc.poll() is None for row, proc in self.processes if not row['reaped'])
            assert time.monotonic() < deadline, 'first browser handoff deadline; stop, no restart'
            time.sleep(0.1)
        done = load(marker)
        assert done['status'] == 'PASS' and done['manifest_sha256'] == self.manifest_sha
        assert self.independent_state() == self.final_before_q
        byte_after = {o: sha(self.db[o]) for o in OWNERS}
        save(self.out / 'BROWSER-OWNER-BYTES-AFTER.json',
             {'before': byte_before, 'after': byte_after, 'db_primary_equal': byte_before == byte_after,
              'no_wal_shm_equality_claim': True})
        assert byte_before == byte_after, 'browser changed owner primary DB bytes'

    def recover(self) -> None:
        assert not self.stop_services(), 'unreaped own service prevents recover'
        before = self.independent_state()
        structure = self.manifest['finance']['structure']
        for path in [Path(structure['binary']), Path(structure['db']),
                     Path(structure['db'] + '-wal'), Path(structure['db'] + '-shm')]:
            if path.exists():
                path.rename(path.with_name(path.name + '.offline'))
        recovered = []
        for owner in OWNERS:
            value = json.loads(self.command('fresh-recover-' + owner, self.owner_argv(owner, 'recover')))
            recovered.append(value)
        after = self.independent_state()
        for owner in OWNERS:
            assert after[owner]['writer_epoch'] == '2' and after[owner]['staging'] == 0
            for field in ['seq', 'root', 'commit_ns', 'image', 'receipts', 'messages', 'published']:
                assert after[owner][field] == before[owner][field], (owner, field)
        assert sha(self.manifest_path) == self.manifest_sha
        save(self.out / 'FRESH-RECOVER-RESULT.json', {'status': 'PASS', 'results': recovered,
             'before': before, 'after': after, 'manifest_unchanged': True,
             'only_own_S_offline': True, 'fresh_cli_processes': True})

    def cleanup(self) -> None:
        errors = self.stop_services()
        rows = []
        for mount in reversed(self.mounts):
            # 指定image必须仍属于本任务，只有该image登记的device才可普通detach。
            try:
                info = plistlib.loads(self.command('cleanup-info-' + mount['owner'], ['hdiutil', 'info', '-plist']))
                matches = [im for im in info['images'] if str(Path(im['image-path']).resolve()) == mount['image']]
                if not matches:
                    rows.append({**mount, 'image_not_attached_confirmed': True})
                    continue
                assert len(matches) == 1
                assert mount['fresh_image_absent_before_create'] and mount['registered_before_attach']
                entities = matches[0]['system-entities']
                direct_mounts = [e for e in entities if e.get('mount-point') == mount['mount']]
                if direct_mounts:
                    assert len(direct_mounts) == 1
                    device = direct_mounts[0]['dev-entry']
                else:
                    # attach可已生效但plist解析/指定mount失败；image精确身份仍可定位自有disk。
                    device = next(e['dev-entry'] for e in entities if e.get('dev-entry'))
                assert any(e.get('dev-entry') == device for e in entities)
                self.command('detach-' + mount['owner'], ['hdiutil', 'detach', device])
                rows.append({**mount, 'actual_info_device': device, 'ordinary_detach_exit': 0})
            except Exception:
                errors.append({'owner': mount['owner'], 'error': traceback.format_exc(),
                               'no_force_or_retry': True})
        if self.socket_root.exists():
            try:
                for path in self.socket_root.iterdir():
                    assert path.name in {o + '.sock' for o in OWNERS} and stat.S_ISSOCK(path.stat().st_mode)
                    path.unlink()
                self.socket_root.rmdir()
            except Exception:
                errors.append({'operation': 'own socket cleanup', 'error': traceback.format_exc()})
        save(self.out / 'PROCESS-FINAL.json', {'processes': [r for r, p in self.processes],
             'all_reaped': all(r['reaped'] and p.poll() is not None for r, p in self.processes),
             'volumes': rows, 'cleanup_errors': errors})
        assert not errors, ('cleanup incomplete; inspect PROCESS-FINAL', errors)


def check_artifacts(path: str | Path, run_name: str) -> dict[str, Any]:
    assert re.fullmatch(r'run-[1-9][0-9]*', run_name)
    data = load(path)
    assert data['schema_revision'] == 'issue1394-financial-current-artifacts/1'
    assert data['features'] == ['s_session'] and data['testonly_features'] == []
    assert data['binaries_non_test'] is True
    review = data['runner_independent_review']
    assert review['status'] == 'PASS' and review['runner_sha256'] == sha(__file__)
    assert 'authority_path_rebinding' in review['covers']
    assert sha(review['path']) == review['sha256']
    run_dir = BASE / run_name
    run_dir.mkdir(exist_ok=False)  # 旧run/已有目录/符号链接一律拒绝，绝不重用。
    argv = ['git', 'rev-parse', 'HEAD']
    git_record: dict[str, Any] = {'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': 10}
    with subprocess.Popen(argv, cwd=ROOT, stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE) as proc:
        git_record['pid'] = proc.pid
        try:
            stdout, stderr = proc.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate(timeout=10)
            git_record['failure'] = 'first preflight timeout; no retry'
            raise
        finally:
            git_record.update(exit_code=proc.returncode, reaped=proc.poll() is not None)
            save(run_dir / 'PREFLIGHT-GIT-HEAD.json', git_record)
        assert proc.returncode == 0, stderr.decode(errors='replace')
    head = stdout.decode().strip()
    assert head == data['frozen_head']
    for name in ['s_structure_session', 'e_economic_session', 'b_chong_session']:
        entry = data['binaries'][name]
        assert Path(entry['path']).is_absolute() and sha(entry['path']) == entry['sha256']
    assert data['frozen_source_manifest']['path'] and sha(data['frozen_source_manifest']['path']) == data['frozen_source_manifest']['sha256']
    for rel, expected in data['consumer_source_sha256'].items():
        assert sha(ROOT / rel) == expected
    inventory = load(BASE / 'INPUT-REUSE-INVENTORY.json')
    for row in inventory['files']:
        assert sha(row['path']) == row['sha256'] and sha(row['source']) == row['sha256']
    return data


def main() -> None:
    if not __debug__:
        raise RuntimeError('禁止python -O关闭验收断言')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--run-name', required=True, help='仅run-[1-9][0-9]*，必须全新目录')
    parser.add_argument('--execute', action='store_true', help='根授权后才设置；会创建新本任务HFS并运行')
    parser.add_argument('--port', type=int, default=38796)
    parser.add_argument('--browser-handoff', action='store_true')
    parser.add_argument('--browser-wait-seconds', type=int, default=240)
    args = parser.parse_args()
    assert 0 < args.browser_wait_seconds <= 240
    assert args.execute, '仅准备状态；必须由根明确执行授权'
    assert re.fullmatch(r'run-[1-9][0-9]*', args.run_name)
    data = check_artifacts(args.artifacts, args.run_name)
    run = Run(data, args.run_name)
    success = False
    try:
        run.provision()
        run.freeze()
        run.s_basis_preflight()
        run.init_and_cache()
        run.start_owners()
        run.prefix()
        run.financial()
        run.start_q(args.port)
        run.http_oracles()
        if args.browser_handoff:
            run.browser_handoff(args.browser_wait_seconds)
        run.recover()
        # 原件最终逐byte SHA重核；全过程不SQLite-open任何封存库。
        for row in load(BASE / 'INPUT-REUSE-INVENTORY.json')['files']:
            assert sha(row['source']) == row['sha256']
        success = True
    except Exception as exc:
        if isinstance(exc, (TimeoutError, subprocess.TimeoutExpired)):
            run.unknown_outcome = True
        save(run.out / 'FIRST-FAILURE.json', {'status': 'UNKNOWN_OUTCOME' if run.unknown_outcome else 'FAIL', 'no_retry': True,
             'operation_outcome': 'Unknown; prior financial request may have committed' if run.unknown_outcome else 'See recorded raw receipts and oracle failure',
             'traceback': traceback.format_exc(), 'unix_completed': run.unix, 'http_completed': run.http})
        raise
    finally:
        cleanup_error = None
        try:
            run.cleanup()
        except Exception:
            cleanup_error = traceback.format_exc()
        status = 'FAILED_CLEANUP' if cleanup_error else ('UNKNOWN_OUTCOME' if run.unknown_outcome else ('PASS' if success else 'FAIL'))
        save(run.out / 'FINAL-RESULT.json', {'status': status,
             'cleanup_error': cleanup_error, 'economic_outcome_unknown': run.unknown_outcome,
             'manifest_sha256': getattr(run, 'manifest_sha', None), 'unix': run.unix, 'http': run.http,
             'browser_handoff_requested': args.browser_handoff,
             'scope': '具名TestOnly现金小域的当前HEAD正式S/E/B、经济HTTP及鲜recover',
             'excluded': ['Native资格', '9011', '全资源闭包', '真实场所', '#1460产品前端']})
        if cleanup_error:
            raise RuntimeError('FAILED_CLEANUP; exact own-image/handle evidence in FINAL-RESULT.json')


if __name__ == '__main__':
    main()
