#!/usr/bin/env python3
"""只读原件并 bytes-copy；不导入 SQLite、不启动任何产品或载体。"""
import hashlib
import json
from pathlib import Path
from typing import Any

BASE = Path(__file__).resolve().parents[1]
OLD = Path('/Users/silencehan/Projects/NewChanlun-1394-content-v3/.scratch')
CASE = OLD / 'issue1394-economic-observer-actual-20260930/case-2'
SMALL = OLD / 'issue1394-financial-reader-small-20260930'


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode()


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1 << 20), b''):
            h.update(part)
    return h.hexdigest()


def main() -> None:
    out = BASE / 'inputs'
    out.mkdir(exist_ok=False)
    rows = []

    def copy(source: str | Path, name: str, expected: str | None = None) -> Path:
        source = Path(source)
        before = source.stat()
        actual = sha(source)
        if expected is not None:
            assert actual == expected, str(source)
        target = out / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open('rb') as src, target.open('xb') as dst:
            for part in iter(lambda: src.read(1 << 20), b''):
                dst.write(part)
        assert sha(target) == actual
        after = source.stat()
        assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
        rows.append({'source': str(source), 'path': str(target), 'sha256': actual,
                     'bytes': before.st_size, 'source_mtime_ns': before.st_mtime_ns,
                     'operation': 'bytes-copy/hash-only; never SQLite-open'})
        return target

    copy(CASE / 'evidence/manifest.json', 'old-manifest.json',
         'bb44978f91d9f3086d244e166d706abcd5a4b4488b1b0cbb1cc6ff73191a0602')
    copy(CASE / 'evidence/finance-input.json', 'finance-input.json',
         '56189b58672b1b458fc2ec933d117c3cf1721bedc031bd86c11742ea27400566')
    copy(SMALL / 'INPUTS.json', 'old-S-INPUTS.json',
         '5a7280178e45f6728c3d4afa9d313b98664af8c4141cccac10c99df639dfa82f')
    copy(SMALL / 'RESOURCES.json', 'reader-resources.json',
         'f8e9e3ca737b3c232c0c62bf748f524badeed575646c53338dca35b1804953dc')
    copy(SMALL / 's.sqlite', 'sealed-S/s.sqlite',
         '08c9d59456cc3eeede74650fad8597ad2743b5acbdf198c7b0b43b64537ec4ad')
    for suffix in ['-wal', '-shm']:
        p = SMALL / ('s.sqlite' + suffix)
        if p.exists():
            copy(p, 'sealed-S/s.sqlite' + suffix)
    copy(OLD / 'issue1394-eb-content-owner-20260930/acceptance-raw/published-cache.json',
         'published-cache.json', '6219f3af68b78ac9eed0e314d1aeacb984c0a61556c59ce0fee39261ceda7efa')
    observer = OLD / 'issue1394-economic-observer-actual-20260930'
    for name in ['FAULT-private.rs', 'FORMAL-CLI-private.rs', 'run_economic_http_case2.py']:
        copy(observer / name, 'old-runners/' + name)
    copy(observer / 'q19-resource-frozen.json', 'q19-resource-frozen.json',
         '36b188ae42be8e24e7fdbb44e7d3a7068200f7c942f50975337d07595ac62e64')
    copy(CASE / 'economic-config.json', 'old-economic-config.json',
         '9d43e290c9d1d53865a8ea45e3c7113bc1ea9bad1ca81d76655794390b06fe49')
    copy(CASE / 'http-plan.json', 'old-http-plan.json',
         '37ebd1e1eba885e96b838de72e2655c1a89cd9d4e05436a4c5cba7ed969327c6')
    manifest = json.loads((out / 'old-manifest.json').read_bytes())
    for authority in manifest['voice_binding']['authorities']:
        owner = authority['authority_id']
        for key in ['bundle_path', 'verification_path']:
            copy(authority[key], 'authorities/' + Path(authority[key]).name,
                 authority[key.replace('_path', '_sha256')])
        bundle = json.loads(Path(authority['bundle_path']).read_bytes())
        for artifact in bundle['artifacts']:
            copy(artifact['path'], 'authorities/' + Path(artifact['path']).name, artifact['sha256'])
    finance = json.loads((out / 'finance-input.json').read_bytes())
    assert finance['policy']['cap'] == '100'
    assert finance['policy']['policy_id'] == 'TestOnly-cash-cap-100'
    assert finance['policy']['model'] == 'TestOnlyUnleveragedCashBuy'
    assert finance['policy']['capability_id'] == 'TestOnly-no-leverage-no-venue'
    assert finance['baseline']['amount'] == '20'
    assert [r['amount'] for r in finance['rights']] == ['40', '50']
    assert [int(p['quantity']) * int(p['limit_price']) + int(p['fee_tail'])
            for p in finance['plans']] == [30, 40]
    cache = json.loads((out / 'published-cache.json').read_bytes())
    assert len(cache['nodes']) == 1307
    seen = set()
    for node in cache['nodes']:
        body = bytes.fromhex(node['body'])
        tag = node['tag']
        assert type(tag) is int and 0 <= tag <= 255
        framed = b'NewChanlun/SContent/1\x00' + bytes([tag]) + len(body).to_bytes(8, 'big') + body
        assert hashlib.sha256(framed).hexdigest() == node['digest']
        assert node['digest'] not in seen
        seen.add(node['digest'])
    result = {'schema_revision': 'issue1394-financial-current-inputs/1',
              'status': 'PREPARED_ONLY', 'files': rows,
              'finance_input_sha256': sha(out / 'finance-input.json'),
              'policy_hash': digest(finance['policy']), 'clock_hash': digest(manifest['clock']),
              'economic_resources_hash': digest(manifest['resources']),
              'economic_q_resources_hash': digest(json.loads((out / 'old-economic-config.json').read_bytes())['resources']),
              'cache_independent_frame_checks': len(seen),
              'no_sqlite_open': True, 'no_product_child': True, 'no_hdiutil': True,
              'limits': '具名 TestOnly 财务小域；无 Native/9011/全资源/真实场所结论'}
    with (BASE / 'INPUT-REUSE-INVENTORY.json').open('xb') as stream:
        stream.write(canonical(result))
    print(json.dumps({'status': result['status'], 'files': len(rows), 'cache_checks': len(seen)}))


if __name__ == '__main__':
    main()
