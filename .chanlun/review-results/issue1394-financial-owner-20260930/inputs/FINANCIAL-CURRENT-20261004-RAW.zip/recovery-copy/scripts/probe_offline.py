#!/usr/bin/env python3
"""只对新owned sentinel测试sandbox data/exec及子进程继承，不接触任何SQLite。"""
import errno
import json
import subprocess
import sys


def main() -> None:
    action, target = sys.argv[1:]
    if action == 'read-allowed':
        with open(target, 'rb') as stream:
            count = len(stream.read())
        print(json.dumps({'allowed': True, 'bytes': count}))
        return
    if action == 'exec-allowed':
        proc = subprocess.Popen([target], stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            stdout, stderr = proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate(timeout=5)
            raise
        assert proc.returncode == 0, stderr.decode(errors='replace')
        print(json.dumps({'allowed': True, 'target': target, 'pid': proc.pid,
                          'exit_code': proc.returncode, 'reaped': True}))
        return
    if action == 'read-denied':
        try:
            with open(target, 'rb') as stream:
                stream.read(1)
        except OSError as exc:
            if exc.errno not in (errno.EACCES, errno.EPERM):
                raise
            print(json.dumps({'denied': True, 'errno': exc.errno, 'action': action}))
            return
        raise RuntimeError('sandbox未阻止owned sentinel data读取')
    if action == 'exec-denied':
        try:
            proc = subprocess.Popen([target], stdin=subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except OSError as exc:
            if exc.errno not in (errno.EACCES, errno.EPERM):
                raise
            print(json.dumps({'denied': True, 'errno': exc.errno, 'action': action,
                              'child_spawned': False}))
            return
        try:
            proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate(timeout=5)
        raise RuntimeError(f'sandbox未阻止owned sentinel执行；PID{proc.pid}已reap，exit{proc.returncode}')
    if action in ('child-read-denied', 'child-exec-denied'):
        child_action = action.removeprefix('child-')
        proc = subprocess.Popen([sys.executable, __file__, child_action, target],
                                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)
        try:
            stdout, stderr = proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate(timeout=5)
            raise
        assert proc.returncode == 0, stderr.decode(errors='replace')
        result = json.loads(stdout)
        assert result['denied'] is True
        print(json.dumps({'denied': True, 'inherited_child_pid': proc.pid,
                          'inherited_child_reaped': True, 'child': result}))
        return
    raise ValueError('未知probe action')


if __name__ == '__main__':
    main()
