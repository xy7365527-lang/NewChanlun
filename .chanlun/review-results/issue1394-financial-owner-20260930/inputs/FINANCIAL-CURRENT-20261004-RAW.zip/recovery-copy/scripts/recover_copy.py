#!/usr/bin/env python3
"""仅新image副本上的独立recover；不改变run3 FAIL，不重发财务/UI。"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import sys
import traceback

BASE = Path(__file__).resolve().parents[1]
FINANCE = BASE.parent / 'issue1394-financial-current-20261004'
RUN3 = FINANCE / 'run-3'
RUNNER = FINANCE / 'scripts/run_current.py'
RUNNER_SHA = '1c8c6d3cc0eeb842fada7c0dc8a0fcfb084893d7ae8e7aff39d71df429412de7'
# 复用已独评且实际跑过的Popen/cleanup/SQL全历史独立oracle，不调用原Run构造器。
sys.dont_write_bytecode = True
assert hashlib.sha256(RUNNER.read_bytes()).hexdigest() == RUNNER_SHA
spec = importlib.util.spec_from_file_location('pinned_financial_runner', RUNNER)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert module.sha(RUNNER) == RUNNER_SHA


class Recovery(module.Run):
    def __init__(self, binding: dict) -> None:
        self.binding = binding
        self.out = BASE / 'recovery-1'
        self.out.mkdir(exist_ok=False)
        self.processes, self.mounts = [], []
        self.unknown_outcome = False
        self.histories = {}
        self.socket_root = self.out / 'unused-sockets'  # 永不创建或启动Unix/HTTP服务。
        self.manifest_path = RUN3 / 'manifest.json'
        self.manifest = module.load(self.manifest_path)
        self.db = {owner: Path(binding['owners'][owner]['db']) for owner in module.OWNERS}
        self.profile_paths = {}

    def info(self, label: str) -> dict:
        return plistlib.loads(self.command(label, ['hdiutil', 'info', '-plist']))

    def verify_owned_mounts(self, label: str) -> None:
        info = self.info(label)
        for source in self.binding['owners'].values():
            assert not any(Path(im['image-path']).resolve() == Path(source['source_image'])
                           for im in info['images']), '源image不得处于任何挂载状态'
        for mount in self.mounts:
            images = [im for im in info['images'] if Path(im['image-path']).resolve() == Path(mount['image'])]
            assert len(images) == 1
            assert any(e.get('mount-point') == mount['mount'] and e.get('dev-entry') == mount['device']
                       for e in images[0]['system-entities'])
            assert Path(mount['mount']).stat().st_dev == mount['dev']

    def copy_mount(self) -> None:
        info = self.info('pre-copy-mount-info')
        for owner in module.OWNERS:
            original = self.binding['owners'][owner]
            mount = Path(original['mount'])
            assert mount.resolve() == mount and not list(mount.iterdir())
            assert not any(Path(im['image-path']).resolve() == Path(original['source_image'])
                           or any(e.get('mount-point') == str(mount) for e in im['system-entities'])
                           for im in info['images'])
            image = self.out / 'images' / (owner + '.dmg')
            image.parent.mkdir(exist_ok=True)
            assert not image.exists()
            row = {'owner': owner, 'image': str(image), 'mount': str(mount), 'device': None,
                   'dev': None, 'capacity': None, 'fresh_image_absent_before_create': True,
                   'registered_before_attach': True, 'source_image': original['source_image'],
                   'source_sha256': original['source_sha256']}
            self.mounts.append(row)
            module.save(self.out / ('COPY-INTENT-' + owner + '.json'), row)
            module.byte_copy(original['source_image'], image)
            assert module.sha(image) == original['source_sha256']
            raw = self.command('attach-copy-' + owner,
                ['hdiutil', 'attach', '-plist', '-nobrowse', '-mountpoint', str(mount), str(image)])
            entities = plistlib.loads(raw)['system-entities']
            entity = next(e for e in entities if e.get('mount-point') == str(mount))
            row.update(device=entity['dev-entry'], dev=mount.stat().st_dev,
                       capacity=os.statvfs(mount).f_blocks * os.statvfs(mount).f_frsize)
            assert row['capacity'] == 25124864
        assert len({r['dev'] for r in self.mounts}) == 3
        self.verify_owned_mounts('post-copy-mount-info')
        module.save(self.out / 'OWN-COPY-MOUNTS.json', self.mounts)

    def owned_connection(self, owner: str):
        import sqlite3
        path = self.db[owner]
        row = next(r for r in self.mounts if r['owner'] == owner)
        assert path.parent == Path(row['mount']) and path.parent.stat().st_dev == row['dev']
        assert path.resolve() == path and path.is_file()
        # 仅new owned image当前挂载的DB；mode=ro保留WAL语义，不用immutable忽略WAL。
        return sqlite3.connect(f'file:{path}?mode=ro', uri=True)

    def before(self) -> None:
        self.verify_owned_mounts('before-sql-owned-copy-info')
        bytes_before = {owner: module.sha(self.db[owner]) for owner in module.OWNERS}
        expected_bytes = module.load(RUN3 / 'BROWSER-OWNER-BYTES-BEFORE.json')
        logical = self.independent_state()
        expected_logical = module.load(RUN3 / 'PRE-Q-STATE.json')
        module.save(self.out / 'BROWSER-AFTER-COPY-BEFORE-RECOVER.json',
            {'primary_sha_before_browser': expected_bytes, 'primary_sha_after_on_copy': bytes_before,
             'primary_equal': bytes_before == expected_bytes, 'logical': logical,
             'logical_equal': logical == expected_logical,
             'note': 'primary物理差异不自动归因浏览器；服务关闭/checkpoint/WAL等需另核，逻辑等式是硬门'})
        assert logical == expected_logical, '浏览器后copied DB完整逻辑不等于PRE-Q，首停'
        self.before_state = logical

    def prepare_profiles(self) -> None:
        probes = self.out / 'owned-probes'
        (probes / 'denied-data').mkdir(parents=True)
        allowed = probes / 'allowed'
        denied_data = probes / 'denied-data/value'
        denied_exec = probes / 'denied-exec'
        allowed.write_bytes(b'owned-allowed\n')
        denied_data.write_bytes(b'owned-denied\n')
        # 用owned Mach-O副本测exec deny，避免shebang解释器路径混淆。
        module.byte_copy('/usr/bin/true', denied_exec)
        denied_exec.chmod(0o755)
        sdir = Path(self.manifest['finance']['structure']['db']).parent
        assert Path(self.manifest['finance']['structure']['binary']).parent == sdir
        helper = BASE / 'scripts/probe_offline.py'
        allow_profile = self.out / 'exec-allow-default.sb'
        allow_profile.write_text('(version 1)\n(allow default)\n')
        exec_hash = module.sha(denied_exec)
        positive = json.loads(self.command('probe-same-mach-o-exec-allowed',
            ['/usr/bin/sandbox-exec', '-f', str(allow_profile), sys.executable,
             str(helper), 'exec-allowed', str(denied_exec)]))
        assert positive['allowed'] is True and positive['exit_code'] == 0 and positive['reaped'] is True
        assert module.sha(denied_exec) == exec_hash
        module.save(self.out / 'SAME-MACH-O-EXEC-POSITIVE.json',
            {'profile': str(allow_profile), 'profile_sha256': module.sha(allow_profile),
             'target': str(denied_exec), 'target_sha256': exec_hash, 'result': positive})
        for owner in module.OWNERS:
            peer_dirs = [str(self.db[peer].parent) for peer in module.OWNERS if peer != owner]
            denied_dirs = [str(sdir), *peer_dirs, str(denied_data.parent)]
            denied_images = [x['source_image'] for x in self.binding['owners'].values()]
            quote = lambda value: json.dumps(value, ensure_ascii=False)
            profile = '(version 1)\n(allow default)\n'
            profile += '(deny file-read-data ' + ' '.join('(subpath ' + quote(p) + ')' for p in denied_dirs) + ' '
            profile += ' '.join('(literal ' + quote(p) + ')' for p in denied_images) + ')\n'
            profile += '(deny process-exec (subpath ' + quote(str(sdir)) + ') (literal ' + quote(str(denied_exec)) + '))\n'
            path = self.out / (owner + '-offline.sb')
            path.write_text(profile)
            self.profile_paths[owner] = path
            prefix = ['/usr/bin/sandbox-exec', '-f', str(path), sys.executable, str(helper)]
            checks = []
            for action, target in [('read-allowed', allowed), ('read-denied', denied_data),
                                   ('exec-denied', denied_exec), ('child-read-denied', denied_data),
                                   ('child-exec-denied', denied_exec)]:
                result = json.loads(self.command('probe-' + owner + '-' + action, prefix + [action, str(target)]))
                assert result.get('allowed' if action == 'read-allowed' else 'denied') is True
                checks.append({'action': action, 'result': result})
            assert module.sha(denied_exec) == exec_hash
            module.save(self.out / ('OFFLINE-POLICY-' + owner + '.json'),
                {'profile': str(path), 'profile_sha256': module.sha(path), 'checks': checks,
                 'S_data_exec_denied': str(sdir), 'peer_data_denied': peer_dirs,
                 'source_images_data_denied': denied_images, 'metadata_allowed': True,
                 'same_exec_positive_target': str(denied_exec), 'same_exec_target_sha256': exec_hash,
                 'scope': '单个recover进程与继承子进程；source S/DMG不改名、不SQLopen，无全局更改'})

    def recover_only(self) -> None:
        results = []
        for owner in module.OWNERS:
            self.verify_owned_mounts('pre-recover-owned-copy-' + owner)
            binary_name = 'e_economic_session' if owner == 'e' else 'b_chong_session'
            binary = self.binding['binaries'][binary_name]
            assert module.sha(binary['path']) == binary['sha256']
            argv = ['/usr/bin/sandbox-exec', '-f', str(self.profile_paths[owner]), binary['path'],
                    'recover', '--manifest', str(self.manifest_path), '--db', str(self.db[owner])]
            if owner != 'e':
                argv += ['--chong', owner]
            value = json.loads(self.command('fresh-offline-recover-' + owner, argv))
            assert value['kind'] == 'Recovered' and value['writer_epoch'] == '2'
            results.append(value)
        self.verify_owned_mounts('after-recover-owned-copy-info')
        after = self.independent_state()
        for owner in module.OWNERS:
            assert after[owner]['writer_epoch'] == '2' and after[owner]['staging'] == 0
            for field, old in self.before_state[owner].items():
                if field not in ('writer_epoch', 'staging'):
                    assert after[owner][field] == old, (owner, field)
        module.save(self.out / 'FRESH-OFFLINE-COPY-RECOVER.json',
            {'status': 'PASS', 'results': results, 'before': self.before_state, 'after': after,
             'financial_requests_replayed': 0, 'run3_fail_preserved': True})


def main() -> None:
    if not __debug__:
        raise RuntimeError('禁止python -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--review', type=Path, required=True)
    args = parser.parse_args()
    assert args.execute, '只准备，等待根执行授权'
    binding, review = module.load(args.binding), module.load(args.review)
    assert binding['schema_revision'] == 'issue1394-recovery-copy-binding/1'
    assert set(binding['owners']) == set(module.OWNERS)
    assert review['schema_revision'] == 'issue1394-recovery-copy-review/1'
    assert review['status'] == 'PASS' and review['script_sha256'] == module.sha(__file__)
    assert review['probe_sha256'] == module.sha(BASE / 'scripts/probe_offline.py')
    assert review['binding_sha256'] == module.sha(args.binding)
    for row in binding['frozen_files']:
        assert module.sha(row['path']) == row['sha256']
    for source in binding['owners'].values():
        assert module.sha(source['source_image']) == source['source_sha256']
    assert sys.executable == binding['python_executable']
    recovery = Recovery(binding)
    success, cleanup_error = False, None
    try:
        recovery.copy_mount()
        recovery.before()
        recovery.prepare_profiles()
        recovery.recover_only()
        success = True
    except Exception:
        module.save(recovery.out / 'FIRST-FAILURE.json',
            {'status': 'UNKNOWN_OUTCOME' if recovery.unknown_outcome else 'FAIL',
             'no_retry': True, 'traceback': traceback.format_exc()})
        raise
    finally:
        try:
            recovery.cleanup()
        except Exception:
            cleanup_error = traceback.format_exc()
        seals, seal_errors = [], []
        for row in [*binding['frozen_files'], *[
                {'path': r['source_image'], 'sha256': r['source_sha256']}
                for r in binding['owners'].values()]]:
            try:
                actual = module.sha(row['path'])
                seals.append({'path': row['path'], 'expected_sha256': row['sha256'],
                              'actual_sha256': actual, 'equal': actual == row['sha256']})
            except Exception:
                seal_errors.append({'path': row['path'], 'error': traceback.format_exc()})
        originals_unchanged = not seal_errors and all(r['equal'] for r in seals)
        source_images = {r['source_image'] for r in binding['owners'].values()}
        images_unchanged = not any(r['path'] in source_images for r in seal_errors) and all(
            r['equal'] for r in seals if r['path'] in source_images)
        run3_status = None
        try:
            run3_status = module.load(RUN3 / 'FINAL-RESULT.json')['status']
        except Exception:
            seal_errors.append({'path': str(RUN3 / 'FINAL-RESULT.json'),
                                'operation': 'load run3 status', 'error': traceback.format_exc()})
        status = 'FAILED_CLEANUP' if cleanup_error else ('UNKNOWN_OUTCOME' if recovery.unknown_outcome else ('PASS' if success else 'FAIL'))
        if any(not row['equal'] for row in seals):
            status = 'SOURCE_CHANGED'
        elif seal_errors:
            status = 'SOURCE_UNVERIFIABLE'
        module.save(recovery.out / 'FINAL-RESULT.json',
            {'status': status, 'cleanup_error': cleanup_error, 'originals_unchanged': originals_unchanged,
             'source_DMG_unchanged': images_unchanged, 'source_seals': seals, 'seal_errors': seal_errors,
             'run3_status': run3_status,
             'scope': '独立新image副本、原logical binding、单进程S/peer离线的fresh recover；非9011/全资源/场所'})
        if cleanup_error or seal_errors or not originals_unchanged or not images_unchanged:
            raise RuntimeError('独立恢复未满足收尾/封存等式')


if __name__ == '__main__':
    main()
