"""#1394 copied149 independent formal S150..151 window; never original9011 continuation."""
import contextlib, hashlib, importlib, json, os, pathlib, shutil, signal, sqlite3, stat, subprocess, sys, time
sys.dont_write_bytecode=True
ROOT=pathlib.Path.cwd();OUT=ROOT/'.scratch/issue1394-manifest-budget-window150-151-20261005'
OLD=pathlib.Path('/Users/silencehan/.codex/worktrees/issue1394-history-sweep/NewChanlun/.scratch/formal-s-request-audit-20261003')
RUNNER=OLD/'runner';INPUTS=OLD/'root-inputs-request-audit-ab-01/inputs'
PREVIOUS_RESULT=ROOT/'.scratch/issue1394-root-text-window143-160-20261004/RESULT.json'
OWN=pathlib.Path('/Volumes/AgentStorage/issue1394-manifest-budget-window150-151-20261005-r1')
FILES=('s.sqlite','s.sqlite-wal','s.sqlite-shm')
def load(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def require(v,m):
 if not v:raise RuntimeError(m)
def save(p,v):pathlib.Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def identity(p):
 p=pathlib.Path(p);s=p.lstat();require(stat.S_ISREG(s.st_mode),'nonregular file');h=sha(p);a=p.lstat();require(all(getattr(s,k)==getattr(a,k) for k in ('st_dev','st_ino','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_mode','st_blocks','st_nlink')),'file changed while hashing')
 return dict(path=str(p),sha256=h,stat={k:getattr(a,k)for k in ('st_dev','st_ino','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_mode','st_blocks','st_nlink')})
def error(e):return {'type':type(e).__name__,'message':str(e)}
@contextlib.contextmanager
def alarm(seconds):
 prev=signal.getsignal(signal.SIGALRM);signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('private bounded operation expired')));signal.setitimer(signal.ITIMER_REAL,seconds)
 try:yield
 finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,prev)
class CopiedOwned:
 """CopyQualified, never InitObserved; persistent extractor reused without fresh-init adoption."""
 def __init__(self,path,runtime):self.path=path;self.runtime=runtime;self.inode=path.lstat().st_ino;self.query=runtime.OwnedDatabase.query
 @contextlib.contextmanager
 def read(self):
  require(self.path.is_file()and not self.path.is_symlink()and self.path.lstat().st_ino==self.inode,'own DB identity changed')
  with contextlib.closing(sqlite3.connect(self.path.as_uri()+'?mode=ro',uri=True,timeout=2))as c:
   end=time.monotonic()+5;c.set_progress_handler(lambda:int(time.monotonic()>=end),1000);c.execute('PRAGMA query_only=ON');c.execute('BEGIN');yield c
 def persistent(self,envelope,ordinal):return self.runtime.OwnedDatabase.persistent(self,envelope,ordinal)
 def terminal(self):
  with self.read()as c:return {'generation':c.execute("SELECT value FROM meta WHERE key='generation'").fetchone()[0],'advance_state':c.execute("SELECT value FROM meta WHERE key='advance_state'").fetchone()[0],'messages_by_status':dict(c.execute('SELECT status,count(*) FROM s_input_messages GROUP BY status')),'published':c.execute('SELECT count(*) FROM s_content_publications').fetchone()[0],'clocks':c.execute('SELECT count(*) FROM s_clock_events').fetchone()[0],'next_attempt_ordinal':c.execute('SELECT next_attempt_ordinal FROM s_protocol_meta').fetchone()[0]}
@contextlib.contextmanager
def observe(binary,handles,startup):
 original=subprocess.Popen
 class Observed(original):
  def __init__(self,command,*args,**kwargs):
   tracked=isinstance(command,(list,tuple))and str(command[0])==str(binary)
   if tracked:require(command[1]=='serve','copied domain must not init/recover')
   super().__init__(command,*args,**kwargs)
   self.window_tracked=tracked
   if tracked:
    row={'pid':self.pid,'argv':list(command),'begin_ns':time.monotonic_ns(),'environment':{k:kwargs.get('env',{}).get(k)for k in ('S_CAPTURE_NATIVE_TESTONLY','S_ALLOCATION_JSON_TESTONLY','S_ALLOCATION_SQLITE_TESTONLY','S_ALLOCATION_PROFILE','S_MANIFEST_WORKSPACE_DIAGNOSTICS')}};handles.append((self,row))
  def wait(self,timeout=None):
   if self.window_tracked and startup['active']:
    remaining=startup['deadline']-time.monotonic()
    if remaining<=0:raise subprocess.TimeoutExpired(self.args,0)
    timeout=remaining if timeout is None else min(timeout,remaining)
   return super().wait(timeout=timeout)
 subprocess.Popen=Observed
 try:yield
 finally:subprocess.Popen=original

def cleanup(controller,handles,result):
 begin=time.monotonic();end=begin+30;errors=[]
 try:
  # Main process first; never let evidence collection postpone cleanup.
  if controller is not None:
   try:
    with alarm(25):result['controller_stop']=controller.stop('s',signal.SIGTERM)
   except BaseException as e:errors.append(error(e))
 finally:
  for proc,row in handles:
   try:
    if proc.poll()is None:proc.terminate()
    try:code=proc.wait(timeout=max(.001,min(2,end-time.monotonic())))
    except subprocess.TimeoutExpired:
     proc.kill();code=proc.wait(timeout=max(.001,end-time.monotonic()))
    row.update(exit_code=code,reaped_by_same_Popen=True)
   except BaseException as e:row.update(reaped_by_same_Popen=False,reap_error=error(e));errors.append(error(e))
  if controller is not None:
   try:
    if handles and all(r.get('reaped_by_same_Popen')for _,r in handles)and result.get('ready_received'):
     with alarm(max(.001,end-time.monotonic())):
      result['socket_cleanup']=controller.prepare_socket(end)
     require(not os.path.lexists(controller.config['socket']),'owned socket still exists')
   except BaseException as e:errors.append(error(e))
   finally:
    try:controller.close();result['controller_closed']=True
    except BaseException as e:errors.append(error(e))
 result['lifecycle']=[r for _,r in handles];result['cleanup_errors']=errors;result['cleanup_seconds']=time.monotonic()-begin

def main():
 require(not(OUT/'RESULT.json').exists()and not OWN.exists(),'result/domain already exists; no retry')
 orchestration=load(OUT/'ORCHESTRATOR-BINDING.json');require(sha(__file__)==orchestration['sha256'],'window script changed');require(sha(OUT/'PYTHON-BINDING.json')==orchestration['python_binding_sha256'],'Python binding changed')
 deps=load(OUT/'PYTHON-BINDING.json')
 for r in deps['files']:require(sha(r['path'])==r['sha256'],'Python/material dependency changed: '+r['path'])
 binding=load(OUT/'BINARY-BINDING-service.json');binary=pathlib.Path(binding['binary']['path']);require(binding['compiler_artifact_profile_test']is False and binding['target_kind']==['bin']and binding['target_name']=='s_structure_session','not service artifact');require(sha(binary)==binding['binary']['sha256'],'service binary changed')
 manifest=load(binding['source_manifest'])
 for r in manifest['entries']:require(sha(pathlib.Path(binding['fixed_source'])/r['path'])==r['sha256'],'fixed source changed')
 sys.path.insert(0,str(RUNNER));sys.path.insert(0,str(ROOT/'s_session'))
 runtime=importlib.import_module('runtime');evidence=importlib.import_module('evidence');control=importlib.import_module('s_service_control');client=importlib.import_module('s_socket_client')
 previous=load(PREVIOUS_RESULT);require(previous['state']=='FAILURE_PRESERVED'and previous['last_attempted_ordinal']==149 and [r['ordinal']for r in previous['received_window']]==list(range(143,149)),'previous149 failure boundary changed');require(previous['owned_terminal_state']=={'generation':'149','advance_state':'idle','messages_by_status':{'Committed':149},'published':149,'clocks':447,'next_attempt_ordinal':150}and previous['all_processes_reaped']and previous['controller_closed']and not previous['cleanup_errors'],'previous149 copy qualification invalid')
 expected=previous['owned_after'];SOURCE=pathlib.Path(expected['s.sqlite']['path']).parent
 require(all(pathlib.Path(expected[n]['path'])==SOURCE/n for n in FILES),'previous file paths not one domain')
 lifecycle=previous['lifecycle'];require(len(lifecycle)==1 and lifecycle[0]['reaped_by_same_Popen'],'previous service unreaped')
 argv=lifecycle[0]['argv'];require(argv[argv.index('--db')+1]==str(SOURCE/'s.sqlite'),'source not actual previous service DB')
 before={n:identity(SOURCE/n)for n in FILES};require(before==expected,'previous149 full stat/SHA seal mismatch')
 old=load(OLD/'execution/ROOT-ACTUAL-RESULT.json');require(old['persistent_committed']==105 and old['received_and_validated_committed']==104,'original history mismatch')
 OWN.mkdir(mode=0o700);directory=OUT/'execution';directory.mkdir(mode=0o700)
 result={'state':'RUNNING','scope':'independent CopyQualified149 formal S150..151 native manifest workspace sharing the approved 512MiB source budget with qualification diagnostics; normal input comparison; source149 Unknown remains','previous_independent_window_received':list(range(143,149)),'source149_persistent_without_received_reply':True,'source_qualification':'CopyQualified, not InitObserved or Received','original_received':104,'original_persistent':105,'original105_DeliveryUnknown_preserved':True,'full9011_complete':False,'staging_enabled':False,'received_window':[],'errors':[],'original_before':before,'binding':binding};save(OUT/'RESULT.json',result)
 controller=None;handles=[];db=None;original_env={k:os.environ.get(k)for k in (*runtime.entry.TESTONLY_ENV_KEYS,'S_MANIFEST_WORKSPACE_DIAGNOSTICS')}
 try:
  for n in FILES:
   with(SOURCE/n).open('rb')as src,(OWN/n).open('xb')as dst:shutil.copyfileobj(src,dst,1048576);dst.flush();os.fsync(dst.fileno())
   os.chmod(OWN/n,stat.S_IMODE(before[n]['stat']['st_mode']));require(sha(OWN/n)==before[n]['sha256'],'copy mismatch')
  require(before=={n:identity(SOURCE/n)for n in FILES},'original changed copying')
  db=CopiedOwned(OWN/'s.sqlite',runtime);initial=db.terminal();require(initial=={'generation':'149','advance_state':'idle','messages_by_status':{'Committed':149},'published':149,'clocks':447,'next_attempt_ordinal':150},'copy initial149 not exact');result['copy_qualified_start']=initial
  original_requests=(INPUTS/'envelopes.draft.jsonl').read_bytes().splitlines(keepends=True)
  future=[client.decode_frame(original_requests[n-1])for n in range(150,152)]
  with db.read()as c:
   for env in future:require(c.execute('SELECT count(*) FROM s_input_messages WHERE source_namespace=? AND source_epoch=? AND message_id=?',(env['source_namespace'],env['source_epoch'],env['message_id'])).fetchone()[0]==0,'future input identity already present')
  config=load(INPUTS/'Controller-A.draft.json');require(config['s_resources']['response_timeout_ms']=='30000'and config['startup_timeout_ms']=='30000'and config['s_resources']['audit_cache_source_bytes']=='1','original deadlines/S7 changed')
  config.update(binary=str(binary),db=str(OWN/'s.sqlite'),socket='/private/tmp/nc1394-manifestbudget150-151-20261005-r1.sock')
  config['s_resources']=dict(config['s_resources'],audit_cache_source_bytes='536870912')
  require(config==load(OUT/'Controller.proposed.json'),'proposed controller changed')
  require(not os.path.lexists(config['socket']),'new socket exists');save(OUT/'Controller.json',config);parsed=control.read_config(OUT/'Controller.json');controller=control.Controller(parsed,OWN/'controller-state')
  clock=pathlib.Path(config['clock_plan']).read_bytes();request_file=INPUTS/'envelopes.draft.jsonl';requests=request_file.read_bytes().splitlines(keepends=True);require(len(requests)==9011,'original full envelope count changed')
  for k in runtime.entry.TESTONLY_ENV_KEYS:os.environ.pop(k,None)
  os.environ['S_CAPTURE_NATIVE_TESTONLY']='1'
  os.environ['S_MANIFEST_WORKSPACE_DIAGNOSTICS']='1'
  startup={'active':False,'deadline':None}
  with observe(binary,handles,startup):
   startup.update(active=True,deadline=time.monotonic()+30)
   try:
    with runtime.Wire(directory,'start-ready'):ready=controller.start_s('1')
   finally:startup['active']=False
   save(directory/'START-RESULT.json',ready);require(ready['state']=='ready'and ready['initialization']is None,'copied domain requires actual Ready, no init');require(len(handles)==1,'not exactly one serve Popen');running=controller.status('s');require(running['state']=='running'and running['pid']==handles[0][0].pid,'Ready PID mismatch');save(directory/'RUNNING-IDENTITY.json',running)
   result['ready_received']=True;save(OUT/'RESULT.json',result)
   for ordinal in range(150,152):
    raw=requests[ordinal-1];require(raw.endswith(b'\n'),'request lost original LF');env=client.decode_frame(raw);result['last_attempted_ordinal']=ordinal;save(OUT/'RESULT.json',result)
    persistent,reply_raw,payload=runtime.exchange_once(client,parsed,env,raw,ordinal,directory,db)
    evidence.validate_receipt(persistent,raw,ordinal,payload,clock)
    result['received_window'].append({'ordinal':ordinal,'request_LF_sha256':hashlib.sha256(raw).hexdigest(),'reply_wire_sha256':hashlib.sha256(reply_raw).hexdigest(),'reply':payload,'persistent_sha256':hashlib.sha256(evidence.canonical(persistent)).hexdigest()});save(OUT/'RESULT.json',result)
  result['state']='WINDOW_RECEIVED'
 except BaseException as e:result['state']='FAILURE_PRESERVED';result['errors'].append(error(e))
 finally:
  try:cleanup(controller,handles,result)
  finally:
   for k,v in original_env.items():
    if v is None:os.environ.pop(k,None)
    else:os.environ[k]=v
   try:
    if db is not None:result['owned_terminal_state']=db.terminal()
   except BaseException as e:result['errors'].append(error(e))
   try:
    result['owned_after']={n:identity(OWN/n)for n in FILES if(OWN/n).exists()};after={n:identity(SOURCE/n)for n in FILES};result['original_after']=after;result['original_full_stat_and_SHA_unchanged']=after==before;require(after==before,'original changed')
   except BaseException as e:result['errors'].append(error(e))
   result['all_processes_reaped']=bool(handles)and all(r.get('reaped_by_same_Popen')for _,r in handles)
   if result['state']=='WINDOW_RECEIVED'and not result['errors']and not result.get('cleanup_errors')and result['all_processes_reaped']and result.get('original_full_stat_and_SHA_unchanged'):result['state']='COMPLETE'
   elif result['state']=='WINDOW_RECEIVED':result['state']='FAILURE_PRESERVED'
   result['whole_Job_or_max_store_qualified']=False;result['strict_peaks']='UNMEASURED';save(OUT/'RESULT.json',result)
if __name__=='__main__':main()
