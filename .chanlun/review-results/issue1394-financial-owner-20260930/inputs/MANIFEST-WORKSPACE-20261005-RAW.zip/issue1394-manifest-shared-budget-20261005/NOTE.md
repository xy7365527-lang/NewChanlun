# #1394 manifest workspace 共用现有 S7 的预算增量

基线为当前真实 Rust r2，以 `BASE-SHA.json` 的八文件摘要为准；本目录独占。`shared-budget.patch` 是相对此基线的增量，`STAGED-SHA.json` 是冻结镜像及 patch 摘要。原 r2 目录和证据未修改。真实源码未修改，未运行 cargo、测试、服务或 SQL，仅 rustfmt 解析和摘要核验。性能、编译及测试结果仍待主控独评后确认。

## 额度与生命周期

Driver.handle 入口先 take 上次 keeper，并在移入 RequestAuditContext 前读取实际 `old_pool = Keeper.retained_source_bytes()`，口径为 Pool.source_cost.total；legacy 费用只读既有 `cache.retained_bytes()`，其 accessor 从 cfg(test) 扩至 Native feature，不改 legacy 配置。入口使用 checked 加法及减法验证 `legacy + old_pool <= S7`，冻结 `total/legacy/old_pool/allowance`，其中 `allowance = S7 - legacy - old_pool`。非法零预算、加法溢出、超额或下溢按现有 S3WriterResourcesInvalid 拒绝，不用饱和减法。每个 context 只准冻结一次。

预算放 RequestAuditContext，不存 Runtime 持久字段。prepare 在消费 context 前复制冻结值，传至 generate_node_products 和 manifest assembler。旧 pool 在 state.rs 原位置释放也不增加本请求额度。只有 Native lease 且有显式预算时录制 workspace。无预算的直接 Runtime、普通、Owned、v2 和 staging 路径继续原完整 assembler。

入口 keeper cap 调整为 `S7 - legacy`。workspace 的一次消费 rebind_and_replay 返回前已释放原件及正文，早于成功 handler 的 finish_source_keeper 保留新 pool。成功收尾再次读取实际 legacy，只将 keeper cap 降至入口 cap 与当前 `S7 - legacy` 中较小者；余量算不出时丢弃可选 keeper。该方法返回 Option，不把已经 COMMIT 的成功回复改成错误。legacy + 新 keeper 来源费用不得各拿一个 S7。

## 明确来源费用

这是来源字节口径，不是实际 heap 账。沿既有 Keeper 的配方，每个唯一原件收费 `body.len + 97`，97 = digest32 + tag1 + 原件证明64；同一 digest 的相同原件只收一次。每次真实 put 的有序 digest 收32字节，重复 put 也分别收费，保留原次序。

固定证明上下文收费为 `84 + text(content_format) + sum(text(18个metadata/source字符串)) + sum(ref(scope及三个根)) + Built + text(batch_id)`。84 = revision4 + 四个固定 Mode/Flavor 对8 + 冻结预算四个u64值32 + generation/input_frontier/source attempt 三个i64值24 + 两个集合长度u64值16。`text(x)=8+x.len`；`ref(r)=text(format)+text(root)+kind1+extent标记1+存在时extent8`；`Built=摘要32+kind1+extent标记1+存在时extent8`。Scope、根引用的 format/root/kind/extent 与所有元数据字段完整计入，不仅收 root hash。

录制前用最大 Built 表示42字节及固定 batch 文本长度保守预留 header 费用；成功组装后以实际 Built/实际 batch_id 重新 checked 结算，再克隆完整 metadata/roots/manifest/batch 发资格。唯一原件与每次 put 的增量都用 checked 算术，在复制/追加前先核费用不超过冻结 allowance。任何费用不足或内部计数溢出只停止录制、释放原件候选并继续同一个严格 assembler，不能增加额度或减少验证。source_cost 是完整成功 workspace 的实际上述配方费用；recording_peak_source_cost 是包括 header 保守预留的录制峰值，均须满足与入口 legacy/old_pool 相加不超过 S7。

原借用的 4 MiB/65,536 条录制门已移除，content_store 两个 SameMaterial 常量恢复 private。既有 lease 自身素材限制不变。未新增公开资源参数、默认额度或 timeout。测试里的536870912是已明确给定 S7，不是产品默认值或无限测试预算。

## 诊断与安全边界

仍只在 `S_MANIFEST_WORKSPACE_DIAGNOSTICS=1` 时向 stderr 输出阶段 JSON，并忽略 Write 返回错误。每请求 entry 日志含 total/legacy/old_pool/allowance 与 keeper cap；prepare/publish 日志带实际 generation、同份冻结预算、workspace_source_cost 与 recording_peak_source_cost，可以复核 `legacy + old_pool + workspace_source_cost <= total`。累计统计另有 last_workspace_source_cost 和 max_recording_source_cost；最大值不可作差，actual cost 为事件内每 workspace 的读数。

r2 的 recorded_body_capacity、put Vec capacity、overflow 前 entries/body_len/body_capacity 峰值观测保留。现有 lease 素材与 workspace 正文在 prepare 时同时在场，另有 BTreeMap 内部结构、allocator 开销、metadata/String 克隆、读取/Verifier临时体等。来源费用不等于实际 capacity，更不等于整个 heap/RSS/I/O，未宣称全部资源合格。

r2 原件重绑定、所有真实 puts 重放、真实 SQL 出生许可、最终两根 Public fresh、每 cut 完整历史业务/独立索引/catalog、事务回滚和回复边界未改。未扩到被取消的 birth-only/candidate/wire 构造。

## 精确正常验证入口，尚未执行

四提交夹具改用显式预算 context，并每代消费/完成真实 keeper；第二代起必须有实际非空旧池，验证 sharing 不等式与全部持久行、根、可达原件。新增 Driver 三次真实 append 正向测试，以同一显式 S7 对照 warm workspace、cold Native 与 ordinary，比较完整类型化持久行、全部节点、可达原件和回复；核两次实际非空旧池与资格计数。没有故障/坏数据/kill 分支。测试辅助表/可达节点读取函数只扩大测试可见性供 Driver 使用。

在专用验证镜像 rust/ 中执行：

```sh
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::prepared::tests::native_manifest_workspace_four_normal_commits_match_cold_and_ordinary_full_rows -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::driver::tests::source_keeper_driver_workspace_shares_s7_with_nonempty_old_pool_and_exact_rows -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::driver::tests::source_keeper_driver_append_repost_restart_preserves_results_and_request_reuse -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::driver::tests::source_keeper_driver_measured_cap_only_changes_retention -- --exact --nocapture
```

只按精确名称运行，不运行整个测试组，组内存在旧负例。后续真实150151受控服务需沿用原冻结输入和原30秒门，明确开诊断，以实际 issued/rebound/overflow、来源不等式及完整输出/原件对照判断是否值得采用；小 fixture 成功不等于该域有效优化。
