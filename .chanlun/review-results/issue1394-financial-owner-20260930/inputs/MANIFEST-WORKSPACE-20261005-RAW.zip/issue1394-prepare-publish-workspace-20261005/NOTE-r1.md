# #1394 prepare→publish workspace 隔离原型

基线 HEAD 为 `857e76459bb9609127ee13dc9e099879b1257812`。真实源码未修改，未运行 cargo、测试、服务或 SQL。staged 五文件通过 rustfmt 解析和格式化；这不证明类型检查、测试通过或性能改善。`BASE-SHA.json`、`STAGED-SHA.json` 和 `workspace.patch` 给独立评审使用。

最小切片放在成功 `assemble_unpublished` 边界。Native lease 路径用私有 recording store 记录本次完整 scope/三根 codec 核验、schema/坐标核验实际读取的原件，以及 manifest 组装实际 puts。成功后才冻结为字段私有、不可序列化、一次消费的 workspace。普通、Owned、v2、staged-node 路径不发 workspace。

lease 在独立索引暂写、catalog 暂写与 after_prepare hook 之前结束。workspace 仅保留原件和成功计算结果，此间不授予任何准入。publish 仍核当前 Begin/历史发布前沿/域格式。实际 TxStore 重新读取 workspace 每个 digest 的当前 tag/body，逐字节比较；元数据、三根完整 ContentRef、manifest Built/batch 和本二进制规则版本均比较。原件失配继续读完其余记录，使 SQL/type 错误仍传播，然后调用原严格 assembler。超限或缺 workspace 也调用同一 assembler，没有宽松判据。

成功绑定后仅省第二次三根完整 codec 遍历与 schema 重组。第一遍 assembler 的全部 puts 按原顺序真实重放，保留每次真实 put 的 SQL/摘要/原件冲突检查及失败回滚。接着仍从实际暂写的独立 SQL 索引许可出生占位，仍完整 fresh 核最终两根 Public，control/clock/回复/事务 commit 原路径保留。历史业务、所有独立索引与 catalog 的每 cut 准入未改；未扩到 birth-only/candidate/wire 方案，也未实现更大的 DAG 同 epoch 证书框架。

workspace 沿用 `SameMaterial` 两个数值作为新增可选局部缓存资格上限，正文实际 Vec capacity 不超过 4 MiB、原件和 put 序列各不超过 65,536 条。这没有共享既有缓存的内存账。prepare recording 时会与 NativeReadLease 素材同时持有两份正文，另有 BTreeMap 节点、digest、tag、put Vec 和元数据/String 克隆。put Vec 计数受限，其实际 capacity 另记；BTreeMap 内部结构与 DTO 克隆未计入正文上限。因此不声称整堆/RSS 或请求资源资格。512 MiB 来源预算、资源默认值和 30 秒限时均未变。

`ManifestWorkspaceStats` 是 TestOnly feature 的线程局部观测，只含计数与容量，不是证明。`issued/rebound/overflow/rebind_rows/replay_puts/recorded_entries/recorded_body_len/recorded_body_capacity/recorded_put_capacity/max_recording_body_capacity` 用于对照。实际150151域超限且不发资格时，必须报告没有该优化收益；小 fixture issued/rebound 成功不能替代实际域测量。当前收益未知，重读是每个唯一原件一次真实 SQL，当前 TxStore 还执行其原有 F 核验，可能仍比旧重复遍历便宜，也可能因复制成本变慢。

新增正常测试只做三次追加和一次真实修订，warm workspace/cold Native/ordinary 比较全部表的全部类型化持久行和全部节点原件，并比较可达节点、最终两根、batch/receipt 与每代完整 state audit。记录 issued/rebound/overflow 和额外正文实际容量、重放 puts；不调用旧 fault/损坏/kill 测试。

评审及主控允许移入专用验证镜像后，可执行以下精确正常入口，本代理未执行：

```sh
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::prepared::tests::native_manifest_workspace_four_normal_commits_match_cold_and_ordinary_full_rows -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::prepared::tests::native_candidate_union_four_real_commits_match_ordinary_roots_rows_and_revision -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::prepared::tests::real_nonempty_commits_bind_history_and_revision_to_true_control_and_sources -- --exact --nocapture
```

命令工作目录是验证镜像的 `rust/`。第二个是已存在的纯正常提交对照入口，未新增其 candidate 构造。不要运行名称宽匹配或整个 prepared 测试组；其中有旧负例。
