# #1394 Native 原件扫描去分配增量（staged，未编译）

日期：2026-10-05。现有票 #1394 下的隔离增量；交付目录只有 staged 三份源码、一个 patch 和本 NOTE。真实源码 SHA 再核对后未变；未调用 git，未执行 cargo、测试、服务或 SQL。rustfmt 只对 staged 做 `--emit stdout` 语法解析，三个文件 exit=0，丢弃格式化输出；它不做名称、类型、借用或 feature 编译检查。

工作树：`/Users/silencehan/.codex/worktrees/issue1394-audit-prefix/NewChanlun`。派发提供的基线 HEAD：`485820bc6c`；source 指纹：`b2608e9d2b3b83fc50fa18bf40fe32a1f55247454350e5b1ec329a70f83ef9df`。这两个标识沿用派发信息，本子任务未读 git 或重算全仓 source 指纹；下表三份实际文件的 SHA 是本次直接核过的。

## 改动及判据

`staged/rust/src/bin/s_session_v2/content_store.rs:2007` 新增私有 digest 读取函数。三个捕获/扫描入口在 Native feature 下借用 `ValueRef::Blob`，直接转 `[u8;32]`，消除每个有效 digest 的短 Vec owner；非 BLOB 再走原 `row.get::<_,Vec<u8>>(0)`，保留原 rusqlite 类型错误。Native feature 未开时仍执行旧 Vec 读取。每行先 digest 类型/长度，再 tag 类型/域，再 body；三条 `SELECT digest,tag,body FROM s_content_nodes`、ensure_format、rows.next 的错误传播和原件比较均保留。两个 fresh 捕获仍各自取得完整 body Vec owner。equal 扫描正文原本已借用，本补丁不重复修改。

`content_store.rs:2046` 新增 `OriginalScanScratch`；`request_audit.rs:31` 放入 RequestAuditContext 独占字段。`state.rs:183` 仅 Native 请求调用新增 `current_originals_equal_for_request_with_scratch`。旧三参数入口作为兼容包装保留，既有故障测试不改。每次扫描开始先 clear；不把集合里上次内容当当前结论，后续仍完整SQL逐行读到末尾、执行去重/遗漏门，mismatch也不能遮蔽后续Err。请求context的Drop在现有释放trace前显式释放scratch，包括正常结束、错误结束及finish_source_keeper返回Driver。容量不会跟随来源Keeper跨请求转交。

没有增加资源额度或改 S7=512MiB/30s；scratch是普通HashSet容量复用，未纳入整堆资格声明。fresh source-subset函数自身的HashSet仍每次新建；captured body owner、MemoryNodes容器、SQLite读取、旧绑定材料、完整审计/输出等其它分配不由本增量资格覆盖。普通、Owned、deadline入口没有接入scratch，未放宽这些入口或Native既有门。

## 未执行的正常测试

以下测试均在 `v3::request_audit::tests`，只使用 Fixture::new 后的正常完整发布材料，未新建坏数据或故障测试：

1. `request_native_three_capture_entries_borrow_digest_and_match_owned_sql_baseline`（staged request_audit.rs:368）：先按原完整SQL逐行实际构造32字节digest Vec，计成功owner数N；再执行fresh capture、equal scratch、source-subset capture三入口，逐字节核所有tag/body。要求执行计数为3N个borrow、0个digest Vec读取，三个完整节点扫描；两个fresh正文的owner必须独立。
2. `request_native_scan_scratch_reuses_capacity_across_complete_transactions`（:431）：一次cold及四次完整独立事务扫描；首个equal扫描容量实际增长，后三次容量和增长计数不变。要求每次仍读全部节点，最终(1 cold,4 hits)。context释放后完整历史弱引用失效，新请求scratch容量为0并fresh核验。
3. `request_native_scan_scratch_cold_warm_and_legal_append_full_output_equal`（:470）：4阶段正常材料（cold、warm、合法增加codec节点后的cold、再warm），每阶段与独立audit_native_current完整输出canonical bytes对拍，包括raw、cuts metadata/roots/batch/snapshot/delta、objects、auxiliary、clock。合法追加还完整捕获并检验旧原件是source-subset。精确计数要求合法追加mismatch扫描读完整当前集合，再fresh捕获；最终(2 cold,2 hits)。

测试计数是可执行的读取/owner路径计数，不是在源码上搜Vec。`digest_vec_decode_calls`计进入原Vec解码的调用；正常材料应为0。baseline实际成功创建非空Vec owner的次数N，结合三个目标入口borrow计数3N，说明被移除的digest Vec owner路径；**没有安装全局allocator，也没有把这些计数冒称malloc事件、完整heap峰值或生产内存资格**。全量完整对拍、编译/借用检查、执行计数实值仍未取得。

既有离线正常diagnostic每phase新增 `original_scan_scratch_capacity_nodes` 与明确scope，报告的是HashSet可容纳节点数，不假设桶字节数或总heap大小。第二项正常测试同时输出首扫容量增长与后扫增长0。新字段不进入正式回复、canonical业务输出或资源配置。

只供下一轮已获授权的精确正常验证使用的命令（本次未执行；须先把补丁装入另一个明确隔离的完整源码副本，不能直接在当前真实工作树跑）：

```sh
cargo test --offline --features s_capture_native_testonly --bin s_structure_session v3::request_audit::tests::request_native_ -- --nocapture
```

该前缀只选择本补丁三项正常测试；不包含既有fault、bad-data、取消测试，忽略型diagnostic也不会运行。birth-only/wire取消方案没有加入。

## SHA-256

| 文件 | base | staged |
|---|---|---|
| `rust/src/bin/s_session_v2/content_store.rs` | `2dba24c5de30d78dccceba58241c7d41e3cb20466682a1d5283e2e60b29986ad` | `709d646a3f2894ef619abd51a509311a6e9be79542c15cf736a6b4c4a5deb0a5` |
| `rust/src/bin/s_session_v3/request_audit.rs` | `11259aa99634aac39a1b4b8fbb54029f31ae26558cb31401a5f126a0345ba646` | `8ec2f0899e324884b5c5e95685759064059bdd1703530823310b84c0c7c6d6bf` |
| `rust/src/bin/s_session_v3/state.rs` | `0330c0880551d7fbd511c8cde0283fde30e74dbac8f817d203eecc655e91c8f6` | `2ff1f3158c2152836e8ea0678aedf1c2161b44d39a0dfdb0fbe421edeec255c6` |

单patch：`native-scan-scratch.patch`。
SHA-256：`bcc4cfe91a01f1ef5e1fa89031011de00f94c305cbdf48c20584b490556f4203`。

验收状态：静态覆盖/基线SHA/patch三文件范围已核；rustfmt语法解析已核。未编译、未运行，不给运行PASS或性能收益数字；9.81%只沿用派发给定观测，不宣称本次重测。
