# #1394 正常150/151窗口独立事实补审

判定：**PASS（限定正常150、151完整接收、既有 oracle 对照、绑定、来源封条、诊断预算与进程回收）**。`ROOT-RESULT.json` 的该范围结论与实际证据一致。未重扫产品代码、未启动任何服务或测试、未重复窗口、未 SQLite-open 任何数据库；本补审只读 JSON、文件字节、SHA、stat 和 PID存活状态，仅写本报告。

## 完整接收及截止时间

`RESULT.json.state=COMPLETE`，errors/cleanup_errors 为空，接收序号严格为 `[150,151]`。两条 exchange 均为 `Received`、error=null，耗时分别为 **20.694808083秒**、**19.839043791秒**，均小于30秒。每条完整 request wire、reply wire、persistent.json 与 publication-owner 对照文件逐字节一致；request/reply 实际 SHA 与 received_window 记录一致，完整 reply envelope 与 exchange.response 一致，payload 与 received_window.reply 一致。持久证据包含 snapshot、完整持久 oracle 的 SHA 与 canonical长度；两条长度均为939644，完整 oracle SHA 与 received_window 及基线一致。这里没有以选取几个回复字段代替完整 wire/oracle 对照。

实际 Ready 的唯一已发送 wire 与 START-RESULT 完整 reply 和 wire SHA 相符；START-RESULT 为 ready、initialization=null、generation149。从真实 Popen begin_ns 到成功 Ready wire end_ns 为 **24.682828459秒**，小于30秒。216次启动连接探测中仅1次发送 Ready 请求；其余215次 request_bytes=0，不是重发150/151，也不是重启本窗口。控制器仍采用原30秒启动和请求配置。

终态为 generation151、idle、Committed151、published151、clocks453、next_attempt_ordinal152，与 ROOT-RESULT 一致。CopyQualified149 的未接收状态、original105 的 DeliveryUnknown 及既有来源边界保持原记录；本窗口没有拼接成 original9011 重放。

## 来源、绑定与回收

三原件 original_before/original_after 全部相等；独立用二进制读取、lstat 和 SHA 重新核对原件及本次 owned_after 共六个文件，完整记录全部匹配，没有 SQLite连接。

服务为本次 frozen-service，实际 SHA 为 `98e4e61d707f98c0f25a80934f1bf654cc9b5dd4db754ef3edaf768fd5b16726`。BUILD-service.jsonl 的实际 compiler artifact 为 `s_structure_session` bin、profile.test=false，features 为 default/s_capture_native_testonly/s_session；原 compiler executable SHA 与 frozen-service 相同。源码聚合 SHA 为 `c8ead0d4167da9f6af7629cf916371b950e6f5d41f2a8611f012079a11628aa6`，642项当前源码和冻结源码逐项匹配。脚本/ORCHESTRATOR、PYTHON-BINDING 和46项材料哈希全部重新匹配，Controller.json 等于 proposed；没有依赖仅 exit=0 判成功。

唯一真实 Popen 为 PID39632；lifecycle.argv 与 RUNNING-IDENTITY.command 一致，Ready control_instance_id 与 running 记录一致，stop PID相同；exit_code=-15、reaped_by_same_Popen=true，controller_closed=true，cleanup_errors为空，cleanup用时0.08372774999588728秒。补审时 PID已不存在，socket也不存在；被清理 socket 的 device/inode/uid 与运行中 socket身份相同。

原始 stop 记录中的 `exit_observation_warnings=["服务完整参数与本次启动命令不符"]` **仍保留**，没有改成无警告。最终回收结论由同一 Popen 的 wait/退出记录、实际运行参数、PID消失和socket身份清理共同支持，不能只引用 controller_stop.state。

## 诊断与S7

SERVICE-DIAGNOSTICS.log 与本次自有域 controller-state/s.log 字节哈希相同，SHA为 `b55d46b71f1e313820e5f7336808a6df2821b32ce4fea807d33b0b39485d2750`，与ROOT记录一致。每代均恰有一条 prepare-issued 和一条 owner-dropped；两条预算记录相同，allowance+legacy+old_pool=536870912，workspace_source_cost≤allowance。

| generation | allowance | old_pool | workspace_source_cost | source_sum | owner_drops | reused_original_reads |
|---|---:|---:|---:|---:|---:|---:|
| 150 | 154465630 | 382405282 | 42874531 | 425279813 | 1 | 1273104 |
| 151 | 154655198 | 382215714 | 43267617 | 425483331 | 1 | 1283045 |

legacy均为0，total与配置S7均为 **536870912**；两条 source_sum 均未超额，scope_unknown_write_invalidations均为0。ROOT提取的所有 scope_* owner字段与原日志相符。这些是既有 workspace/owner诊断，**没有实际非test OriginalScanScratch capacity、growth或digest借用计数**；测试日志中的 capacity_nodes、growth、digest借用计数不能冒充服务窗口读数。

## 既有测试及feature-off记录

已核TEST-RESULT两项命令的exit=0与对应日志SHA；日志实际为3项 request_native 正常测试加1项 driver append/repost/restart正常测试，合计4 passed。测试记录覆盖冷/暖/合法append完整输出、完整事务间容量复用、三入口digest借用对照、driver结果/请求复用；本补审没有重复运行。

双feature测试构建和实际服务构建均有exit=0及 build-finished.success=true记录。首feature-off命令漏了bin必需的 `s_session`，原CHECK-feature-off-RESULT.json 的exit=101与stderr解释保持完整。随后r2只补 `--features s_session`，exit=0、build-finished.success=true，artifact features仅为default/s_session；native feature保持关闭。这是修正错误检查命令，不是把首次失败改写成成功，也没有重试正常窗口。

## 判定边界

基线耗时21.117401416/20.086794334秒，本次单次减少约 **2.0012% / 1.2334%**；只能描述这两次测量，不证明稳定性能改善、非test scan实际capacity行为或完整9011。strict_peaks仍UNMEASURED，whole_Job/max_store、整体heap/RSS/I/O及目标完成未资格化；ROOT中的full9011_complete、whole_resources_qualified、goal_complete均为false，口径正确。

PREPARATION.json 的旧pending/未执行字段按执行前快照保留，未修改。`root_verify.py` 实际会复制诊断日志并写ROOT-RESULT，故本补审没有重新执行该程序；已阅读其断言与产出逻辑并独立复核上述事实。产品静态独评沿用前轮PASS，不扩大本报告范围。
