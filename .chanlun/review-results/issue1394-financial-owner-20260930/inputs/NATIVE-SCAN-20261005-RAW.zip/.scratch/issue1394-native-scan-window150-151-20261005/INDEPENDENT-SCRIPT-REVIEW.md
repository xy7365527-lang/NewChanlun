# #1394 正常窗口脚本独立静态复核

判定：**PASS / Approve（限定静态脚本与准备绑定）**。相对已审 publication-owner 正常窗口，未发现新增 CRITICAL 或 HIGH 问题。本报告不判定本次服务运行、诊断观测、正常对照或整体资源资格化结果。

复核对象为本目录 `window.py`、`SCRIPT.diff` 及准备绑定；未扫描仓库，未改产品源码，未启动服务、执行 SQL、Cargo 或测试，未新增故障注入或坏数据测试。`git diff --` 对指定两份 Python 文件无输出，因为此工作草稿不在跟踪差异中；另以两份实际文件生成统一差异，确认与 `SCRIPT.diff` 逐字一致。

## 差异与保留约束

- 实际改动仅为输出目录（第4行）、新自有域（第8行）、冻结服务路径断言（第94行）、结果范围说明（第107行）、新 socket（第120行）。没有恢复 birth-only、candidate 或 wire 方案。
- 原封存三文件仅由 `identity` 的 lstat/SHA 与第111行二进制读取复制接触；所有 SQLite 入口封装在 `CopiedOwned.read`，实例只绑定本次 OWN 的 `s.sqlite`（第114行）。复制前/后与最终三文件完整 stat/SHA 检查保留（第104、113、153行），没有原件 SQLite-open 路径。
- 30秒启动与完整请求配置保留（第119、130行），S7 为 `536870912`（第121行）；本次 proposal 与原配置应用这几项授权变更后的对象完全相等。请求仍严格为原始第150、151条，保留原 LF。
- 第90行拒绝已有 result/domain；第142行首次异常进入 `FAILURE_PRESERVED`，没有重试或重发分支。来源149仍为持久已提交但未收到回复，来源 Unknown 与 original105 DeliveryUnknown 保留，没有改成 Received。
- 第41–58行跟踪真实 `subprocess.Popen`，只允许 serve；第60–87行对同一 Popen 执行 terminate/wait/kill/wait 并登记实际回收结果，仍先回收后采证。COMPLETE 条件仍要求无错误、回收成立、原件封条不变（第155–158行）。
- `runtime.exchange_once`、`evidence.validate_receipt`、wire、完整 payload 与持久 oracle 的调用和保存均未变化（第132、138–140行），依赖的绑定文件哈希也未失配。本次差异没有削弱原完整响应校验与证据持久化。

## 绑定核验

- 脚本 SHA-256：`2ad02edf44f43b41cefd553365909c3984cb577364e9a3eb115ddb248f180b7d`，匹配 ORCHESTRATOR-BINDING；PYTHON-BINDING 的 SHA 与其绑定相符，46项 Python/材料文件全部相符。
- 新 binary.path 精确为本工作树 `.scratch/issue1394-native-scan-scratch-20261005/frozen-service`；实际服务 SHA 匹配 binding，`compiler_artifact_profile_test=false`、`target_kind=["bin"]`、`target_name=s_structure_session`。
- SOURCE.json 的642项冻结源码逐项哈希全部相符；按清单声明公式重算的聚合 SHA、清单与服务 binding 均为 `c8ead0d4167da9f6af7629cf916371b950e6f5d41f2a8611f012079a11628aa6`。
- SOURCE-LIST 的 source_result SHA、三原件封条记录与前窗口 owned_after 一致；publication-owner 基线 ROOT-RESULT、RESULT 和 runner SHA 均相符。本复核没有重新打开原件数据库。
- Python AST 解析通过；当前 PATH 没有 ruff、mypy、pylint 或 black，未安装工具或扩大检查范围。

准备状态的时间边界：静态检查期间服务 binding 已出现，随后本次 OWN、RESULT.json 和 execution 也已存在，说明根任务已占用本窗口。PREPARATION.json 仍是准备时的 `PREPARED_WAITING_SERVICE_BINARY`/pending 记录；本报告不据此否定当前 binding，也不将其冒充最新运行状态。第90行此时应拒绝再次运行，根任务须用首次实际结果验收，禁止重试此域。

产品三文件补丁 PASS、正常测试与编译产物生成来源的独立验收仍由根任务负责，本报告没有重复或扩大该范围。
