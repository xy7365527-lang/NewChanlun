# #1394 Native digest 借用与 OriginalScanScratch 正常窗口准备

这是 #1394 的工作草稿，只准备独立的正常 150、151 窗口。未启动服务，未执行 SQL、Cargo 或测试。已复用通过的 `.scratch/issue1394-publication-owner-window150-151-20261005/window.py`，仅替换本次具名域、说明、来源清单与服务绑定路径，并加上冻结服务路径检查。差异见 `SCRIPT.diff`。

## 本次路径与来源

- 窗口目录为 `.scratch/issue1394-native-scan-window150-151-20261005/`。
- 新自有数据库域为 `/Volumes/AgentStorage/issue1394-native-scan-window150-151-20261005-r1/`。
- 新 socket 为 `/private/tmp/nc1394-natscan150-151-20261005-r1.sock`。
- 冻结服务必须为 `.scratch/issue1394-native-scan-scratch-20261005/frozen-service`。
- 来源仍是 `.scratch/issue1394-root-text-window143-160-20261004/RESULT.json` 封存的 CopyQualified149。原件为 `/Volumes/AgentStorage/issue1394-root-text-window143-160-20261004-r1/` 下的 `s.sqlite`、`s.sqlite-wal`、`s.sqlite-shm`。`SOURCE-LIST.json` 保留其既有 stat/SHA 封条和对照窗口来源。

原件只能按字节复制、取 stat 和 SHA-256，禁止 SQLite-open。所有 SQL 仅在本次新自有副本上执行。来源149虽然持久提交，但没有已接收回复，Unknown 继续保留；本窗口不会将它改写为 Received，也不接续 original9011。

## 运行前条件

1. 主控完成三文件补丁的独立验收、冻结源码与服务构建，并在本窗口目录写入 `BINARY-BINDING-service.json`。该文件必须包含实际 compiler artifact、非 test 的 `s_structure_session` bin、`binary.path` 与 SHA-256、`source_manifest`、`source_aggregate_sha256`、`fixed_source` 及构建绑定证据。不可从旧服务复制哈希或伪造完成记录。
2. `binary.path` 必须等于上述冻结服务路径。`source_manifest` 应指向本次补丁的 `SOURCE.json`，`fixed_source` 应指向与该实际服务对应的冻结源码。主控核对源码清单聚合 SHA 与 binding 一致；runner 在运行时重新核实服务 SHA、清单逐项源码 SHA、脚本与 Python/材料依赖 SHA。
3. `PREPARATION.json`、`Controller.proposed.json`、`PYTHON-BINDING.json`、`ORCHESTRATOR-BINDING.json` 保留本次准备记录。若修改脚本或材料，必须先更新对应绑定；不得在失败后通过修改它们重试本域。
4. 本次新自有数据库域、socket、本窗口 `RESULT.json` 和 `execution/` 均尚不存在。AgentStorage 已挂载且有本次复制所需空间。原件封条与来源生命周期必须通过 runner 的运行前检查。

启动与每次完整请求的截止时间均为 30000 ms。S7 固定为 `536870912`，其余资源配置沿用已批准窗口。只发送原始输入第150和151条，不故障注入、不写坏数据。首次意外失败保留原状态和完整证据，不重试。

## 唯一运行命令

从本工作树执行一次，输出保留在本窗口目录：

```bash
cd /Users/silencehan/.codex/worktrees/issue1394-audit-prefix/NewChanlun
/Users/silencehan/.local/bin/python3.12 -B .scratch/issue1394-native-scan-window150-151-20261005/window.py > .scratch/issue1394-native-scan-window150-151-20261005/RUN.stdout 2> .scratch/issue1394-native-scan-window150-151-20261005/RUN.stderr
```

`window.py` 把业务异常写入 `RESULT.json`，退出码本身不能证明成功。不得用“进程退出为0”代替结果验收。

## 运行后的必要验收

- `RESULT.json.state` 为 `COMPLETE`，实际 Ready 对应唯一 serve Popen，接收窗口严格为 `[150,151]`。每条保留完整请求、wire reply、payload 与持久 oracle；用既有 evidence 校验并与 publication-owner 对照窗口逐条比对回复及持久 oracle。
- 两条完整交换均在30秒内，terminal 严格为 generation151、idle、Committed151、published151、clocks453、next_attempt_ordinal152。若失败，保留首次失败序号、未发送尾部与持久状态，禁止重发。
- 取本次自有域 `controller-state/s.log`，原样复制到本窗口 `SERVICE-DIAGNOSTICS.log` 并登记 SHA。检查两次既有 workspace qualification、source_sum 与 allowance/old_pool 总额；S7仍为536870912。记录 Native digest 借用与 OriginalScanScratch 的实际 capacity、来源成本、drop/reuse 证据，若日志没有覆盖某项则照实标为未观测，不以补丁文本代替运行证据。
- `original_before` 与 `original_after` 的三原件完整 stat/SHA 相等；本次源码、binary 和所有材料 binding 在收尾再次核验。SQL不得触及原件。
- 同一 Popen reaped，controller closed，owned socket removed，cleanup_errors 为空，cleanup 证据完整。保留新自有数据库、完整 execution 证据、stdout/stderr 和首次失败原状。
- 主控写 `ROOT-RESULT.json`，把对照、deadline、binding、源封条、cleanup 与诊断的观察结果各自写实。通过本窗口只证明正常150/151这一范围，不宣称完整9011、全部历史规模或整体 heap/RSS/I/O 资格化。

本准备不恢复取消的 birth-only、candidate 或 wire 方案，不扩大资源门，不涉及前端。原件105、来源126/142/149的 Unknown 状态保持既有边界。
