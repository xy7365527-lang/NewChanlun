# #1394 固定 capture 历史双投影 staged 补丁

仅 `.scratch/issue1394-projection-sweep-20261005/staged/rust/src/bin/s_session_v3/object_index.rs` 改动，真实源码、binary、运行中的 9011 未碰。此目录是工作草稿，不入仓、不提交。原件及副本 SHA 见 STAGED-RESULT.json；projection-sweep.patch 是单文件可审阅补丁。当前正式运行停止前不应用。

## 改动与成本

HistorySweep 的 by_id、birth/death 事件和 active 主序 rank 提取为不可变 HistoryEvents，用 Arc 在两个本轮游标之间共享。累计 withdrawn 独立以原 ordering(..., true) 排序建 rank，不能借用 activity rank。初始化各主序排序一次。旧 before-g 成员/changes 游标保持 `<g` 边界，双投影 through-g 游标保持 `<=g` 边界，两者不混用状态。

双投影改成事件范围推进，重复 cut 不推进，跳跃推进跨过的全部事件，回退先撤销 death 再撤销 birth。生产判据要求 withdrawn_generation 严格晚于 first_known_generation，birth==death 不在合法实际域内；本补丁不改这条判据。BTreeSet 以 `(rank, original_ordinal)` 保留原稳定平局，births 维持原件插入序。所有活动、累计撤回及本代出生成员仍生成完整 Template/Public 数组，逐对象 published/batch/lifecycle 和 capture 闭包判据保持。既有两phase wire memo 没新增缓存；局部 Template/Public pair 表只缓存本代出生项。

设 N 为固定索引对象总量，E 为撤回事件数，G 为 cut 数，M_g=A_g+D_g+B_g。初始化及共享事件表 O(N log N)；单调 through-g 游标跨过每个 birth/death 一次，事件更新合计 O((N+E) log N)。各 cut 仍有事件树定位 O(log N)、完整输出 O(M_g)，本代 pair 查找 O(B_g log B_g)，节点闭包/codec/可达字节处理还要另计。故不能声明整个历史审计线性，不能从设计成本断言实际提速。

额外常驻空间是 withdrawn rank 的 N 个 usize，以及 through-g 的 active/withdrawn 两棵 BTreeSet。合法生命周期中两集合总成员数至多 N，树节点有额外布局成本。旧 before-g active 集合仍存在，birth/death/by_id/rank 表只共享一份。每cut原选中成员列表和双数组工作集仍 O(M_g)，pair 表从 O(A_g+D_g) 缩至 O(B_g)。这是当前完整 Native/BudgetNone audit 私有标准容器状态，不代表 Owned/总体资源预算已经资格化。普通、Owned、deadline、计费入口均未搬到新事件容器；generic at_cut_projected 的原扫描/排序保持。

## 已准备但未执行的验证

旧完整双投影算法仅作为 cfg(test) 参照，不接生产重判/失败兜底。新增正向入口 `v3::object_index::tests::native_history_projection_sweep_positive_real_generations_complete_roots_and_material` 唯一调用 `real_generations(true, false, false)`。它只使用真实正常输入、合法修订和完整load的索引。512个单调cut计数检查接在该load之后，显式断言所有撤回对象 first<death；另外覆盖重复/跳跃/回退，不使用旧抽象birth==death夹具。完整双投影检查比较六根及全部可达tag/body，并比较公开可达值，核事件表共享与完整输出项计数。没有放宽生产生命判据，没有新增故意坏数据、故障注入或负例框架。

三个既有 real_generations 测试入口均显式传 `include_legacy_negative_cases=true`，保留原行为，本轮禁止执行。新入口唯一传false，结构上隔离五处旧代码：① g3混合producer候选，仅true且g==3；② union坏root/触发器，仅true且native_union且g==1；③ g2 wrong[common].immutable=corrupt，仅true且g==2；④ foreign capture与budget拒绝，仅true；⑤末尾 UPDATE immutable_root=generated_root及对应拒绝检查，仅true。false路径连末尾该事务也不创建。旧抽象事件测试的birth==death只是绕过load的历史内部夹具，本次新增512cut与正向实际路径不援引或执行它。

待正式运行停止、主控决定应用并允许验证之后，只精确选择新增正向入口，可用以下命令。此命令未运行，不可把它当成当前验证结果。

```sh
cargo test --offline --features s_capture_native_testonly --bin s_structure_session v3::object_index::tests::native_history_projection_sweep_positive_real_generations_complete_roots_and_material -- --exact --nocapture
```


本轮只对副本运行 rustfmt，退出0，说明语法可解析并已格式化。git diff --no-index --check 未打印空白错误，退出1仅因存在差异。未 cargo、未编译、未测试、未打开DB、未启动服务、未 commit，因此借用/type/语义/资源/速度均未获得运行验收。原件SHA再次比对相同。9011状态与后续应用/编译决策仍由主控持有，不作成功或进度保证。
