> r1 历史冻结，仅保留旧审阅对象。源码快照由 `patch/r1-publication-material-owner.patch` 重建；当前 staged/ 和 NOTE.md 已是收紧发行口后的最终版本。不得把本 r1 作为最终交付。

# #1394 发布材料 owner 最小切片（隔离冻结）

真实工作树：`/Users/silencehan/.codex/worktrees/issue1394-audit-prefix/NewChanlun`。主控报告当前 Git 身份 `22798a2960005663938573c14eb826d82a1f751c`；Rust 字节仍为其已验真实来源 `047825708159e6c671390807f9c7a88ffda2f5037577560ea66c2ed10cd21f08`。本 patch 是相对当前真实字节的六文件增量；冻结时已逐个核验下述六文件来源摘要相同。

仅在本目录写 `staged/`、`patch/` 和本 NOTE；真实源码、Git、旧证据均未修改。未运行 cargo、测试、服务或 SQL。`rustfmt --edition 2021 --config skip_children=true` 解析及 `--check` 均 exit=0，这不构成类型检查、编译或运行验证。

Patch SHA-256：`9e5c9fbd9fd830b6dedd5ce49490a36d8921d2cc2cd6fa1b2b3587f53f55a4da`。

六文件来源清单文本 SHA-256：`5cb2a5e3fa2ff3b8fd0715a65352d726555b50637350a3485b11a15c7507a41a`；staged 清单文本 SHA-256：`2150e7798d914a0e4e4c373dc04edf067d4670e65b0c6e79e53d95281bb6ae0c`。清单算法为按相对路径排序、每行 `hex摘要  相对路径`、末尾一个换行，再作 SHA-256；不是主控的九文件 aggregate 配方。

## 封闭范围与资格来源

仅有 workspace 的 Native 发布入口改借 `&mut Transaction`；无 workspace、staged、ordinary、Owned、v2 仍进原 TxStore 完整 assembler。私有 `NativePublicationLease` 只暴露固定 resolve 内部实现，不提供 SQL、connection、hook、Deref、savepoint 或外部 callback；租约及 `PublicationMaterialStore` 的字段、构造器均为模块私有，不可序列化或从外部构造资格。

真实 Begin/scope 和当前前沿仍读当前事务。租约前复用既有 Native 活动事务、隔离/格式及 schema 效果门；原件资格只由本事务每行真实 SQL、F 和全正文逐字比较产生。上下文含 revision、format、完整 metadata/roots、manifest Built 和 batch_id，全部仍比较；上下文或原件失配也读完所有原件，然后走原严格 assembler。同一 workspace 的 map 直接移入租约，无完整 map/body 第二份复制；本切片仅复用 SQL 取材，复用读取仍重新 F 和 codec，未引入 codec 结论缓存。

原录制的有序 puts 仍逐个调用原 `put_before_write`：摘要、真实 SELECT、存量正文逐字比较以及实际 INSERT 保留。重放期材料暂不授予随后读取资格，只有全部 writes 属 Noop 或现有 schema 加实际 `total_changes/changes` 证明的单目标 insert 才安装 base。未知 SQL 效果禁止安装或清空整个 base；并非以 INSERT 这个字面决定保留。每个真实 put 都取消目标原件；重放完成后取消全部重放目标，发布阶段后续 puts 在操作前取消目标。目标首次及之后读取都走实际 SQL/F，本切片不额外恢复其 warm 资格。

固定 `resolve_indexed_templates` 闭包继续读实际暂写独立出生索引、执行原许可判断、替换和 puts，再执行最终两根 Public `verify_many_fresh`。该固定 helper 的非测试调用链仅有独立索引 SELECT，没有绕过 NodeStore 的节点 UPDATE/INSERT/DELETE 或 callback 配置。material store 在 fixed resolve 返回前显式 drop，早于后续 Commit 原 SQL 和新 keeper 保留；不返回 owner、capture、cache 或 bool 给 Commit。

## 预算与诊断

沿用 `.scratch/issue1394-manifest-shared-budget-20261005/NOTE.md` 的同一 S7 冻结额度和来源配方，不新建预算框架，不提高 S7 或 30 秒期限。workspace source_cost 仍保守收费整份已录制原件和原 puts；被取消的目标会提前释放，费用不返还、不用释放额追加资源。

本切片没有新增常驻完整池、去重 hit 集合或 working-frame memo。复用 read 只克隆当前一份节点返回体，执行原 fresh F；rebind 只暂持一个当前 SQL 行正文与已录制 body 比较。现有 prepare Native 小素材 memo、原 BTreeMap 结构/allocator、metadata/String、Verifier 及返回体暂存仍不被 source_cost 证明为全 heap/RSS 资格。诊断新增 owner 实际 body capacity 和绑定/剩余条数，不混为字节预算。

开启既有 `S_MANIFEST_WORKSPACE_DIAGNOSTICS=1` 时，每个 owner 闭包结束后只输出一个 `publish-material-owner-dropped` 事件，含实际 generation、原冻结 budget/source_cost、scope_bound_originals、scope_remaining_originals、scope_owner_body_capacity、scope_rebind_sql_rows、scope_reused_original_reads、scope_fallback_sql_reads、scope_put_sql_checks、scope_unknown_write_invalidations 和 scope_owner_drops；stderr 写失败不改业务结果。没有逐节点日志。reused_original_reads 是命中次数，**不是不同 digest 的唯一计数**；fallback_sql_reads 包含实际 rebind SQL reads，put 的原 SQL 检查单独计数。可用 fallback 减 rebind 行数观察后续 fallback，但不得把跨作用域累计 max 作差。

## 尚未执行的纯正常验证

新增合法存量 Noop / 新节点 insert 测试，验证实际 rebind SQL/F 次数、随后 warm 读不发 SQL、每次合法 put 后目标首次 cold SQL/F、未改旧原件保留、退出后重新 SQL；无坏数据、故障、取消、wire 或 birth-only 改造。既有四提交测试含正常 append 和 revision，继续完整回复、全部持久行、全部节点及可达字节对拍，并新增实际命中、fallback、put 检查和 owner 释放断言。Driver 三次正常 append 保留完整结果/节点/可达字节及统一来源额度对拍，并增加同样断言。

只在主控批准的验证镜像 `rust/` 运行以下精确入口，禁跑含旧负例的整组：

```sh
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session content_manifest::tests::native_publication_material_owner_normal_puts_keep_base_and_read_targets_cold -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::prepared::tests::native_manifest_workspace_four_normal_commits_match_cold_and_ordinary_full_rows -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::driver::tests::source_keeper_driver_workspace_shares_s7_with_nonempty_old_pool_and_exact_rows -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::driver::tests::source_keeper_driver_append_repost_restart_preserves_results_and_request_reuse -- --exact --nocapture
cargo test --offline --release --features s_capture_native_testonly --bin s_structure_session v3::driver::tests::source_keeper_driver_measured_cap_only_changes_retention -- --exact --nocapture
```

后续真实150/151使用原冻结输入、显式原 S7 和 30 秒门，开启同一个诊断开关；核 owner 命中/fallback、总来源不等式和完整输出/节点/可达原件。这里没有性能、编译或测试通过的结论，资格是否改善真实窗口只能据主控独立验证及这些实际计数裁定。

## 来源六文件 SHA-256

```text
27c4e9aaf6dc029cf05190b1803caf25f96bf915b4b5c0b88a8af430da8c2612  rust/src/bin/s_session_v2/content_manifest.rs
eb5bce6a10d37b63141cf9d1b0a8b00b4c242bba6c65f2ca60b1b349db0b9c8f  rust/src/bin/s_session_v2/content_publication.rs
88d6f47d711dd3a32ed28bbd11b1e656b7a7782949bd761ed2db4ba6f34cd4e5  rust/src/bin/s_session_v2/content_store.rs
846069abe8adb032ab4ff02feff1f168a078525e3422c4550f8d6e57e9254962  rust/src/bin/s_session_v3/commit.rs
c97c819050788163e13344f52ea37e4abe5eefa122a0eb680276daade487bc37  rust/src/bin/s_session_v3/driver.rs
84fca4827daa72a4d900158cd2f576512e7021e74045c44e466625b9d27d54dc  rust/src/bin/s_session_v3/prepared.rs
```

## staged 六文件 SHA-256

```text
7293c0bdbba3eea19f16eb4a7fe4ea7f6a699362f71b0be55a4763a08230fdd4  rust/src/bin/s_session_v2/content_manifest.rs
82509dd8d96b4acd6e5b5c3ad43b29d72dd8aaf63dcce8e265b92b727685574a  rust/src/bin/s_session_v2/content_publication.rs
2dba24c5de30d78dccceba58241c7d41e3cb20466682a1d5283e2e60b29986ad  rust/src/bin/s_session_v2/content_store.rs
cf2a26adf70ad587392ef255c5a2ab7d72df10f88b654d72614867afa68799b5  rust/src/bin/s_session_v3/commit.rs
997c53ceacc64436c5f64dbc782fa8d6f20862a0e26d7818750f2566b69894a9  rust/src/bin/s_session_v3/driver.rs
357c8df42e8bc28284eb45d1925c3742dd860c18357910082dd0d2e525dbe44b  rust/src/bin/s_session_v3/prepared.rs
```
