"""#1394 existing typed Controller with frozen Rust Q3, bounded actual lifecycle."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ATTEMPT = HERE / 'attempt1'
ATTEMPT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / 's_session'))
import s_service_control as control

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fingerprint(path):
    if not path.exists():
        return {'exists': False}
    st = path.stat()
    return {'exists': True, 'bytes': st.st_size, 'sha256': sha(path), 'mtime_ns': st.st_mtime_ns}

def db_files(path):
    return {suffix: fingerprint(Path(str(path) + suffix)) for suffix in ('', '-wal', '-shm')}

def emit(phase, **values):
    entry = {'phase': phase, 'monotonic_ns': time.monotonic_ns(), **values}
    with (ATTEMPT / 'events.jsonl').open('a') as f:
        f.write(json.dumps(entry, ensure_ascii=False) + '\n')
    print(json.dumps(entry, ensure_ascii=False), flush=True)

old = ROOT / '.scratch/issue1394-q3-http-runtime-20260930'
small = ROOT / '.scratch/issue1394-financial-reader-small-20260930'
binding = json.loads((old / 'BINDING.json').read_text())
inputs = json.loads((small / 'INPUTS.json').read_text())
source = Path(inputs['source_db'])
binary = Path(binding['binary'])
resources = Path(binding['resources'])
assert sha(binary) == binding['binary_sha256']
assert sha(resources) == binding['resources_sha256'] == '50ea5bf865de8a37d8187069d70bee85ca4caac9c759a60ad2e3c717743d4eb1'
assert sha(source) == inputs['source_db_sha256']
source_before = db_files(source)
holders = subprocess.run(['lsof', str(source), str(source) + '-wal', str(source) + '-shm'], capture_output=True, text=True)
(ATTEMPT / 'source-lsof.stdout').write_text(holders.stdout)
(ATTEMPT / 'source-lsof.stderr').write_text(holders.stderr)
assert holders.returncode == 1 and not holders.stdout and not holders.stderr, 'source has holders or lsof unavailable'
time.sleep(.2)
source_stable = db_files(source)
assert source_stable == source_before, 'source DB/WAL/SHM unstable'
assert not source_before['-wal']['exists'] or source_before['-wal']['bytes'] == 0, 'nonempty WAL requires readonly backup; no copy performed'
write(ATTEMPT / 'source-preflight.json', {'before': source_before, 'second_sample': source_stable, 'lsof_returncode': holders.returncode, 'no_open_holders': True, 'copy_method': 'byte copy main after zero WAL and no holder validation; no SQLite connection to original'})
originals = ATTEMPT / 'originals'
originals.mkdir()
for name, path in {
    'OLD-BINDING.json': old / 'BINDING.json', 'SMALL-INPUTS.json': small / 'INPUTS.json',
    'input-1.json': small / 'input-1.json', 'clock.json': small / 'clock.json',
    'query-resources.json': resources, 'catalog.json': ROOT / 's_session/catalog/signed-catalog.json',
    'profile.json': ROOT / 's_session/profiles/ohlc_integer_tb02a_v1.json',
    'S-RESOURCE-PLAN.json': ROOT / 's_session/tests/fixtures/tb01c/runtime-plan.json',
    's_service_control.py': ROOT / 's_session/s_service_control.py',
    's_socket_client.py': ROOT / 's_session/s_socket_client.py',
    'q_serve.rs': ROOT / 'rust/src/bin/s_session_v3/q_serve.rs',
    'q_runtime.rs': ROOT / 'rust/src/bin/s_session_v3/q_runtime.rs',
    's_structure_session.rs': ROOT / 'rust/src/bin/s_structure_session.rs',
    's_structure_session': binary,
}.items():
    shutil.copyfile(path, originals / name)
python = Path(sys.executable).resolve()
probe_argv = [str(python), '-c', "import json,sysconfig; print(json.dumps([sysconfig.get_config_var(k) for k in ('LIBDIR','LDLIBRARY','PYTHONFRAMEWORK','PYTHONFRAMEWORKPREFIX')]))"]
probe = subprocess.run(probe_argv, capture_output=True, check=True)
(ATTEMPT / 'python-probe.stdout').write_bytes(probe.stdout)
write(ATTEMPT / 'python-probe.json', {'argv': probe_argv, 'executable_sha256': sha(python), 'python_version': sys.version})
plan = json.loads((ROOT / 's_session/tests/fixtures/tb01c/runtime-plan.json').read_text())
input1 = json.loads((small / 'input-1.json').read_text())

def raw_ready(port, out):
    request = b'GET /api/ready HTTP/1.0\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n'
    with socket.create_connection(('127.0.0.1', port), timeout=3) as conn:
        conn.settimeout(3)
        conn.sendall(request)
        chunks = []
        while True:
            data = conn.recv(65536)
            if not data:
                break
            chunks.append(data)
    response = b''.join(chunks)
    header, body = response.split(b'\r\n\r\n', 1)
    (out / 'ready.request.http').write_bytes(request)
    (out / 'ready.response.http').write_bytes(response)
    (out / 'ready.response.body').write_bytes(body)
    assert header.split(b'\r\n')[0].split()[1] == b'200'
    return json.loads(body)

def pure_negative_checks(controller, cfg, out):
    fake = {'service': 'q', 'pid': 2147483647, 'db': cfg['db'], 'command': [cfg['binary'], 'query-serve'], 'process_identity': 'synthetic-expected-identity', 'control_instance_id': 'synthetic-expected-nonce'}
    controller.save_record('q', fake)
    with patch.object(control, 'process_identity', return_value='synthetic-foreign-identity'), patch.object(control.os, 'kill') as kill:
        try:
            controller.stop('q', signal.SIGTERM)
        except ValueError as exc:
            pid_error = str(exc)
        else:
            raise AssertionError('foreign PID identity accepted')
        assert not kill.called
    controller.record_path('q').unlink()
    body = {'ok': True, 'cut': {'session_id': cfg['session_id'], 'session_generation': cfg['session_generation']}, 'producer_epoch': cfg['query_epoch'], 'control_instance_id': 'synthetic-foreign-nonce'}
    with patch.object(controller, 'status', return_value={**fake, 'state': 'running'}), patch.object(control, 'read_health', return_value=body), patch.object(controller, 'confirm_ready_process') as confirm, patch.object(control.os, 'kill') as kill:
        try:
            controller.wait_ready('q', query_epoch=cfg['query_epoch'], deadline=time.monotonic() + .08)
        except TimeoutError as exc:
            nonce_error = str(exc)
        else:
            raise AssertionError('foreign nonce accepted')
        assert not confirm.called and not kill.called
    result = {'scope': 'pure validation of existing Controller using explicit synthetic PID/HTTP observations; no real foreign process and no signals', 'foreign_identity_rejected': pid_error, 'nonce_rejected': nonce_error, 'kill_calls': 0, 'ready_confirm_calls': 0}
    write(out / 'NEGATIVE.json', result)
    return result

def run_one(name, stop_signal):
    out = ATTEMPT / name
    out.mkdir()
    db = out / 's.sqlite'
    shutil.copyfile(source, db)
    db.chmod(0o444)
    db_before = db_files(db)
    port_probe = socket.socket()
    port_probe.bind(('127.0.0.1', 0))
    port = port_probe.getsockname()[1]
    port_probe.close()
    cfg = {'schema_revision': 's-launcher/2', 'session_id': inputs['session_id'], 'session_generation': inputs['session_generation'], 'source_namespace': input1['source_namespace'], 'source_epoch': input1['source_epoch'], 'producer_id': input1['producer_id'], 'producer_epoch': input1['producer_epoch'], 'writer_epoch': inputs['writer_epoch'], 'query_epoch': '1', 'delivery_retain_generations': str(json.loads((small / 'init.stdout').read_text())['delivery_retain_generations']), 'port': str(port), 'startup_timeout_ms': str(plan['startup_timeout_ms']), 'db': str(db), 'socket': '/private/tmp/q3c-' + hashlib.sha256(str(out).encode()).hexdigest()[:16] + '.sock', 'binary': str(originals / 's_structure_session'), 'python': str(python), 'catalog': str(originals / 'catalog.json'), 'profile': str(originals / 'profile.json'), 'clock_plan': str(originals / 'clock.json'), 'browser': str(ROOT / 's_session/browser/index.html'), 'query_resource_config': str(originals / 'query-resources.json'), 's_resources': plan['s_resources']}
    write(out / 'config.json', cfg)
    cfg = control.read_config(out / 'config.json')
    write(out / 'resolved-config.json', cfg)
    controller = control.Controller(cfg, out / 'state')
    proc = None
    result = {'signal': signal.Signals(stop_signal).name, 'port': port, 'db_before': db_before}
    try:
        result['negative'] = pure_negative_checks(controller, cfg, out)
        deadline = time.monotonic() + int(cfg['startup_timeout_ms']) / 1000
        env = controller.runtime_environment(deadline)
        safe_keys = ('PYO3_PYTHON', 'LD_LIBRARY_PATH', 'DYLD_LIBRARY_PATH', 'DYLD_FRAMEWORK_PATH')
        write(out / 'environment-declaration.json', {'method': 'existing Controller.runtime_environment', 'explicit_python': cfg['python'], 'inherited_values_not_exported': True, 'configured_keys': [k for k in safe_keys if k in env], 'keys_only_sha256': hashlib.sha256(json.dumps(sorted(env)).encode()).hexdigest()})
        argv = [cfg['binary'], 'query-serve', '--protocol-revision', 's-session/3', '--db', cfg['db'], '--resource-config', cfg['query_resource_config'], '--producer-epoch', cfg['query_epoch'], '--host', '127.0.0.1', '--port', cfg['port']]
        write(out / 'start-args.json', {'method': 'Controller.start_process', 'service': 'q', 'argv': argv, 'requested_signal': result['signal']})
        emit('start_process', instance=name)
        proc = controller.start_process('q', argv, env, deadline=deadline)
        result['pid'] = proc.pid
        result['uid'] = os.getuid()
        initial = controller.status('q')
        write(out / 'status-after-start.json', initial)
        emit('wait_ready', instance=name, pid=proc.pid)
        ready = controller.wait_ready('q', query_epoch=cfg['query_epoch'], deadline=deadline)
        write(out / 'controller-ready.json', ready)
        raw = raw_ready(port, out)
        assert raw == ready['reply'], 'production ready raw body differs from Controller returned body'
        assert raw['cut']['generation'] == '1'
        running = controller.status('q')
        write(out / 'status-ready.json', running)
        assert running['state'] == 'running' and running['pid'] == proc.pid
        assert raw['control_instance_id'] == running['control_instance_id']
        assert control.process_identity(proc.pid, argv) == running['process_identity']
        result.update({'ready_state': ready['state'], 'control_instance_id': running['control_instance_id'], 'process_identity': running['process_identity'], 'raw_ready_equals_controller_reply': True})
        emit('stop', instance=name, pid=proc.pid, signal=result['signal'])
        stopped = controller.stop('q', stop_signal)
        write(out / 'controller-stop.json', stopped)
        result['stop_receipt'] = stopped
        result['exit_code'] = proc.wait(timeout=int(cfg['startup_timeout_ms']) / 1000)
        result['reaped'] = proc.poll() is not None and control.process_identity(proc.pid, argv) is None
        after_status = controller.status('q')
        write(out / 'status-after-reap.json', after_status)
        listener = subprocess.run(['lsof', '-nP', '-a', '-iTCP:' + str(port), '-sTCP:LISTEN'], capture_output=True, text=True)
        (out / 'listen-after-stop.stdout').write_text(listener.stdout)
        (out / 'listen-after-stop.stderr').write_text(listener.stderr)
        result['no_listen_after_stop'] = listener.returncode == 1 and not listener.stdout and not listener.stderr
        rebind = socket.socket()
        rebind.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            rebind.bind(('127.0.0.1', port))
            result['rebind_after_reap'] = True
        finally:
            rebind.close()
        result['db_after'] = db_files(db)
        result['db_main_bytes_unchanged'] = result['db_after']['']['sha256'] == db_before['']['sha256']
        result['db_wal_no_structure_write'] = not result['db_after']['-wal']['exists'] or result['db_after']['-wal']['bytes'] == 0
        assert stopped['state'] == 'stopped' and after_status['state'] == 'stopped' and result['exit_code'] == 0 and result['reaped'] and result['no_listen_after_stop'] and result['rebind_after_reap'] and result['db_main_bytes_unchanged'] and result['db_wal_no_structure_write']
        result['status'] = 'PASS'
        emit('reaped', instance=name, pid=proc.pid, exit_code=result['exit_code'])
    except BaseException as exc:
        result.update({'status': 'FAIL', 'error': repr(exc)})
        raise
    finally:
        if proc is not None and proc.poll() is None:
            # Only this exact owned child; existing Controller must validate before signal.
            cleanup = controller.stop('q', stop_signal)
            result['failure_cleanup'] = cleanup
            result['cleanup_exit_code'] = proc.wait(timeout=int(cfg['startup_timeout_ms']) / 1000)
        controller.close()
        write(out / 'RESULT.json', result)
    return result

emit('preflight_complete', source_sha256=inputs['source_db_sha256'])
results = []
try:
    results.append(run_one('sigterm', signal.SIGTERM))
    results.append(run_one('sigint', signal.SIGINT))
finally:
    source_after = db_files(source)
    write(ATTEMPT / 'source-after.json', source_after)
    assert source_after == source_before, 'original source main/WAL/SHM changed'
manifest = {'schema_revision': 'issue1394-actual-controller-manifest/1', 'ticket': 1394, 'status': 'PASS_BOUNDED_EXISTING_CONTROLLER_Q3', 'worktree_head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(), 'whole_binary_binding_head': binding['head'], 'whole_binary_current_head_bound': False, 'source_compatibility': 'git diff old binding head to current HEAD for q_serve.rs/q_runtime.rs/s_service_control.py empty; preserved original binding, not whole-current-HEAD claim', 'controller_source': str(ROOT / 's_session/s_service_control.py'), 'python': {'path': str(python), 'sha256': sha(python)}, 'rust_binary': {'path': str(originals / 's_structure_session'), 'sha256': sha(originals / 's_structure_session')}, 'source_db': str(source), 'source_before': source_before, 'source_after': source_after, 'original_source_bytes_unchanged': True, 'q_resource_sha256': sha(resources), 's_seven_resource_fields': plan['s_resources'], 's_resource_gate_executed': False, 'fresh_instances': results, 'reused_content_evidence': {'path': str(old / 'attempt3/RESULTS.json'), 'sha256': sha(old / 'attempt3/RESULTS.json'), 'executed_in_this_attempt': False}, 'scope': 'existing typed Controller.start_process(q,Rust argv) -> wait_ready -> status -> stop -> reap; frozen original single-bar S3 DB readonly byte copies; two fresh Q processes', 'not_claimed': ['formal start_q /3 or s-launcher/3 support', 'S3 serve/fifo qualification or seven-field gate execution', 'complete browser consumer or client installation', 'full9011', 'all resources/production capacity', 'M1/#1323 completion', 'main integration/push'], 'evidence': {str(p.relative_to(HERE)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(ATTEMPT.rglob('*')) if p.is_file() and not p.name.endswith(('.lock','-shm','-wal'))}, 'harness_sha256': sha(Path(__file__))}
write(HERE / 'ACTUAL-CONTROLLER-MANIFEST.json', manifest)
report = f'''# #1394 现有 Controller 的 Q3 实跑\n\n结果：两个全新 Q 实例均通过 `start_process("q", Rust argv)` → `wait_ready("q", query_epoch="1")` → `status` → `stop` → 回收。SIGTERM 与 SIGINT 均退出 0；控制 nonce、PID/启动身份/UID、生产 Ready 原始 HTTP 正文与 Controller 返回一致；停止后无 LISTEN，端口可重新绑定。\n\n使用原 Q21 SHA `{sha(resources)}`，未改资源数值。源为已有 S3 单 bar 数据，不生成结构数据；复制前 lsof 无打开者、两次 DB/WAL/SHM 哈希及 mtime 稳定且 WAL 为零，原数据库从未建立 SQLite 连接。每实例使用不同只读 main 副本与 state 目录；两副本 main 字节 SHA 未变、WAL 无结构写，原件三文件完全不变。\n\n配置严格经现 `read_config` 的 `s-launcher/2` 校验，身份按原 INPUTS/input/init，七个 S 资源值来自已有 TB01C runtime-plan；本次未执行 S 门，不能声称 S 执法通过。环境由现 `Controller.runtime_environment` 以具名 Python probe 建立，继承环境值未输出。纯合成观察负控调用现 Controller，验证外来进程身份拒绝发信号、外来 nonce 拒绝 Ready；没有信号发送给外来进程。\n\n二进制 SHA `{sha(originals / 's_structure_session')}` 保留 `{binding['head']}` 整体来源绑定；Q3/control 相关三文件对当前 HEAD diff 为空，但不能当作当前 HEAD 全体二进制重建。原 7 页 / 37 nodes 内容案例只引用旧摘要，未重跑。\n\n这是一份现有 typed 控制核心与旧小源域的生命周期验收，不代表正式 `start_q /3`、Browser 完整消费者、9011、全部资源、M1 或 main。所有启动的服务均已停止回收。详细 args、cfg、源文件、二进制、Python、profile/catalog/clock/resource SHA、进程原件及端口/数据库前后证据在单一 `ACTUAL-CONTROLLER-MANIFEST.json` 与 `attempt1/`。\n'''
(HERE / 'RESULTS.md').write_text(report)
emit('complete', instances=len(results), manifest_sha256=sha(HERE / 'ACTUAL-CONTROLLER-MANIFEST.json'))
