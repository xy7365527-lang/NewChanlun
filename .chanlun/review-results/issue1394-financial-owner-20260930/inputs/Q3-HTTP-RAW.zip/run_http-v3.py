"""#1394：实际正式Q3 CLI、HTTP与两次新进程信号收尾；不当作完整消费者验收。"""
import hashlib
import http.client
import json
import signal
import socket
import struct
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HERE = ROOT / "attempt3"
HERE.mkdir(exist_ok=False)
(HERE / "BINDING.json").write_bytes((ROOT / "BINDING.json").read_bytes())
BINDING = json.loads((HERE / "BINDING.json").read_text())
D = b"NewChanlun/SContent/1\0"


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frame(tag, body):
    return hashlib.sha256(D + bytes([tag]) + struct.pack(">Q", len(body)) + body).digest()


def sequence(items):
    if not items:
        return frame(0x11, b"")
    if len(items) == 1:
        return frame(0x12, items[0])
    k = 1 << ((len(items) - 1).bit_length() - 1)
    return frame(0x13, struct.pack(">Q", len(items)) + sequence(items[:k]) + sequence(items[k:]))


class Edge:
    def __init__(self, value):
        assert set(value) == {"format", "root", "kind", "extent"} and value["format"] == "s-content/1"
        assert value["root"].startswith("sc1-") and len(value["root"]) == 68
        self.digest = bytes.fromhex(value["root"][4:])


def value_digest(value):
    if isinstance(value, Edge):
        return value.digest
    if value is None:
        return frame(0, b"")
    if type(value) is bool:
        return frame(2 if value else 1, b"")
    if type(value) is str:
        raw = value.encode()
        chunks = [frame(0x10, raw[i:i + 4096]) for i in range(0, len(raw), 4096)]
        return frame(3, struct.pack(">Q", len(raw)) + sequence(chunks))
    if type(value) is list:
        return frame(5, struct.pack(">Q", len(value)) + sequence([value_digest(x) for x in value]))
    if type(value) is dict:
        fields = [frame(0x14, value_digest(k) + value_digest(value[k]))
                  for k in sorted(value, key=lambda x: x.encode())]
        return frame(6, struct.pack(">Q", len(fields)) + sequence(fields))
    raise ValueError("This metadata probe does not decode original JSON numeric tokens")


def projection_root(page, rows):
    fixed = dict(page["fixed_cut"])
    fixed["catalog_evidence"] = Edge(fixed["catalog_evidence"])
    logical = {"fixed_cut": fixed, "catalog": Edge(page["catalog"]),
               "rows": [dict(row, record=Edge(row["record"])) for row in rows],
               "counts": page["counts"], "scope": page["scope"],
               "omissions": page["omissions"], "order_version": page["order_version"]}
    digest = value_digest(logical)
    assert "qcut3-" + frame(0x22, digest).hex() == page["cut_projection_digest"]
    return {"format": "s-content/1", "root": "sc1-" + digest.hex(), "kind": "object", "extent": "7"}


def envelope(cut, payload, name):
    return {"schema_revision": "s-session/3", "session_id": cut["session_id"],
            "session_generation": cut["session_generation"], "source_namespace": "testonly-q3-http",
            "source_epoch": "1", "message_id": name, "producer_id": "independent-http-probe",
            "producer_epoch": "1", "payload_hash": hashlib.sha256(canonical(payload)).hexdigest(),
            "causal_refs": [], "payload": payload}


def exchange(port, output, name, route, cut=None, payload=None):
    request = b"" if payload is None else canonical(envelope(cut, payload, name))
    start = time.monotonic()
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    try:
        connection.request("GET" if payload is None else "POST", route, body=request or None,
                           headers={"Content-Type": "application/json"})
        response = connection.getresponse()
        raw = response.read()
        headers = list(response.getheaders())
        status = response.status
    finally:
        connection.close()
    (output / (name + ".request")).write_bytes(request)
    (output / (name + ".response")).write_bytes(raw)
    meta = {"route": route, "http_status": status, "elapsed_seconds": time.monotonic() - start,
            "request_bytes": len(request), "response_bytes": len(raw), "headers": headers,
            "request_sha256": hashlib.sha256(request).hexdigest(), "response_sha256": hashlib.sha256(raw).hexdigest()}
    (output / (name + ".json")).write_text(json.dumps(meta, indent=2) + "\n")
    assert status == 200, (route, status, raw[:400])
    reply = json.loads(raw)
    if payload is not None:
        assert reply["schema_revision"] == "s-session/3"
        assert reply["session_id"] == cut["session_id"] and reply["session_generation"] == cut["session_generation"]
        assert hashlib.sha256(canonical(reply["payload"])).hexdigest() == reply["payload_hash"]
        reply = reply["payload"]
    assert reply["ok"] is True
    return reply


def run_one(name, stop_signal):
    output = HERE / name
    output.mkdir(exist_ok=False)
    argv = [BINDING["binary"], "query-serve", "--protocol-revision", "s-session/3",
            "--db", BINDING["runtime_db"], "--resource-config", BINDING["resources"],
            "--producer-epoch", "1", "--host", "127.0.0.1", "--port", "0"]
    (output / "command.json").write_text(json.dumps({"argv": argv, "requested_signal": stop_signal}, indent=2) + "\n")
    start = time.monotonic()
    with (output / "stdout").open("xb") as stdout, (output / "stderr").open("xb") as stderr:
        process = subprocess.Popen(argv, stdout=stdout, stderr=stderr)
        (output / "pid.json").write_text(json.dumps({"pid": process.pid}) + "\n")
        port = None
        result = {"pid": process.pid, "requested_signal": stop_signal, "actual_formal_http": True}
        try:
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                assert process.poll() is None, "Q exited before listen announcement"
                raw_log = (output / "stderr").read_text()
                lines = raw_log.split("\n")[:-1]
                announcements = [json.loads(line[5:]) for line in lines if line.startswith("[q3] ")]
                if announcements:
                    announcement = announcements[-1]
                    assert announcement["resource_config_sha256"] == BINDING["resources_sha256"]
                    port = int(announcement["listen"].split(":")[-1])
                    (output / "listen.json").write_text(json.dumps(announcement, ensure_ascii=False, indent=2) + "\n")
                    break
                time.sleep(.02)
            assert port is not None, "No real listener announcement"
            ready = exchange(port, output, "ready", "/api/ready")
            cut = ready["cut"]
            assert cut["generation"] == "1" and cut["session_id"] == "issue1394-financial-small-20260930"
            first = exchange(port, output, "snapshot-0", "/api/v3/snapshot", cut,
                             {"op": "snapshot", "session_id": cut["session_id"], "session_generation": cut["session_generation"],
                              "scope": {"structure": "CompleteCut", "economic": "not_started"}, "history_mode": "AsKnown",
                              "as_of_generation": "1", "page_size": "1", "order_version": "s-record-order/2"})
            rows = list(first["rows"])
            page = first
            page_count = 1
            fixed_fields = ["fixed_cut", "catalog", "counts", "scope", "omissions", "order_version", "cut_projection_digest"]
            while not page["done"]:
                assert page_count <= int(first["counts"]["total"])
                token = page["next_token"]
                page = exchange(port, output, f"snapshot-{page_count}", "/api/v3/snapshot", cut,
                                {"op": "snapshot", "snapshot_token": token})
                assert all(page[k] == first[k] for k in fixed_fields)
                assert int(page["offset"]) == len(rows)
                rows.extend(page["rows"])
                page_count += 1
            assert len(rows) == int(first["counts"]["total"]) > 0
            assert len({(row["family"], tuple(row["key"])) for row in rows}) == len(rows)
            root = projection_root(first, rows)
            anchor = {"kind": "projection", "fixed_cut": first["fixed_cut"],
                      "cut_projection_digest": first["cut_projection_digest"], "projection_ref": root}
            content = exchange(port, output, "content", "/api/v3/content", cut,
                               {"op": "content", "anchor": anchor, "path": [{"field": "rows"}],
                                "unit": "items", "offset": "0", "limit": "1"})
            assert content["anchor"] == anchor and content["offset"] == "0" and content["end"] == "1"
            assert content["total"] == str(len(rows)) and len(content["items"]) == 1 and content["nodes"]
            for node in content["nodes"]:
                raw = bytes.fromhex(node["body_hex"])
                assert "sc1-" + frame(int(node["tag"], 16), raw).hex() == node["root"]
            cursor = {"session_id": cut["session_id"], "session_generation": cut["session_generation"],
                      "catalog_revision": cut["catalog_revision"], "scope": first["scope"],
                      "after_generation": "0", "base_cut": "cut-0", "index_frontier": "",
                      "last_seq": "-1", "order_version": first["order_version"]}
            watch = exchange(port, output, "watch", "/api/v3/watch", cut,
                             {"op": "watch", "cursor": cursor, "max_batches": "1", "client_id": "http-probe"})
            assert watch["gap"] is None and len(watch["deltas"]) == 1 and watch["next_cursor"]["after_generation"] == "1"
            result.update({"status": "PASS", "listen_port": port, "snapshot_pages": page_count,
                           "snapshot_rows": len(rows), "projection_ref": root, "qcut_independent_recompute": True,
                           "returned_content_node_hashes_verified": len(content["nodes"]), "watch_deltas": 1,
                           "full_content_semantics_or_client_install_verified": False})
        except BaseException as error:
            result.update({"status": "FAIL", "error": repr(error)})
            raise
        finally:
            if process.poll() is None:
                process.send_signal(stop_signal)
            try:
                result["process_exit"] = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                result["process_exit"] = process.wait(timeout=5)
                result["forced_kill"] = True
            result["elapsed_seconds"] = time.monotonic() - start
            if port is not None:
                probe = socket.socket()
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    probe.bind(("127.0.0.1", port))
                    result["listener_rebind_after_reap"] = True
                except OSError as error:
                    result["listener_rebind_after_reap"] = False
                    result["rebind_error"] = repr(error)
                finally:
                    probe.close()
            (output / "RESULT.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
        assert result["process_exit"] == 0 and result["listener_rebind_after_reap"] and not result.get("forced_kill")
        return result


assert sha(Path(BINDING["binary"])) == BINDING["binary_sha256"]
assert sha(Path(BINDING["resources"])) == BINDING["resources_sha256"]
assert sha(Path(BINDING["runtime_db"])) == BINDING["runtime_initial_db_sha256"]
previous = json.loads((ROOT / "attempt2/sigterm/RESULT.json").read_text())
assert previous["status"] == "PASS" and previous["process_exit"] == 0 and previous["listener_rebind_after_reap"]
previous["raw_case_path"] = str(ROOT / "attempt2/sigterm")
previous["source_script_sha256"] = sha(ROOT / "run_http-v2.py")
current = run_one("sigint", signal.SIGINT)
current["raw_case_path"] = str(HERE / "sigint")
current["source_script_sha256"] = sha(Path(__file__))
results = [previous, current]
assert sha(Path(BINDING["runtime_db"])) == BINDING["runtime_initial_db_sha256"]
summary = {"schema_revision": "issue1394-q3-formal-http-result/1", "ticket": 1394,
           "status": "PASS_BOUNDED_FORMAL_Q_RUNTIME", "fresh_processes": results,
           "binding_sha256": sha(HERE / "BINDING.json"), "script_sha256": sha(Path(__file__)),
           "source_db_unchanged": True, "controller_or_browser_acceptance": False,
           "proof_domain": BINDING["scope"]}
(HERE / "RESULTS.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"status": summary["status"], "processes": len(results),
                  "pages_each": [r["snapshot_pages"] for r in results]}, ensure_ascii=False))
