# #1394 Native history 字段定位，只读结论

本轮不实施结构 cursor。当前 profile 不能支持将字段读取当作优先性能改造面。未修改源码，未运行 Cargo、测试、服务或 SQL。

基线为 `f2f2bef080`，读取 `.scratch/issue1394-publication-owner-profile151-20261005/PROFILE-TREE.json`。图索引 `Users-silencehan-Projects-NewChanlun-rust` 对相关新符号返回零结果，随后读取本 worktree 源码。

## 已定位的重复与成本

去掉函数名内嵌的 closure 祖先重复后，`verify_generated_members_swept_with_records<HashReader>` 为 32 个互不嵌套采样根，合计 1549/main15874。直接子树 `field_ref` 为488、`lookup_fields_refview` 为330，两者互斥，合计818，即主线程5.153%。`find_field` 位于前者之内，458，不能再相加。全 profile 的字段读取还含准备、发布与 source 等阶段，不能混归 history。

`object_index.rs:1848` 先取生成态 `objects`，每个成员在 `:1866` 单独定位/解码 `object_id`，执行重复身份及独立索引匹配后，`:1885` 才选 shape/typed exact 字段集并读取该记录。由此，身份路径查找与随后 exact DFS 确实再次访问同一记录的共同结构和 `object_id` 字段。488 也包含每代 `state.objects` 定位，不能全部归为逐记录身份读取。

`path.rs:1104` 的 `find_field` 每层核两直接子节点，再各下行边界叶并比较键，原注释明确其 O(depth²) 读取；`path.rs:321` 的 `object_fields_output` 已经一次 DFS，不存在把 exact 多字段改成“一次遍历”的新增收益。

## 唯一结构方向及限制

若以后取得更强实测依据，最小有意义方向是一个单记录、两阶段共享结构读取 cursor。第一阶段仍按原路径取得 `object_id`，保留已成功读取的逻辑位置与角色上下文。原 `seen` 和独立身份索引检查照旧执行。第二阶段在原 exact 读取位置继续原 DFS，只复用第一阶段读过的同一位置，未读位置继续按既有顺序读取与核验。

它须绑定实际同一 Native capture owner、完整 record Ref 四字段、字段树逻辑位置、序列期望 count/k、Value/字段/键角色与 exact schema。仅 normal Native 原件、完整审计、无 Owned/预算/期限/render 门可进入。不同对象、不同 capture、overlay-only、JsonInner、普通动态来源、Q/fragment 与任何有门路径仍走原核。不能只按 digest 把不同逻辑叶位置合并。只保留成功结构材料，不缓存失败或业务通过结果；记录结束或失败即销毁。不前移 exact schema、元数据或 immutable 检查，错误顺序仍为身份读取、重复身份、未知身份、exact、元数据、内容、出生原件。

预计改动至少触及 `s_content/path.rs` 的结构遍历状态、实际 capture 绑定入口，以及 `history.rs`/`audit_store.rs`/`object_index.rs` 的单记录两阶段接线，不能以叶函数各自加缓存收尾。这是设计方向，尚未实现，也没有证明其读取/trace 合同可直接接纳。

已有 `NativeRecordFields` 是完整 record 成功后才 seed 的 history→source 交接；source 字段 memo、scalar memo 和 wire 复用均已存在。本方向不把这些已有收益重新计入，也不恢复 immutable-only、birth-only、candidate 或 wire 工作。

## 本轮判断及以后正常验收

818 是两个整棵互斥调用子树的包络，不是可消除时间。可省的是共同结构交集，尚无逐位置读取次数或端到端收益证据。为这个小于5.153%的真实收益上限引入新的位置、角色和寿命状态，本轮不值得优先实施。

以后若重开，只需同一正常固定 capture 前后对拍成功输出、实际对象/字段 refs、完整 history/source 取材归属、现有成功读取 trace，并用同一正常窗口比较实际读取/解码次数、耗时与峰值。保留现有普通/Owned/门路径回归，不新增故障或坏数据验证，不改变期限与512MiB S7。实现与正常验证均未在本轮执行。
