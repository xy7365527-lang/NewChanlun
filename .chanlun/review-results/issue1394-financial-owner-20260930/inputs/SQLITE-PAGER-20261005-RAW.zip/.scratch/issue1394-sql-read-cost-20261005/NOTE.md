# #1394 SQLite 读取成本限定只读诊断

本次只读当前 HEAD `f2f2bef0803c9b80cee1fa405c5234ae3402f1b9` 的指定源码、依赖源码和封存 JSON/采样树。根任务给定 Rust 聚合 SHA256 为 `c8ead0d4167da9f6af7629cf916371b950e6f5d41f2a8611f012079a11628aa6`，正常150/151为20.6948/19.8390秒。本次没有重跑或重新计算该聚合，不把根任务给定读数说成本次实测。未打开SQLite数据库连接，未运行Cargo/测试/服务，未改配置，未执行故障或坏数据测试。唯一写入为本笔记。

## 最值得行动的候选

先在下一次已有授权的正常具名域，记录固定 writer 连接的只读 SQLite pager 计数，再据实际阶段 miss 与 spill 决定是否试验显式有限 `cache_size`。保持每个 SQL、参数、读写顺序、事务/提交顺序、F 和业务判据；维持 WAL/FULL/fullfsync 与当前 auto checkpoint。此次不实施诊断或试验，不选缓存数值。

这比“给 read_material 再加 prepared cache”更有依据，因为当前 SELECT/INSERT 已经准备语句复用；被动采样的主要可疑物理成本是随机 B-tree 页读取。现有证据还不足以推荐扩大缓存，不能说已证明 thrashing，也不能保证消除某个百分比的总时间或完成9011。有限page cache优化仍是物理成本改善，逻辑访问量及最坏增长阶数不变。

## 语句准备已复用

- `rust/src/bin/s_session_v2/content_store.rs:112–126` 的 `read_material` 使用 `prepare_cached("SELECT tag, body FROM s_content_nodes WHERE digest=?1")`，然后按旧次序 query_row、严格转换tag及完整原件校验。重复调用这个API不等于每次执行 sqlite3_prepare。
- `content_store.rs:675–711` 的 `TxStore::put_before_write` 先执行原摘要与实际 SELECT/新旧原件检查；需要写入时 INSERT 也使用 `prepare_cached`。Native put 委托这条路径，不能把put的SELECT误算成可删的冗余读取。
- 当前 `rust/Cargo.lock:1615–1626` 为 rusqlite 0.40.2，bundled libsqlite3-sys 0.38.2。依赖 `rusqlite-0.40.2/src/cache.rs:136–149` 命中返回旧RawStatement，只有miss才prepare_with_flags；`:154–161` Drop时清参数并归还。`src/row.rs:109–114` Rows Drop仍reset statement，故每次实际SQL执行保留。
- `rusqlite-0.40.2/src/lib.rs:168` 的默认statement缓存容量是16，连接建立时初始化。指定S源码没有设置容量或flush。全源码针对配置字面量的查证同样没有S容量设置；未据此宣称运行中缓存绝不逐出或绝无reprepare。
- 请求并非每次重开连接。`s_session_v3/driver.rs:77–91` Driver持Connection，`:292–294` 启动open一次。正常新ingest的Handle事务在 `:400–453` accept后提交；Advance在 `:483–515` 使用Immediate事务、Begin后提交；Commit在 `:520–526` 新Immediate事务交给runtime。这些事务共用Connection及其statement/pager状态。不能合并事务或省去提交来降低开销。

## 已核连接配置与仍未测范围

`rust/src/bin/s_structure_session.rs:304–311` 的open_db只显式设置 WAL、synchronous=FULL，macOS还设置fullfsync=ON。未查到S设置cache_size、mmap_size或cache_spill；economic_session自己的 `content_store.rs:263` 设置cache_spill OFF/auto checkpoint0，属于另一个owner，不适用S。

当前bundled `sqlite3.c:14848–14849` 默认SQLITE_DEFAULT_CACHE_SIZE=-2000，`:14901–14902` 默认page size4096，`:16139–16140` 默认mmap0。`libsqlite3-sys-0.38.2/build.rs:151–170` 没有在固定flags中覆盖这些值，但 `:321–332` 允许额外构建flags。因此源码与常规默认只支持“未显式调整”；没有实际writer连接的PRAGMA回读、编译配置与库header绑定，不能把默认当成已测有效配置。

[SQLite cache_size官方说明](https://www.sqlite.org/pragma.html#pragma_cache_size) 将-2000解释为约2048000 B的建议缓存容量。页缓存按需分配，该值不是整个SQLite或进程heap硬上限；page_size变化也会改变页数与字节关系。连接复用不意味着整库页都留在缓存中。反过来，主DB/WAL大于默认cache也不证明工作集需要整个库常驻。

封存 `publication-owner-profile151-20261005/RESULT.json` 的original_before/stat给出source149主DB284565504 B、WAL164305632 B、SHM327680 B；owned_after主DB295931904 B、WAL164367432 B。这些是原运行记录的文件stat与hash，本次只解析JSON，未打开原件数据库。不能将DB与WAL相加当唯一页工作集，也不能用文件大小推导pager miss次数。

## 2822 / 720 / 962 的真正归属

指定数字对应 `.scratch/issue1394-publication-owner-profile151-20261005/PROFILE-SUMMARY.json`，15874主线程样本及同目录PROFILE-TREE。根任务确认该样本绑定旧b2608e9d产物；当前f2f2只比它增加digest借用/scan scratch，但没有当前新profile。本笔记不把旧profile冒充当前实测。另一个projection-profile151有17856主线程样本、pread4405/VM1032，不混合两份树。

计算每节点self=count-Σ直接子count，以叶函数名称匹配，再按完整祖先栈互斥分类；以下self之和与摘要逐项相等。包含样本不能随意相加或当调用次数。

| pread self所属真实操作 | 样本 |
|---|---:|
| read_material → Native put 的必要原件检查 | 891 |
| read_material → Native current_checked | 1156 |
| read_material → TxStore | 324 |
| read_material → PublicationMaterialStore | 62 |
| current_originals_equal全扫 | 118 |
| capture_with_original_subset全扫 | 51 |
| COMMIT | 35 |
| history其他SQL | 2 |
| 其他 | 183 |
| 合计 | 2822 |

pread的SQLite近栈中2432样本走 `sqlite3VdbeExec → sqlite3BtreeIndexMoveto → getAndInitPage → getPageNormal → readDbPage → unixRead → pread`，334走B-tree Next。它们指向点查/迭代的物理页读取，没有说明同一页重复了几次、页来自DB还是WAL、是否OS缓存命中或SSD实际读取。这些仍缺VFS/pager观测。

`__fcntl`720个self样本**全部属于COMMIT → unixSync → fcntl**。493在 `sqlite3WalDefaultHook → sqlite3_wal_checkpoint_v2 → sqlite3WalCheckpoint → unixSync`，227在 `sqlite3PagerCommitPhaseOne → pagerWalFrames → unixSync`。它不是读SELECT的重复文件锁；正与macOS fullfsync配置一致。保留提交与durability配置的本轮候选不能靠关同步/改变checkpoint省掉这720。

`sqlite3VdbeExec`962个self样本中，683属于current_originals_equal全扫，33属于capture_subset全扫；read_material分Native put31/current_checked58/TxStore10/Publication10共109；history其他2，其余135。重点是 `sqlite3_step` 执行原SQL，不能把VM占比当成准备语句反复编译。

编译族 `sqlite3LockAndPrepare/sqlite3Prepare/sqlite3RunParser` 去除同栈嵌套后的最外层包含样本仅8；RunParser self为2。StatementCache.get/cache_stmt self分别23/11。采样不是精确成本上限，没采到也不等于没有；但它不给“重新准备SQL是显著热点”提供支持。单把已有prepare_cached改成更长存活statement，最多有很小且未测的缓存管理收益，还会影响stmt借用/生命周期与错误传播，不是当前最大候选。

## S7 与pager资源名分

`s_session/tests/fixtures/tb01c/runtime-plan.json:108–112` 将audit_cache_source_bytes明写为retained source bytes，非RSS。该fixture旧数值268435456不替代当前批准536870912。`RESOURCE-GATE-MAP-20261005.md:9–17,21` 同样把S7限定为保留审计来源字节，保持当前512MiB与30秒，没有把SQLite pager列为S7对象。`state.rs:75–90` 的检查接收已计算retained来源量；pager字节没有进入此证明。

SQLite pagecache只缓存SQLite物理页，每次原SQL仍返回当前事务数据并执行原F及业务检查，缓存页不是审计成功证书。它可跨请求保留内存，但“跨请求有内存”不自动等于S7来源owner，更不自动产生全heap门。Q的 `S3-RUNTIME-20260918.md:210–212` 说明其保留对象配方和临时SQLite边界，仅作相关计量区别，不能把Q私有缓存合同搬成S pager硬门。

当前S公开资源文件exact七字段见 `writer_cli.rs:18–30`，没有pager hint。没有查到被冻结的cache_size/statement容量合同，故正常具名域内部有限pagecache试验本身不自动要求用户新许可，也不应往公开资源exact里加隐藏字段。所选值、有效PRAGMA、编译flags、实际缓存字节与RSS仍是需绑定记录的新实验资源输入；不得默用默认、宣称是原实窗、扩大S7或改变30秒。现有APPROVED-SOURCE §5.9.6的RSS测量义务不变，没有据此自建RSS/全heap数值门。

## 必要只读计数与随后判断

现有封存日志没有实际cache_size/page_size/mmap/cache_spill、CACHE_HIT/MISS/WRITE/SPILL/USED或statement reprepare计数。下一次已有授权正常运行可在同一writer连接、关键阶段边界以resetFlag=0读取 `sqlite3_db_status`，记录HIT/MISS/WRITE/SPILL的累计差值、CACHE_USED以及STMT_USED当前近似字节，并回读有效PRAGMA。只观察，不修改事务、计数基础、返回或审计结果。

[SQLite db_status官方说明](https://www.sqlite.org/c3ref/c_dbstatus_options.html) 明写CACHE_USED、HIT、MISS、WRITE及STMT_USED的highwater恒0。零不是严格峰值；可自行记录采样USED最大值，但须标为sampled_max，不能冒称strict_peak。CACHE_WRITE含WAL页写，不代表所有恢复/rollback写；IO错误后该数也有定义限制。

若要核语句准备，rusqlite0.40.2 `statement.rs:716–726` 已有get_status/reset_status；[SQLite stmt_status](https://www.sqlite.org/c3ref/c_stmtstatus_counter.html) 的RUN/REPREPARE/VM_STEP可用只读累计差，另需区分新sqlite3_prepare与自动reprepare。此处不因为工具可用而实施任何观测。

行动次序是先取得上述阶段差，只有真实miss/spill支持时才在新正常具名域试有限pager hint，并对照原操作次数、完整回执/输出、30秒、S7、RSS及库/WAL。保持WAL/FULL/fullfsync/auto checkpoint，不改cache_spill、mmap、locking或提交边界。单纯修改mmap访问路径或缓存淘汰策略缺乏当前证据，不推荐；它们也不能作为故障语义等价的捷径。

若计数表明大部分miss都是首次接触唯一新页、旧页复用距离超过可承担的有限缓存，有限pagecache收益自然受限；若重复旧页miss集中，才有可核验的物理读优化空间。无论哪一种结果，SQL逻辑执行及增长下界保持，不把常数改善包装成完整9011的算法闭环。
