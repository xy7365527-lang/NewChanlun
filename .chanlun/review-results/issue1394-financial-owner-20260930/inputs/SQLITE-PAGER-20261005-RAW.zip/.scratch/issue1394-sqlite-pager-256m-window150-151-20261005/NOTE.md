# #1394 SQLite pager 256MiB hint 正常窗口准备

本目录是 #1394 的工作草稿。复用已经默认窗口实跑的 runner 与同一冻结服务，在独立新域试 `S_NATIVE_SQLITE_CACHE_KIB=262144`。单位是 KiB，即256MiB，此值是 pager hint，不是RSS硬上限。原S7仍为536870912字节来源预算，启动和完整请求仍为30秒。

本次只准备，未运行服务、SQL、Cargo 或测试。`BINARY-BINDING-service.json` 从默认窗口逐字复制，路径、源码绑定与hash未改；实际 service SHA 为 `0e9cef4460f284d8fa8a60fae155bef11843714b459c239a5c9aabed2ff07bdf`。脚本差异见 `SCRIPT.diff`，配置与材料绑定差异见 `BINDINGS.diff`。业务流程只改变新具名域/socket及私有env值，对应scope说明同步更新。

## 实验依据与绑定

默认真实窗口的 cache_size 为-2000。150/151的miss为5736413/4917505，hit为13174110/10891733，spill为30756/53012；完整耗时为20.694023/19.834563417秒。默认诊断截至末请求报告的进程生命周期maxrss为2270969856字节。主控报告物理RAM为103079215104字节。较多pager miss支持进行本次正常cache hint比较，尚不证明收益，也不能把miss乘页大小当成SSD读取字节。

`EXPERIMENT-INPUT.json` 固定精确env值、单位、依据、S7与RSS边界、正常窗口范围和记录口径。Python binding纳入该输入、默认ROOT-RESULT及默认完整RESULT；Orchestrator binding经Python binding覆盖这些材料，并显式登记实验输入和默认ROOT结果SHA。runner在运行前核全部绑定，参数文件变更即失败。

环境设置由runner明确写 `S_NATIVE_SQLITE_CACHE_KIB='262144'`，Observed Popen保留实际env记录，finally恢复运行前值。继续使用 `S_CAPTURE_NATIVE_TESTONLY=1`、`S_MANIFEST_WORKSPACE_DIAGNOSTICS=1`。startup_readback必须取probe实际日志，不能从env反推生效；预期cache_size为-262144，但实际值由主控验收。WAL、FULL、fullfsync和autocheckpoint保持既有配置。

## 固定路径与源封条

- 新窗口为 `.scratch/issue1394-sqlite-pager-256m-window150-151-20261005/`。
- 服务仍为 `.scratch/issue1394-sqlite-pager-probe-20261005/frozen-service`。
- 新自有域为 `/Volumes/AgentStorage/issue1394-sqlite-pager-256m-window150-151-20261005-r1/`。
- socket为 `/private/tmp/nc1394-pg256150-151-20261005-r1.sock`。
- 来源仍是 `.scratch/issue1394-root-text-window143-160-20261004/RESULT.json` 封存的CopyQualified149，原件三文件位于 `/Volumes/AgentStorage/issue1394-root-text-window143-160-20261004-r1/`。完整来源stat/SHA及基准见 `SOURCE-LIST.json`。

原件只允许按字节复制、stat与hash，禁止SQLite-open。SQL只在本次新自有副本上执行。来源149及原件105、来源126/142的既有Unknown保持。独立新域不接续或拼接完整9011。

## 运行前与唯一命令

主控先复核本目录脚本、实验输入及绑定差异，确认新OWN/socket/RESULT.json/execution均不存在，AgentStorage已挂载并有复制空间。runner实际运行时重新核服务与冻结源码SHA、Python/材料hash和来源生命周期/封条。首次意外失败原样保留，不重试，不重发。

从工作树执行一次：

```bash
cd /Users/silencehan/.codex/worktrees/issue1394-audit-prefix/NewChanlun
/Users/silencehan/.local/bin/python3.12 -B .scratch/issue1394-sqlite-pager-256m-window150-151-20261005/window.py > .scratch/issue1394-sqlite-pager-256m-window150-151-20261005/RUN.stdout 2> .scratch/issue1394-sqlite-pager-256m-window150-151-20261005/RUN.stderr
```

退出码0不能代替业务验收，异常写入RESULT.json。

## 主控独立验收

- RESULT为COMPLETE，Ready对应唯一serve Popen，实际received严格为150/151。保留完整wire请求/回复、payload及persistent oracle，用已有evidence校验并与默认窗口逐条比较完整reply/oracle。
- 两条完整交换均在30秒内，终态generation151、idle、Committed151、published151、clocks453、next_attempt_ordinal152。失败保留首个序号、未发送尾部与持久状态，不把持久提交推成收到回复。
- 保存原始SERVICE-DIAGNOSTICS.log并登记hash。检查NativeTestOnlySqlitePager的startup/config readback和每次request before/after统计，Popen环境必须为262144，requested_cache_kib与effective cache_size必须从实际日志确认。journal_mode=wal、synchronous=2、fullfsync=1、wal_autocheckpoint=1000。
- 比较default与256MiB窗口的hit/miss/write/spill端点差、cache_used近似值、完整耗时及进程生命周期maxrss快照。标明i32端点差可能漏掉中间overflow/reset，pager严格峰值未测；RSS不是Rust heap，也不是请求专属峰值。单次性能比较不证明稳定增益。
- 核两次既有workspace qualification、source_sum、allowance/old_pool和owner reuse/drop，S7不变。整体heap/RSS/I/O未资格化。
- 三原件完整stat/SHA前后相等，源码/binary/材料绑定收尾重核。所有同一Popen回收、controller关闭、socket移除，cleanup_errors为空；保留新副本与全部证据。
- 主控写ROOT-RESULT，分别记录环境、有效配置、pager、耗时/oracle、RSS量纲、S7、源封条、绑定及cleanup。任何未观测项照实报告，不补推。

不故障注入、不写坏数据，不恢复取消的birth-only/candidate/wire方案，不扩大S7门，不涉及前端。
