# #1394 SQLite pager 默认配置正常窗口准备

本目录是 #1394 的工作草稿。当前范围是 SQLite pager 正常诊断，不使用 immutable 候选。本次仅准备脚本、配置、绑定与说明，未启动服务，未执行 SQL、Cargo 或测试，未生成服务 binding。

复用 `.scratch/issue1394-native-scan-window150-151-20261005/window.py`，完整 wire/persistent oracle、来源封条、首次失败不重试与 cleanup 流程照旧。`SCRIPT.diff` 记录脚本差异，`BINDINGS.diff` 记录 proposed 配置与材料绑定差异。基准仍为 native-scan 的第150条 `20.694808083` 秒、第151条 `19.839043791` 秒。

## 默认配置的环境证据

runner 在启动前显式执行 `os.environ.pop('S_NATIVE_SQLITE_CACHE_KIB', None)`，继续设置 `S_CAPTURE_NATIVE_TESTONLY=1` 和 `S_MANIFEST_WORKSPACE_DIAGNOSTICS=1`。Observed Popen 的 environment 字段新增 `S_NATIVE_SQLITE_CACHE_KIB`，默认窗口应记录为 null。finally 恢复运行前的私有环境变量原值，原先未设置则继续清除。

本脚本不增加 RSS 采样线程，仍保留原有严格峰值 UNMEASURED。主控若添加被动采样，只接受同一 Popen PID 且服务尚活时的 `ps -o rss= -p PID` 样本，至多每250ms一次，单次 ps 超时1秒；保留原始时间序列及 sampled_max_bytes，明确它不是严格峰值。采样不能改变请求、业务结果或截止时间，采样失败不得触发请求重试，cleanup 必须停止并 join 采样线程。

## 固定路径与来源

- 输出目录为 `.scratch/issue1394-sqlite-pager-default-window150-151-20261005/`。
- 冻结服务必须为 `.scratch/issue1394-sqlite-pager-probe-20261005/frozen-service`，runner 已硬锁该路径。
- 新自有数据库域为 `/Volumes/AgentStorage/issue1394-sqlite-pager-default-window150-151-20261005-r1/`。
- socket 为 `/private/tmp/nc1394-pgdef150-151-20261005-r1.sock`。
- 来源仍是 `.scratch/issue1394-root-text-window143-160-20261004/RESULT.json` 封存的 CopyQualified149，原件为 `/Volumes/AgentStorage/issue1394-root-text-window143-160-20261004-r1/` 中的 `s.sqlite`、`s.sqlite-wal`、`s.sqlite-shm`。完整 stat/SHA 封条与基准来源见 `SOURCE-LIST.json`。

原件只允许按字节复制、stat 与 SHA-256，禁止 SQLite-open。所有 SQL 仅在本次新自有副本上执行。来源149仍是持久提交但未收到回复的 Unknown；原件105及来源126/142/149的既有 Unknown 边界保留。

## 主控接回后的前置条件

1. 完成本次 pager 诊断模块的验收、源码冻结与真实服务构建，随后在本目录写实际 `BINARY-BINDING-service.json`。记录非 test 的 `s_structure_session` bin、实际 compiler artifact、binary SHA、source_manifest、source_aggregate_sha256、fixed_source 和构建绑定证据；不能复制旧服务的哈希冒充新服务。
2. source_manifest 应指本次 pager 诊断源码清单，fixed_source 应对应真实服务冻结源码。主控核清单聚合 SHA 与 binding 一致；runner 运行前核 binary SHA、冻结源码逐项 SHA、脚本及 Python/材料依赖 SHA，收尾由主控重新核验。
3. 新自有域、socket、本目录 `RESULT.json` 与 `execution/` 尚不存在；AgentStorage 已挂载并有复制空间。来源 lifecycle/stat/SHA 须通过运行前检查。
4. 启动、每次完整请求均为30秒；S7固定 `536870912`，其余资源门保持已有值。只发送原始正常输入150、151。首个意外失败保留原状，不重发或重试本域。

## 唯一运行命令

主控完成前置条件后执行一次：

```bash
cd /Users/silencehan/.codex/worktrees/issue1394-audit-prefix/NewChanlun
/Users/silencehan/.local/bin/python3.12 -B .scratch/issue1394-sqlite-pager-default-window150-151-20261005/window.py > .scratch/issue1394-sqlite-pager-default-window150-151-20261005/RUN.stdout 2> .scratch/issue1394-sqlite-pager-default-window150-151-20261005/RUN.stderr
```

业务异常保存在 `RESULT.json`，退出码0不是验收结果。

## 必要验收

- `RESULT.json.state` 为 COMPLETE，Ready 对应唯一 serve Popen，received_window 严格为 `[150,151]`。完整原始请求、wire reply、payload 与 persistent oracle 保留，用既有 evidence 校验，并与 native-scan 基准逐条比对完整 reply/oracle。
- 两条完整交换均在30秒内。终态 generation151、idle、Committed151、published151、clocks453、next_attempt_ordinal152。失败时保留首个失败序号、未发送尾部和持久状态，不把持久提交等同收到回复。
- 原样复制新自有域 `controller-state/s.log` 到本目录 `SERVICE-DIAGNOSTICS.log`，登记 SHA。独立检查 `NativeTestOnlySqlitePager` 配置行和每个请求 before/after 统计，核默认 cache 配置；Observed Popen environment 的 `S_NATIVE_SQLITE_CACHE_KIB` 必须为 null。
- 两次 workspace qualification、source_sum、allowance/old_pool 与 owner reuse/drop 仍按既有口径核验，S7为536870912。pager 统计与 S7 来源字节、RSS 分开报告，不能据此宣称整体资源资格化。
- 三原件 original_before/original_after 完整 stat/SHA 相等；源码、binary 和材料绑定收尾重新核验。SQL始终只触及本次新副本。
- 同一 Popen reaped、controller closed、socket removed、cleanup_errors 为空，保留新自有数据库与完整执行证据。若有额外采样，记录线程停止和 join 证据。
- 主控写 `ROOT-RESULT.json`，分别记录对照、deadline、环境、pager统计、源封条、binding和cleanup观察。单次150/151窗口不证明稳定收益、完整9011或整体 heap/RSS/I/O 资格化。

不故障注入、不写坏数据，不恢复取消的 birth-only/candidate/wire 方案，不扩大资源门，不涉及前端。
