"""#1394 正常窗口事后验证。只读封存字节，不连接任何数据库。"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil


ROOT = Path.cwd()
OUT = ROOT / ".scratch/issue1394-sqlite-pager-default-window150-151-20261005"
BASE = ROOT / ".scratch/issue1394-native-scan-window150-151-20261005"


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1048576), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    spec = importlib.util.spec_from_file_location("native_scan_window", OUT / "window.py")
    window = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(window)
    result = load(OUT / "RESULT.json")
    baseline = load(BASE / "RESULT.json")
    assert result["state"] == "COMPLETE"
    assert not result["errors"] and not result["cleanup_errors"]
    assert [row["ordinal"] for row in result["received_window"]] == [150, 151]
    assert result["received_window"] == baseline["received_window"]
    terminal = {"generation": "151", "advance_state": "idle", "messages_by_status": {"Committed": 151}, "published": 151, "clocks": 453, "next_attempt_ordinal": 152}
    assert result["owned_terminal_state"] == terminal
    assert result["original_before"] == result["original_after"]
    for rows in (result["original_after"], result["owned_after"]):
        for row in rows.values():
            assert window.identity(row["path"]) == row
    elapsed = {}
    previous = {}
    for ordinal in (150, 151):
        exchange = load(OUT / f"execution/input-{ordinal}.exchange.json")
        assert exchange["error"] is None and exchange["result"]["transport"] == "Received"
        elapsed[str(ordinal)] = exchange["whole_exchange_elapsed_ns"] / 1e9
        assert 0 < elapsed[str(ordinal)] < 30
        previous[str(ordinal)] = load(BASE / f"execution/input-{ordinal}.exchange.json")["whole_exchange_elapsed_ns"] / 1e9
        for name in (f"input-{ordinal}-0.request.wire", f"input-{ordinal}-0.reply.wire", f"input-{ordinal}.persistent.json"):
            assert (OUT / "execution" / name).read_bytes() == (BASE / "execution" / name).read_bytes(), name
    binding = load(OUT / "BINARY-BINDING-service.json")
    assert binding["compiler_artifact_profile_test"] is False
    assert binding["target_name"] == "s_structure_session" and binding["target_kind"] == ["bin"]
    assert set(binding["compiler_features"]) == {"default", "s_capture_native_testonly", "s_session"}
    assert sha(binding["binary"]["path"]) == binding["binary"]["sha256"]
    source = load(binding["source_manifest"])
    aggregate = hashlib.sha256(json.dumps(source["entries"], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    assert aggregate == binding["source_aggregate_sha256"] == source["aggregate_sha256"]
    for row in source["entries"]:
        assert sha(ROOT / row["path"]) == row["sha256"]
        assert sha(Path(binding["fixed_source"]) / row["path"]) == row["sha256"]
    orchestration = load(OUT / "ORCHESTRATOR-BINDING.json")
    assert sha(OUT / "window.py") == orchestration["sha256"]
    assert sha(OUT / "PYTHON-BINDING.json") == orchestration["python_binding_sha256"]
    for row in load(OUT / "PYTHON-BINDING.json")["files"]:
        assert sha(row["path"]) == row["sha256"]
    assert result["all_processes_reaped"] and result["controller_closed"]
    assert len(result["lifecycle"]) == 1
    process = result["lifecycle"][0]
    assert process["reaped_by_same_Popen"] and process["exit_code"] is not None
    try:
        os.kill(process["pid"], 0)
    except ProcessLookupError:
        pass
    else:
        raise AssertionError("service PID remains live; inspect identity")
    config = load(OUT / "Controller.json")
    assert not os.path.lexists(config["socket"])
    assert config["startup_timeout_ms"] == "30000"
    assert config["s_resources"]["response_timeout_ms"] == "30000"
    assert config["s_resources"]["audit_cache_source_bytes"] == "536870912"
    owned = Path(config["db"]).parent
    shutil.copy2(owned / "controller-state/s.log", OUT / "SERVICE-DIAGNOSTICS.log")
    diagnostics = [json.loads(line) for line in (OUT / "SERVICE-DIAGNOSTICS.log").read_text().splitlines() if line.startswith("{")]
    qualification = []
    for generation in (150, 151):
        issued = [row for row in diagnostics if row.get("generation") == generation and row.get("stage") == "prepare-issued"]
        dropped = [row for row in diagnostics if row.get("generation") == generation and row.get("stage") == "publish-material-owner-dropped"]
        assert len(issued) == len(dropped) == 1
        issued, dropped = issued[0], dropped[0]
        budget = issued["budget"]
        cost = issued["workspace_source_cost"]
        assert budget == dropped["budget"]
        assert budget["total"] == 536870912
        assert budget["allowance"] + budget["legacy"] + budget["old_pool"] == budget["total"]
        assert cost <= budget["allowance"]
        assert dropped["scope_owner_drops"] == 1 and dropped["scope_reused_original_reads"] > 0
        assert dropped["scope_unknown_write_invalidations"] == 0
        qualification.append({"generation": generation, "budget": budget, "workspace_source_cost": cost, "source_sum": cost + budget["legacy"] + budget["old_pool"], "owner": {key: value for key, value in dropped.items() if key.startswith("scope_")}})
    assert process["environment"]["S_NATIVE_SQLITE_CACHE_KIB"] is None
    pager = [row for row in diagnostics if row.get("diagnostic") == "NativeTestOnlySqlitePager"]
    starts = [row for row in pager if row["stage"] == "startup-before-first-transaction"]
    handles = [row for row in pager if row["stage"] == "handle-before-after"]
    assert len(starts) == 1 and len(handles) == 3
    start = starts[0]
    assert start["requested_cache_kib"] is None
    pragmas = {}
    for name, reading in start["pragmas"].items():
        assert reading["availability"] == "available", name
        pragmas[name] = reading["value"]
    assert pragmas["journal_mode"] == "wal" and pragmas["synchronous"] == 2
    assert pragmas["fullfsync"] == 1 and pragmas["wal_autocheckpoint"] == 1000
    assert pragmas["cache_spill"] > 0 and pragmas["mmap_size"] == 0
    samples = [start["snapshot"]]
    per_request = []
    for row in handles:
        assert row["business_result_ok"] and row["reset_flag"] == 0
        assert row["pager_peak_measurement"] is False
        before, after = row["before"], row["after"]
        samples.extend([before, after])
        deltas = {}
        for name, item in row["cumulative_delta"].items():
            expected = after[name]["current_i32"] - before[name]["current_i32"]
            assert expected >= 0 and item["value"] == expected
            deltas[name] = expected
        hit = deltas["cache_hit_cumulative_i32"]
        miss = deltas["cache_miss_cumulative_i32"]
        per_request.append({"message_id":row["message_id"], "deltas":deltas,
            "pager_hit_ratio":hit/(hit+miss) if hit+miss else None,
            "miss_pages_times_page_size_not_ssd_bytes":miss*pragmas["page_size"],
            "cache_used_after_bytes_approximate":after["cache_used_bytes_current_approximate"]["current_i32"],
            "process_maxrss_as_of_after_bytes":after["process_maxrss"]["bytes"]})
    assert [row["message_id"] for row in handles] == ["launcher-ready-1", "message-150", "message-151"]
    for sample in samples:
        for name, item in sample.items():
            assert item["availability"] == "available" and item["rc"] == 0, name
            if name == "process_maxrss":
                assert item["raw_unit"] == "bytes" and item["bytes"] == item["raw_maxrss"] and item["bytes"] > 0
            else:
                assert item["highwater_i32"] == 0
    rss = [sample["process_maxrss"]["bytes"] for sample in samples]
    assert rss == sorted(rss)
    pager_summary = {"requested_cache_kib":None, "effective_pragmas":pragmas,
        "requests":per_request, "process_maxrss_reported_bytes":max(rss),
        "rss_scope":"process lifetime kernel high-water observed at diagnostic snapshots; not request-only or Rust heap",
        "pager_used_max_of_samples_bytes_approximate":max(sample["cache_used_bytes_current_approximate"]["current_i32"] for sample in samples),
        "pager_strict_peak":None, "i32_endpoint_delta_limit":"no observed negative/decrease; intermediate overflow/reset not ruled out"}
    report = {
        "state": "PASS_NORMAL_SQLITE_PAGER_DEFAULT", "validated_received": [150, 151],
        "source_aggregate_sha256": aggregate, "service_sha256": binding["binary"]["sha256"],
        "whole_exchange_seconds": elapsed, "baseline_whole_exchange_seconds": previous,
        "single_run_elapsed_reduction_percent": {key: (1 - elapsed[key] / previous[key]) * 100 for key in elapsed},
        "reply_and_persistent_oracle_identical_to_baseline": True, "terminal": terminal,
        "original_and_owned_live_stat_sha_verified": True, "source_and_all_bindings_revalidated": True,
        "same_Popen_reaped_controller_closed": True, "socket_removed": True, "cleanup_complete": True,
        "qualification": qualification, "shared_source_budget_held_for_both": True,
        "diagnostic_log_sha256": sha(OUT / "SERVICE-DIAGNOSTICS.log"),
        "pager": pager_summary,
        "no_fault_injection": True, "full9011_complete": False, "whole_resources_qualified": False,
        "goal_complete": False, "limits": ["单次两请求窗口，不证明稳定性能增益或完整9011", "独立窗口不拼接重放", "S7保留来源字节与整体heap/RSS量纲不同"],
    }
    (OUT / "ROOT-RESULT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ("state", "whole_exchange_seconds", "single_run_elapsed_reduction_percent", "cleanup_complete", "pager")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
