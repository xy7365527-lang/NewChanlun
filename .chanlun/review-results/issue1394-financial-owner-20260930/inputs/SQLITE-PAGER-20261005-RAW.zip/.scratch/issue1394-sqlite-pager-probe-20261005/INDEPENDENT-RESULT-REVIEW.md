# #1394 default / 256MiB SQLite pager 正常窗口合并事实复核

判定：**PASS，限定两组独立正常150/151窗口的完整输出、实际配置、计数、绑定、来源封条及清理事实**。未发现具体不匹配或阻断。256MiB候选在本次窗口中降低pager miss、避免观测到的事务中spill，完整回复和持久oracle与default相同，单次耗时减少约14.51%/14.13%，同时进程RSS高水位观测增加约302.94MiB。这些结果不能直接扩为稳定性能增益、生产结论或完整9011资格化。

本报告合并复核以下两目录：

- `.scratch/issue1394-sqlite-pager-default-window150-151-20261005/`
- `.scratch/issue1394-sqlite-pager-256m-window150-151-20261005/`

本次只读JSON、文件字节、SHA、stat、PID状态；没有SQLite-open任何数据库，没有启动服务、测试、编译或重跑窗口。两份root_verify.py均只阅读而未执行，因为它们会复制诊断日志并写ROOT-RESULT。仅写本报告；产品两文件补丁静态独评沿用 `INDEPENDENT-REVIEW.md`，没有扩成全仓审查。

## 输入与runner差异

两份实际runner差异与各自SCRIPT.diff逐字一致。default相对前轮正常窗口只更换具名域、socket、说明、frozen-service路径，新增私有cache环境记录/保存恢复，并在启动前清除该变量；256MiB相对default仅更换本次具名域、socket、说明，将 `S_NATIVE_SQLITE_CACHE_KIB` 设为规范值 `262144`。原封存DB访问、30秒截止、首次异常保留不重试、S7、完整exchange/receipt校验和真实Popen回收分支均保留。

EXPERIMENT-INPUT的SHA与ORCHESTRATOR绑定相符；其default ROOT-RESULT seal、两条耗时和pager读数与实物一致。262144KiB=268435456字节=256MiB，是连接会话内cache_size建议值。两组从同一CopyQualified149来源字节复制至各自新域，source before三件完整stat/SHA封条相同，未拼接旧窗口或接续original9011。EXPERIMENT/PREPARATION中的未运行状态作为执行前快照保留，未改写。

## 正常结果、完整对照与30秒门

两组RESULT均为COMPLETE，errors/cleanup_errors为空，接收序号严格为 `[150,151]`；每条exchange为Received且error=null。

| 请求 | default秒 | 256MiB秒 | 单次耗时减少 |
|---|---:|---:|---:|
| 150 | 20.694023 | 17.691335209 | 14.5099278% |
| 151 | 19.834563417 | 17.030979916 | 14.1348385% |

独立重算exchange原始纳秒与百分比，均匹配ROOT。每条完整request.wire、reply.wire、persistent.json逐字节对照：default与前轮native-scan基线相同，候选与default相同。request/reply实际SHA匹配RESULT记录；完整reply envelope等于exchange.response，payload等于received_window.reply；persistent证据中的完整oracle canonical SHA匹配RESULT及基线。没有只比较回复的几个字段。两组received_window整个对象也与各自基线相等。

Ready均为实际ready、initialization=null，Ready wire与START-RESULT完整回复及wire SHA匹配。Popen begin_ns至唯一成功Ready wire end_ns：default **25.529375917秒**、候选 **24.453002791秒**；启动与两条完整请求均在30秒内。228/210次启动连接探测各只有一次发送Ready请求，其余探测request_bytes=0，未重发150/151或重启服务。

两组终态严格相同：generation151、idle、Committed151、published151、clocks453、next_attempt_ordinal152。来源149的未接收状态、original105的DeliveryUnknown以及CopyQualified名分保留。

## 实际pager配置与持久性

| 项目 | default | 256MiB候选 |
|---|---:|---:|
| 启动时requested_cache_kib | null | 262144 |
| cache_size有效回读 | -2000 | -262144 |
| cache_spill有效回读 | 483 | 63429 |
| 最大采样cache_used近似字节 | 2116736 | 276057728 |
| 采样记录的进程maxrss字节 | 2270969856 | 2588622848 |

启动日志各有一条startup-before-first-transaction，配置回读均available；lifecycle环境分别为unset/`262144`。两组均为page_size4096、journal_mode=wal、synchronous=2、fullfsync=1、wal_autocheckpoint=1000、mmap_size=0，持久性配置未改变。

固定补丁SHA为 `5428e29b90f39f352fdab0aafc0fc2e7f0a360e70741eb4156f651c96f0824ab`；限定核对staged helper，唯一显式 `pragma_update` 为 `cache_size`，其余PRAGMA仅查询。cache_spill正值由483变为63429是有效阈值回读变化，**不等于关闭spill**，不能声称两组spill阈值相同。候选事务spill差值为0只是这次正常请求的观测。

cache_used是当前近似值，候选最大采样值约263.269MiB，并非256MiB硬峰值限额。SQLite状态highwater字段在这些读数中均为0且标明不支持峰值，不能把0当成无分配或峰值为零。

## 四项累计端点差值

逐项从原始handle-before-after日志重算after−before；三条handle分别为launcher-ready-1、message-150、message-151，business_result_ok=true、reset_flag=0、pager_peak_measurement=false。所有端点均available、rc=0、非负、无端点下降，四项原始delta与ROOT逐项相符。

| 请求/组 | hit | miss | write pages | transaction spill pages |
|---|---:|---:|---:|---:|
| 150 default | 13174110 | 5736413 | 31208 | 30756 |
| 150 256MiB | 18409594 | 500929 | 24307 | 0 |
| 151 default | 10891733 | 4917505 | 53462 | 53012 |
| 151 256MiB | 15309392 | 499846 | 35909 | 0 |

两组hit+miss总数对150均为18910523、对151均为15809238；候选hit ratio为97.3511%/96.8383%，default为69.6655%/68.8947%。Ready请求的四项delta及ratio也独立重算匹配ROOT。

这些是同连接i32累计计数的端点差值，不排除采样之间wrap/reset；日志保留该限定。WRITE是脏页写计数，SQLite IO/write错误后其语义可能未定义，不能仅凭db_status rc=0排除历史写错误。miss×4096只用于页大小换算，**不是SSD实读字节或物理I/O**；本报告未据此计算磁盘吞吐。

RSS原始字段在本macOS进程各采样均rc=0、raw_unit=bytes、bytes=raw_maxrss，采样序列非下降，ROOT取max正确。读数是kernel RUSAGE_SELF截至采样时的进程生命周期RSS高水位，不是请求独立峰值、Rust heap、SQLite pager严格峰值或退出后的最终独立测量。两组末次观测相差317652992字节=302.9375MiB；没有把该差值全归因于pager或新增全heap门。

## S7、来源封条与绑定

两组Controller均等于proposed，startup/response仍30000ms，S7仍 **536870912**。每代各一条prepare-issued和owner-dropped，两组对应代的预算及scope_*读数相同：

| 代 | allowance | old_pool | workspace_source_cost | source_sum |
|---|---:|---:|---:|---:|
| 150 | 154465630 | 382405282 | 42874531 | 425279813 |
| 151 | 154655198 | 382215714 | 43267617 | 425483331 |

legacy均为0，allowance+legacy+old_pool=536870912；workspace_source_cost≤allowance，source_sum未超总预算。两代scope_owner_drops均为1、reused_original_reads为1273104/1283045、unknown_write_invalidations均为0。内部页缓存实验没有扩大S7的来源字节额度；S7与进程RSS量纲不同。

两窗SERVICE-DIAGNOSTICS.log均与各自owned/controller-state/s.log字节哈希一致，匹配ROOT：default `1f8176aac2b4412d454d133e050d8a8776829397096329d4c4a2ecbc8aa2f39a`，候选 `105ac8dd2061063ea2dc52d04f9ef414d25d4c8eb523804bc9706c95ea513d45`。

各窗原件original_before=original_after；独立用二进制读/lstat/hash重核各组三原件及三owned文件，完整stat/SHA记录全部匹配，没有打开数据库连接。

两组共用实际非test服务SHA `0e9cef4460f284d8fa8a60fae155bef11843714b459c239a5c9aabed2ff07bdf`；源码聚合SHA `86d44f8c22423ea3e7276d6a706fd84762c179ee08188135b995e1f73abb1fe1`。643项当前/冻结源码、default49项及候选54项Python/材料、script/ORCHESTRATOR/PYTHON绑定均匹配。BUILD-service记录exit=0、build-finished.success=true；实际compiler artifact为s_structure_session bin、profile.test=false、features为default/s_capture_native_testonly/s_session，compiler executable哈希与frozen-service相同。feature-off检查exit=0、build-finished.success=true，native feature不在artifact features中。本补审未运行新测试或编译。

## 进程回收与边界

default唯一Popen PID71005、候选唯一Popen PID74662；运行argv与RUNNING-IDENTITY.command逐项相同、Ready control_instance_id对应，stop PID相同。两者exit_code=-15、reaped_by_same_Popen=true、controller_closed=true、cleanup_errors为空，cleanup分别0.08747462485916913/0.0789792500436306秒；补审时两个PID均不存在，socket均消失，清理socket的device/inode/uid匹配运行身份。

两份controller_stop均保留原始「服务完整参数与本次启动命令不符」观察警告；不将其删成无警告。回收判定依据真实同一Popen的退出及wait记录、实际运行命令、PID消失和socket身份清理。

两份窗口ROOT状态分别为PASS_NORMAL_SQLITE_PAGER_DEFAULT/PASS_NORMAL_SQLITE_PAGER_256M，与实物一致；full9011_complete、whole_resources_qualified、goal_complete均为false。探针目录ROOT与两个窗口ROOT分属不同汇总/运行对象，不用执行前或中间快照的candidate-not-run措辞替代候选首次实际结果。本报告将二组最终事实合并于此，不另写窗口尾部报告。

两组各执行一次、仅正常150/151、共享宿主顺序运行，未重复/随机化或测完整9011。这里支持「本次候选的miss、spill及elapsed观测改善、RSS观测增加」；不证明稳定因果性能增益、全部历史规模、非test scan scratch容量峰值、全资源资格化或生产默认采用。没有故障注入，也未恢复取消的birth-only/candidate/wire算法方案。

试验开关**默认未开启**；必须处于Native TestOnly模式并显式启用diagnostics，候选再显式设置私有cache变量才采用256MiB hint。本报告是Native TestOnly效应证据，**不是生产默认256MiB，也不是完整9011**。根任务登记的最终本地代码提交为 `ecd8371e8fe71f33d2af040d32c2aa3b1bacdfbe`；提交名分不改变两窗冻结源码/服务与default seal的本次核验结论。
