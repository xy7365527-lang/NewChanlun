## 代码审查报告

本报告绑定 #1394 私有 pager 探针，基线 HEAD `f2f2bef0803c9b80cee1fa405c5234ae3402f1b9`。范围仅为 base/staged 的 driver.rs 差异、新增 sqlite_pager_probe.rs、NOTE.md、SHA.json 与 pager-probe.patch。只做静态审阅与哈希/补丁重建核对，未运行 Cargo、测试、SQL、服务或故障注入。

### 概念层质询结果

通过。新增代码引用的是 SQLite pager 状态、建议缓存量和内核进程 RSS 统计，没有改动笔、线段、中枢、背驰等缠论判据。未发现需进入谱系比对的概念矛盾。

- 六项 db_status 读数与峰值的名分一致。CACHE_USED、STMT_USED 是当前近似内存量；HIT/MISS/WRITE/SPILL 是累计计数。helper:191-196 明写 high-water 不支持峰值，helper:229 设置 `pager_peak_measurement=false`。SQLite 对这些状态的语义见 [官方参数说明](https://www.sqlite.org/c3ref/c_dbstatus_options.html)。SPILL 的同款 highwater=0 按本次固定 bundled 源实现理解。
- helper:146-174 在 macOS 按 bytes、Linux 按 KiB 转 bytes；`RUSAGE_SELF`、`rc == 0` 后读初始化结果、负值检查和 checked 乘法正确。helper:199-203 将其明确限定为进程生命周期 RSS high-water，不推成 Rust heap 或请求独立峰值。单位依据为 [Apple XNU calcru](https://raw.githubusercontent.com/apple-oss-distributions/xnu/main/bsd/kern/kern_resource.c) 与 [Linux getrusage 手册](https://man7.org/linux/man-pages/man2/getrusage.2.html)。
- helper:215-220 对状态缺失、负计数及端点下降输出 null；非负单调时相减不会触发 i32 算术溢出，同时保留采样间 wrap/reset 无法排除的限定。该 delta 是受限的端点差值，不能解释为无条件精确计数。SQLite 的 i32 截断行为见 [官方 db_status 接口](https://www.sqlite.org/c3ref/db_status.html)。
- helper:228 与 NOTE 保留 CACHE_WRITE 在 SQLite IO/write 错误后的未定义语义；不能凭 rc=SQLITE_OK 或 delta 数字排除此前写错误。
- cache_size 是连接会话建议值，不能推出全部 heap/RSS 限额；S7=512 MiB 与 30 秒门不在补丁改动面内。负值按 KiB 的解释与 [官方 cache_size 文档](https://www.sqlite.org/pragma.html#pragma_cache_size) 一致。

边界分析仅为源码推导。规范值 1 与 262144 可通过；0、262145、前导零、空白、符号、非 ASCII 数字、非 Unicode 与解析溢出均被拒绝。状态失败、负计数、下降端点与 getrusage 失败均不会生成伪造的有效 delta/RSS 值。没有执行这些输入。

### 工程层审查

| 严重级别 | 数量 | 状态 |
|---------|------|------|
| CRITICAL | 0 | pass |
| HIGH | 0 | pass |
| MEDIUM | 0 | info |
| LOW | 0 | note |

结论：PASS，仅限固定哈希下的静态代码审阅。没有超过 80% 置信度的阻断问题。

已核证据：

- driver:301-307 在首次 Driver 事务前冻结 Native + diagnostics=1，并仅在该分支执行 configure_and_log。普通、Owned、未 opt-in 或 feature-off 无新增 helper SQL、FFI、getrusage 或日志调用。这里审的是补丁新增调用，不声称原有其他诊断开关也被冻结。
- driver:360-374 保存 before，调用原完整流程，采样 after，然后直接返回保存的 Result。抽出的 handle_with_request_audit 函数体与 base 原 handle 函数体逐字一致，预算入口提前 Err 同样回到外层；日志使用无返回值 helper，stderr 写错误被忽略，未新增诊断重试或覆盖 Committed 的错误传播路径。
- helper:50-62 唯一写 PRAGMA 是显式缓存实验的 cache_size。缺省没有写操作；无效值、设置/回读失败及不一致显式拒绝启动。helper:64-85 的其余 PRAGMA 全部只查询，未显式改变 WAL、FULL、fullfsync、autocheckpoint、cache_spill、mmap 参数。
- helper:124-135 的 sqlite3_db_status 同步使用当前借用连接的有效句柄及栈内 i32 指针，resetFlag=0，Snapshot 不保存引用或指针。getrusage 指针也仅在同步调用内使用。libc 依赖由 s_capture_native_testonly -> s_session 启用，没有增加依赖或后台线程。
- 缓存输入先转有界整数，PRAGMA 名称固定，没有输入拼接 SQL。日志只新增请求 message_id、状态和数值观测，不输出请求正文、库内容或环境原值；未见新增密钥、路径遍历或权限绕过路径。

### 交付绑定与限制

独立重算结果全部匹配 SHA.json：

| 对象 | SHA-256 |
|------|---------|
| base driver.rs | `997c53ceacc64436c5f64dbc782fa8d6f20862a0e26d7818750f2566b69894a9` |
| staged driver.rs | `ddb4ff2c4617471d74104bdd9363cf22156605f77abb3387899c749a5514413d` |
| staged sqlite_pager_probe.rs | `3c58ae756b23de9a203ab4f67263ad5b664001c0ffdedbc63b05832744105fa4` |
| pager-probe.patch | `5428e29b90f39f352fdab0aafc0fc2e7f0a360e70741eb4156f651c96f0824ab` |
| NOTE.md | `c2ce25eea88483c4779b16ef06ffceb0c4f5f656590d4c9adc0c49b9749d1fd5` |

按 patch 在内存中从 base 重建 driver 与 helper，均逐字匹配 staged。共享工作目录的 git apply --check 返回 1，原因是检查时实际目标已含补丁且 helper 已存在；不将该结果宣称为 apply-check PASS，也未回退或覆盖其他代理的文件。

本报告没有验证非 test Native 编译、feature-off 编译、正常 150/151 窗口输出或候选缓存值效果。这些验收由根执行。诊断本身会产生少量分配和同步 stderr 输出，读数用于同域观测，不保证无测量扰动。PASS 不证明完整审计、全部分配覆盖、请求独立 heap 峰值、512 MiB 全进程上限或 30 秒性能资格。
