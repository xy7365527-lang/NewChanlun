# #1394 SQLite pager 私有诊断 staged 补丁

本目录绑定 `f2f2bef0803c9b80cee1fa405c5234ae3402f1b9`。仅准备 staged 源码，真实源码未改。补丁为 `pager-probe.patch`，源文件与补丁 SHA-256 见 `SHA.json`。这是正常性能诊断的私有实验工具，不能证明完整审计、S7 所有分配覆盖或 30 秒资格成立。

## 接线与范围

`driver.rs` 以 `#[cfg(feature = "s_capture_native_testonly")] #[path = "sqlite_pager_probe.rs"]` 引入独立私有 helper。根执行源 manifest 必须同时纳入以下路径，并核对 `SHA.json`，漏 helper 不算同源运行。

- `rust/src/bin/s_session_v3/driver.rs`
- `rust/src/bin/s_session_v3/sqlite_pager_probe.rs`

只有 `CapturedNative` 且 `S_MANIFEST_WORKSPACE_DIAGNOSTICS=1` 在启动时生效。开关在 `open_db` 返回后、Driver 首次事务前冻结。非 Native、Owned、未 opt-in 或 feature-off 无额外诊断 SQL、FFI 或日志。`open_db` 原 WAL、FULL、macOS fullfsync ON 均保留。prepare_cached、原 SQL/F/业务验证、S7=536870912 和 30 秒公开资源字段均未修改。

`handle` 外层先保存六个整数读数与当前 message_id，然后执行原完整流程，返回前重新借连接采样。预算准备阶段的提前 Err 同样进入 after 采样。snapshot 不含连接引用或指针。日志输出错误被忽略，不改变 Result；COMMIT 后不会因诊断日志失败变成失败回复。诊断不重试业务。

## 私有缓存实验

首个 baseline 必须不设置 `S_NATIVE_SQLITE_CACHE_KIB`。缺省不写 cache_size，启动日志中的 requested_cache_kib 为 null。

根根据 default pager 实测结果冻结新具名实验域值后，才使用本变量。仅规范十进制正整数 `1..262144` KiB，拒绝空串、符号、空白、前导零、非 ASCII 数字、超界值与非 Unicode 输入。在同一 Native+diagnostics 分支、首次事务前转为负 `cache_size`，设置后回读必须相等。无效输入、设置失败或回读失败/不一致显式拒绝启动，绝不 fallback。连接退出后设置失效；这只是 SQLite 建议缓存量，不能约束全部 heap/RSS 峰值。未设置变量不改变默认值。

唯一写 PRAGMA 是这一显式 `cache_size` 实验入口。checkpoint、cache_spill、journal、sync、mmap 全部保持既有值，只查询。

## 诊断 JSONL schema revision 1

全部输出到 stderr，每行 diagnostic=`NativeTestOnlySqlitePager`。

启动行 stage=`startup-before-first-transaction`，包含 requested_cache_kib、cache_size_semantics、pragmas、snapshot。pragmas 逐项只读 cache_size、page_size、journal_mode、synchronous、fullfsync、wal_autocheckpoint、cache_spill、mmap_size；成功为 availability=`available` 与 value，失败为 availability=`unavailable` 与 rc。rc 是 rusqlite SqliteFailure 的 extended_code，其余错误为 null。纯观测失败不拒绝业务。

请求行 stage=`handle-before-after`，包含 message_id、business_result_ok、before、after、cumulative_delta、reset_flag=0、pager_peak_measurement=false。business_result_ok 仅表示原 Result 是 Ok，不另断言 committed。

每个 snapshot 含以下六项，每项都有 availability、rc、current_i32、highwater_i32、highwater_semantics。sqlite3_db_status 非 SQLITE_OK 时两个值为 null，并保留 rc。

| key | 含义 |
|---|---|
| cache_used_bytes_current_approximate | 连接 pager cache 当前近似字节 |
| cache_hit_cumulative_i32 | pager cache 累计命中 |
| cache_miss_cumulative_i32 | pager cache 累计 miss |
| cache_write_pages_cumulative_i32 | 写出脏页累计数，WAL 模式为写入 WAL 页；SQLite IO/write 错误后语义未定义 |
| cache_spill_pages_mid_transaction_cumulative_i32 | 页缓存溢出引起的事务中途脏页写出累计数 |
| stmt_used_bytes_current_approximate | 本连接 prepared statements 当前近似 heap/lookaside 字节 |

这些接口 highwater 均不提供峰值，成功时 SQLite 返回 0。保留原始值并用 highwater_semantics 明写 unsupported，不能把 0 报成峰值。四项累计计数仅在 before/after rc 都成功、两值非负且单调时计算 `after-before`。否则 delta.value=null，interpretation 为 unavailable 或 overflow_or_reset_uncertain。即使端点单调也明写不能排除两次采样间的 wrap/reset。当前字节量不作累计差值。

SQLite FFI 只有一个同步封装。Connection 借用期间句柄有效，输出指向栈内 i32，不保存 SQLite 指针，resetFlag 始终为 0，不复位共享计数。

每个 snapshot 还含 process_maxrss，字段为 availability、rc、raw_maxrss、raw_unit、bytes、semantics。macOS/Linux 在同一 opt-in 分支同步调用 getrusage(RUSAGE_SELF)。rc=0 才读取初始化的栈内 rusage；macOS 原值为 bytes，Linux 原值为 KiB，checked_mul(1024) 转为 bytes。负值、转换溢出或调用失败只记 unavailable，其余平台记 unsupported。它是内核报告的本进程截至采样时点的生命周期 RSS high-water，不是 Rust heap 或当前请求独立峰值。不新增依赖、线程或外部 ps。未 opt-in 不调用 getrusage。

单位依据：[Linux man-pages](https://www.man7.org/linux/man-pages/man2/getrusage.2.html) 明写 KiB；[Apple XNU kern_resource.c](https://github.com/apple-oss-distributions/xnu/blob/main/bsd/kern/kern_resource.c) 的 calcru 将 ru_maxrss 赋为 tinfo.resident_size_max。Apple 存档旧 getrusage 手册的 kilobytes 文案与现代实现不同，采用现代 Darwin bytes 口径。

## 已核依赖与验证边界

目标工作树 Cargo.lock 为 rusqlite 0.40.2、libsqlite3-sys 0.38.2；Cargo.toml 启用 bundled。本机该 libsqlite3-sys 的 sqlite3/sqlite3.c 常量为 SQLite 3.53.2。源码 25362 起将 SPILL/HIT/MISS/WRITE 放在同一分支并置 highwater=0，CACHE_USED 与 STMT_USED 也置 0。这里记录依赖源码版本，不声称已经执行运行时版本查询。

已执行 staged 两文件 rustfmt 2021 格式化与 --check，exit=0；git apply --check，exit=0；静态检查 patch 只含两个目标源码文件。没有运行 Cargo、单测、服务、SQL 或故障注入。非 test Native build、feature-off check 与真实正常窗口由根负责。

官方接口语义见 [SQLite db_status 参数](https://www.sqlite.org/c3ref/c_dbstatus_options.html)、[cache_size](https://www.sqlite.org/pragma.html#pragma_cache_size)、[sqlite3_db_status](https://www.sqlite.org/c3ref/db_status.html)。
